import assert from 'node:assert/strict'
import { parseProjectFiles } from '@trigramco/ontolang'
import { compileModel, executeStory, initializeWorld, inspectWorld } from '@trigramco/ontolang/runtime'

// This file runs unchanged from an installed package. Form money values are
// integer minor units; authored money literals are normalized by the parser.
const source = `project HeadlessTasks
actor Employee
  name: string
actor Clerk is an Employee
object Board
  name: string
  tasks: Task[]
  total: money = sum of Task.cost
object Task
  title: string
  board: Board
  cost: money @default(1.25)
  status: drafted | completed @final
story Tasks about Board
  Clerk creates Task for Board
    requires Task.title exists
    requires Task.cost is more than 0
    sets Task.status to "drafted"
  Clerk completes Task
    requires Task.status is "drafted"
    sets Task.status to "completed"
seed Clerk
  name: "Ada"
seed Board
  name: "Inbox"
seed Task
  title: "Seed task", board: "Inbox", cost: 2.50
`

const model = compileModel(parseProjectFiles('headless-tasks', { 'model.onto': source }))
const initial = initializeWorld(model, '2026-10-13T12:00:00Z')
assert.deepEqual(initial.standing, [])
assert.equal(inspectWorld(model, initial.snapshot).get('Board:Inbox').fields.total, 250)

const created = executeStory(model, initial.snapshot, {
  story: 'Clerk creates Task for Board', actor: 'Employee:Ada',
  participants: { Board: 'Board:Inbox' }, about: 'Board:Inbox',
  fields: { title: 'Prepare shipment', cost: 200 }, mint: 'Task:shipment',
})
assert.equal(created.committed, true, JSON.stringify(created.violations))
const completed = executeStory(model, created.snapshot, {
  story: 'Clerk completes Task', actor: 'Employee:Ada',
  object: created.created.id, about: 'Board:Inbox',
})
assert.equal(completed.committed, true, JSON.stringify(completed.violations))
const repeated = executeStory(model, completed.snapshot, {
  story: 'Clerk completes Task', actor: 'Employee:Ada',
  object: created.created.id, about: 'Board:Inbox',
})
assert.equal(repeated.committed, false)
assert.equal(repeated.snapshot, completed.snapshot)

const world = inspectWorld(model, completed.snapshot)
console.log(JSON.stringify({
  created: created.created,
  status: world.get(created.created.id).fields.status,
  boardTotalMinorUnits: world.get('Board:Inbox').fields.total,
  repeatedActionRefused: repeated.violations.map(violation => violation.kind),
}, null, 2))
