> Portable snapshot of maintained Onto material. [Package capabilities](../../../START_HERE.md) define the shipped boundary; dated decisions and host implementation notes are context. [Source manifest](../../../SOURCE_MANIFEST.json) records provenance. Links marked “Onto source” are optional host/background references.

> **Layer: AUTHORING-TIME** — the IDE surface where domain stories are written and classified into the model.

# Story authoring — backlog

The front-end is built (see [spec.md](spec.md): canvas input, classify-at-commit — 9 categories / 4 archetypes / locus / slots / residue, exogenous-input detection, story decomposition, the story tree). Only a thin remainder, neither blocking:

- Wire the optional downstream **LLM-judgment pass over classifier residue** (residue surfacing is complete; the judgment pass is deliberately unwired).
- **Folder description field** (follow-up to the folder sparkle, 2026-08-18): generation
  currently reads a folder's intent from its name + ancestor path alone. If that proves too
  thin a signal, add an optional description on the folder entity and feed it into
  `/api/folder-stories`' context.
- **Auto-promote emergent actors/objects** from decomposition (today they require manual confirm).
- Exogenous **locus arm** (deferred — no live corpus case needs it).
- **Role-noun attach at commit** (cross-feature): when a nominated actor resolves as a *role*
  (Employee → Person + role), the commit path surfaces an attach proposal instead of silently
  minting a new type. The hook lands in this feature's commit path; the design is owned by the
  [roles-permissions backlog](../roles-permissions/backlog.md).
- **Canvas accepts the `produces "value"` sentence suffix** (owner decision 2026-08-03 — this
  feature owns the story-sentence grammar): the authored fallback for a verb whose produced
  status is a different term of art (`Broker binds Policy produces "in-force"`). The ontolang
  loader and printer already speak it ([ontolang spec](../ontolang/spec.md)) — one grammar, two
  doors — so the canvas parser/classifier should accept the same phrase, keep it visible in the
  sentence (no pill), and pin the same `story/transition-to` edge; the named value must be a
  declared status of the primary object.
  **SUPERSEDED (walk ratified 2026-08-24): do not build.** The joins tier 2 walk
  ([walk map](../ontolang/full-decision-pass-2026-08-22.md)) retires the `produces` suffix:
  a status write is an explicit `sets Path to value` clause under the beat, and load-time
  verb→status derivation is dead (editor assist only).

## ▶ The parser consolidation — v1 SHIPPED 2026-09-02 (the canvas side)

The composer now parses through the one parser. **v1 is a thin composition, not the wrap** (the 2026-09-02 adversarial-review verdict): `ontolang/parse-fragment.ts` — `parseBeatFragment(text, {catalog})` — composes the loader's own pieces (lexical pre-checks, the beat-word checks, `parseDSL`, the extracted `resolveBeatNames` pass) over ONE sentence; the fused per-beat clause loops contribute nothing for a bare sentence, so the wrap (printed context + synthetic files + a `parseProjectFiles` mode flag) is deferred to the clause slice below. Same grammar, two feeders: file mode = errors, app mode = warnings + suggested fixes (the severity table is in [spec.md](spec.md); contract as built in the [ontolang spec](../ontolang/spec.md)). From the 2026-08-14 list, items 1, 2, and 4 shipped; item 5 is dropped:

- ✅ **Port the canvas onto the one parser (v1).** The fragment parse runs on the composer's idle pause (600ms) and once at confirm; diagnostics render as a non-blocking chip row (`FragmentDiagnostics`, styled after the prose chip) near the composer, in its own state — never `popoverPositions`, so warnings can never gate confirm. Errors (only `unreadable` / `first-person` / `#` / newline) gate Confirm AND Decompose, with the blocking message named in the tooltip; a `fix`-bearing diagnostic (the spaced-name CamelCase rewrite) gets a one-click apply that rewrites the composer. **Confirm consumes the fragment beat** — canvas-confirmed stories now persist the ordered participant pairs and subject/primary-object labels (additive `story/create`/`story/confirm` op args — [authoring-sync (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/authoring-sync/backlog.md)); pre-port stored stories still await the cleanup back-fill ([ontolang backlog](../ontolang/backlog.md)). NOT in v1: the coach act-rewording for data-operation sentences ("sets Task Priority" → suggest an act) — a property path in the object slot surfaces as the loader's own error, no rewording suggestion yet.
- ✅ **The confirm gate asks actor-or-object.** A new name from `FragmentResult.newEntities` gets an actor/object toggle on the needs-definition popover pane, defaulting to the parser's evidence kind; confirm splits the actor/object sets from the beat datoms + the overrides, and the popover-click kind derivation reads the fragment result/catalog (dst only as last-resort fallback where neither has an answer). KNOWN HOLE (recorded, not fixed): the pre-confirm define flow (`saveEntityDefinition` → defineEntity mint) can still mint dst's kind guess before confirm for canonical-grounded names — full fix rides the next slice. And an override flips only the actors/objects split — the persisted slots (recipient/pairs) keep the name where the loader would re-slot it once declared; feeder divergence recorded in the [ontolang backlog](../ontolang/backlog.md) (next-slice fix: re-run the fragment parse with the override injected into the catalog).
- ✅ **Demote the NLP typing helper.** `interpreter/dst-entity-parser.ts` no longer decides anything at confirm; it remains the live-typing span painter + ghost feeder (kept, not deleted).
- **DROPPED — wire suggested fixes to the rename machinery** (was item 5): no v1 diagnostic can produce an (oldName→newName) pair — every v1 check references sentence tokens, never near-miss catalog names. Revisit only when a diagnostic proposes a catalog-name correction. (Stale path fixed with the drop: `renameEntity` lives in `runtime/store.ts`, not `runtime/rename-entity.ts` — pair names and labels DO rewrite on entity rename since this slice, via the store's own rename loop.)
- **Smarter actor-wins** — the pure-recipient case: a person-noun that never acts in any beat stays an object (owner call 2026-08-13: a separate later pass, not part of the inference fix). Unchanged by the port.
- **Rebuild the eval fixtures** — 10 of 48 cases in `evals/canvas-cases.jsonl` still expect spaced names (5 investment-bank, 1 cinema, 4 jellyfin); the port has landed, so the rebuild is unblocked and the evals can measure the real grammar.

### The clause slice (deferred, one bundle)

What v1 deliberately left out, collected as the next slice's scope:

- **The wrap** — printed context + synthetic files + a `parseProjectFiles` mode flag, so the fragment path runs the per-beat clause loops (gates, `sets`, `finds`…) the thin composition skips. With it comes the composer's birth `sets` (the composer writes none in v1 — the feeder divergence in the [ontolang backlog](../ontolang/backlog.md)).
- **Clause assist for linked records** *(2026-08-19 design — rides joins tier 2, [note](../ontolang/joins-tier-2.md), not settled)*: every transition beat carries its `sets` clause, and a beat moving a record its sentence doesn't name (`Student attends Retreat` moving `RetreatBooking`) carries its link atoms written out. The studio makes that cheap: **propose** the clause text into the beat (origin ladder: proposed → confirmed — assist at typing, never derivation at load), and **annotate** clause-resolved records in the canvas/printer view (generated comments; hand-written comments stay inert). Modeling rules 21–22 ([modeling.md](../ontolang/modeling.md)) are the guidance to keep in step.
- **Enforcement upgrades** — CLOSED: objectless beats (2026-09-02, sweep case 10), the dangling trailing preposition (2026-09-04), the mid-sentence empty pair, the label law (one word of letters and digits), labeled grammar words judged on their head, value-marked undeclared names, and leading-`every` position (all 2026-09-05, the second sweep's batch) — loader errors + composer gating diagnostics throughout.
- ~~Diagnostic span anchoring + chip placement~~ — **shipped 2026-09-04 with the coalesce** ([spec.md](spec.md) rendering section): composer-mode diagnostics carry char spans into `sourceText`, and the active chip's word wears the arc + margin-note treatment. Still open from the original bullet: the idle parse runs on story load, so warnings can render for an already-confirmed story — non-blocking, but worth a quieting pass.
- **The define-flow mint hole** (the known hole under the confirm gate above).

### Studio parser extension and unification (ruled 2026-09-02/03 — the composer sweep's verdict; build on owner ask)

The sweep's through-line: the old NLP parser and the grammar disagree on the
same screen (a filler word strips a declared name's color; "I is ambiguous"
popover beside the first-person chip). Ruling: **one grammar, three
consumers** — strict (confirm + file door, shipped), **prefix-tolerant
per-keystroke** (this slice), and drafting assists (decompose — LLM/NLP may
draft freely; the parser judges the output; the ghost stays catalog
completion, ruled in item 7). Requirements, each ruled during the sweep:

1. **A prefix-tolerant entry point in ontolang** beside `parseBeatFragment`,
   same token rules: for an unfinished sentence it answers (a) which slot
   each token occupies, (b) what is still missing ("waiting for a verb" —
   retires the red unreadable chip on a paused prefix, kept as-is for now,
   sweep case 9), (c) the legal continuations at the cursor — catalog names,
   the 54-preposition closed class, `every`, known verbs. (c) was written
   as the autocomplete source; the ghost ruling in item 7 removed that
   consumer — see the open consequence there. Precedent: rule-dsl
   editor-support builds on the rule parser.
2. **Painting comes from the grammar + catalog, not the NLP.**
   Owner-flagged exhibit (2026-09-03, case-hunt row 5): type
   "Customer quickly moves Order" — the chip correctly blames "quickly"
   and names "moves" as the verb, while the painter's pills call
   "quickly" the ACTION and mark "moves" as an OBJECT needing
   definition. The painter's slot assignment must be the grammar's. The declared-
   catalog overlay in `renderEntitySpans` (landed with the sweep) is the
   downpayment; the prefix parse takes over slot painting. A declared name
   NEVER loses its paint to a neighboring errant word (ruled, case 4);
   unreadable text paints nothing falsely.
3. **Word-addressed diagnostics render anchored** (ruled, case 2): every
   flagged word gets a mark at the word; at most ONE renders its full
   popover/handwritten text (most severe, or nearest the caret); the rest
   show on hover/tap; same-word stacking is one anchor carrying lines. The
   chip row demotes to sentence-level diagnostics + overflow. Gating stays
   severity/`blocksConfirm`-based — never the popover count. The anchored
   pipeline is the existing annotations + handwritten-margin machinery; the
   measure pass must learn rects for non-entity words.
4. **One voice per word — the popover UI and define pane STAY**: what goes
   away is the old NLP parser writing its own duplicate opinions into them
   (the "I is ambiguous" text beside the grammar's first-person message).
   Same UI, fed by the grammar.
5. **`interpreter/dst-entity-parser.ts` deletes** once prefix painting
   lands — the ghost needs no replacement (item 7: it already completes
   from the catalog, not the NLP; only its accept-time instant coloring
   rewires to the grammar's paint state); with it go the `isActor` dst
   fallback and the define-flow mint hole (`saveEntityDefinition` minting
   dst's guess).
6. **Kind-flip re-slot** (v1 divergence): after an actor/object toggle,
   re-run the fragment parse with the override injected into the catalog so
   persisted slots match the loader's re-slot for the same sentence.
7. **Ruled 2026-09-03 (owner): the gray suggestion text keeps today's
   exact behavior.** It completes the word being typed against the
   declared-name catalog — capitalized prefix, two letters or more,
   shortest match wins, Tab accepts, Escape dismisses. No slot filter, no
   verb or preposition completion, no LLM, no whole-sentence drafts. The
   code already works this way (`useGhostAutocomplete` matches the store
   vocabulary; the NLP parser never fed the completion), so the NLP
   deletion leaves the ghost untouched — only its accept-time instant
   coloring moves to the grammar's paint state. Consequence, open: item
   1(c)'s legal-continuation answer loses its named consumer — whether
   the entry point still computes it is the owner's call.
   **Open question 2**: when several words each carry a problem, one word
   shows its full message beside it (the rest are marks + hover) — does
   that one message use the bordered box style ("I" IS AMBIGUOUS) or the
   red handwriting style (needs definition), or errors-box / warnings-hand?
8. **Every token kind gets a visual treatment** (owner, 2026-09-03): the
   painter today knows only actor/action/object words — once painting comes
   from the grammar's slot assignment, the trailing `@correction` mark (and
   any future mark) gets its own color instead of rendering as plain text.
9. **Parked, related**: multi-line canvas wrap past what fits (the 90-char
   cap landed; single-line assumption spans spans/ghost/measure).

## Open questions & deferred

- **Preposition-only names must classify as OBJECT — the recipient actor mint retires (decided, owner 2026-08-18).** Today a name whose only evidence is preposition-target position ("System saves Task **to TaskList**") registers as an actor — the source of 13 non-agent actors across 7 seeds (Kitchen, Board, TaskList, Cart, Cookie, the Hangman drawing…). Ruling: **subject position is the only agency evidence**; a name seen only after prepositions classifies as object. Applies to the whole-input evidence scan (parseDSL) and classify-at-commit alike; declared kinds still win. Coordinate with the toy-seed re-version (its own task): fix the seeds first or together — never flip the default alone, the seeds pin the old behavior in goldens. Decision record: [ontolang backlog](../ontolang/backlog.md), follow-on section; practice: [modeling.md](../ontolang/modeling.md) rule 2.

- **Actor/object NAME COLLISIONS (found 2026-08-11; root-caused
  2026-08-14; parked for later by team call).** Confirming a story whose
  classified slots put an EXISTING actor's name in the object position
  makes confirm-time registration (`registerStoryEntities` →
  `ensureObject`) mint a second catalog entity — actor Barista AND object
  Barista, doubled in every suggester/pane. Root cause, proven two ways:
  (1) deterministic unit repro — feed `acceptStory` slots with a known
  actor name under `objects` and the twin mints every time (registration
  trusts slots blindly); (2) the live trigger is LLM VARIANCE — the
  classification pass usually respects a known actor (hand-testing could
  not force the mint with any wording), but Coffee Order op #89
  ("Customer talks to Barista", typed story, LLM classify pass) carried
  `objects=["Barista"]` once and that was enough. Recommended fix
  regardless of policy: an actor-wins guard AT REGISTRATION (skip minting
  a kind-twin when the name exists in the catalog — the last gate must
  not trust a nondeterministic upstream), plus a one-time cleanup of
  existing twins (both logged ones and pre-sync local residue, so the
  cleanup wants to be a small in-app migration). Open policy question for
  the team: are same-name kind-twins ever DESIRABLE (if yes, every menu/
  badge/suggester must disambiguate kind instead)? Revisit after the
  sync merge.

- **Slot / multiplicity UI is unbuilt.** Still to design: how a slot label is
  shown, entered, and told apart from the object's type. **CORRECTED (owner ruling
  2026-08-24, the plurals decision):** there is no plural noun form and no `*`
  mark — plurality is the determiner word (`every`, reserved) in front of the
  always-singular noun; the multiplicity UI displays the determiner, never a
  marked noun. The old `*` display question is void.
- **Classifier multiplicity axis (open).** Infer the *unmarked* iteration case —
  "Picker pulls Item": one item, or each? — as a **select-one vs apply-each**
  dimension the classifier proposes and the coach confirms when genuinely
  ambiguous (ask once, cache forever). Distinct from the *marked* case: `every` is the
  only story-grammar determiner (`each`/`a`/`an`/`the`/`all` are non-words in beat
  sentences).
  **Language half ratified (owner, 2026-08-19):** the instance-source trichotomy —
  selected / resolved / enumerated ([binding backlog](../ontolang/binding-backlog.md)) —
  is this same axis; the classifier surface remains this item.

## Known, accepted (2026-08-01)

- **If the canvas ever grows real editor features** (rich text,
  multi-line, more history/selection machinery): stop extending the
  hand-built contentEditable and adopt an editor framework wholesale
  (Lexical or ProseMirror — undo, caret math, and span rendering all
  come with it). Rebuild-scale team decision; noted 2026-08-05 while
  hand-rolling Cmd+Z undo, which is ~50 lines against a framework's
  built-in.
- **Cold deep-link hydration race — RECURRING, now FIXED structurally
  (2026-08-05).** A direct story URL rendered an empty canvas if the
  router selected the beat before the local store restored. This bug has
  resurfaced 3+ times (realtime provider remount 2026-07-31; again
  2026-08-05 when an unrelated timing change in the hardening pass
  re-exposed it): it is TIMING-SENSITIVE, and "not reproducible" only
  ever meant the current build's timing happened to hide it. The
  punch-through (`pendingHydrationRef`, from old staging `9b9edab`) is
  now APPLIED at the story-load effect in
  `studio/app/[[...path]]/page.tsx`: the effect remembers a selected
  beat the store didn't have and re-fires once when it appears, keyed on
  story existence so it can never clobber a live edit. If a blank story
  on refresh EVER reappears, do not re-litigate: check the punch-through
  survived whatever refactor touched the load effect.
