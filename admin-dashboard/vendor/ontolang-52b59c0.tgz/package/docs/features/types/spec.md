> Portable snapshot of maintained Onto material. [Package capabilities](../../../START_HERE.md) define the shipped boundary; dated decisions and host implementation notes are context. [Source manifest](../../../SOURCE_MANIFEST.json) records provenance. Links marked “Onto source” are optional host/background references.

> **Layer: AUTHORING-TIME** — recognises object kinds & specialization during authoring. (The type taxonomy it produces is CROSS-CUTTING / part of the IR.)

# Types & kinds — spec (what's built)

**Status:** object specialization is fully built; the kind catalog is a built asap-slice with completion pending → [backlog.md](backlog.md).

## Built — object specialization (the type system)
- `schema/specialization.ts`: `conformsTo` (transitive, irreflexive), `composeFields` (own + inherited, nearest-wins), `deltaFields` (subtype adds), `concreteSubtypes` (polymorphic resolution; abstract excluded).
- File loading and complete-model compilation reject incompatible inherited field redeclarations before composing their effective catalogs. The [Ontolang semantic contract](../ontolang/spec.md#complete-model-semantic-validation--2026-10-10) defines the permitted refinements; the low-level composition helper still operates on draft definitions.
- Ontolang parents are concrete independently of Stories; the [standalone-model contract](../ontolang/spec.md#standalone-models-and-workflow-readiness--2026-10-10) owns this rule and the native-export boundary for legacy explicit abstract flags.
- **Wired into runtime** (`runtime/store.ts`) and **polymorphic on the instance side** (`instance-store.query("Product")` spans `Product`, `Drink` and `Pastry`).
- **Exercised on real seed data** (Coffee single-parent subtypes; legacy Investment Bank multi-parent interfaces).

## Built — kind catalog (asap slice)
- `kind-catalog/`: 6 baseline kinds (Person · Organization · Transaction · Agreement · Document · Product) + 5 archetypes (Customer · Employee · Vendor · Invoice · Booking) + `canonicalLookup` (false-friend-aware: client/ticket/master/token… → null).
- Load-bearing integration: gates the NEEDS-DEFINITION pill in the studio; consumed by `CoachingSidebar`. **12 tests.**

## Built — catalog rail rendering
- A type does not need records to appear in the catalog rail. Coffee's concrete
  `Product` parent appears alongside `Drink` and `Pastry`, even with no direct
  Product records. Legacy explicitly abstract contracts remain excluded by the
  catalog resolver; having no records does not make a type abstract.

## Not built (→ backlog.md)
Full ~12-kind closed set (Task · Event · Collection · Place · Area · System + Bare-Object), the Place/Area/`within` render surface, and the publish/versioning step.

## Superseded
The Tier-1 ~200-entity gist vocabulary (an earlier, never-built approach) was **replaced** by this narrower closed kind catalog.
