# Ontolang

`@trigramco/ontolang` owns the language model, Story/Rule/Formula parsing,
canonical printing, semantic validation, immutable vocabulary imports and bounded
RDF/SHACL export, reusable templates, portable walkthroughs and the current
TypeScript execution engine. This private
workspace package prepares later repository extraction. Its language and execution APIs build
and run independently of Onto; production dependencies are `@noble/hashes` and `zod`.

```ts
import { parseProjectFiles, printProject } from '@trigramco/ontolang'

const model = parseProjectFiles('inventory', {
  'model.onto': 'project Inventory\nobject Item\n  name: string\n',
})
const files = printProject(model)
```

| Entry point | Public contract |
| --- | --- |
| Root | Browser-safe project parsing/printing, diagnostics, vocabulary and Story sentence parsing |
| `/node` | Directory loading and reusable source/vocabulary file readers |
| `/rdf` | Deterministic RDF/RDFS and SHACL export with per-construct coverage |
| `/editor` | Story fragments, Rule/Formula highlighting and suggestions |
| `/rules` | Rule/Formula parsing, validation, binding and lifecycle analysis |
| `/model` | Language model, field and AST types, vocabulary snapshots and qualified names |
| `/semantics` | Shared values, actor policies, numeric checks, date arithmetic and status helpers |
| `/classification` | Deterministic action and actor classification used by language admission |
| `/catalog` | Shared grounding vocabulary used by classification |
| `/templates` | Definitions, module dependencies, composition, provenance, source loading and portable identities |
| `/walkthroughs` | Walkthrough schemas, types and bounded configuration validation |
| `/runtime` | Headless TypeScript Story, Rule and Formula execution |
| `/runtime/adapters` | Shared adapter contracts and execution helpers; no concrete database adapters |

The root, RDF and editor entries are browser-safe. Filesystem imports live in
`/node`; consumers can import only declared entries. The tarball includes built
JavaScript, TypeScript declarations and the classification dictionary.

For an application with `domain/` beside `app/`, call
`parseProject('./domain')` from `/node`, or pass relative keys such as
`customers/entities.onto` to `parseProjectFiles`. Recursive `.onto` files form one
domain; folder names add no namespaces. Root files and direct `stories/*.onto`
keep their existing order, followed by other nested sources sorted by path.
The selected root bounds discovery. See the
[source-loading contract](docs/features/ontolang/spec.md#recursive-domain-source-loading--2026-11-01)
for path validation, exclusions, symlinks, companions and explicit imports.

`ProjectModel` preserves the domain JSON/datom shape and optional portable
companions. Root parsing/printing and `/node` loading validate and round-trip
`templates.json` and `walkthroughs.json`, including template ownership, Story
identities, folders, empty companion lists and opaque host metadata.

`/templates` applies ordinary model modules, resolves dependencies and explicit
bindings, tracks provenance, and supports conservative detach/removal. It accepts
caller-provided definitions; Onto's Warehouse/Accounting library and template
picker remain in Onto. `/walkthroughs` validates portable navigation data;
publication's model/command reference checks and navigation execution stay with
the host. The existing companion formats and validation messages are retained.

Unknown template fields travel as bounded inert JSON in `templateExtensions`.
These cannot override the companion's structural fields. Onto additionally
interprets and validates its AI proposals; an independent consumer can preserve
those fields without importing AI detection or UI code. Onto extends the model
as `ProjectSeed` with proposal types and example seed versions.

The optional `onAssembled` hook runs after companions and before model-wide
validation. It may update companions, opaque host metadata and Story identities,
folders and ordering. Companion structure is checked again after the hook.
Language source, vocabulary contracts and revision pins remain immutable; change
declarations, Rules, Formulas and initial records through their `.onto` source.

The same package supplies headless execution through `/runtime`, including
`compileModel`, `initializeWorld`, `executeStory`, `inspectWorld`, `tick` and
System helpers. See [the runtime guide](RUNTIME.md) and [runnable example](examples/headless.mjs).
Parser-only imports do not load the engine. `/runtime` and `/runtime/adapters`
are browser/Worker-compatible and do not load Node or Studio dependencies.
The `/rules` single-record `evaluate` API is advisory; `/runtime` supplies complete
cross-record execution. RDF export reports bounded coverage and does not execute models.

## Internal organization

Source has no `src/` wrapper. Public imports use the entries above, not implementation paths.

```text
packages/ontolang/
  language/                    Parsing, printing, validation and model definitions
  runtimes/
    typescript/
      engine/                  Story, Rule and Formula execution
      adapters/                Shared adapter contracts and helpers
        node-sqlite/           Concrete adapter
        cloudflare/            Concrete adapter
  sdks/                        Future consumer-facing libraries (not created)
    typescript/                Future SDK (not created)
    python/                    Possible future SDK (not created)
  examples/                    Models, execution logs and headless example
  test/                        Language and execution API tests
  package.json
```

Node SQLite and Cloudflare are adapters for the same TypeScript runtime. Concrete
adapters expose explicit package entries; platform dependencies must
remain outside language and pure execution imports. SDKs will support publishing
projects, invoking project APIs and subscribing to updates. An SDK language does
not imply a runtime implementation. Future runtimes can reuse behavioral fixtures;
there is no discovery, plugin registry, runtime selection or universal execution interface.

Concrete adapter entries and the bundled deployment host provide SQLite
persistence, publication and scheduling. Studio remains a separate authoring app.
The package is independent of Clerk and the authoring database. Deployment account
settings, bindings, domains and secrets belong to the deploying application.

## Install one tarball

```sh
pnpm --dir packages/ontolang pack --pack-destination ../../out/ontolang
# In a consumer outside the repository:
npm install /path/to/trigramco-ontolang-0.1.0.tgz
node node_modules/@trigramco/ontolang/examples/headless.mjs
```

No second Ontolang package or dependency override is needed. Registry publication
remains release work.

```ts
import { applyTemplate, type TemplateDefinition } from '@trigramco/ontolang/templates'
import { parseWalkthroughs } from '@trigramco/ontolang/walkthroughs'

const definition: TemplateDefinition = {
  id: 'notes', version: 1, name: 'Notes',
  modules: [{ id: 'records', name: 'Records', dependsOn: [], content: {
    objects: [{ 'object/name': 'Note' }],
    fields: { Note: [{ name: 'text', type: 'string' }] },
  } }],
}
const result = applyTemplate(model, definition, { moduleIds: ['records'] })
if (result.ok) {
  result.seed.walkthroughs = parseWalkthroughs([])
  const portableFiles = printProject({ ...result.seed, id: result.seed.id ?? 'inventory' })
}
```

From the workspace root:

```sh
pnpm build:ontolang
pnpm watch:ontolang # alongside pnpm dev when editing language or execution source
pnpm test:ontolang
pnpm test
```

Package tests use built public exports. Distribution checks install a tarball in
an isolated consumer, exercise Node exports, compile declarations, check private
paths and bundle browser entries. Onto retains portable-file, seed, publication
and reference/SQLite conformance tests against package-backed facades. Install,
development, tests and production builds prepare the package before consumers run.

The package includes a self-contained collaborator kit: [START_HERE.md](START_HERE.md)
introduces the capabilities and setup, with local grammar/specification docs,
an authoring skill, the editor extension source and complete example projects.
[SOURCE_MANIFEST.json](SOURCE_MANIFEST.json) records their maintained sources and
snapshot hashes. These assets work when copied or installed outside Onto.

During this first package phase, edit the authoritative sources in Onto and then
regenerate the snapshot from the workspace root:

```sh
pnpm sync:ontolang-capabilities
pnpm check:ontolang-capabilities
```

The drift check also runs in `pnpm test:ontolang`. Repository separation and
publication are later work.

## Standalone deployment

The tarball also ships concrete Node SQLite/Cloudflare adapters and a deployable
Worker, participant assets and local runner. See [deployment](DEPLOYMENT.md) for
the versioned release, interchangeable targets and standalone participant codes.
Actual hosted acceptance remains pending credentials.
