> Portable snapshot of maintained Onto material. [Package capabilities](../../../START_HERE.md) define the shipped boundary; dated decisions and host implementation notes are context. [Source manifest](../../../SOURCE_MANIFEST.json) records provenance. Links marked “Onto source” are optional host/background references.

> **Layer: CROSS-CUTTING** taxonomy (roles / phases / interfaces are part of the model/IR) + **RUNTIME** surfaces (permission matrix, view-as-role, read-permission). Type-level built; instance layer deferred.

# Roles & permissions — spec (what's built)

## Explicit runtime enrollment — 2026-10-10

Role eligibility is no longer inferred from absent seeds or grants, and actions do
not confer roles. Affiliation, access and enrollment are distinct declarations.
The [runtime spec](../rule-runtime/spec.md#actor-entry-and-enrollment) owns standard
trusted enrollment, owner authority, live subset checks and suspension. Existing
assigned-role administration and authored grants/revocations remain the domain
mutation path; derived subsets are never assigned.

**Status:** 🟡 type-level built + the instance layer's **first runtime slice** (the assignment slice, 2026-08-04) + **role fields on the edge** (2026-08-30). Built: the role/phase catalog, the `conformsTo` interface graph, phase partitions + ranks, the read-permission engine (`mayRead`, `seniority >= N`) wired to the live PermissionMatrix + "view as role" toggle — and, at the instance level, **assignment edges written and read** with the role's **capability fields carried per holding** (below). The rest of the instance layer (transitions, bearer-fact eligibility enforcement, grant/revoke surfaces) → [backlog.md](backlog.md). Design detail below.

---

## The assignment slice — the instance layer's first runtime cut (built 2026-08-04)

A role instance IS a base-kind instance plus an **assignment edge** — the §4 reification, running. The instance store (`runtime/instance-store.ts`) resolves role-typed create/query against the role catalog living in the same conn:

- **Minting.** `create('AccountExecutive', project, {name})` mints an **Employee** instance (the rigid base) — or reuses the same-named one — and opens an `assignment/*` edge (`actor` = the instance's eid, `role` = the catalog entry's eid, `from` = now, `to` open). Same name ⇒ same person: a second role lands as a second edge on the ONE base instance; re-asserting a held role is a no-op. Phases (`role/kind 'phase'`) never redirect — attribute-style, as designed (§3.1).
- **Resolution.** `query('AccountExecutive', project)` resolves through OPEN edges to the base instances holding the role — a closed `to` stops resolving (revocation closes, never retracts), and re-granting opens a fresh edge beside the closed one. Plain types and the base type itself resolve as before. The runtime's pick-only ref pickers feed from `query`, so `Territory.owner: AccountExecutive` lists the holders — the lead-intake exit.
- **Seeding.** A `seed AccountExecutive` block with `name: "Jordan Alvarez"` rows in a corpus ([ontolang](../ontolang/spec.md)) lands in the seed's `instances` keyed by the ROLE (field checks resolve through the `is a` chain — the base Employee declares `name`); `seedProject` writes the role catalog first, then routes every row through the role-aware create — base + edge, never a mono-typed role instance. The append-only log records both facts (`instantiate` Employee, `associate` role).
- **Cleanup.** `deleteProject` retracts `role/*` and `assignment/*` datoms with the project, so delete-and-replace re-seeds never orphan edges.

- **Role fields on the edge (2026-08-30).** The role's declared **capability fields are facts about the holding** (decision 1, 2026-07-23: an `approvalLimit` belongs to the employment, not the person): the ontolang loader emits a role block's non-mirror, non-computed fields into the catalog entry (`roles: {Name: {kind, base, fields}}` → `role/fields`), and the store treats that list as the **edge's schema**. A role-typed create **splits** its payload — capability fields land in `assignment/fields` (one JSON blob per edge, the `inst/fields` convention), the rest on the base instance — and the associate log entry records the capability facts with the grant. `transition` **routes** a patch the same way (a capability key of a held role writes that edge; the base blob never absorbs edge facts), so runtime forms and the records admin edit them with no surface changes. Re-asserting a held role stays a whole no-op; revocation (closing `to`) removes the facts from the read view with the holding.
- **Role fields are readable (2026-08-18 decision, built with the edge fields).** An instance's **read view** = its own fields + every open holding's edge facts, and it carries `holdings` (the open role names): `query`/`get`/`all`/`factLookup` all serve the merged view, and the fact snapshot (`runtime/fire.ts`, the ClockBar's tick) carries `holdings` through. The rule-runtime resolves role-typed reads **through the holding**: `instancesOf(role)` scans to holders, `resolveRef` follows a role-typed ref to a holder (create-time ref validation included), and a Formula aggregation over a role type collects the holders — all fail-closed for non-holders as before. Overlay is edge order; a like-named capability collision across two held roles is last-wins (degenerate under the modeling lint — capability fields are role-specific; the base/role like-name convention stays the open question in §11).

Pinned in `runtime/instance-store.test.ts` (mint = base + open edge · role query via edges with plain/base queries unchanged · two roles = ONE person, two edges · idempotence · closed-edge exclusion + re-grant · phase no-redirect · project-scoped catalog · the capability split/route/merge describe) and, corpus exits, `examples/lead-intake-routing.test.ts` (the owner picker's exact option derivation lists the three seeded AccountExecutives) + `examples/sangha-role-fields.test.ts` (ServiceTeamMember's `skills`/`availability` round-trip seed text → role catalog → edge → role-scoped, base-scoped, and fact-lookup reads).

**Not in this browser-store slice** (→ [backlog.md](backlog.md)): permissions evaluation over holdings, the phase-transition machine, `assignment/context`, grant/revoke surfaces, nomination UI, and bearer-fact **eligibility enforcement** (the read side is built above; "only an actor bearing R may fire a beat realizing R" and `mayRead` keyed off holdings are not).

**Persistent `/run` host — built 2026-09-23:** current applications store one base
actor with role holdings and holding-owned capability values, enforce effective
membership for human/agent bindings, and execute Story grants/revokes. The owner
actor profile editor also exposes explicit Assign/Remove controls for routine
administration, with prerequisites, receipts and activity. These controls change
domain holdings only; signup, affiliation and application-access policy remain
unimplemented. See the owning [runtime spec](../rule-runtime/spec.md#lead-intake-and-persistent-domain-roles--2026-09-23)
for built scope and limits. This does not change the older browser-store slice's
remaining work above.

Declared enum values are also enforced on held-role capability edits and grants
by the shared reference/SQLite write path; see the owning
[runtime value contract](../rule-runtime/spec.md#reference-identity-and-role-enum-values--2026-10-10).
Capability uniqueness now follows effective holders, and enum writes normalize
unambiguous casing to the declared string; see the
[constraint follow-up](../rule-runtime/spec.md#inherited-uniqueness-and-canonical-enum-values--2026-10-11).

---

## Roles, phases & interfaces — design detail

> **Dated:** 2026-05-26. **Status:** proposed.
> The ontology's *specialization* layer: how a base type acquires sub-kinds
> (roles, phases) and how types share shape (interfaces). Grounded in UFO
> (Guizzardi) and the Agent Role Ontology Design Pattern. Companion to the
> ontology/rules decision log.

---

## 1. The problem

A base type — `Employee`, `Order` — needs sub-kinds that (a) are substitutable for
the base, (b) carry their own fields, (c) can be gained and lost by an individual.
Naive subtyping fails (c): a thing cannot change its subtype. The research resolves
this into **three distinct mechanisms** — roles, phases, interfaces — that were being
conflated.

---

## 2. Rigidity — the organizing principle (from UFO)

A type is **rigid** if its instances must be instances of it for as long as they
exist — `Employee`, `Person`, `Order`. A rigid type provides **identity**.

A type is **anti-rigid** if instances hold it *contingently* — they can stop being it
without ceasing to exist. Promotion, status change, role assignment are all
anti-rigid transitions.

**Hard rule (UFO anti-pattern):** an anti-rigid type may never be the supertype of a
rigid type. Every role and phase points back to **exactly one rigid base type** (its
"kind"). The IB-seed error — five seniority "Actor types" with no rigid `Employee`
beneath them — is this rule violated. A role/phase never floats free of its kind.

---

## 3. Three mechanisms

### 3.1 Phase — an intrinsic, exclusive sub-kind

A **phase** is an anti-rigid sub-kind that applies in virtue of **intrinsic**
properties, and phases of a base type form a **partition** — an instance is in
**exactly one** at a time.

- Examples: bank **seniority** (Analyst → Associate → VP → Director → MD); customer
  **tier** (Bronze/Silver/Gold); `Person` life-stage (Minor/Adult).
- Ordered or unordered, but always **mutually exclusive** — you are one.
- Promotion = moving through the partition. A `transition` on the base type.
- Resolves the earlier "ordering" question: an **ordered, exclusive** sub-kind set
  (seniority) is a **phase**, not a role.

### 3.2 Role — an extrinsic, relational, multi-hold sub-kind

A **role** is an anti-rigid sub-kind that applies in virtue of **extrinsic,
relational** properties — the instance has the role *because of a relationship* to
something else.

- Examples: `Reviewer` (of a PullRequest), `Approver` (of a Claim), `FireWarden`
  (of a Building), `Member` (of an Organization).
- **Relationally dependent** — a role exists only via a relationship to a context
  entity. No relationship, no role.
- **Non-exclusive** — an individual holds **many roles at once** (RBAC-style).
- Gained/lost freely; not a partition.

### 3.3 Interface — a shared shape across unrelated types

An **interface** is a **named shape multiple base types declare conformance to**, so
rules and views can target the shape, not the type. Horizontal (across unrelated
types), where roles/phases are vertical (specializing one type).

- Onto already has interfaces: **the Coad archetypes** (moment-interval,
  party-place-thing, description). The work is to make the archetype layer
  **executable** — let a rule say `for every moment-interval, …` and a view render
  once per archetype.
- Not user-facing. The user tags/confirms an Object's archetype; the consequence is
  that archetype-level rules and views apply. Invisible plumbing; visible payoff
  (DRY rules, polymorphic views, the render layer).

| | Phase | Role | Interface |
|---|---|---|---|
| Axis | vertical (one type) | vertical (one type) | horizontal (many types) |
| Basis | intrinsic | extrinsic / relational | shared shape |
| Exclusive? | yes — a partition | no — multi-hold | n/a |
| Anti-rigid? | yes | yes | n/a (a contract) |
| User-facing? | yes (lightly) | yes (lightly) | no (system plumbing) |

---

## 4. How a role is represented — reified, edge-held, time-indexed

From the Agent Role ODP and the Time-indexed Value pattern:

- A **role is a reified entity** — it has identity and **its own fields**
  (`Approver` may carry `approval_limit`). Not an enum value, not a bare attribute.
- An **Actor (or Object) holds a role via an edge** — a relationship triple. Both
  ends are entities, so "holds" is necessarily an edge.
- The holding edge **carries a validity interval** — `from`, optional `to` — using
  the `duration` / `now` primitives. The system can answer "who was the Approver on
  March 3rd". Time-bounding is **built in**, not optional.
- The edge also carries the **context entity** — the role is relational, so the edge
  records *what* the role is held in relation to (`Reviewer` *of which* PR).

Substitutability: the base entity (`Employee`) is untouched and still fully an
`Employee` everywhere. The role hangs off it via the edge. Promotion-type changes
never destroy the base entity.

A **phase** is lighter: a phase is an attribute-style state on the base type (the
partition value), changed by a `transition`. It carries its own fields when needed,
but being exclusive it does not require the multi-edge structure a role does.

---

## 5. Bearing vs. realization — classification vs. permission

Two distinct uses of a role, kept distinct (CCO pattern; Foundry concurs):

- **Bearing** — an Actor *bears* a role: a standing fact ("this Employee bears the
  Approver role"). This is **classification**.
- **Realization** — an *act* (a story beat) *realizes* a role: the role is what makes
  the act legitimate ("this approval beat realizes the Approver role"). This is
  **permission / eligibility**.

Eligibility rules key off realization: "only an Actor bearing role R may perform a
beat that realizes R." Slot-eligibility (from the rule DSL) is exactly this — a rule
that the slot's occupant must bear the required role.

---

## 6. Story-roles vs. domain-roles — keep separate

- **Domain-role** (this spec) — real, configured in the ontology, reified,
  edge-held, has rules. `Approver`, `MD`-phase.
- **Story-role** — the `:` disambiguation label (`Employee:Sender`). Story-local,
  evaporates, not an ontology entity, no rules. Pure disambiguation.

The discriminator: a name is a **domain-role** iff it is **configured in the
ontology**. An unconfigured `:` label is a story-role. The ontology is the registry
of what is real. The system never promotes an unconfigured label to a domain-role on
its own (configure, don't derive).

---

## 7. Objects too

Roles, phases, and interfaces apply to **Objects**, not only Actors:

- Object **phase** — an `Order`'s lifecycle status (Draft/Submitted/Fulfilled) is a
  phase partition. (This is also what the `transition` action category moves.)
- Object **role** — `Account:Source` in a *configured* sense (a reified role with
  context), distinct from the story-local `:` label.
- Object **interface** — the archetype an Object conforms to.

One mechanism set, both sides of the Actor/Object divide.

---

## 8. Configuration, not derivation

Roles, phases, and interface-conformance are **configured in the ontology** — a
deliberate authoring act — **not derived from stories**. Stories *reference* them;
the ontology *defines* them. An unconfigured name stays story-local. The system may
*propose* (nominate) a role/phase from story patterns, but promotion to the ontology
is an explicit, confirmed act.

---

## 9. Formal lineage

This spec is a restriction/adoption of established work — named so it is not
reinvented and does not silently drift:

- **Rigidity, phase, role, mixin** — UFO (Guizzardi); the role/phase distinction and
  the anti-rigid-supertype rule are UFO results.
- **Reified, edge-held, time-indexed roles** — the Agent Role ODP and the
  Time-indexed Value in Context pattern (MODL / SPAR / PRO).
- **Bearing vs. realization** — the CCO Agent-Role structural pattern.
- Onto adopts the *distinctions* and the *reification structure*; it does **not**
  adopt OWL/description-logic tooling (consistent with the standing decision to take
  ontology methodology, not the OWL formalism).

---

## 10. Read-permission — the built engine (the read counterpart of act-eligibility)

Read-permission (who may *see* a field or object) is **rule-shaped**, and the engine
is **built** (`schema/permission.ts`, wired to the runtime output renderer and the
PermissionMatrix lens). Two rule forms:

- `expose <scope> to <audience> [when <condition>]` — grant a read.
- `withhold <scope> from <audience>` — deny a read.

**Audiences** are the read counterpart of roles: a specific **role** name; the two
boundary groups **`inside`** (every internal/staff role) and **`outside`** (known
external counterparties); **`anyone`** (truly public — anonymous, link-only); and
**`self`** (the bearer of the record).

**Audience ordering** is by **power, not alphabet**: audiences run inside → outside →
then ranks ascending, and are **banded by boundary** (internal group, external group,
public). The matrix and any audience list read in this power order so the most-trusted
audiences sit together and rank progressions read naturally.

**Safety floor — no derived read ever reaches the public.** A derived read-arm never
emits `anyone`; an anonymous viewer matches **only** `anyone`. So a story can hand a
document to a Buyer (a real audience), but derivation can never publish it to the open
internet — reaching `anyone` is always a deliberate authored act.

**`mayRead(viewer, scope)`** resolves a viewer against the rules by precedence: a
matching **withhold** wins (deny) → else a matching **expose** grants → else the
**default**. The default is **private-unless-exposed** on the boundary: internal
roles read everything until a rule narrows it; an external/public audience reads
nothing unless explicitly exposed. Rank-gated reads (`seniority >= N`) compare the
viewer's phase rank.

Qualified scopes use the declared type catalog: a rule on `Warehouse.Product`
covers `Warehouse.Product.SKU`, while `Warehouse` does not grant access to every
type in that namespace. Publication and renderer field checks supply this catalog
or the known owning type. Policies on imported types belong to the host's access
configuration, not the pinned vocabulary contract. Local additions/removals and
backfill preserve their origin and condition through
[dedicated authoring operations (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/authoring-sync/spec.md#read-policy-preservation-2026-10-10).

**Surfaces.** The runtime renderer renders **as a viewer** — fields/columns the
viewer may not read are excluded (`deriveBeatDocs` + the "view as role" toggle). The
**PermissionMatrix** (a runtime lens — see [scenarios (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/scenarios/)) shows the
whole roles × objects grid and lets a configurer author expose/withhold rules by
cell; it is a lens over the rules, never the enforcement mechanism. Read rules are
evaluated at **projection** time — they never enter the firing engine's fire-and-derive loop.

**How read rules originate.** Beyond hand-authored expose/withhold, two arms are
**derived** deterministically from the stories (`deriveReadRules`): **touch→read** —
the subject role of any beat naming object O may read O (you can't act on what you
can't see); **conveyance→read** — the recipient of a send / distribute / issue /
present / walk-through beat may read O (the outward mirror of the handover; it
depends on the ordered subject/recipient binding). Derived rules regenerate from the
model whenever it changes; an authored override wins over a derived rule.

**What a read-permission rule *is*.** Each rule carries four parts:

- a **mode** — `act` or `read` (this feature owns the `read` mode; act-eligibility is
  its counterpart);
- a **scope** — a whole `object` or a single `object.field`;
- an **audience** — who the rule is about (a role, `inside`/`outside`, `self`, `anyone`);
- an **origin** on a ladder — `derived` → `proposed` → `confirmed` → `authored`.

The origin ladder governs re-derivation: a **derived** rule regenerates freely each time
the model changes, but a **confirmed** or **authored** rule is a settled human decision
and is **never clobbered** by re-derivation. `proposed` sits between — a suggestion
awaiting a person's yes.

**PermissionMatrix — cell + click encoding (built).** Each cell is a **binary
labelled mark** — a green check (may read) or a red cross (may not) — where **colour
carries the answer** and the glyph never carries meaning alone (aria-labelled text
equivalents; no partial-fill "Harvey ball," since access is not a quantity). Origin
is a **secondary** cue shown in words at the point of inquiry: a boxed mark = a
person authored or confirmed it, a bare mark = it was derived. **Clicking flips** the
cell (check→block, cross→grant; click your own decision again to undo). Editing is
**override-only** — only deviations from the derived baseline are stored, and a click
that could not change the outcome is **refused** rather than writing a dead rule.

**Matrix affordances (built).** Object columns **expand to their fields**, so a read can
be granted or denied at whole-object or single-field grain. **Clicking a cell writes
through to the rule store** — it adds or removes a read rule directly. The grid itself
**stores nothing**: it is a live view of the rules, so every visible mark traces back to
a rule and there is no shadow state to fall out of sync.

Built today at the **type level**; the *instance* layer's assignment slice now
exists (a concrete actor holding a role — see the built section above), but
`mayRead` does not yet key off holdings for `self`/role audiences — that wiring
stays in [backlog.md](backlog.md).

---

## 11. Open / deferred

- Exact field-level interaction when a role and its base type have like-named
  fields — convention needed (qualified reference, base wins, or disallow). Minor.
- Whether phases need their own fields often enough to warrant reification, or stay
  attribute-style. Lean: attribute-style until a real case forces otherwise.
- Interface mechanics — can an interface declare *rules* (not just shape) that all
  conformers inherit? Likely yes (that is the payoff), but confirm against the
  rule-scope model when the rule DSL spec is finalized.
