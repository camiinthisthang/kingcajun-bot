> Portable snapshot of maintained Onto material. [Package capabilities](../../../START_HERE.md) define the shipped boundary; dated decisions and host implementation notes are context. [Source manifest](../../../SOURCE_MANIFEST.json) records provenance. Links marked “Onto source” are optional host/background references.

> **Layer: RUNTIME** — the firing engine that evaluates the authored model (fire-and-derive loop, intents, recompute).

# Rule runtime — spec (what's built)

## Host read and notification cost — 2026-11-02

The #302 fix and scaling follow-up build on staging `7c33b760`, which includes
merged #220, its post-merge fixes and #300. Subscription tickets, connections, notifications and presentation
authorization no longer construct discarded snapshots or query result pages.
They resolve current identity, role/binding, expiry and query-entry permission;
actual reads still enforce row/field policy and Story guards. Socket failures are
isolated so a disconnected peer cannot turn an already persisted save into a 500.
Successful mutations invalidate synchronously in host order. Receipt replays and
refusals do not advance the host sequence unless committed view state changed.
Ordinary reads no longer schedule one-second alarms; ticket/socket expiry retains
an explicit wake deadline, and writes still reserve a recovery wake.
Bearer expiry is rechecked after waiting for the project queue. Pings authorize
only their sending socket; a clock-derived change still broadcasts to all peers.
Clock refreshes during cursor authorization now advance the host sequence and
reject stale pagination. Presentation, ticket, receipt and connection paths also
announce read-triggered changes rather than losing their invalidation. Request
finalizers also announce clock refreshes committed before a later failure, while
preserving the original HTTP error. Alarm finalizers announce earlier successful
cranks if a later crank fails; recovery and retries remain intact. Delivery
finalizers likewise announce a clock refresh committed by a claim before its
provider fails. The durable
epoch advances before notification, so notification errors cannot replace a
committed response. An already announced change is not announced again by its
finalizer.
View continuity includes the committed model/day stamp as well as business
revision. Clock-only subset membership, read rules and Story guards therefore
invalidate cursors and all subscribers on the next authorized refresh. Even
clock-independent current models advance this metadata once per day, without
rederiving facts or changing business revision; repeated same-day reads do not
invalidate again. This conservative daily invalidation avoids missing temporal
view dependencies that are absent from Formula and subset projection analysis.

Catalog discovery skips roles that cannot have authority and filters candidate
IDs in SQLite using the existing scope, deny, delegation and resource predicates.
It stops at the first available target, retaining individual discovery as the
final check. An actor with no accessible targets no longer triggers one discovery
per stored record. Collection reads count authorized rows in SQLite
and fetch only the requested page. Snapshot eligibility performs at most sixteen
candidate previews per Story; an incomplete search reports `unknown`, preserving
point discovery and execution for an eligible record beyond that budget.

Ordinary Story queries resolve entry authority before selecting records, filter candidate IDs using
the existing SQL policy, and evaluate the shared Story interpreter in batches of
up to 400 records. Facts are shared only inside one read-only batch; no identity
or fact cache survives into another request or write. Only the requested page is
hydrated for display. Search retains JavaScript case matching over masked fields.
Batch evaluation is rollback-only, and batches that exceed the shared read budget
split until they fit; a single candidate retains its original evaluator and
per-candidate budget. The complete optimized query also has a shared ceiling of
250,000 semantic work units, 30,000 world SQL reads and 50,000 hydrated records,
including failed split attempts. Exhaustion refuses the whole answer with HTTP
422 `read-limit`, without partial counts or committed candidate writes.
Cloudflare keyed reads and page hydration respect its 100-parameter limit.
Cost-bearing, approval, explicitly ID-masked reads and other unsupported command shapes retain the original
per-record path. Exact counts and searches still require examining candidates;
this removes repeated SQL calls, not all record-dependent work.

Read-only query evaluation reuses cardinality results whose numeric bounds and
where operands depend only on literals, the fixed clock or the counted member.
The shared interpreter still evaluates binding-dependent operands for each
candidate. This memo belongs to one query transaction, including its batches;
mutable command worlds and later queries never share it. Projection similarly
batches known record reads and shares immutable reads/constant predicates within
one pass. Simple 4,000-item and 5,000-total-record imports now publish and query
successfully. Models with more expensive derivations can still hit their existing
complete-read limits. A local aggregate probe improved from approximately
16/81/289 ms at 100/500/1,000 items to 11/13/16 ms; 4,000 items completed in 49 ms.
These are synthetic measurements, not universal latency bounds.

Effect and invitation delivery use a short serialized claim, provider I/O outside
the project queue, and a short serialized completion. Completion opens the current
runtime and checks both project generation and durable attempt lease. Replaced
leases and removed/cancelled intents cannot be acknowledged by an older attempt.
Invitation leases survive host restarts; retries recheck revocation/acceptance/
expiry. Provider idempotency keys remain stable. Operator alerts also run outside
the queue. Live authorization linearizes at claim; a revocation after sending
starts cannot recall the external request. Tests hold successful/failing providers
and alerts open while unrelated reads/writes complete, and cover duplicate claims,
late acknowledgements, republication, revocation and durable lease recovery.

A `snapshot` request with a bounded `page` selector returns metadata/counts without
broad entity rows or per-Story candidate previews, together with the selected
entity/query page, authorized labels for its referenced IDs, and action discovery
for only its displayed IDs. Every fetch
rechecks current identity, row/field policy and Story guards; there is no shared
actor-result or authority cache. The QA browsing surface uses this combined read
(up to 200 rows); opening a form retains the full snapshot for reference choices.
The existing full snapshot API and standard participant form flow remain available.
Catalog and presentation metadata reload when their model/generation/release or
identity changes. Invalidation bursts coalesce for 50 ms, with one active refresh
and at most one pending refresh. Host sequence participates in view identity even
when business revision is unchanged. A changed actor/view discards late results; an in-flight response cannot restore
a snapshot after socket revocation.
Transient read transport/5xx failures retry at most twice; authorization, query
refusals and commands do not use that retry path.

`hosting/scripts/verify-read-cost.ts`, included in the host test command, uses
real local Workerd HTTP, WebSockets and alarms with 0/25/100/405 Coffee orders and
0/1/3 subscribers, alternating actors. `ONTO_READ_COST_STRESS=1` additionally
covers 10/100 subscribers; `ONTO_READ_COST_SHARED_ACTOR=1` uses one actor for
comparison. Passive counters assert no view materialization during tickets,
saves or idle notifications, bounded notification SQL calls, and no read-triggered
alarm acceleration. Connection and ping counters cover the WebSocket path too;
a queued credential-expiry test proves an expired mutation leaves configuration
unchanged. It checks changed/unchanged saves, invalidations and refreshed
data, immutable retries and stale-revision refusals. Every subscriber refetches
concurrently after invalidation. Request-local counters record each refresh and
the aggregate SQL work, plus queue/execution time and client-visible completion.
A held-queue test overlaps three requests to verify counter isolation; the old
shared counter object could itself crash concurrent requests. Node regressions compare the
catalog with exhaustive discovery, page counts/visibility, late eligible records,
and fresh agent expiry/revocation/binding checks. Further tests cover 1,000-record
query/catalog growth, failing Story guards after the first 400 candidates, search,
scoped delegation, batch rollback, adaptive read budgets and host parameter limits.
The hosted suite also checks 200-row pages and records first-use QA identity setup
separately from steady read costs. Nested Workerd transaction tests
also preserve 403/404 errors and roll back writes.
An independent per-record query oracle checks 1,944 combinations of input validity,
scope, nested references, aggregates, policy, search and pagination. Explicitly
masked IDs retain their original target-binding semantics. Real Project-method
tests cover committed changes followed by query/ticket/connection errors,
rollback-only failures, partial alarm commits, provider retries and notification exceptions.

In the synthetic 100-order fixture, snapshot SQL calls fell from 11,873 to 1,218;
an unchanged save with three subscribers fell from 35,604 to 178 calls, with no
subscriber snapshots. The follow-up reduces the Node 100-order one-row query from
3,026 to 34 prepared SQL calls and the no-access catalog snapshot from 1,460 to
360. With the host wrapper and cursor checks, local Workerd one-row queries use
108/112/117/135 SQL calls at 0/25/100/405 records; no-access snapshots stay at 416.
The earlier full-snapshot path used 1,374 SQL calls per subscriber at 405 records.
The combined 100-order page uses 365 calls per successful refresh. A 100-subscriber
same-actor burst completed without retries at 36,500 calls and approximately 3.1 s,
versus the earlier full-snapshot probe's 121,800 calls and 6–6.5 s. A repeated
100-subscriber burst encountered local Workerd transport failures; 25 bounded
read retries recovered all responses in approximately 3.3 s. Successful-response
SQL counters do not include unmeasurable failed transport attempts. This is a
recovery check, not clean 100-subscriber capacity acceptance.
These count calls, not billed rows, and are local evidence, not hosted latency or
quota acceptance. Budget enforcement, maintenance costs and the deployment-source
gap remain in the [backlog](backlog.md#runtime-cost-and-error-boundary-review--2026-11-02).
Regression coverage includes application/runtime, host boundary/authorization,
shared package and installed-package tests, participant lifecycle tests, standalone
deployment checks, real local Workerd lifecycle/cost suites, typechecks and the
production Worker dry-run build. Aggregate checks cover equivalence, clock/binding
variation, complete counts, budget refusal, cache lifetime and projection rollback;
client checks cover burst coalescing, sequence changes, late actor responses,
metadata reuse and bounded transient-read recovery.
Host CI installs `hosting/` with `--ignore-workspace`: it has its own lockfile
outside the root workspace. Without that flag pnpm silently reinstalls the root
packages, leaving the host dependencies absent on a fresh runner. Maintained
runtime docs also regenerate the package capability snapshot before its checks.

## Local publication host — 2026-10-10

`hosting/` runs the current application service in one SQLite Durable Object per
application, behind a Worker gateway. The shared SQL transaction adapter retains
Node behavior and uses Durable Object transaction callbacks for nested candidate
rollback. Schema-version-2 scalar semantics remain in TypeScript. Publication,
queries, commands, enrollment, invitations, owner/agent authority, System alarms
and an outbox Queue execute in local workerd.

An opt-in Studio bridge signs short-lived project/environment credentials after
Clerk verification. The existing Run view publishes to that host when configured.
Its Publication panel manages participant entry, invitations, automatic effects,
external-delivery pause/resume and failed deliveries. Workers Static Assets now
serves the independent `published-app/` client; `/apps/<id>` supplies public
or signed-in entry, enrollment and generated command/query controls. External
accounts enter under the model's policies, independently of Studio organization
membership. The saved project owner remains the management authority. Opening
entry requires complete actor policies.
The panel refreshes on the host change sequence, including configuration changes
from another owner tab that leave the business revision unchanged. Older status
responses cannot overwrite a newer refresh. A confirmed invitation send releases
its operation key before status refresh, so another deliberate send creates a new
invitation; an uncertain send retries the original operation and expiry.

Studio migration `0026` gives each saved project a permanent UUID. Publication is
scoped to that UUID and verified tenant; renaming preserves the runtime address.
The verified creator owns publication. HTTP, WebSocket and Queue traffic route
directly to the project DO using its environment and runtime ID. Legacy
name-derived runtime IDs stay accessible but are not automatically merged.
The authoring registry owns UUID creation and migration; the runtime consumes
the signed identity without querying Studio's database. The independent browser
uses project-local SQLite sessions and calls the Cloudflare API directly. The
[auth spec (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/auth/spec.md#published-application-identity--2026-10-10) owns the
one-use account handoff; [rendering (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/rendering/spec.md#published-participant-interface--2026-10-10)
owns the extracted interface. Presentation-plan publication is built below;
hosted MCP parity and remote rollout remain in the [architecture work order](backlog.md#published-application-architecture--decision-2026-10-23).
Studio's GET receipt bridge forwards the operation, original generation and
delegation to that host; query-string identity claims are not forwarded.
Recreating a deleted project uses its new creator under the
[registry identity rules (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/authoring-sync/spec.md#publication-identity--2026-10-10);
the previous creator cannot publish the new project's runtime.

Writes require the current generation; business commands also carry the model
hash and immutable operation input. The host reserves the operation and its exact
input before execution. Ordinary business writes and their result envelope commit
atomically; batches keep independent member commits. A restart between members or
before the final envelope write resolves their saved progress without rerunning
members or caching a stale-revision refusal. A reservation with no saved outcome
remains pending. Durable result envelopes preserve accepted and refused outcomes
and identify the recorded operation in command responses.
Throttling, authentication failures and other errors before receipt lookup leave
the original submission unresolved; HTTP status alone never releases its key.
Studio's owner client also retains the original revision for immutable command
retries after a response is lost and state is refreshed. Run allocates a fresh
operation only after a matching recorded refusal; batch continuations use the
current revision because they are separate dispatches of the saved run.
Batch receipt lookup and original-command replay read current durable member
progress or the terminal shared receipt, including after resume and restart,
without dispatching more work. Incomplete batch lookups return counts and remain
visibly incomplete. The original command input and conflict checks stay fixed.
Receipt lookup rechecks current authority and reports an
indeterminate outcome when an old generation has no retained receipt. Participant
drafts and exact pending submissions survive browser reload for up to seven days,
scoped by account, project and role. Retrying retains the original key and fences.
Explicitly starting enrollment again creates a new operation, even with the same
name and role; uncertain enrollment retries keep the original operation.
Account changes and access revocation clear the departing account's drafts.

Signed view cursors bind generation, model, audience, selector and change sequence.
Stale pagination restarts from the first page. Short-lived, one-use WebSocket
tickets bind an allowed browser origin; sockets carry invalidations, never rows.
Reads and invalidations recheck current permissions. Role revocation closes the
socket and clears visible data.
Late ticket responses and socket events from a replaced view or connection are
ignored, so they cannot invalidate the current view or erase its drafts.
An abandoned query response cannot reset a newer search or page; only the active
query can restart pagination after a stale cursor.
Unverifiable cursors after signing-key rotation, mismatched view cursors and
missing page cursors also produce a view reset. Subscriptions can reconnect with
a reset after a cursor's signing key is retired. Cursors prove continuity only;
current view authorization remains required before issuing or consuming a ticket.

The delivery adapter posts signed, timestamped JSON to an operator-configured
webhook with a stable idempotency key. Redirects are refused; failed deliveries
retry and eventually enter a visible dead-letter queue. Optional signed alert
webhooks report exhausted deliveries. Provider keys bind environment, project
and local delivery identity. Equal operation IDs in distinct project databases
therefore remain separate at a shared recipient; retries retain the same key.
The webhook body's key matches its Idempotency-Key header. Email invitations resolve an existing
verified Clerk account before queuing a targeted link through the same provider
contract. New accounts must sign up and verify first. Revocation accepts the ID
returned by either the emailed or manual invitation API; queued delivery checks
that revocation before contacting a recipient. Owners can pause all
external deliveries, including invitations, independently of participant entry
and automatic Story selection. Republication atomically removes enabled effects
whose Stories no longer exist. New or reintroduced Stories require explicit
selection. Entry/pause changes also prune legacy obsolete selections; explicitly
selecting an unpublished effect is refused. The pause persists across restarts; alarms retain
pending work and Queue consumers check the pause before delivery. Business
commands and System Stories continue. Explicit local simulation records only
project/delivery IDs in the console and marks deliveries complete without a real
recipient; it creates no R2 copies or real emails.

**V1 scope decision — 2026-10-11:** platform-native SQLite DO recovery history is
the backup baseline. There is no application backup schedule, R2 snapshot bucket,
export/import job, recovery registry or user-facing restore operation. Removed
operations and configuration fields are rejected by the strict API. Native PITR
is not invoked or locally verified by this host; a supported operator recovery
procedure and product restore are deferred to the
[runtime backlog](backlog.md#recovery-and-sensitive-data-review--2026-10-11).

The emulator verifier covers all 16 canonical projects, Hotel/Coffee workflows,
authorization, concurrent retries, immutable receipts, UID rename, stale cursors,
socket revocation, signed local webhook delivery and actual alarms/Queues. It
checks delivery pause/resume and persistence across process restarts, including
pending invitations/effects, effect removal during publication, batch progress and
completion after resume/restart, direct project routing and rejection of deferred
backup/restore requests. These use disposable local state and local recipients.
Fault-injection tests also stop batch dispatch between members and before receipt
storage, reopen SQLite, and verify recovery without duplicate writes. Client tests
exercise enrollment restart, delayed subscription/query responses, and owner
retry behavior after lost responses or recorded refusals. A client-to-host test
reopens SQLite after a committed response is lost and verifies one business write.
Isolated Postgres route tests cover creator authority through deletion,
recreation and rename. Local workerd sends matching operation IDs from two
projects to one deduplicating recipient and verifies both effects and invitations.
Publication-control tests cover repeat invitation sends, failed status refreshes,
lost responses, and overlapping status reads. Local workerd verifies that
configuration changes invalidate the owner view and advance its host sequence
without changing business revision.
It also checks pagination and socket recovery after cursor-key retirement,
including refusal when the caller lacks the requested actor role.

The standalone [Coffee fixture](#hosted-coffee-acceptance--2026-10-25) is deployed
and verified on Cloudflare; the reference Studio/staging deployment remains
separate. CI, operator commands, a staging provisioner and an isolated staging
fixture drill are built. The latter two print a plan by
default; remote execution needs credentials and operator configuration. Real
platform eviction, quotas, latency and provider reconciliation still need staging
acceptance. Setup and exact limits live in [hosting/README.md (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/hosting/README.md).
## Independent execution package — 2026-10-13

The shared Story, Rule and Formula engine is exposed by
[`@trigramco/ontolang/runtime`](../../../RUNTIME.md), an entry
in the single Ontolang package. The [owning package layout](../ontolang/spec.md#single-package-organization--2026-10-25)
separates the language, TypeScript engine and shared adapter helpers. It builds
JavaScript/declarations independently of Studio. `compileModel`,
`executeStory`, `tick`, System execution and log replay retain their existing
semantics. `initializeWorld(model, now)` combines seed absorption with initial
Formula derivation and standing issues; `inspectWorld` provides model-aware reads.
The shipped headless example runs with plain Node and no server or credentials.

The independent creation tests exposed a missing birth-value step in Story
preparation. Newborn guard reads now receive declared defaults after supplied
form values, sentence reference fills and written `sets`. Snapshot and SQLite
execution share the same helper used by committed creates: absent/cleared
inputs fill, explicit zero/false values win, money stays in minor units and
timestamp `now` uses the supplied clock. Derived guards see those values;
refused previews leave no facts or Formula metadata. Application tests cover
discoverability, execution, command retries and restart with these defaults.

The public `/runtime/adapters` entry supplies the trusted preparation, query, Formula and
guard/apply/check contracts, not concrete database implementations. Existing root imports are compatibility facades;
the Node/SQLite application continues to use indexed reads, incremental
derivation and atomic writes through the same packaged implementation. The
birth-default guard correction
advances the host interpreter stamp to `semantics:4`, so a persisted System
schedule rechecks newly enabled Stories without a model edit. Completed command
receipts and System completion keys remain stable.

Hosts own verified identity, enrollment, storage/transactions, receipts,
completion keys, clocks, scheduling and delivery. They persist matching model
source/revisions and facts, then recompile on restart. The package's snapshot
API accepts trusted caller inputs; person-triggered Stories require eligible
actor records, with anonymous execution limited to explicitly public actors and
Stories whose bindings need no actor record. System Stories have their own path. `every`
returns partial member results and its resulting snapshot must be retained even
when a later member is refused. Initial/ticked standing issues remain distinct
from command refusals.

The runtime entries load no Node, SQLite, DataScript or Studio dependencies.
The single tarball is checked in an isolated plain-Node consumer, including public
declarations, private exports, browser/Worker bundling and the existing behavioral
execution logs. PR #220 integrates #240 with concrete Node SQLite/Cloudflare adapters, headless
publication and optional presentation artifacts. This consolidation does not deploy that host. Registry/repository
ownership and operational acceptance remain in the [backlog](backlog.md#package-release-and-host-integration).

The [MCP interface (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/mcp/spec.md) exposes the existing application operations
through the same authorization checks. Caller-scoped receipt inspection returns
commit status/revision without saved input or record details. Runtime hosting is
unchanged; adding MCP does not deploy Cloudflare infrastructure.

### Extraction regression review — 2026-10-13

Owner and actor creates also accept omitted fields with declared defaults,
including `@required` defaults. Truly required fields still block submission;
explicit zero/false values win, and updates do not refill defaults. Preview and
discovery leave facts, Formula dependencies, projection state and receipts
unchanged when a candidate is refused.

Published command inputs preserve record selectors when a captured field has
the same name. For example, a `Board` participant remains `Board`, while the
captured `Item.Board` field uses that qualified input name. The same rule covers
`target` and `about`; only colliding fields are qualified. Each compiled command's
`CommandInfo.fieldInputs` maps canonical domain field names to public inputs.
Execution, schemas and Studio prefill use that mapping; aliased schema fields
carry `x-onto-field-name` alongside their original type/reference metadata.
Actor profile editing still exposes canonical field names. Absent inputs named
`constructor`, `toString` or `valueOf` never become inherited prototype values
through these mappings; declared defaults still apply.
The headless `ExecutionInput.fields` API continues to accept canonical names.

Host `currentCompilerVersion` advances from `1` to `2`. Same-source republication
rebuilds older saved command schemas with default exemptions and capture mappings,
preserving stored facts and completed receipts. This is separate from language
publication version `5` and interpreter stamp `semantics:4`; the interpreter
stamp refreshes runtime state automatically, while command schemas require
republication.

Legacy schemas without `fieldInputs` distinguish captures from selectors through
their saved parameter identities and exclude computed fields. This preserves
ordinary older commands; a field lost to a name collision in an older schema
still requires republication to obtain a distinct public input.

Native seed absorption fills missing or cleared reciprocal scalar references
and rejects contradictory nonempty one-to-one claims. Compiled seed rows remain
unchanged. Existing stored facts and explicit imported snapshots are not repaired
by republication; inconsistent saved links still require an explicit relink.

Primary, participant, context and pre-solved bindings that name the same exact
Story token must agree on one record. Conflicts return `invalid-binding` before
writes instead of silently replacing a selection. Distinct labelled tokens keep
their separate identities. An exact participant token already supplies the
`about` context, so published forms request that record once; an exact `every`
token supplies context per member without an extra selector. Independent or
labelled contexts still require their own binding.

For a partially successful headless `every`, the returned snapshot and `derived`
facts both describe the latest committed member even if a later member refuses.
The host retains its existing durable member results and resumable plan contract.
Focused package, SQLite, publication, actor-profile, Studio prefill and restart
regressions cover these corrections; they do not establish hosted deployment or
complete owner acceptance.

## Local corpus, enrollment and scheduling — 2026-10-10

The runtime build incorporates the durable Investment Bank implementation from
PR #210. PR #240 integrates that execution behavior with Ontolang semantic
validation and RDF tooling in the [single package](../ontolang/spec.md#single-package-organization--2026-10-25).
Language tooling and runtime execution retain separate public entry points.

All **16 registered projects now have canonical Ontolang**. Their 32 canonical and
registered source versions are audited independently. Six complete execution logs
run through the application service, including System actions and ticks. Ten more
committed `workflow.json` fixtures cover successful writes, refusal cases, each
acting person's/organization's browse work, receipt replay and reopening SQLite
after every step. These are specific tested workflows, not a claim that every
possible Story/input combination or external integration is accepted. The
[generated matrix (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/reports/runtime-corpus-sweep/matrix.md) records the
remaining synthetic-probe gaps separately.

### Actor entry and enrollment

`@affiliation`, `@access` and `@signup` are parsed, printed, validated and preserved
through authoring, import/export, copying and op replay. Studio actor panes expose
shared Select controls. Incomplete legacy declarations remain editable and may be
published for **private owner QA**, with explicit notices. Participant entry
requires complete applicable declarations; there is no name-based policy default.
Affiliation does not authenticate or grant authority. `@boundary external` remains
the separate legacy system-execution ownership flag.

The reference no longer infers open roles or grants roles on first action. Human
Stories need an eligible actor; only an explicitly public role may leave its actor
unbound, and any clause that consumes that actor still fails closed. The host adds
trusted enrollment operations and `/api/runtime/entry`:

- Authenticated entry uses verified user/organization identity and a server-owned
  person mapping; callers cannot choose another person's record.
- `self` permits joining, `invite` requires a targeted, expiring invitation, and
  `none` requires owner provisioning or a domain grant. Owner-only invitations are
  hashed, revocable and single-use. No email is sent by these local adapters.
- A narrower assigned role reuses its base record and enforces protected base
  prerequisites. Independent bare roles currently retain separate domain records
  linked to the same verified account; this does **not** implement a universal
  Person substrate or add a Person declaration to models.
- Derived subsets are never enrolled/granted directly. Participant binding checks
  live eligibility on each use. Owner suspension blocks entry and enrollment;
  domain-role removal and account suspension remain separate operations.
- The original `/api/runtime` is private owner/agent QA. Public entry requires an
  explicitly public actor. Organization/service representation has no ordinary
  person signup. Owner identity at publication is the initial administration
  authority; affiliation and actor names never grant it.

Reference choices combine the model's selection policy with explicit read denials
for both the caller and any delegating actor. Discovery hides denied IDs, and
submitting one refuses the command without consuming its operation ID. This check
also applies to existing saved command schemas without republication. Selected
participant roles cannot borrow read access from another live or previously held
role; tests cover assigned-role revocation and clock-derived expiry after restart.
Read denials retain their principal/action/resource scope, including wildcards;
a denial for an unrelated principal, action or record does not block selection.

Optional reference inputs accept `null`, as advertised by the command schema;
selection checks apply only when an identifier is supplied. Current-language
execution treats `null` as omitted input, not as a request to clear a saved field.
Required references still refuse `null`, and supplied identifiers must remain
available under the same selection and read-denial checks.

Coffee has self-enrolling Customer and invitation-only Barista. Collecting and
browsing orders pin the Customer; both roles browse Drink and Pastry. Its old log
now explicitly refuses a Barista acting as Customer without enrollment. The
application suite verifies the allowed enrollment path, invitations, suspension,
private reads, lifecycle gates and receipts. Sangha has explicit policies while
**preserving** attendance-derived NewStudent/OldStudent and
AssistantTeacher-is-a-Teacher. Its participant tests verify Student enrollment,
derived entry, protected teacher prerequisites and stale role revocation.

### System execution and effects

`ApplicationService.runSystem` uses shared candidate/deadline semantics, indexed
SQLite facts and the ordinary authority/receipt/candidate path. It selects one
reference crank before writing, commits a bounded crank atomically, and saves
completion keys and refusals. A separate Node worker (`pnpm runtime:scheduler`,
started by `pnpm dev`) wakes without a browser. `--once` performs one bounded visit;
`ONTO_RUNTIME_DIR` selects its storage. The worker loads Studio's environment like
the web server; relative storage paths resolve under `studio/`. It visits each project for at most eight
cranks; the normal limit is 200 candidate combinations per crank, configurable up
to 1,000 by trusted code. Exceeding a budget rolls back that crank.

Wake state survives restarts and considers model changes, fact revisions and UTC
day/deadline changes. Conditional Formulas now receive the clock in both the
reference and SQLite interpreters. A day change performs a bounded Formula rebuild
before read projections and candidate evaluation. Invariants that lapse with time
remain standing issues; time is not rejected as a business write.

The scheduler never adopts external systems, and non-extinguishing Stories remain
visible diagnostics and are excluded from automation. Automatic **system `every`**
is explicitly unsupported; person-triggered durable `every` is built. Successful
system completion is keyed by Story/action semantics and bound records. A new
recurring occurrence of the same effect needs an occurrence model; resetting a
record is not a new effect identity. Trusted `ONTO_SYSTEM_EFFECTS` configuration
(JSON Story-name array) enables queuing named effect Stories; unset handlers stay
open. This commits an outbox intent, not a remote delivery.
The worker records the enabled effect configuration with its wake state. Changing
that configuration wakes it immediately on restart, even if the model, facts and
clock have not otherwise changed. Duplicate names and ordering do not change the
configuration. Existing databases gain this state without resetting records or
completion receipts. Trusted hosts using `systemDue` pass the same `effects`
configuration they pass to `runSystem`; omitting it retains the clock/model check.

Log Stories and other supported System effect Stories also queue an outbox intent.
Effect candidates pass the same Story gates and `where` clauses as writing
candidates in both schedulers. A blocked effect acquires no completion key and
can run after its conditions become true; successful effects retain exactly-once
completion across restart. Reference and persisted scheduler regressions cover
both gate refusal and record-link selection.
Payloads retain the executor's resolved token-to-record bindings, including labeled
`finds` selections, for delivery after restart. Effects without a compiled outbox
channel stay open. Republishing unchanged source upgrades older command schemas
without reseeding records; existing completion receipts are preserved. Previously
completed effects are not automatically redelivered or reconstructed.

The primary supplies a matching `about` context when it creates that record,
uses the same token, or is the only declared record of that type. Thus
`System logs Item:notice` in `story Notices about Item` binds the context to the
selected Item and queues one effect per record.
Labeled primary records do not always supply an `about` context: if multiple
sentence/finds tokens share that type, the command exposes the separate required
context. Unambiguous aliases and a newly created context record retain their
existing binding behavior. Automatic enumeration uses the same primary/context
decision: a primary alias is not a second Cartesian slot, repeated bare tokens
are enumerated once, and a separate required context is enumerated even when no
predicate reads it. Existing scheduler state wakes after the interpreter upgrade;
successful completion receipts are retained.

`deliverEffects` supplies a trusted handler seam with durable leases, bounded
batches, retry backoff and permission rechecks. Recipients receive a stable
idempotency key and **must deduplicate it**: a crash after remote success but before
local acknowledgement can repeat a request. Delivery re-resolves the original
caller and actor binding, including effective domain roles and clock-derived
membership; revoked or changed bindings cancel pending intents before the handler
runs. Delivery also rechecks record-level permission on the committed target,
including targets supplied by `every` dispatch rather than form inputs. Reassigning
a private target cancels its pending effect; still-authorized targets can deliver.
Delivery does not rerun business preconditions: an authorized command that moves
its record out of its initial state still delivers its committed effect.
Each item's authority check and lease use a fresh clock; retry backoff starts
when its handler fails. By default elapsed monotonic time advances the supplied
batch-start timestamp; trusted hosts/tests may supply a nondecreasing `clock`.
A worker that loses its lease reports `superseded` and cannot acknowledge or
reschedule the new owner's attempt. Non-Error provider rejections are recorded
without aborting the remaining batch. Delivery refuses an enclosing transaction
before invoking any handler, so its lease commits before contacting a recipient.
Saved payload bindings do not establish current authority. QA undo/redo is
blocked once any external delivery attempt starts, including a failed attempt
whose acknowledgement may have been lost. Never-attempted pending effects remain
reversible. Tests exercise ambiguous acknowledgement/restart recovery against an
idempotent fake recipient, including forcibly killing the delivery process before
and after recipient acceptance. Recovery waits for the saved lease to expire and
reuses the same key, preserving one recipient-side effect. No production
email, payment, auth-provider or streaming adapter is supplied.

### Corpus and acceptance boundaries

Investment Bank's 101-Story fixtures, durable `every`, canonical seed version 12 and
completed owner walkthrough are preserved. Sangha's 53-Story fixtures and 32-step
log remain covered. Seed version 5 includes explicit policy metadata and the
[attendance/capacity rules](#sangha-attendance-and-capacity--2026-10-10). Its **owner
walkthrough is still pending**; automated verification is not owner sign-off.
The [owner checklist (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/rule-runtime/baseline.md#sangha-owner-acceptance--2026-10-10) asks the owner
to confirm the business assumptions and walk through the screens.

Record Label now has an advance/revenue/recoupment path; Music, Pizza, Git, Cinema,
Todo, Login, Hangman and TicTacToe have persistent workflow fixtures and browse
Stories. TicTacToe enforces turns, unique cells, all eight winning lines and draws.
Login uses trusted verification facts without implementing an identity provider;
Hangman's sample includes a game-master outcome and supplied correctness facts,
not arbitrary-word parsing. Jellyfin has current parseable Stories, playable-media
and private playlist/stream gates, trusted service events, and a mapping of all
239 imported sentences in `examples/ontolang/jellyfin/migration.json`; duplicate
sentences map to reusable commands. It models media-server work without delivering
media bytes. Legacy narrative/query/effect Stories outside these paths are not
misreported as complete applications.

Portable `walkthroughs.json` guides accompany the touched lifecycle models. The
TicTacToe fixture is move-driven rather than a status-list walkthrough. Regenerate
registered examples with `pnpm seeds:runtime`; the six established corpus helpers
remain available. Run `pnpm test:runtime` and `pnpm audit:runtime:corpus` for the
application fixtures and measured publication/probe matrix. Production hosting,
participant-facing signup screens, provider adapters and owner acceptance remain
in the [backlog](backlog.md).

**Status:** steps 1–4 **built** — the fire-and-derive loop, the intent-fact lifecycle, invariant-derived required fields, and the guarded write path + violation banners — **plus the full Formula runtime** (expressions, aggregation, the conditional form, date ± duration, string concat — computed fields evaluate in the derive step, land with the write, and ripple to the instances an aggregation lives on), **time-flow** (comparable `now`, the clock tick, standing violations — the hotel deadline moment, live), **joins tier 1** (2026-08-03: any-depth ref-hop paths in rule predicates + the cross-participant comparison, bound per fire), **and the `@` attribute runtime halves** (2026-08-04: the `@default` create-time write — a create fills declared defaults, `now` at the creation instant; and `@unique` enforcement — the standing index check, duplicates banner, never reject). Production hosting remains → [backlog.md](backlog.md). **The runtime catch-up (2026-09-05, owner ruling 2026-09-04 — "the runtime catches up to the language first"):** every construct the ratified grammar admits and the loader emits now executes in the reference loop — the story execution over the whole clause family (bound names and `about`, `finds`, `where`, `sets`/`adds`, `grants`/`revokes`, `every`, `@correction`), explicit actor eligibility, the collection quantifiers, derived subsets, the system-step runner, and the **execution-log fixture** (`examples/execution-logs/`) that replays each construct's corpus exemplar as the conformance suite — see *The runtime catch-up* below.

## Built today

### Model admission — 2026-10-10

[Qualified vocabulary types](../ontolang/spec.md#scoped-vocabulary-imports--2026-10-10)
use the existing runtime type catalog, Rules and Formulas. Compilation verifies
imported contracts against their pinned source; namespace prefixes do not confer
permission across every type in that namespace. The application compiler adds
platform actor identity fields to a runtime copy after checking the source.
Read projections resolve even capitalized fields against declared qualified
types. Host policies remain separate from imported invariants and retain their
origin and conditions through [authoring sync (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/authoring-sync/spec.md#read-policy-preservation-2026-10-10).

`compileModel` runs the shared [Ontolang semantic checks](../ontolang/spec.md#complete-model-semantic-validation--2026-10-10)
before compiling executable Stories. The current publication path uses the same
file loader and model compiler. Legacy publication also supplies its field
catalog to rule parsing. Invalid inherited contracts, predicate paths/types or
recursive subset/formula definitions are rejected. Compiled models expose
nonblocking missing-data `warnings` separately from execution `diagnostics`.
It also enforces [workflow readiness](../ontolang/spec.md#standalone-models-and-workflow-readiness--2026-10-10)
for Story-written status lists. Incomplete workflows can be authored but cannot
execute or publish through the current path. Unused actors and descriptive enums
are legal, including models with no Stories. Creating-door detection is shared
with file loading and readiness analysis, so births cannot disguise missing
transitions and quoted text or another record's status cannot change creation.
The evaluator's existing truth values are unchanged; low-level AST evaluation
continues to assume a validated model.

### Stored field presence — 2026-10-13

A stored field exists only when the record's field map owns that key. JavaScript
prototype members are never domain values: legal fields named `constructor`,
`toString` or `valueOf` remain absent until explicitly supplied. This applies to
Rule existence checks, numeric and enum validation, uniqueness, Formula paths,
defaults, seed references, sentence-name fills, read projections and the
authoring store's advisory lookup. Own values such as `0`, `false` and empty text
retain their ordinary semantics. Inherited field declarations and held-role
capabilities still resolve through their catalogs.

Missing-data, Formula and public-application regressions cover absent values,
explicit falsy values, role reference hops, creation defaults, optional seed
references, publication, unrelated edits, explicit linking and restart. The
paired-reference suite also verifies that an omitted prototype-named field
cannot alter its inverse.

### Dependent invariants — 2026-10-10

A write checks invariants on the directly written types and on types whose
invariants read that write through references, inverse collections, Formulas or
derived subsets. For example, creating `Warehouse.StockMovement` checks the
owning balance's nonnegative quantity, and creating `Payments.Capture` checks
that total captures do not exceed the request amount. A failed check refuses
the entire write and its derived effects.

`compileRuleset` collects transitive type dependencies using the same read walk
as derivation cycle validation. The reference executor, authoring guarded writes
and SQLite commits share this check. Scope remains conservative at type level:
each affected invariant is checked over its attachment's instances; this is not
incremental per-record Rule maintenance. An invariant on an unrelated type does
not block the write. SQLite's existing complete-read budgets remain in force.

Tests cover inherited aggregate members, chained Formulas, reference traversals,
inverse collections, subset membership, unrelated invalid records, and rollback
of facts and dependency metadata. The utility application test covers execution
parity and restart. The Lead Intake regression also checks that editing a source
date cannot silently violate the Lead's derived SLA deadline. Clock ticks and
`@unique` retain their existing standing-violation behavior.

This requires shipping the shared runtime code with the language changes; no
database schema migration is needed. Existing models must pass the stricter
checks, and previously accepted writes that violate dependent invariants will
now be refused. Imports still install definitions only; external payment and
warehouse adapters remain separate work.

### Record bindings in quantified gates — 2026-10-10

A labeled reference always reads its exact Story binding. In
`at least 1 Item where amount is more than Item:limit.amount`, the left side
reads each counted Item and the right side reads the supplied limit record.
An unlabeled `Item.amount` in that filter still reads the counted member.
An absent label never falls back to a bare type binding or the current subject.

Free references in global count filters and field-valued bounds in both global
and collection counts are required Story inputs. A `finds Item:sample` solves
only that token; it cannot exempt an absent `Item:limit` from the input check.
Likewise, finding `Item:source` does not turn `creates Item:new` into an update.
The shared creation check distinguishes those records in file loading,
workflow readiness and execution compilation.

Reference and SQLite regressions cover passing and failing gates, omitted
inputs, exact labels on qualified types, creation and refusal rollback.
Publication version 2 refreshes the affected command schemas on unchanged-source
republication, preserving saved records. Restart and execution after upgrade
are tested; see the [publication upgrade contract](#numeric-safety-and-calendar-arithmetic--2026-10-10).

### Binding and Formula contract review — 2026-10-10

An unlabelled ancestor name identifies the single unlabelled Story record that
inherits from it. An explicitly named ancestor wins over inferred ancestry;
multiple eligible descendants require an explicit record name. Validation,
required-input analysis, creation classification and execution share this rule.
Within a counted-member filter, the counted type's ancestors refer to that
member. Qualified imported names retain their separate identities throughout.

Supplied primary, participant, context and pre-solved `finds` records must exist
and satisfy their declared type, including live subset membership. A modifying
Story requires its primary record even without written clauses. Creation needs
an unused identity. Violations return `invalid-binding` before candidate writes.
Partially supplied `finds` bindings constrain the joint search; the solver cannot
replace a supplied record with another matching record.

Aggregates and splits use live derived-subset membership, including inherited
fields and reference scoping. SQLite observes the membership reads as Formula
dependencies, so entering/leaving a subset or moving a reference updates every
affected total. Conditional Formulas receive the supplied world clock in both
engines. Calendar comparisons share the arithmetic parser and preserve years
`0000`–`0099`; comparison precision remains one calendar day.

The published host refreshes clock-dependent Formulas and projections when its
calendar day changes, including rewind and restart. This uses its existing
bounded read/derivation transactions; it does not introduce an automatic
scheduler. Low-level SQLite callers still initialize the derived world with the
clock they supply before executing against it.

Publication version 3 rebuilds earlier command schemas, Formula values and
dependencies on unchanged-source republication. The upgrade test starts from
version 2 with an omitted ancestor participant and an incorrect subset total,
preserves stored records, executes the repaired action and reopens successfully.
See the [cross-feature evidence](../ontolang/spec.md#cross-feature-contract-review--2026-10-10)
and the deployment contract below.

The subsequent reference-path review confirmed three related failures in valid
models. Formula reference hops, aggregate operands/filters and split owners now
retain the declared reference type's field catalog. A `Reviewer` holding on a
`Person` therefore exposes its `office` capability throughout
`reviewer.office.name`, including after the Office changes. Collection Rules
evaluate live derived-subset membership, so `Selected[]` agrees with a Formula
count over the same collection and excludes other owners' records. Stored
references unwrap every subset level to reach the underlying identity; leaving
a subset does not break an existing reference. This also applies to label
normalization during initial publication and paired-reference writes.

Publication version 4 rebuilds the affected Formula values and dependencies on
unchanged-source republication. The published-app regression starts from a
version-3 model with an unset Formula, republishes, updates the referenced
Office, then reopens and verifies the result. Twelve new regression cases fail
against the prior implementation (`cf9594b1`) and pass with these corrections;
they are witnesses of these three defect classes, not twelve independent bugs.

### One-to-one relationship updates — 2026-10-10

Moving a paired reference clears displaced views throughout the source domain
declared by its inverse, including base records, sibling subtypes and role
holders. Updates to held role capabilities use the role's field declarations even though
the stored record has the base actor type. An empty reference write also clears
the old inverse, and a simultaneous rename uses the previous label to find that
inverse. Unrelated types with the same field name retain their links.
The shared write path applies these changes before deriving Formulas and
checking invariants; a refusal rolls back links, computed values and dependency
metadata together.

Six regression cases reproduce these failures against `729f35e4` and pass with
the corrections. Coverage includes local/imported models, base/subtype moves,
sibling moves, role-held links, unlinking, simultaneous renaming, invariant
refusal and published-app restart. These are fixes to existing write semantics, with no new syntax,
command schema or publication-version change. Deploy the shared runtime to
apply them to subsequent writes. Existing inconsistent stored links require an
explicit relink; republication does not infer which authored link should win.

For two paired fields on the same type, the target record's own forward link
also clears when displaced. For example, moving `A.next` to a self-linked `B`
sets `B.previous` to `A` and removes `B.next = B`. Dependent Formulas retract,
and an invariant requiring the displaced link refuses the entire move. For a
symmetric `peer: Node @of(peer)` self-link, the authored replacement is preserved
even when the record's fallback label changes with that reference. The old inverse
is the field already overwritten; inverse cleanup must not erase its new value.
Six regression cases fail on `58c8fdd7` and pass with these two corrections. The
local/imported matrix checks all 34 partial one-to-one arrangements of three records, from
either field, with every move and clear: 1,632 cases through both reference and
SQLite execution. Another 672 cases check all 14 symmetric arrangements with
explicit and fallback labels. Published-app coverage also verifies both fixes
after restart. This uses the same shared write path and needs no syntax,
publication-version or schema change.

### Atomic paired writes and role changes — 2026-10-13

The complete batch's final requested edges must agree with their reciprocal
edges before any writes land. For example, `A.next = A` together with
`A.previous = B` cannot satisfy the same one-to-one relation; both executors
refuse the batch with an invariant violation and preserve every record.
Inverse maintenance runs after all authored writes, so targets created later
in the batch are available and superseded forward writes cannot displace the
final requested relationship.

Opening a new role holding mirrors its supplied paired capability fields;
granting an already-held role remains a no-op. Revocation clears inverses only
for capabilities it drops. Fields still owned by the base actor or another
effective holding retain their values and links. Reopening with an explicitly
supplied reference restores its reciprocal link. `pair-consistency.test.ts`
covers conflicting and compatible simultaneous edits, deferred targets,
superseded writes, inheritance, grants, revokes, numerical rollback and SQLite
restart.

### Seed references and inverse choices — 2026-10-10

The shared scalar-pair resolver honors an explicit inverse choice from either
end, so writing an unselected reference cannot alter the chosen relation. The
[language validator](../ontolang/spec.md#the-loader--ontolangparse-projectts-core--parse-dirts-node-wrapper)
rejects contradictory explicit choices before execution.

Seed references may point to their own record by exact ID or unambiguous label;
self-reference does not exempt a duplicate label from the ambiguity check.
Seeded role capability references materialize their inverse using the role's
declaration while retaining the base actor identity. Seed loading and initial
application publication resolve all labels against the original input before
replacing them with IDs. This preserves identity when a record's fallback label
comes from a reference field, regardless of record order.

Eight regression cases fail against `44214ec2` and pass with these corrections,
including source admission, direct compilation, local/imported execution, seed
loading, initial publication and restart. Deploy the validator and shared runtime
together. Existing contradictory declarations must be corrected; existing
inconsistent stored relationships still need an explicit relink. These fixes
require no additional publication-version or database schema change.

### Reference identity and role enum values — 2026-10-10

Inverse collections, scoped aggregates and money splits resolve each incoming
reference to the same record as a forward reference hop. An eligible exact ID
wins over display labels; a stored label falls back to the first eligible record
in creation order. An ID belonging to an unrelated type does not hide an eligible
label. Reverse indexes supply candidates, not final membership. A label matching
another record's ID therefore cannot make one entry belong to both accounts or
duplicate its amount in both totals. Seed labels still require an unambiguous
match during initialization.

Enum validation includes held-role capability fields when an update names the
stored base actor, and capability values supplied with a role grant. Undeclared
values refuse the complete candidate in both reference and SQLite execution.
The [enum storage contract](#inherited-uniqueness-and-canonical-enum-values--2026-10-11)
also applies. Existing invalid values on
untouched fields do not block unrelated writes.

Publication version 5 rebuilds saved Formula values and dependencies on
unchanged-source republication. The current interpreter stamp also repairs old
cached totals on the next read after reopening; see the
[read-upgrade contract](#declared-enum-ordering--2026-10-10).
Tests cover ID/label collisions, duplicate labels, wrong-type IDs, creation order,
inheritance, live subsets, collection gates, totals, allocation, role edits and
grants, rollback, republication from version 4 and published-app restart. The
[language contract suite](../ontolang/spec.md#cross-feature-contract-review--2026-10-10)
checks local and imported models. These are shared runtime corrections with no
new syntax or database schema migration.

Eight regression cases fail against `b4db5953` and pass with the corrections;
two wrong-type-ID controls pass on both versions. These are witnesses of the
two defects, not eight separate bugs.

### Inherited uniqueness and canonical enum values — 2026-10-11

`@unique` applies to the declaring type's complete membership. A `Product.sku`
declaration compares Product, Vape and Accessory records together; inherited
copies produce no duplicate warnings. A constraint introduced only on a subtype
retains that narrower scope, and unrelated types remain independent. Role-owned
unique fields compare effective holders, excluding inactive dependent roles.
The reference tick, published application's standing issues and authoring
ClockBar use these same scopes. Duplicating writes still commit, corrections
clear the warnings, and publication/restart preserve the behavior. Authoring
does not require unfinished Stories to compile before showing a duplicate.

Enum writes store the declared string, matching source loading, publication
and predicate evaluation. The runtime preserves its case-insensitive input
compatibility: unambiguous `CLOSED` becomes declared `closed` before creation
gates, Formula derivation and storage. Exact declarations win when a list contains
distinct case variants; ambiguous input is refused. Numeric `1` and boolean
`true` cannot stand in for enum strings `"1"` and `"true"`. Creation, edits and
role-capability grants share the check, with complete rollback on refusal.
The `@final` guard also recognizes unambiguous legacy casing, so an old `CLOSED`
record cannot bypass a declared `closed @final`. Existing empty-input handling
and correction Stories remain supported. Untouched legacy invalid values are
neither rewritten nor allowed to block unrelated writes.

Twenty-one regression cases fail on `ff3904ec` and pass after the fixes; an
additional authoring-store test covers unfinished workflows and imported
definitions. Coverage includes reference/SQLite parity, rollback of facts and
derivation metadata, standing issues in the published app, correction and
restart. These fixes require the shared runtime code, with no syntax change,
database migration or additional republication: the checks run on writes and
standing reads. Publication version remains 5 for the earlier Formula repair.

### Numeric safety and calendar arithmetic — 2026-10-10

Native Ontolang `int` and `money` inputs and computed results must remain safe
integers (`-9007199254740991` through `9007199254740991`; money uses minor units).
The shared Formula interpreter checks each numeric operand and intermediate
arithmetic result, including aggregate accumulation. For example, `value + 1`
refuses a write of `9007199254740991`, and `(value + 1) - 1` cannot hide that
overflow. An average also refuses if its intermediate sum exceeds the range,
even when the final quotient would fit. Legacy float fields retain finite
floating-point arithmetic.

Unsafe inputs and complete candidates return a `numeric-range` violation through
Story preparation and the reference/SQLite commit paths. No candidate facts, mirrored references,
computed values or derivation metadata survive a refusal. Direct numeric writes, including role-capability grants and edits,
are checked too. Evaluation retries transient errors while other computed
operands settle, so a safe final dependency chain is not rejected just because
a prior pass still held an old value. Creation gates use a provisional view that
contains only the newborn: unsafe computed values stay unavailable there rather
than rejecting unrelated gates before the other Story writes can land. The
complete candidate always uses strict arithmetic checks. Missing operands and division by zero
retain their existing unset behavior.

Clock advancement and existing-world reads make an unsafe computed result
unavailable, clear dependent computed values, and expose a `numeric-range`
standing diagnostic. Time still advances and the application remains readable
after restart. Guard reads use that view so a correcting Story can execute.
The complete write candidate remains strict: a still-unsafe candidate is
refused, including an unrelated edit that leaves the numerical failure in place.

SQLite stores read-time failures in the automatically installed
`_world_formula_error` cache alongside Formula dependencies. Candidate refusal
rolls back this metadata with facts. A safe correction removes the diagnostic;
QA undo/redo captures and restores it with the derived values and projections.
Repeated reads at the same clock and interpreter stamp preserve storage and
revision. Reference tick and public-application regressions cover transitive
clearing, unsafe refusal, successful correction, restart and undo/redo.

Rounded integer division and money allocation use exact integer bookkeeping.
Splitting `-9007199254740991` across three members yields
`[-3002399751580330, -3002399751580330, -3002399751580331]`, preserving every minor
unit. Calendar arithmetic treats years `0000`–`0099` literally, preserves four
digit years, and handles leap years correctly. Impossible input dates or results
outside `0000`–`9999` stay unset rather than storing invalid timestamp text.

**Deployment:** ship these shared runtime changes with the parser. The
`semantics:3` read stamp rebuilds old saved Formulas and dependencies on the
next read, including same-day reopen with unchanged source. Current publication
records `ontolangRuntimeVersion: 5`, so republication also rebuilds older
command schemas when their source hash is unchanged. Publication remains
revision-checked and atomic, preserves authored facts, and refuses if the saved
facts produce an unsafe formula under the new semantics. The numerical-error
cache table is installed automatically; no manual database migration is required.
Legacy schema-version-1 SQL applications are outside this
native Ontolang publication upgrade.

Regression coverage includes positive/negative overflow, money, intermediate
expressions, aggregates, transitive derivation, exact allocation, calendar
boundaries, complete rollback, successful subsequent writes, restart and
unchanged-source republication. Counterfactual tests against the previous
commit reproduce the fixed defects; the same regressions pass with these fixes.

### Declared enum ordering — 2026-10-10

Catalog-backed field reads carry the enum's declared vocabulary into the shared
comparison function. Ordered Rule comparisons and Formula aggregate filters use
declaration rank, including inherited fields, reference paths and compatible
field-to-field operands. Numeric-looking and date-looking enum labels still use
their declared order. Equality retains stored-value semantics; missing or
undeclared ordered operands and conflicting enum orders fail closed. Ordinary
numeric and timestamp comparisons retain their existing behavior. The AST and
stored enum values are unchanged.

This fixes `count of Booking where stage is at least "confirmed"`: with requested,
confirmed, attending and attended records it returns 3, rather than 0. The same
comparison serves Rule gates, collection filters and conditional Formulas. Tests
exercise all four ordering operators, equality, all aggregate operations,
reference/SQLite parity, scoped and inherited collections, missing references,
and published preview/commit/receipt/restart behavior. Sangha's explicit equality
counts remain valid and its seed does not need another change.

Persistent read projections and scheduler wake state now include an interpreter
semantics version alongside the source hash (`semantics:3` for the current
interpreter). Existing applications rebuild their saved Formulas and dependencies on their next read after an upgrade, even on the
same day with unchanged source. The scheduler notices the old version and wakes.
A changed derived value increments the revision; repeated current-version reads
do not rebuild. A persisted interpreter-stamp mismatch always repairs the
projection, even when the model reads no clock. Day changes alone do not rewrite
clock-independent Formula or subset projections, including rewind and restart.
Model identity, saved business facts and completed command/effect
receipts remain intact. A regression simulates old cached totals and verifies
repair, invariant refusal and receipt replay after reopening SQLite. Future
interpreter changes that invalidate saved reads must bump `currentSemanticsKey`.

### Sangha attendance and capacity — 2026-10-10

Canonical Sangha and registered seed version 5 require open registration for
booking requests and confirmations, `in-progress` for Student attendance start,
and `completed` for Student attendance completion. The Teacher begins after Admin
closes registration and concludes before Students complete. Derived NewStudent and
OldStudent remain based on attended booking evidence; no manual membership grant
is introduced. Cancelled retreats cannot admit booking requests or attendance.

`Retreat.bookedCount` sums confirmed, attending and attended bookings linked to
that retreat. `confirmedCount` retains its narrower meaning; `fillPercent` now uses
bookedCount. Positive capacity and `bookedCount <= capacity` are invariants. A
Student progressing through attendance does not release their seat.

Invariant scope now includes records changed by mirrored writes and Formula
recomputation, including transitive dependents and their base types/holdings.
Previously only directly written types were checked, allowing a booking change to
violate its Retreat's capacity. The reference compares the derived candidate to
the derived starting state; SQLite tracks affected records without scanning the
whole world. Unchanged, unrelated types retain the existing scope boundary.
Refusal rolls back facts, Formula values and dependency metadata. Discovery uses
the same candidate check without saving it; commit checks again inside its write
transaction, so competing ready previews cannot overbook the last seat.
This also closes the equivalent Lead Intake bypass: backdating a ContactForm to
make a linked Lead's deadline already overdue refuses, while a valid date edit
still recomputes deadlines. A clock tick itself remains a standing-rule event.

Tests cover early attendance/completion, closed/cancelled registration, all three
seat-consuming states, separate-retreat counts, invalid capacity, participant
privacy, derived membership, replay/restart and competing confirmations using two
SQLite connections. A shared-executor regression verifies transitive Formula
limits on inherited types and complete rollback. Portable walkthrough guidance,
op replay and the 32-step reference/persistent log use the same order. See the
[owner checklist (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/rule-runtime/baseline.md#sangha-owner-acceptance--2026-10-10) for the remaining
business and screen acceptance; these changes do not deploy a host or update
existing saved models automatically.

### Corpus publication and execution sweep — 2026-10-10

`pnpm audit:runtime:corpus` audits all 16 canonical folders and 16 registered seeds
independently. It publishes disposable applications, probes every admitted Story,
compares committed facts with the reference and checks receipt replay and read-only
query/search/pagination. All 32 sources publish. It also runs six complete public
application logs and ten additional persistent workflows, with reopen-after-step
coverage. It never opens live owner datasets. The [generated evidence (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/reports/runtime-corpus-sweep/README.md)
separates these workflow tests from synthetic probes needing additional inputs.
Jellyfin's obsolete syntax and Coffee's implicit role-conferral mismatch are fixed;
provider implementations and owner UX acceptance remain outside this audit.

### Investment Bank and durable every execution — 2026-10-01

The application host executes `every` through the shared Story interpreter.
It snapshots at most 200 members once, persists the request and model hash,
and executes each child in its own SQLite transaction through ordinary actor,
permission, Rule, Formula and receipt checks. Later members see earlier saved
writes; a refused child rolls back only its own candidate. Empty lists succeed.

`_every_run` stores the frozen request and member list; `_every_member` stores
per-member results. Stable child operation IDs prevent duplicate writes across
retries, process interruptions and simultaneous requests. Successful children
are skipped; refused/unattempted children may resume. A completed parent has an
ordinary receipt. Changed inputs conflict with its operation ID, and unfinished
runs cannot resume against a different published model. Completed retries retain
their saved response. The caller's active credential/binding is checked again.
An already-open service synchronizes the published command schema before choosing
ordinary versus batch dispatch, so publication from another connection does not
misroute a newly added `every` command.
Discovery, resource choices, queries and record action lists also synchronize
before mapping command inputs and outputs, using the same model snapshot
throughout the read. Owner role selection refreshes before validating a role
published by another connection.

Discovery simulates the same sequential children within a rollback savepoint.
The initial dispatch refuses if any member is unreadable, rather than silently
omitting it or exposing its identity. The reserved child-operation namespace is
unavailable to public callers. Owner and participant HTTP entry points return
207 with member results for an incomplete dispatch, 422 for command refusal,
and 200 for a committed result. `/run` shows saved progress and **Resume unfinished run**
for the same caller and actor binding, including after page/server restart;
resume uses server-held inputs. Saved progress never exposes those inputs or
member identities in the listing. Each successful child appears in activity;
this slice does not add batch undo, cancellation, background workers or hosted
durability. A new operation intentionally starts a new batch.

Investment Bank's canonical files generate registered seed version 12 via
`scripts/sync-investment-bank-seed.ts`. Explicit document fields replace obsolete
multi-parent interfaces. Fictional staff, counterparties, a Mandate and an
EngagementLetter provide setup; Deals, CIMs and ProcessLetters are created by
Stories. Deal.business and CIM.deal preserve workflow context; a Buyer may
answer only its own ProcessLetter. All ten actors have browse Stories. The
companion JSON walkthrough proposes origination → CIM/engagement → marketing →
per-Buyer letters/answers → close; this advice does not add domain guards.

The service tests execute **all 101 Stories (80 actions, 21 queries)** against
explicit, isolated prerequisite fixtures and compare write results to the
reference. The 14-step reference deal log also completes through public bindings
and persistence, including refused actions, private browsing and restart.
Separate generic tests cover partial progress, aggregate constraints, target
iteration, zero/over-limit membership, revoked bindings, model changes and two
racing processes. Real HTTP checks cover partial results and resumption with
scoped test-agent credentials.

**Owner browser walkthrough completed and verified — 2026-10-02:** the canonical
seed was loaded into the local TEST project database and published with 11 setup
records. Saved activity and a fresh service read confirm one Apex Industries
Deal closed, one linked CIM, and exactly two ProcessLetters answered by their
respective Buyers, Northstar Capital and Willow Partners. One `every` run has
two committed member results and a completed parent receipt; no unfinished batch
or walkthrough step remains. Nine committed Story events represent eight user
actions because the batch contributes two child events. The Deal name was left
blank successfully; an automatic business-derived name has only been discussed,
not implemented. The 11 focused Investment Bank/every tests passed again.
This manual run covers the happy path; denied access, interrupted execution,
restart and concurrent retries remain separately established by automated tests.

An unambiguous primary record supplies its own `about` context, matching the
reference. Repeated labeled types retain a separate required context input. Projection reuses hydrated records within
one read-only projection pass; this avoids exhausting read budgets just by
checking a wide vocabulary's memberships. No cache survives a domain write.

### Sangha application and live subset membership — 2026-09-27

The public host admits derived subsets using the shared Query World predicate
semantics. Sangha's NewStudent/OldStudent eligibility changes with attended
RetreatBookings; derived roles cannot be manually created or granted. Persisted
holdings such as DedicatedStudent and ServiceTeamMember remain explicit grants.
Both kinds participate in actor choices and permission-checked queries/actions.

After candidate writes, the host refreshes the projection in the same transaction.
Before binding or policy reads it refreshes when the trusted UTC/QA day, model
hash or dirty records change. A persisted projection stamp keeps separate
connections, restarts, republication and QA undo/redo consistent. Stale human
and agent bindings are rejected. Discovery rolls back projection changes with
candidate facts. Stored references to subsets retain their base identity when
eligibility changes, matching shared reference resolution. Clock refresh occurs
on access; this does not add background scheduling.

Subset models currently reconsider the complete bounded record domain (maximum
5,000 records plus existing World read budgets), rather than tracking subset
predicate dependencies incrementally. Refreshes fail explicitly on budget
exhaustion. Non-subset models retain the dirty-record projection path.

Canonical Sangha now has 53 Stories: 31 actions and 22 browse/query Stories,
covering every actor. Donation and VolunteerAssignment creation use existing
`submits`/`creates` semantics instead of verbs that recorded events without
creating statusless objects. `scripts/sync-sangha-seed.ts` generates registered
`examples/sangha-seed.json` (version 5) from canonical Ontolang. No runtime domain-specific
Sangha behavior is added. The reference appointment fixture uses the declared
string enum value for duration, matching public schemas.

`application/current-sangha.test.ts` executes every Story and the complete
32-step reference log through ApplicationService, with discovery, receipts and
fact parity. It checks private booking/donation queries, revoked-role access,
restarts, linked-record corrections, undo/redo and clock-driven access changes.
The canonical seed contains only teachers, an administrator and volunteer role
setup; students and workflow records are created during a walkthrough.

The Studio import and publication path now preserves actor/object subset
predicates. Authoring backfill emits entity declarations before Stories and
carries all stored `sets`/`adds`, `grants`/`revokes`, `finds`/`where`, `about` and
`every` clauses. A grammatical object that is an actor (Teacher recognizes
Student) does not create a second object declaration. These are persisted model
ops; runtime records stay in the separate SQLite application. Regression coverage
reconstructs Sangha through replay twice, compares all executable model data,
publishes that reconstruction, and proves attendance changes NewStudent to
OldStudent. The local Sangha project was reconciled with additive metadata ops;
its saved runtime records were preserved.

### Portable walkthrough configuration — 2026-09-28

Hotel and Sangha carry `walkthroughs.json` beside their `.onto` files. The JSON
contains named paths over existing Stories: a root record and lifecycle field,
participant reference, entry Story, stages, optional alternatives and input/actor
bindings from the followed or related record. It is navigation data, not new
Ontolang grammar or execution policy. `@trigramco/ontolang/walkthroughs` owns the
bounded schema/types; `schema/walkthrough.ts` delegates to that public package API.
The package loads and prints the companion without a runtime dependency;
publication validates Story, entity, field and public-input references. See the
[package contract](../ontolang/spec.md#independent-language-package--2026-10-13).
Malformed configuration and stale references produce a diagnostic rather than
silently omitting steps. Renamed/deleted references must be updated in the recipe.

The loader/printer preserves the companion file; the seed carries `walkthroughs`.
Studio saves it on the project via `project/set-walkthroughs`, backfills/replays it
and exports it into the published files. An explicit empty list clears guidance.
Current publication also carries accepted Story identities and the complete saved
folder hierarchy in `templates.json`. Assigning a Story to a Studio folder keeps
that metadata valid in the portable source. Republishing folder-only changes
preserves saved runtime records, actor bindings, stable Story commands and
walkthrough guidance across a restart.
Hotel seed 26 and Sangha seed 5 include this configuration. Existing examples can
use **Runtime tools → Dataset and setup → Load example walkthroughs** to save
missing guidance and republish without reseeding records. Existing customized
walkthroughs are not overwritten by that action. Old Hotel publications without
configuration retain their compatibility recipe until upgraded.

The shared Next evaluator selects a path from the Story, followed record and
selected actor. Sangha covers retreat administration, booking/attendance, group
membership, appointments, volunteering and service-team applications. Related
retreat actions resolve back to the selected Student's booking; ambiguous records
require selection. Handoffs to OldStudent retain the same concrete Student.
Labels follow declared references (for example, the booking's retreat name).

Suggestions check current permission and runtime discovery for each actor. An
unbound existing actor is previewed in a rolled-back savepoint; the explicit
**Continue as …** click establishes the QA binding. Revoked bindings are excluded.
Handoffs select the role, person, Story and inputs; execution still requires
**Run Story**. This remains owner-only QA navigation. Regression coverage checks
import/replay, publication validation, booking-to-attendance and appointment
handoffs, restart, unauthorized callers and no saved preview activity/bindings.

### Published application baseline

Warehouse and Accounting templates run as ordinary canonical models on this
host. Their modules, business guards and limits belong to the
[templates spec](../templates/spec.md); the host adds no template-specific
business logic. Published command metadata retains declared money types for
the shared [Run entry/display contract (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/rendering/spec.md#money-display-and-entry).

The recovered prototype is integrated on current staging: `rule-runtime/application/`
publishes versioned applications and provides discovery, actor bindings and the
human/agent API over `rule-runtime/relational/` SQLite transactions. The Run QA
interface preserves personas, room changes, named refusals and durable undo/redo.
Its [guide and recovery status (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/rule-runtime/baseline.md#recovery-onto-staging--2026-09-22)
define the supported scope. Version 1 retains the preserved prototype Hotel fixture. Version 2 now publishes
the canonical Hotel model through the shared Story executor, described below.
Admission still rejects unsupported host features instead of discarding them.
The current reference executor below remains authoritative.

Run confirms a saved Story with green text, border and tinted background.
Pre-run eligibility explanations, including why another run is unavailable,
are neutral grey. Disabled Run buttons have neutral grey borders and backgrounds,
with text darker than the surrounding eligibility explanation. Failed execution
alerts retain the error color, so a completed run is visually distinct from the
availability of the next attempt.

The owner accepted the current Hotel baseline on September 22. The observed
browser activity covers booking, confirmation, assignment, check-in, invoice
creation/payment, checkout and repeat cleaning; room moves and service-charge
propagation have automated coverage, without a claimed manual run of those paths.
The [baseline guide (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/rule-runtime/baseline.md#accepted-hotel-baseline-and-pr-consolidation)
records acceptance and the incorporated research and actor-policy drafts.

Published Formulas now share division, rounding and date-shift implementations
with the reference executor (`rule-runtime/scalars.ts`). Explicitly rounded
division and averages are admitted; days/weeks retain time-of-day, months/years
clamp to the destination calendar, and hours/minutes require a timestamp with a
time. Valid stored timestamps accept the reference's date-only or zoneless time
spelling and reject impossible dates/times. SQL aggregation supplies operands in
record creation order to a JavaScript sum, preserving the reference's
floating-point reduction; empty sums are zero, empty averages are unset, and a
missing matched operand makes the result unset. The 29 publication/execution
regressions in `application/formula-parity.test.ts` compare these results with
the reference before and after edits and database restart. This closes those
scalar gaps for new publications, not the remaining Story/holding/collection
semantics or existing published-model migration.

The Studio integration uses current navigation and organization-bound requests,
including generation checks on late responses. Human requests require verified
organization membership plus the expected-org header; agent requests use their
application-scoped credentials. These changes do not migrate the original demo's
live data or establish production hosting/readiness.

### Query World and shared Story preparation

The snapshot executor now uses `makeQueryWorld` through its snapshot adapter.
Both it and `relational/world-source.ts` share the same reference resolution,
effective role holdings, derived-subset predicates, collection membership and
newborn scan visibility. The SQLite source reads typed facts and ordered
holdings through indexes, requires the owning Runtime transaction, batches
record hydration and throws on a query/record budget overflow. It never returns
a partial collection as a complete answer. Updates keep record creation order;
rollback and restart preserve the reads.

`execute.ts` now calls `prepareStory` for binding, eligibility, `finds`, `where`,
written assertions and guards. Those stages accept a World from either source;
the snapshot executor then calls its existing commit/derive/check loop. The
SQLite differential tests check queries at every state of all six execution
logs and compare preparation results for individual non-`every` Story calls.
They also exercise role revocation, ID/label precedence, missing/falsy values,
newborn visibility, bounded reads and the recovered Runtime's rollback.

`evalFormulaWithReads` also shares the complete Formula interpreter between
snapshot and indexed operands (`relational/formula-reads.ts`). Reference hops,
ordered aggregates and money splits read through the source. Conditional
expressions temporarily overlay the in-progress record in a savepoint, including
a newborn, then roll it back on success or read-limit failure. Corpus-state
comparisons include every available computed-field expression; focused tests
cover split order and negative money, missing/empty aggregates, and conditional
overlay cleanup. This preserves existing reference semantics, including the
conditional's absent clock. The affected derivation component below uses these
operand reads and persists computed results.

### Transactional candidate writes and affected Formulas

`commit.ts` now shares `guardAssertions`, `applyWrites` and `checkAssertions`
between the snapshot executor and `relational/commit.ts`. Defaults, final-status
checks, implicit participant bindings, unambiguous one-to-one link moves, enum
checks, postconditions and touched-type invariants (including indirect Formula
and mirrored writes) retain one implementation; see [dependent invariants](#dependent-invariants--2026-10-10).
`commitSqlite` applies only the affected records within a savepoint, derives
computed results and checks the candidate. A refusal or exception rolls back
facts, holdings, computed fields, dependency metadata, pending work and insertion
order while leaving the owning transaction open.

`relational/derive.ts` records Formula dependencies on keyed records and indexed
candidate queries, including absent references and empty collections. A write
invalidates queries matched by either its old or new record. Dependency work is
persistent, and settlement follows affected records to quiescence using the
shared Formula interpreter. Each affected pass reads the previous pass's values
before publishing its own results; this also preserves field order when computed
fields supply fallback record labels. Undefined results remove stale computed
facts and invalidate their dependents. Initialization reads computed-field types
once after import; ordinary writes do not copy or recompute a whole-world
snapshot. Query, record, dependency-domain and evaluation budgets fail explicitly
rather than committing an incomplete result. Type-wide Rules and global Formula
queries may still require their complete bounded domains; this is not a constant
cost guarantee for every model.

`relational/story.ts` runs shared Story preparation against that derived world.
A newborn's guard view has its written values and computed consequences, omits
it from scans, and rolls back before applying the actual batch with defaults and
pair writes. The component executes one Story or one supplied frozen member.
It does not accept responsibility for selecting or persisting an `every` run.

`relational/commit.test.ts` compares the actual SQLite writes, refusals, bindings,
keys, holdings and derived values for individual Stories/member runs across all
six current corpus logs. SQLite is seeded once and changes through its own write
path; the reference never supplies replacement candidate snapshots. The test
harness supplies system inputs and frozen `every` dispatch, so these checks do
not establish durable scheduler/receipt parity. Focused cases cover both sides
of reference moves, transitive retraction, missing references and label changes,
ordered money splits, dependent holdings, postcondition refusal, link-pair and
holding rollback, budget failures, dependency restart and computed-label order.
An affected write is also checked with 1,200 unrelated records present.

### Current Hotel application and Run integration

Version 2 sends canonical Ontolang files across the publication boundary; the
server reparses them and derives its own metadata. The live authoring export
preserves committed Story clauses, labels, fields, Formulas and attached Rules.
Version 1 remains the recovered prototype contract. Cross-version publication
refuses rather than rewriting an existing dataset.

`application/current-compile.ts` projects schemas, authorized selections and
commands into the existing application infrastructure. It does not lower Story
meaning to SQL. The trusted current-language candidate hook runs only after
identity, actor binding, role, permission, input, approval and budget checks.
Commands requiring this hook fail closed when the host is absent. Shared Story
preparation, candidate writes, affected Formulas and checks execute inside the
same transaction as revision, audit, outbox and idempotency receipts. Discovery
runs that candidate in a rollback-only savepoint. Scalar read projections keep
the existing permission-aware UI, resources and persona controls usable.

Initial publication imports typed facts and resolves each label reference to
exactly one identity. Model republication rebuilds Formula dependencies while
preserving saved facts; unsupported schema migrations refuse atomically. Ordinary
writes project affected IDs, including Formula consequences. Query and derivation
budgets remain explicit and incomplete reads never become accepted answers.
Standing type invariants and unique collisions use shared evaluation.

The current Hotel persona demo creates a separate application using the current
authored model and seed catalog, with named QA actors and a fixed September 19,
2026 simulation date. It does not add the recovered model's Assignment type or
its additional guest policy. Canonical guidance follows the authored scalar room
relation, Service `finds`/`adds`, labelled room move and correction Story. System
steps are manually selected in QA. The recovered demo remains available in its
existing dataset and its source fixture remains checked in.

The canonical Hotel seed makes **Receptionist assigns Room to Reservation**
available only for a confirmed or checked-in reservation with no room yet.
After assignment, both the same-room retry with a new operation and assignment
to another room refuse; replaying the original operation returns its receipt.
**Receptionist moves Reservation from Room:current to Room:target** is the
separate room-change Story, available while confirmed or checked in; its current-room
link must match the reservation. These are authored seed Rules, with identical
checks for people and agents. Existing current demos can use **Apply assignment
rules** to save these gates to the authoring project and republish the model,
preserving Story identities, custom rules, records and activity. The older
mid-stay-only move gate is replaced. Model republication invalidates old undo
checkpoints as described below.

Hotel booking now requires `Reservation.roomClass exists` and requires the
reservation's room and invoice to remain unset at submission. Guests choose a
room class and dates; the room number is assigned by the Receptionist and the
invoice is linked later. The same Rules persist in both seed representations.
Current capture schemas omit fields proven absent by direct negative-existence
gates in every alternative, while retaining fields whose absence is only one
possible branch or concerns a nested path. Required class checks and rejected
room/invoice inputs are enforced server-side for people and agents. Older current
demos can use **Apply booking rules** to save and publish the seed's booking gates
without resetting their records.

QA undo/redo captures canonical facts, Formula dependencies, numerical-error
cache metadata and projections alongside the existing domain rows. Authority is compared, never restored;
model edits and grant/binding changes invalidate old checkpoints. Tests exercise
booking through invoicing, subsequent charge propagation, labelled moves,
correction, restart, preview rollback, actor spoof/refusal, receipt replay,
undo/redo and additive republication. Both the recovered and current Hotel HTTP
checks pass through the real Next/Clerk boundary with isolated agent credentials.
Organizations is enabled in this worktree's Clerk development instance. The
[isolated project database (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/authoring-sync/spec.md#isolated-local-project-storage)
resolves the subsequent project-list failure. Signed-in browser checks cover
Hotel import and reload, persona-demo creation, and RoomClass browsing/search.
The full manually driven browser lifecycle remains for owner testing.

**Remaining host limits:** computed or ambiguously named role capabilities
refuse admission. Automatic system/tick scheduling and complete six-corpus
application parity remain ahead. Durable `every` support is described above. Domain dates use the
QA date or current UTC date; there is no persistent deadline scheduler. The
internal six-log Story/member tests remain broader than the public host. No
original live data was migrated, no staging deployment occurred, and the actor
signup/affiliation policy from #178 was not invented by this integration.

### Lead Intake and persistent domain roles — 2026-09-23

Version 2 now admits explicit actor roles and Story `grants`/`revokes`. A seeded
Sales Rep or Account Executive remains one Employee with a holding. Capability
values are stored in `_world_role_fact`, keyed to that holding, while identity
fields stay in `_world_fact`. Profile edits retain this ownership; revocation
removes capability values, and regranting does not restore old values. Effective
membership controls read projections and human/agent actor bindings after each
write and restart. Discovery and refusal roll back the same transaction; QA
undo/redo includes capability storage. Empty capability storage preserves older
Hotel checkpoints. Opening an older current-model database adds the new empty
storage table without reseeding facts or changing the application revision.

The owner actor picker can bind an existing eligible record. Derived roles do
not offer a generic New actor command: create the base Employee, then assign a
role in its profile or through an authored business Story, preserving identity.
These domain holdings remain separate from
application authorization grants and the unimplemented signup/affiliation plan.
Capability names must be distinct across a base and its roles; computed role
capabilities and direct role-creating Stories are explicitly refused for now.

The canonical Lead Intake seed and its generated registered seed contain six
Employees (three Account Executives, a manager, a Sales Rep, and an unassigned
Employee), three territories, explicit actor types and five query/browse Stories
among its 18 Stories. Routine staff assignment is handled by the actor editor;
the artificial appointment/suspension Stories were removed in seed version 2.
Routing consumes its Account Executive
participant by checking the territory owner; Account Executives can browse and
work only their own leads. `current-roles.test.ts` covers intake through conversion,
role grant/revoke/regrant, stale human/agent bindings, restart, capability ownership,
refused edits and undo/redo. Seed parity and parse/print stability are checked.

#### Actor role administration

An existing actor's profile has a **Roles** section listing the assignable roles
over its rigid base. **Assign** and **Remove** save immediately. These are
owner-only platform operations through the command, receipt and transactional
candidate path, with an activity entry; they are not generated domain Stories.
Agents and simulated domain actors cannot invoke them. No application access
grant changes. Role prerequisites are enforced, and a held dependent role whose
base role was removed is shown as inactive. Removing the role currently being
played returns the owner to the same actor under its base type.

Each change requires an expected revision and operation identifier. Retries
replay the receipt; stale requests refuse without changing holdings. Capability
cleanup and effective membership use the same grant/revoke assertions as Story
execution. Tests cover authorization, replay, stale writes, dependent roles,
restart and revoked human/agent bindings.

The corpus's natural business examples are in Sangha: accepting a
VolunteerApplication grants RetreatVolunteer, accepting a ServiceTeamApplication
grants ServiceTeamMember, and revoking a GroupMembership revokes DedicatedStudent.
`relational/commit.test.ts` executes the existing canonical acceptance and
membership-revocation Stories through SQLite, including participant and repeat
refusals. This is focused engine coverage: the full Sangha application still
refuses publication because derived subsets are not yet supported by the host.
See the [walkthrough setup (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/rule-runtime/baseline.md#lead-intake-test-setup--2026-09-23).

### Canna Manufacturing walkthrough — 2026-09-25

The current host admits the complete canonical Canna Manufacturing model. The
registered seed is generated from `examples/ontolang/canna-manufacturing` by
`scripts/sync-canna-seed.ts`, with exact parity and parse/print checks. Its 97
Stories include 21 added browse/review Stories covering every working person or
organization role; the existing two query-classified substeps are also retained.
Fictional setup data supplies 16 Employees with explicit holdings, a test lab,
six catalog entries, two placeholder package tags, equipment and the vault.
No batches, samples, case packs or activity are seeded.

Authored intake gates require positive quantity and reserve package references
for their later assignment steps; case creation reserves the vault for storage.
Generic input-schema derivation enforces those rules, without a Canna-specific
runtime branch. Application tests exercise polymorphic catalog browse/search,
all four typed intake forms, failed-write rollback, a held record's lab-result
gate, vault aggregation, repeat refusal and restart. This is local application
testing, not an integration with Metrc, a real lab or equipment. System effects
remain queued/manual. See [walkthrough setup (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/rule-runtime/baseline.md#canna-manufacturing-test-setup--2026-09-25).

### Query and browse Stories in Run

Both application versions retain every admitted authored Story in the owner
catalog, including query verbs such as browse, view, search and review. Retired
Stories remain withdrawn. A query opens a searchable, paginated results table in
its Story pane; it needs no selected target and remains available for an empty
collection. Authored participants remain explicit inputs. Query results apply
the selected role, concrete actor binding, scoped authority, row and field read
policy, and the Story's conditions. Current Stories use shared preparation for
`finds`, `where` and gates. A query verb with explicit writes remains an execution.

The `query` API operation returns only authorized, condition-matching records.
Search runs over visible returned values, so withheld fields and rows cannot
match. Queries use a consistent read transaction and do not create records,
change revisions, consume budgets, emit effects, create receipts, or add activity
and undo checkpoints. Sending a query Story through `execute` refuses. Pages
default to 50 rows and accept at most 200; this local baseline still enumerates
authorized rows before applying Story conditions, rather than pushing arbitrary
shared clauses into SQL.

Older saved applications expose an owner-only **Enable browsing** upgrade. It
recompiles the saved published source, checks the expected revision, preserves
saved records, and invalidates old undo checkpoints as a model publication does.
It does not import newer authoring edits or convert between source versions.
Regression coverage checks full Story retention for both Hotels, generic query
verbs, permissions, masking, gates, participants, empty collections, pagination,
search, restart, revocation, unchanged history, and saved-model upgrades. Both
real HTTP checks include query/search through issued agent credentials.

### Recovery compatibility audit (2026-09-22)

The [compatibility audit (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/rule-runtime/compatibility-audit-2026-09-22.md) compares staging with the preserved July-based runtime prototype, using current corpus replays and isolated publication/execution probes. The evidence generator is `scripts/runtime-compatibility-audit.ts`; results are under `reports/runtime-compatibility/`. It verifies the preserved source before importing it and uses only temporary databases. `--require-parity` fails on recorded incompatibilities. Its original 40 passing tests did not establish current Ontolang conformance. The audit preceded the integration above; its historical logs record three stale diagnostic-text expectations, now corrected to current diagnostic wording during integration. The original live prototype was not migrated.

### The fire-and-derive loop (`rule-runtime/`)
`commit(ruleset, snapshot, batch) → CommitResult` — the reference execution semantics: pure, headless (no UI, no DataScript, no O'Doyle). Per commit attempt:

**guard** (the firing beat's preconditions, on the current snapshot) → **apply** (the batch onto a candidate snapshot, input untouched) → **derive** (recompute rule-holds to a fixpoint — the Formula seam is here) → **check** (postconditions + in-scope invariants, on the candidate) → **commit or reject**.

A rejected batch leaves the input snapshot exactly as it was ("nothing bad becomes real"). The whole derived set is recomputed from scratch each commit — correct and simple at seed scale; no truth maintenance because there is no incrementality to maintain (the fast engine is the scale answer, step 5).

- **The full rule fragment** — `rule-runtime/evaluate.ts`, the authoritative world-aware evaluator: **state · comparison · identity · cardinality**. Cardinality *counts across records* — the first counting capability, which the fast engine (step 5) must reproduce — and covers the grammar rebuild's additions: the **universal quantifier** (`all Review where …` — every instance passes the where; vacuously true on an empty world) and **field-valued bounds** (`at most Order.capacity Guest` — the bound resolves through the binding environment; unresolved fails closed). It reuses the render-layer evaluator's comparison helpers, so the symbol↔string seam is identical. **Every reference resolves through ONE binding environment** (joins tier 1): an AttrRef or identity EntityRef reads the instance its entity name binds — an explicit binding first, else the subject when the name matches the subject's type (slot labels `Type:Role` require their exact binding) — and an unbound reference is undetermined and **fails closed**, never misread against the subject's same-named field. Slot-labeled identity ACROSS beats ("the Guest who checks in is the Guest who booked" — 4 of 8 example domains + FHIR) still awaits the ratified story-context binding (`story Name about Type` declares a bound context; the fire supplies the instance — joins tier 2, ratified 2026-08-24, build queued; [ontolang backlog](../ontolang/backlog.md)).
- **Timing / polarity / attachment** — precondition = guard, postcondition & invariant = check; `must` holds / `must-not` fails; story-attached (by beat) and type-attached (invariant, over every instance of a directly or transitively affected type; see [dependent invariants](#dependent-invariants--2026-10-10)).
- **Stratification** (`stratify`) — the ruleset-compile contract; trivial today (the flat fragment is one stratum), the seam for when derived facts arrive. The contract it enforces: positive cycles are fine (the fixpoint converges), but a cycle **through negation or a count** is rejected at compile time (`unstratifiable`) — a count or absence test may only read relations already finished in a lower stratum.
- **The enablement chain** — the derived rule-holds set *is* the lifecycle (Coffee: exactly one command enabled per step).
- **Tested** — `rule-runtime/commit.test.ts` + `rule-runtime/evaluate.test.ts` (26 tests) against the Coffee (status-gate lifecycle), Hotel (confirm gate + stale re-fire refused), and Investment-Bank (no-rule) corpora, plus the timing axes and `must-not`. Run via `pnpm test`.

### Joins tier 1 — ref-hop paths + the cross-participant bind (2026-08-03)
A rule predicate now reads THROUGH refs, and a beat's gate can compare its participants — the two shapes the Foundry/OO comparison rated the top gap, forced by the lead-intake corpus (`Lead.territory.openLeadCount is less than Lead.territory.capacity` gating the routes beat; `Lead.region is Territory.region` gating the assigns beat).

- **Any-depth ref-hop paths** (`rule-runtime/world.ts`) — with the object catalog compiled into the ruleset, the world's `attr` walks a multi-segment path through ref fields: every segment before the last must be a **declared ref**, and each hop resolves the stored value (the target's **label**, `schema/instance-label.ts`) to its instance via `resolveRef` — the ONE hop mechanism, shared with the Formula traversal, spanning the refType's concrete subtypes. **Forward only**: no reverse traversal (aggregation `via` stays the sole reverse mechanism) and no transitive closure (parked with a tripwire in the [ontolang backlog](../ontolang/backlog.md)). Unset, dangling, or non-ref anywhere along the path → the atom is undetermined and **fails closed** (a must-gate rejects; nothing throws). Field and catalog lookups stay case-forgiving per segment (the `RoomClass`/`roomClass` precedent). Cardinality where-filters hop the same way (the member-relative tail walks the member's refs).
- **The cross-participant bind** (`rule-runtime/commit.ts`) — an `Assertion` may carry `bindings` (entity name → instance id: the firing beat's non-subject participants), and the loop **derives implicit bindings from the write itself**: every ref field the batch writes binds its declared refType to the referenced instance — the assigns beat's secondary participant IS the ref being written. Explicit entries win; the subject's own type never binds implicitly (a self-ref write can't hijack subject reads); two written refs of one refType drop that binding (ambiguity must not silently pick). Guard-time bindings resolve against the current world, check-time against the candidate (a batch-created ref target binds). Outside a fire (the derived enablement set, `deriveHolds`) a cross-participant atom has no binding and **fails closed** — per-instance enablement is advisory; the fire is authoritative.
- **The guard reads the derived truth** — `commit` recomputes Formulas over the CURRENT world before evaluating preconditions (previously it trusted stored copies, which a seeded world doesn't have). The routes gate is the forcing case: `openLeadCount` is a computed aggregation the guard must see fresh. The recompute is a read — a rejection still returns the input snapshot untouched.
- **The advisory read stays single-instance** — the store's `factLookup` now fails CLOSED on a multi-segment path (it used to misread the ref field's stored label as the value); a hop needs the whole world, which only the loop has. The suggestion floor (`rule-dsl/validator.ts`) walks declared ref paths, so a valid hop-path suggestion passes it; non-subject state/comparison suggestions are still rejected (a suggestion can't rely on the fire's write shape).
- **Tested** — `rule-runtime/joins.test.ts` (15: the two-hop gate opening and closing on the far value, a three-hop walk, unset/dangling/non-ref/no-catalog fail-closed, implicit + explicit + precedence + ambiguity + self-ref bindings, the unbound derived set) and `examples/lead-intake-routing.test.ts` (5: the REAL corpus file through the guarded write path — region mismatch rejected and match committed via the implicit bind, the capacity gate opening on a free territory and rejecting at capacity against the seeded givens, the routed count rippling into the territory, the unset-ref fail-closed).

### Side effects — the intent-fact lifecycle (`rule-runtime/intents.ts`)
The pure core derives intents; a platform executor carries them out exactly once. Layered on top of the loop (imports `commit`; `commit` does not import it).

- **`deriveIntents(agentBeats, snapshot)`** — an agent-subject beat whose precondition holds on an instance yields an **open, keyed** intent (`transition` or `emit`). Data, not an action.
- **`executeIntents(intents, ctx)`** — routes each by intent type (transition vs emit), acts **once**, and closes it **only on success** (its key enters `done`). A `transition` re-enters the **fire-and-derive loop** (guard re-checked → a stale intent, or a vanished target, is a *refusal*, not a phantom apply); an `emit` routes by **channel** to a **registered handler** (a handler that throws is a refusal — earlier effects in the batch are not stranded). A **refusal leaves the intent open** to retry; re-running over the same `done` set is a **no-op → replay-safe** (no double-sends). An intent with no handler stays open.
- **`step(ctx)`** — one crank of the agent loop (derive + execute); a depth-N agent chain advances one crank per call (the visible storyboard).
- **Exactly-once** is the content-addressed **key** (`intentKey` — a structured, collision-free `(beat, instance, effect)` identity); the `done` set is the closed-intent set (nothing deleted, closed only by successful action). Re-firing the *same* effect on the same instance later (recurrence) needs an occurrence token — deferred with the durable log. **Handlers may deliver, not decide** (the handler policy in [backlog.md](backlog.md)).
- **Tested** — `rule-runtime/intents.test.ts` (15 tests): Hotel's agent confirm (+ stale-refusal + no-re-derive), the emit handler (exactly-once, no-handler-stays-open), the failure paths (throwing handler, vanished instance, refusal-doesn't-poison-and-retries), multi-beat ordering, `must-not`/unset, and a two-step chain advancing one crank at a time.

### Invariant-derived required fields (`rule-runtime/required-fields.ts`)
Which fields a capture form must require, derived from the rules — deterministic, no LLM. `requiredFromRules(type, rules, systemFields) → string[]` feeds the form guard as the **third tier** beside explicit-`required` and ref fields.

- **The definition:** field F of type T is required at capture iff some **creation-gating** `must` rule — a precondition on the create/capture beat whose object is T, or a **type-level invariant** on T — has **every** DNF clause containing a non-negated atom on `T.F`. An unset F fails such an atom (the evaluators fail closed), so every clause fails, so creation can't commit — the form demands F up front.
- **What never requires:** negated atoms (unset satisfies them) · `must-not` rules · cardinality (counts across records) and identity (names no field) atoms · postconditions · story-attached invariants and type-attached preconditions (not creation gates). Both sides of a comparison count when they read T (`Order.deposit < Order.total` demands both); a cross-entity atom counts only the fields on T. System-managed fields are subtracted.
- **The accepted boundary:** a *disjunctive* creation gate (`total > 0 or exempt is :yes`) marks **nothing** required — no single field is in every clause; the write-time check catches it. The corpus has no such rules; revisit as clause-groups only if authoring grows them.
- **The wiring:** `requiredAtCapture(type, beat, projectRules, systemFields)` owns the per-beat scoping — this beat's rules count only when it instantiates/captures (a transition beat's gates guard the transition, not capture: an approval bound is not a form demand), and of the project's rules only the type-attached ones join. The studio's form derivation (`deriveBeatDocs`) calls it per beat and injects the result as `SerializeContext.ruleRequiredFields`; `ui-dsl/serialize.ts` marks the FieldSpecs; the FormView guard (submit blocked until every visible required field is filled) consumes them like any other required field. The serializer stays pure — injected data, same pattern as `systemFields`. The derived form is a **runtime** surface — pick-only over the declared domain.
- **Known boundary:** a *contributed* field (a picked subtype's delta, composed onto the form) is merged past the serializer, so a creation gate naming one isn't tier-3 marked — the write-time check is the backstop ([backlog](backlog.md)).
- **Tested** — `rule-runtime/required-fields.test.ts` (28 tests: the definition, the disjunctive boundary, every never-requires case, degenerate ASTs, system-field subtraction, slot labels, the per-beat scoping) + the serializer tier in `ui-dsl/index.test.ts`.

### The guarded write path + violation banners (`runtime/fire.ts`, step 4)
"Nothing bad ever becomes real" now holds in the **running app**, not just headlessly: a surface's write fires through the loop, and a rejection lands nothing and banners its reasons at the surface that fired it.

- **The bridge** — `fireCreate` / `fireTransition` (`runtime/fire.ts`): the instance store becomes the `FactSnapshot` (`instanceStore.all(project)` — every live instance), the write becomes an `Assertion`, `commit()` guards → applies → derives → checks. Only a committed batch reaches the store (one writer: the store's own create/transition, which keeps the append-only log — a rejection appends **nothing**); a rejected batch returns the loop's reason-bearing `Violation`s.
- **Beat identity** — a **transition** carries its beat's storyId (the doc's `sourceBeatId` provenance, stamped by `deriveBeatDocs`, excluded from the content hash), so the beat's story-attached preconditions guard it authoritatively. The gray-out (`rule-dsl/evaluate` via `isEnabled`) stays the advisory read in front; what the loop catches is the **stale re-fire** — enablement read from facts that moved — verified live (Coffee: a second Prepare on the same Order rejects with `precondition failed: Order.status is :ordered` and no log entry).
- **The banner** — `ViolationBanner` (studio, the modeling-lint banner family + the `--error` token): `⊘ Rejected` + each violation's message and instance, at the form's submit or above the command list; dismissable, cleared by the next successful fire. A rejected form keeps the user's values for a retry. The SystemFireBar fires every enabled instance through the guard and collects refusals into one banner — the batch doesn't stop at the first refusal.
- **Accepted boundaries** — the studio's **creates** still fire without a storyId, so create-beat gates don't guard them from the UI. The LOOP is ready for them now: `commit` checks a create's preconditions against the candidate (where the new instance is real), and a cross-entity gate through a written ref binds its participant (joins tier 1) — wiring the studio's create call sites to pass their beat remains open. Type-attached invariants still check the create's candidate (creation patch included). **Associate/emit** stay unguarded — no `Assertion` op exists for them yet.
- **Tested** — `runtime/fire.test.ts` (9 tests, real DataScript store): commit + log on success, the stale re-fire rejected with nothing landed, bare writes, the vanished target, must/must-not invariants on create and transition, and `instanceStore.all` as the snapshot source.

### Formulas — the full runtime (`rule-runtime/formula.ts`)
The third DSL's runtime half, complete: a **Formula computes a value** where a Rule checks one. `Field = expression` lives as `FormulaDef` on `ObjectField.computed` (the IR — hand-built in seeds today, exactly as Rules ship pre-parsed ASTs; the surface grammar arrives with the [rule-dsl](../rule-dsl/backlog.md) rebuild and emits this same shape). **The grammar type-resolves; the runtime never guesses** — each meaning is its own node kind (`+` over strings is a `concat` node, `date + 30 days` is a `date-shift` node), so evaluation stays deterministic and fail-closed.

- **Expressions:** literals (numbers and strings) · field paths · numeric `+ - * /` · `days between` two dates. **Ref traversal** — a multi-segment path (`reservation.room.rate`) hops ref fields by resolving the stored value (the instance's **label**, the shared convention in `schema/instance-label.ts` — the same value the picker stores) to the target instance. Fail-closed throughout: unset operand, dangling ref, division by zero → the computed field stays unset, and rules on it fail closed.
- **Aggregation:** `sum | count | min | max | avg of Entity[.field] [where …]`. Scope flows through refs: `via` on the IR names the ref field on the *aggregated* entity that must point back at the subject (the multi-ref decision is made at authoring time and carried in the IR; absent = global). The member span includes concrete subtypes, like the ref hop. **Where-filters use rule-cardinality semantics exactly** (an unresolved operand = the member doesn't match — one mechanism for the fast engine to reproduce); a *matched* member whose aggregated field is unset poisons the aggregate (a member is an operand). Empty match set: sum/count `0`, min/max/avg unset.
- **The conditional form:** value-first, first-match, else mandatory (`100 if total > 500, 50 if …, else 0`). Each case's `when` is a rule DNF (logic = words) evaluated by the authoritative world-aware evaluator against the subject — with the in-progress candidate folded in, so a case can gate on fields computed in the same derive.
- **Date ± duration:** whole-number durations (integer timeline) in minutes · hours · days · weeks · months · years. Day-family shifts preserve a trailing time-of-day; month/year shifts **clamp to the target month's last day** (Jan 31 + 1 month = Feb 28, never Mar 3); minute/hour shifts require a time-of-day (a bare date fails closed). The shift amount may be a field (linear arithmetic).
- **String concat:** a `concat` node joins parts (numbers stringify); an undefined part fails the node closed.
- **The derive step, for real:** `recomputeFormulas` (the seam named since step 1) folds computed values into the candidate to a bounded fixpoint BEFORE check — so **rules gate on computed values**, aggregates included (an invariant on `Order.subtotal ≥ Order.minimum` rejects the violating write). Chains converge: computed line totals feed a computed subtotal in one derive. The object-field catalog rides `CompiledRuleset.catalog`.
- **Write-back + ripple:** a committed write carries the candidate's computed fields through the store (`runtime/fire.ts`), and now **ripples**: any *other* instance whose computed fields the derive changed (an aggregation lives on the Order, not the LineItem; a Room-rate edit moves Invoice totals) is mirrored through the store as its own System-actor log entry (`recomputed subtotal`) — the stored world stays equal to the world the loop checked. Boundary: a CLEARED computed value corrects the loop's view every fire, but the store's copy persists until a write next touches that instance (the store's transition merges; it cannot delete).
- **Rendering:** computed fields are read-only everywhere and excluded from capture forms (like system-managed fields); they appear as list columns and in emit payloads.
- **Not yet:** unit algebra (`int × money = money`) and authoring-time acyclicity enforcement (the bounded fixpoint terminates a cycle instead) — both land with the surface grammar's totality validator (the [rule-dsl](../rule-dsl/backlog.md) rebuild).
- **Tested** — `rule-runtime/formula.test.ts` (42: the expression fragment, traversal, fail-closed, the derive seam, rules-see-computed; aggregation ops + via-scoping + where semantics + subtype span + the converging chain gated by a rule; the conditional's ordering/else/fail-closed/candidate-visibility; date-shift families + clamping; concat) + `runtime/fire.test.ts` (the ripple: a LineItem create/transition mirrors the Order's subtotal, visibly logged) + `examples/seed-hotel.test.ts` (the REAL hotel seed, v10: the confirm/decline **branch**, the **two-level derived chain** — `Service.charge → Reservation.serviceCharges` (aggregation) `→ Invoice.total` (ref traversal) — rippling into an existing invoice, "Guest pays Invoice" closing the loop, and every computed field round-trip-pinned to the Formula grammar).

### Time-flow — comparable `now`, the clock tick, standing violations (`rule-runtime/clock.ts`)
Time enters the loop as a fact. `FactSnapshot` carries `now` (a date on the integer timeline — its day number is the whole number the DSL compares); both evaluators resolve the `now` literal against it (absent → fails closed, the pre-time behavior — so a clockless world is untouched).

- **`tick(ruleset, snapshot, now) → TickResult`** — the clock's loop entry point: advances `now`, recomputes Formulas, re-derives the rule-holds (the enablement chain moves with time — a `now`-gated command can become enabled by a tick alone). Where a write can be rejected, **time always passes**: a type invariant `now` crossed with no write to reject comes back as a **standing violation** (`kind: 'standing'`, per instance, over EVERY instance of the invariant's type — the clock touches the whole world) — a banner and a legitimate intent trigger, never a rejection. `deriveIntents` over the ticked snapshot fires `now`-gated agent beats (the escalation path).
- **Guards see the clock:** `FireDeps.now` threads the project clock into the guarded write path, so a `now` precondition (`no early check-in`) gates commands authoritatively; the advisory `evaluate(dnf, facts, now)` gray-out matches.
- **Authoring for time (the clock-safe idiom):** a `now` invariant should say when it STOPS applying (`status is "checked-in" or … or not now is more than checkIn`) — the disjunct is what lets the fixing write commit while the violation stands, and the **negated form fails OPEN without a clock**, so seeded time rules are inert until the first tick.
- **The studio surface:** the render harness's **ClockBar** — a date + TICK control; standing violations render in the step-4 banner family with the `⧗ Standing` label (the one non-rejection in the family). The chosen `now` threads into every fire and gray-out on the page. The **hotel seed** (v10) carries the demo: the no-early-check-in gate and the check-in deadline invariant — create a reservation, tick past its check-in day, the lapse banners; checking in still commits.
- **Tested** — `rule-runtime/clock.test.ts` (8: the gated precondition by clock, no-clock fail-closed, tick-before/past-deadline, the fixing write on a lapsed world, enablement moving with the tick, the `now`-gated intent) — plus the live path verified in the browser.

### The `@default` create-time write (2026-08-04)
A field may declare `@default(value)` (ontolang's `@` attribute — [ontolang spec](../ontolang/spec.md)); **the loop's create writes it**. Shared creation-default logic fills every declared default its own fields don't set in both Story preparation and commit's APPLY step. Derived newborn guards therefore read the same born-with values the committed candidate carries back through the store (`fireCreate`'s write-back, the instantiate log entry included).

- **Unset means absent or `''`** (a cleared form input); an explicit value always wins, falsy included (`0`, `false`).
- **`@default(now)`** — the only timestamp default — writes the snapshot's clock: the same comparable `now` the tick advances, read at the creation instant. **No clock → the field stays unset** (pre-time, matching `now` predicates failing closed). The sentinel is type-scoped: a *string* default `"now"` writes the literal.
- **Money defaults are already minor-unit integers** in the schema (the loader scales) — written as-is.
- **Written once, then ORDINARY:** the field is user-editable through the guarded write path afterward (unlike a computed field); a transition never re-fills. Never on a computed field or a status enum — the loader rejects both (a status is born as its first declared value, the birth patch's job).
- **The capture guard is exempt:** a declared default removes the field from every create-time required tier, including owner/actor command schemas and `ui-dsl/serialize.ts` (explicit `@required`, rule-derived; a ref can't carry a default) — the field receives its value at create, so an empty input must not block submit. Update requirements remain unchanged. Presentation stays **derived** — no pre-fill/hide language fact, no per-form flag (the ontolang target-format doctrine).
- **Tested** — `rule-runtime/commit.test.ts` (7: every default kind at create with money as-is, the clock value, no-clock unset, explicit-wins/`''`-fills, the type-scoped sentinel, ordinary-after, a create gate reading the born-with value) + `ui-dsl/index.test.ts` (the guard exemption, tier by tier) + `examples/lead-intake-routing.test.ts` (the corpus exit: `submittedOn` fills through `fireCreate`, `Lead.triageDeadline`/`contactDeadline` compute off it, and the SLA `always` rules ARM — the tick past the deadline raises the standing violation that the unset field had left vacuously satisfied forever).

### `@unique` — the standing index check (`rule-runtime/unique.ts`, 2026-08-04)
The ontolang riders' runtime half: a field declared `@unique` (`ObjectField.unique` — the `@` attribute the parser emits) is enforced over the world, **as a standing violation, never a write refusal** — the duplicating write COMMITS (an import, a race, a correction in progress — the world is allowed to be in that state), and the world stands ⧗-flagged until someone resolves it. The authoring half (the field editor's unique toggle) stays in the [entity-authoring backlog (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/entity-authoring/backlog.md).

- **The check** — `uniqueViolations(snapshot, catalog, subtypesOf?, types?) → Violation[]`: index each declaring type's `unique` fields over its current members; a shared value yields ONE `kind: 'standing'` violation per collision **group** (declaring type · field · value) naming every colliding instance. Callers supply their type context for [inherited and role scopes](#inherited-uniqueness-and-canonical-enum-values--2026-10-11). No catalog → nothing to check (the rules-only path is untouched).
- **The locked semantics** (owner, with the attribute decision): **unset never collides** — the check fails closed on missing values like every evaluator; **matching is exact** — Map-key identity (SameValueZero), so no case-folding, no normalization, and a number never equals its string spelling.
- **The maintenance pass** — `tick` appends the index check to its standing set (recomputed from scratch, like the invariants), so resolving the duplicate clears the violation on the next recompute. In the studio the **ClockBar** — the standing-violation surface — also derives the set **live** against the store on every render (the host re-renders per store change): a committed duplicate banners at once and the banner clears when the data heals. The live banner has **no dismiss** (`ViolationBanner`'s `onDismiss` is now optional): there is nothing to dismiss away — fixing the value is the only exit. The tick's own banner keeps the time-family violations; the live derive owns the unique family at that surface.
- **Tested** — `rule-runtime/unique.test.ts` (10: the collision group naming field + instances, the duplicating write committing, three-way groups, per-field independence, no-catalog, both unset-never-collides shapes, case-exactness, number-vs-string, tick-surfaces-and-clears) + the corpus exit in `examples/lead-intake-routing.test.ts` (`ContactForm.email @unique` from the loaded `.onto` file: duplicate submit commits, stands in the tick beside the quiet SLA invariants, unset and case-variant emails add nothing, correcting the email clears it).

### The advisory read (clock-aware, fail-closed on world-scoped shapes)
- `rule-dsl/evaluate.ts` — the pure single-instance `evaluate(dnf, facts) → bool` the render layer uses to gray out a command (pull, not push). State + Comparison; Cardinality + Identity fail closed, and so does a **ref-hop path** (joins tier 1 tightened this from misreading the ref's stored label: a hop needs the whole world, which only the loop has — a hop-gated command grays out conservatively and the loop decides). The loop's guard is the *authoritative* version behind this advisory display read — since step 4, literally: the same click that the gray-out allows is re-checked by the loop before it lands.

### The runtime catch-up — the story execution over the ratified clause family (2026-09-05)
The owner ruled (2026-09-04) that the runtime catches up to the language before anything is built on it. Every construct the loader emits on a story datom (`story/sets` · `story/where` · `story/finds` · `story/grants` · `story/revokes` · `story/adds` · `story/about` · `story/every` · `story/correction`, plus the participant tokens with their labels) now executes in the reference loop. The loop's shape is unchanged — guard, apply, derive, check, commit or refuse; refusals named and sourced; standing violations never block; fail closed on unset, dangling, or undetermined — and a **story execution** now sits in front of it.

- **The compiled model** (`rule-runtime/model.ts`, `compileModel(seed)`) — the loaded project (the loader's `ProjectSeed`, or the studio's equivalent) becomes what the loop executes: the **type system** (`TypeSystem`: transitive object subtypes, `is a` chains, derived subsets with their `@where` predicate parsed through the rule grammar), the **chain-merged field catalog** (a subtype reads its base's fields, a role its own capability fields), the parsed rules (story gates attached by story id, invariants by type), and one **compiled story** per story datom: its tokens (`Type:label` verbatim), `about`, `every`, `@correction`, the classifier category, the **creating-door verdict**, the gates and every clause in resolved form, the tokens some clause **consumes**, and — for a system story — the **D11b self-extinguishing verdict**. The creating door is the loader's rule read back (sharpened in this build, `ontolang/parse-project.ts` `creatingDoor`): nothing on the story or its enclosing stories presupposes the record exists (no gate on the primary's status, no `where` naming it, no `finds` reaching it); then a status-bearing primary needs its **written birth line** on a creating or unknown verb, and a status-less primary has only the classifier's instantiate verdict. Open roles (no seed, no `grants` anywhere in the model) and diagnostics (system steps that would loop) ride the model.
- **The seed world** (`rule-runtime/seed.ts`, `seedWorld(model, now?)`) — the corpus's `seed` rows as a deterministic `FactSnapshot`: ids `Type:label`, a role seed as its **base kind plus the holding** (Kerem is a `Teacher` holding `AssistantTeacher`), **name-pointing resolved to links at absorb** (D11d — `roomClass: "Standard"` becomes the RoomClass's id; exactly one match or an error), one-to-one pairs materialized on both sides.
- **Ref values are instance ids** in the reference world (a execution writes the bound instance's id; seeds resolve at absorb); every read also accepts the target's **label** (what the studio's pickers store), so a label-storing world evaluates identically — the label is a fallback, never the identity (`world.ts` `resolveRef`, `refersTo`).
- **The execution** (`rule-runtime/execute.ts`, `executeStory(model, snapshot, input)`) — binds subject, target, participants and context, validates explicit actor eligibility, prepares clauses, checks gates and finality, commits or refuses, then derives Formulas. An action never enrolls its actor. Public roles may omit the subject only when no clause consumes it.
- **`every`** — the marked type's members are listed **once at executing**; each member runs the whole execution on its own through the normal write path with its own run key (`(story, run id, member)`); a later member sees earlier members' commits. Zero members: nothing runs, the execution commits as a whole.
- **Holdings** — `grant`/`revoke` are assertions the loop applies (`world.ts` `applyAssertion`): re-granting a held role is a no-op, a revoke closes the holding and drops its capability facts from the read view; a holding **counts only while every base role in its `is a` chain is held** (D13a — `countsAs`), so revoking the underlying role blocks the dependent one at once.
- **One-to-one pairs** (ratified 2026-08-26) — two scalar refs between the same two types are one relation, kept **materialized on both sides** by the loop's apply step (`commit.ts` `applyWrites`): a ref write on either view is the plain move — the far side names the writer back, and every displaced view clears. Implicit pairing resolves the source field's declaration owner through inheritance. A directed self-reference never pairs with itself, and a subtype-specific ref never acquires an unrelated base ref as its inverse. An explicit `@of` can still declare a symmetric self-pair. Reference, seed and SQLite regressions cover sibling preservation, relinking and affected Formulas.
- **Quantified gate bindings** — counted members are local to the scan; free outer references and field-valued bounds remain consumed inputs. The [record binding contract](#record-bindings-in-quantified-gates--2026-10-10) covers exact labels, collection bounds and distinct `finds` slots.
- **The evaluator** (`rule-runtime/evaluate.ts`) — the **collection quantifiers** execute (`every`/`some`/`no`/`all`/a counting bound over the members of a `Type[]` link, element-rooted predicates, the trailing and introducer-first layouts; an unbound owner fails closed; over an empty collection `no`/`all` hold and `some` fails — paired subsets partition); a **type scan is polymorphic** through the type system (a Product count spans Drink + Pastry, a role scan returns holders, a **derived subset** scans its base and recomputes the predicate live); a role-typed subject reads through its holding.
- **The system-step runner** (`rule-runtime/system.ts`) — a story whose actor is `@type system` (and not external) executes by itself: the **enumerated arm** — one candidate per tuple of records its conditions admit (the object when the story does not create it, each participant a clause consumes, each joint `finds` answer); `deriveSystemExecutions` keeps the candidates whose execution **would commit** (a dry run) minus the keys already done; `systemStep` is one crank — a tick first if one arrived (time always passes; the standing set comes back), then each derived execution once, threading the world; a refusal leaves the execution open. A step the model diagnosed as **never self-extinguishing** (its writes never falsify its own gate — D11b) is never auto-executed; an **effect step** (emit/log — no world write) is extinguished by its effect record and routes to a handler by the story's sentence (none → stays open). `nextDeadline` is the **sorted-deadline check**: the earliest future date any `now` comparison in the model crosses — when a scheduler should wake and tick.
- **The studio's write path carries the marks it needs** — `runtime/fire.ts` passes the model's `@correction` marks to the loop (`FireDeps.corrections`, filled by `makeFireDeps` from `queryCorrectionStories`), so a story-fired command out of a finished status is refused and a `@correction` command commits, the gray-out agreeing; and the ripple now mirrors a one-to-one pair's far side into the store as its own `linked …` log entry, beside the recomputed fields (a create's far side names the record the store minted, never the loop's scratch id). Pair maintenance acts on **identity only** — an id, or a label exactly one record carries; an ambiguous label maintains nothing, because names are never identity. The ruleset **memoizes** its catalog and subtype lookups for its life (`compileRuleset`), and a world its per-instance field lists: the studio's lookups are DataScript queries, and the world asks on every hop and scan — unmemoized, one gray-out dry run cost ~700 ms against the real store (2026-09-09); memoized, ~5 ms. The doors themselves still send a bare create or transition (below).
- **The advisory read applies polarity** — a surface's `enablementRuleIds` now carry every precondition gate, `must-not` included (`render-layer/mapping.ts`, `contract.ts`), and `rule-dsl/evaluate.ts` `evaluateRule` is the polarity-aware single-instance read; the studio's gray-out was already the loop's own verdict run dry (`enablement.ts` → `wouldCommitTransition`), so a `forbids` gate disables its command exactly as the guard would refuse it.
- **The refusal vocabulary** (`types.ts` `ViolationKind`): `rejected-precondition` · `rejected-postcondition` · `invariant` · `standing` · `unbound` · `not-eligible` · `rejected-finds` (with `detail`: type, token, matched, each line's count) · `rejected-where` · `rejected-final`. A execution refuses at the first failing stage with every failure of that stage (finds → where → gates + `@final`), then the loop's own checks.
- **The execution log — the conformance fixture** (`rule-runtime/replay.ts`, `examples/execution-logs/*.json`, `rule-runtime/conformance.test.ts`) — a plain-JSON log names a corpus, an optional starting clock and extra world rows, and steps (`execution` · `tick` · `system` · `assert`) each with what the runtime must produce: committed or refused by name, the world afterward as facts (instances, fields, `@holdings`; refs as ids; `null` = unset/absent), standing violations, per-member runs, the executes a crank committed and the intents it left open, counts, derived holds, the next deadline. Any other implementation of the loop replays the same logs against the same corpora and must reach the same answers. Six logs pin the constructs on their corpus exemplars: **coffee** (the lifecycle through the execution, sentence-name fill, written birth, `@final`, explicit actor eligibility) · **sangha** (`finds` zero/one/two with the D8a counts, the actor-pin `where`, `grants`/`revokes` with the D13a scan, eligibility on closed roles, derived subsets recomputing, `per` counting) · **hotel** (`Type:label` clauses, ref writes, `adds` through `finds` with the aggregation rippling, the system confirm, the clock gate, `nextDeadline`, the standing deadline, the `@correction` reopen, the one-to-one invoice pair, `unbound`) · **lead-intake** (the system chain — consumed form, routing, the alert step extinguished by the created record; `@default(now)`, the SLA tick, `@unique`, the modify door) · **investment-bank** (`about` context: the unbound refusal and the birth-story exemption; subsets as actors; `every` minting one letter per current Buyer with the sentence-name fill) · **canna-manufacturing** (subtype lifecycles, `finds` on the lab sample, `adds` into the vault with the collection aggregation, the external actor, the effect step).
- **Corpus and loader changes that rode along** — the creating-door rule sharpened (ancestors' gates count; `where`/`finds` on the primary count; the written line decides for status-bearing primaries; a sub-story under a gated story no longer gets an invented birth line) · lead-intake: `ContactForm.status` (submitted → consumed, the intake step's extinguisher) and the alert as `System opens LeadAlert for AccountExecutive` with `finds Lead` + `requires no LeadAlert in Lead.alerts` (the corpus's former alert story could never extinguish itself) · investment-bank: `Deal.status` (pitched → mandated → marketed → closed) with the origination as the birth story, and `ProcessLetter` as a record per buyer (`drafts ProcessLetter for every Buyer`, `Buyer answers ProcessLetter`) · canna: `draws TestSample` (the sample is born there) · the record-label app seed gained the gates its transitions were missing.
- **Tested** — `rule-runtime/model.test.ts` (creating doors, tokens, consumed names, D11b verdicts + the diagnostic, explicit eligibility, chains/subsets/catalog, rule attachment) · `seed.test.ts` (ids, role seeds, name-pointing exactly-one, pair materialization) · `world.test.ts` (countsAs incl. D13a, resolveRef id-then-label, subsets, link members, unscanned, scalarPartner, holdings apply) · `clauses.test.ts` (condition semantics fail-closed, joint finds, the D8a counts, both `where` forms) · `quantifiers.test.ts` (every quantifier layout, the empty collection, the unbound owner, polymorphic counts) · `commit-writes.test.ts` (grant/revoke, `@final` + the correction channel, pair moves, `gatesChecked`) · `story.test.ts` (binding, labeled tokens, the anonymous execution, fills and their ambiguity, defaults, the modify door, `adds`, conferral no-ops, `every`) · `system.test.ts` (enumeration, the dry-run derive, done keys, cranks, tick-in-crank, effect steps, `nextDeadline`) · `replay.test.ts` (the player's own contract) · `conformance.test.ts` (the six logs). Run via `pnpm test`.

**Assumptions taken where a ruling left a runtime detail open — for the owner:**
1. **Refs store ids** in the reference world (labels accepted on read). The rulings speak of "the link, never the text" (D11d); the studio still stores labels — its wire format is the data-and-transport session's call.
2. **Refusal order** — finds, then where, then gates with `@final`, then the loop's checks; a execution reports every failure of the first failing stage only.
3. **The guard world reads the newborn but never scans it** (counts, members, subsets see the world before the act). Nothing ratified says which world a creating story's `requires` reads; this keeps both `requires Lead.contactForm exists` and `requires no LeadAlert in Lead.alerts` meaningful.
4. **Anonymous execution requires explicit public access.** Consumed actor clauses still require a bound actor. Enrollment is a separate trusted operation; there is no first-action conferral.
5. **System steps that write nothing (emit/log) are extinguished by their effect record**, not by the world; the D11b check applies to writing steps, which must falsify a gate or are diagnosed and never auto-executed. A system story's participants no clause consumes are narrative, not enumerated.
6. **Holdings are written in the batch, atomically with the execution** (the 2026-08-18 text says the commit emits an assignment intent the executor performs; in the reference the batch is the one writer — a refused execution grants nothing).
7. **A transition with no story is the correction channel** (D10d's "direct edit on a live record IS a correction") — it may leave `@final`; a story-executed step may not unless `@correction`.
8. **An unknown verb with a gate-less status write is a birth**; a transition reads its from-status. The record-label seed's gate-less transitions gained gates for this reason. **Status-less objects have no written birth** — their creating door is the classifier's instantiate verdict (`offers MonetaryDonation`, `sends Invoice` classify as emit and create nothing) — the point-event gap; a written mark would close it.
9. **The modify door** — form values on a bound record for a non-creating story are data the door supplies, not a clause.
10. **`every`** — the execution commits as a whole iff every member run committed; a refused member never blocks the others.
11. **`where … is not` fails closed on an unset or dangling link** (query semantics), unlike a rule's `not` form.

## Not built
Production rollout, real provider configuration and broader view presentation remain in the [current backlog](backlog.md). The local Worker and signed webhook adapter are built. Shared TypeScript execution over SQLite is the engine; a separate fast-engine port is not planned.

## Studio transitions publish on the current runtime (2026-09-29)

`exportApplicationSource` (runtime/application-source.ts) chose the
recovered prototype for any studio project whose stories used only the
state rail's status change — the legacy `story/transition-to` edge —
because its routing list named the clause family but not the edge, and
the prototype's contract then refused the edge ("…does not support
story/transition-to. Publication was stopped"). Export now translates the
edge into the ratified written clause (`sets <primary>.status to "<v>"`,
unless the story already writes the status) and routes the edge, and the
composer's participant/label data, to the current runtime. Pinned in
runtime/application-source.test.ts. Publication may now surface the
current runtime's own model checks (e.g. a status nothing sets) — those
are real, actionable model errors, not the prototype gate.

## Hosted Coffee acceptance — 2026-10-25

A fresh installed tarball built from `0d493dc7` deployed the packaged Coffee
example and default presentation through the same standalone interface used by
local Wrangler. The user approved a scoped Wrangler device login; the runner
retrieved its OAuth access token privately, discovered the matching account and
created Worker `onto-coffee-b3c77896`, its effects Queue, SQLite Durable Object
class and Static Assets. No manually created API token, Studio endpoint/database
or Clerk account was used. The application signing key was generated and retained
in the local credential store, separately from Cloudflare authentication.

The retained [Coffee application](https://onto-coffee-b3c77896.onto-mcp-code-mode-runner.workers.dev/apps/74fafeafdf998f913457ac4b268fc2698ee1c0e903a3b37975254fa683f510f6)
uses project UUID `b3c77896-6309-4891-824e-f2e0c5ac5fdb` and runtime generation
`0e827866-89cc-469d-b743-89f227d67175`. Real hosted checks passed:

- Application/assets serving, one-use participant code claims, Secure/HttpOnly
  cookies, wrong-origin rejection and participant/owner authorization boundaries.
- Customer enrollment, published plan/design reads, WebSocket readiness and
  invalidation after execution; eight concurrent identical requests produced one
  order. Changed payloads and stale generations were refused.
- A compatible model update added `Order.note`, rebuilt its presentation and
  redeployed the actual Worker. The project generation, participant session,
  order and receipt survived. The updated release is `3cbe06be30fa2764ec5ae07c14dff512b966e7b502e85b6e32faab3aa7d9a776`.
- Concurrent presentation-only publication refused a stale release revision;
  participant logout invalidated the session.
- Browser QA completed sign-in, Customer enrollment, a plan-selected order and
  visible live record update on the hosted application.

These are hosted fixture checks, not production readiness or owner UX acceptance.
Platform eviction/cold-start durability, native recovery, quotas/load, external
provider delivery and optional Clerk handoff remain unverified. Worker
redeployment is not evidence of platform eviction. The reference Studio/staging
host and its migration/configuration remain separate work.

## Standalone Cloudflare browser login — 2026-10-25

`ontolang-deploy login` uses Wrangler OAuth with OS keychain storage and a fixed
scope set: account/user read, Workers scripts write and Queues write. The user
approves browser consent; `--device true` supports remote terminals and
`--browser false` lets the user choose the correct browser profile. Deployment
retrieves a current token through Wrangler's default profile, which refreshes an
expired OAuth session. Tokens stay in runner memory and child environments, with
Wrangler disk logging disabled. They never enter manifests, release files or
command arguments. Login is explicit; missing/revoked authentication fails with
the login command rather than opening a browser during deployment.

Account discovery follows paginated account results and matches the requested
workers.dev subdomain. Multiple accounts never cause an arbitrary first-account
selection. An explicit account ID must match; unmatched or ambiguous discovery
fails before infrastructure mutation. CI API tokens remain supported and take
precedence over OAuth. Preflight and deployment use the same selected credentials
despite inherited global keys, aliases or Cloudflare API endpoint overrides.
The [deployment guide (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/hosting/DEPLOYMENT.md#hosted-cloudflare-target)
owns login commands and operational details. Mocked authentication and full
runner tests cover OAuth, API tokens, account discovery and refusal paths. The
[Coffee fixture](#hosted-coffee-acceptance--2026-10-25) also verifies actual OAuth
deployment and participant sign-in.

## Standalone correctness review — 2026-10-25

The deployment review reproduced and corrected unsafe update paths. Before
hosted infrastructure changes, the runner verifies Worker project/environment/
origin bindings and authenticates the saved credential. It refuses foreign Queue
producers/consumers, missing credentials and unexpected generation changes.
Connecting is read-only with respect to credential creation. Local manifests with
missing/mismatched durable generations cannot silently create replacement state.
The [deployment guide (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/hosting/DEPLOYMENT.md) owns the operational steps.

Release publication now compares `expectedReleaseRevision` inside the serialized
project operation in addition to the business revision. Presentation-only edits
therefore conflict when another publisher changed the release. Unauthorized
publishers are refused before release compilation. Release sizes count UTF-8 bytes;
admitted nested snapshots are detached from input objects. V1 canonical ordering
is fixed to `en-US` across runner locales, retaining earlier English hashes without
changing the existing host receipt-hashing behavior.

Regression evidence includes real installed-consumer workerd refusal of concurrent
presentation overwrites and generation mismatch, plus host-session replacement
and persisted receipts across restart. Mocked Cloudflare preflight tests cover
existing Worker/Queue collisions and missing/rejected credentials. English/Turkish
subprocesses produce the same release hash. The subsequent
[Coffee fixture](#hosted-coffee-acceptance--2026-10-25) provides hosted evidence.
Infrastructure deployment is not transactional with release publication, and
hard-crash lock recovery remains manual; the [backlog](backlog.md#hosted-verification-still-required)
keeps those operational limits separate from the local correctness checks.

## Request bounds and portable imports — 2026-10-25

The full PR #220 review reproduced two integration failures. Unauthenticated
request parsing could accumulate one validation error per invalid array/map
entry before rejecting the request: 30,000 short entries fit within the HTTP
byte limit. The host now requires Zod 4.6.6 or later, which checks array bounds
before traversing members. Input maps are limited to 256 entries and actor-binding
maps to 100 before value validation. Normal scalar/field limits still apply.
Regression tests cover both arrays and maps; the real workerd harness sends
unauthenticated oversized requests and requires a single bounded diagnostic.

Directory releases now preserve the portable `imports.json` vocabulary snapshot,
alongside Ontolang sources and supported companions. The previous allowlist
silently omitted it, making otherwise valid exported projects fail admission.
Tests reopen pinned imports with their original directories absent, compare the
exact release revision with direct file export, reject tampered digests, and
exclude unrelated JSON files. The installed-consumer check exercises this through
the shipped deployment entry point.

Review coverage includes the complete PR delta (including the consolidated
language package), host/Studio authorization, enrollment and browser sessions,
read filtering and actor bindings, receipt replay and partial batches, nested
SQLite rollback, formulas and vocabulary contracts, queues/provider signatures,
live subscriptions, presentation admission/rendering, deployment ownership and
credential handling, packaging and current staging integration. The generated
Fact Log viewer conflict with staging `55a6c4c9` was resolved by rebuilding it
from the merged sources.

Combined-branch validation passed: `pnpm test` (3,501 passes and one existing
skip, including 186 package tests and 335 MCP tests), host type checks/dry-run
build, 39 frontend/host unit tests and the real workerd scenarios for all 16
canonical projects, 46 deployer/release/session tests, the fresh installed
consumer deployment, Studio TypeScript, 149 CLI tests and three local database /
publication migration tests. Both newly reproduced
failures were tested before and after their fixes. The dependency scan remains
non-clean: the root audit reports 6 critical, 81 high, 68 moderate and 24 low
findings, including inherited Studio/tooling dependencies; the separate hosting
lockfile reports 5 high, 7 moderate and 3 low. These counts are advisory matches,
not verified exploit counts. See the [maintenance and acceptance work](backlog.md#next-todo-headless-publication-in-three-stages--2026-10-25)
before production rollout. Local tests do not establish platform recovery,
load/cost limits, Windows runner behavior or real production provider delivery.

The existing hosted Coffee fixture was updated with the reviewed Worker from
`f089e659` at 2026-10-26 06:05 UTC. Real unauthenticated array/map requests each
returned HTTP 400 with one diagnostic and a response below 1 KB. The application
page remained available; generation, model hash, release revision and business
revision (5) were unchanged. This is security-patch acceptance on the same fixture,
not a new project or a replacement dataset.

GitHub's package and runtime-host jobs for `f089e659` did not start: both report
an account payment / spending-limit block. Local validation above passed, but
remote CI confirmation still requires resolving that account issue and rerunning
the checks.

## Repeated admission and dependency review — 2026-10-26

The repeated review found a release/host admission mismatch. `createRelease`
compiled input without applying `validateSource`, allowing duplicate initial
record IDs, invalid read-policy shapes and files/paths above host limits. Such a
release could reach infrastructure deployment before the host rejected it.
Release creation now uses the host's source validator before compiling. Four
regressions failed before the fix and pass afterward; a deployment regression
also submits a correctly hashed invalid release and verifies that no Cloudflare
requests or deployment-state writes occur. Valid v1 release hashes are unchanged.

Studio's Next.js, `@next/env` and `eslint-config-next` move from 16.1.6 to 16.4.3.
Transitive overrides require DOMPurify 3.4.17 and proxy-addr 2.0.8. These address
the six critical matches in the earlier audit, including the upstream
[Next.js image-optimization](https://github.com/advisories/GHSA-2464-fhr4-w9xw),
[cache](https://github.com/advisories/GHSA-673q-mjm6-r5xr),
[DOMPurify](https://github.com/advisories/GHSA-cg2g-xh64-v4q7) and
[proxy-addr](https://github.com/advisories/GHSA-jqcg-44mw-7w3h) advisories.
The local Studio production build passes with the patched versions. The root
audit now reports 0 critical, 58 high, 49 moderate and 16 low matches. This is an
improvement, not a clean dependency assessment; the independent hosting lockfile
and remaining production acceptance work still need the backlog's follow-up.

The combined rerun passes 3,501 main-suite tests (one existing skip), 43
frontend/host tests, 51 deployment/release/session tests, 149 CLI tests and three
database/migration tests. The real workerd checks pass all 16 canonical examples,
including authorization, rejected-write rollback, concurrent receipts, restart,
sessions, alarms and queued delivery. The fresh installed consumer passes
publication, execution, restart and compatible update. Studio builds pass with
both Webpack and the default Turbopack path; a production-server HTTP smoke on
the documented `localhost` origin returns 401 for unauthenticated management and
400 for unsupported participant publication. The final source recheck found no
additional confirmed authorization or rollback defect. These checks do not
replace remote CI, real Clerk owner-flow acceptance or the operational drills.

## Published presentation releases — 2026-10-25

A version-1 `ontolang-release` adds optional `frontend: default | none`; omission
keeps the default renderer and preserves earlier v1 release hashes. It also adds optional `{ version: 1, renderer: shared, plan, design? }` presentation data.
The plan binds the admitted model hash and a validated entity/field/command
contract; unknown fields, executable extensions and stale model references are
rejected before publication. Design snapshots use schema/resolver version 1 and
normalized allowlisted choices. Both contribute to the canonical release SHA-256.
A model update must supply a matching plan or omit it; there is no fallback to an
incompatible old snapshot. API-only releases reject presentations.

The whole release JSON and revision occupy `_host_release` in the same project
SQLite database and transaction as model publication. Failed validation leaves
the prior release intact; compatible updates retain identity, facts, authorization,
receipts and sessions. Presentation-only updates invalidate live views without
resetting business data. No Studio database or asset bucket is involved.
The authorized `presentation` read returns only the presentation/release revision
and generation/model fences. The shared renderer lives in Workers Static Assets;
`frontend: none` makes `/apps/<id>` unavailable while retaining the project API.
The [rendering spec (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/rendering/spec.md#published-plan-renderer--2026-10-25)
owns the participant behavior and custom frontend descriptor boundary.

Release admission, isolated installed-consumer workerd tests and renderer tests
cover persisted plan/design snapshots, changed-model rejection, forged revisions,
restart/update and API-only updates with retained receipts. Local browser QA
completed code sign-in, Coffee enrollment, a plan-selected command, live record
rendering and sign-out. Hosted Coffee deployment/sign-in are now
[verified](#hosted-coffee-acceptance--2026-10-25); owner UX acceptance remains
pending. See the [acceptance guide (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/hosting/DEPLOYMENT.md).

## Ontolang host integration — 2026-10-25

PR #220 incorporates PR #240 at `e41b7062`. The single package retains the
`language/` and `runtimes/typescript/` layout and all public language/runtime
entries. Host-independent republication compares both compiler and interpreter
versions, preserving durable records and receipts through compatible updates.
SQLite candidate execution uses the host's atomic transaction abstraction;
numeric failures become refusals after rollback. Provisional newborn Formula
reads retain #240's semantics while Durable Objects use transaction callbacks.
Formula-failure queries use the shared SQL interface on both platforms.

Combined checks: package tarball isolation and declarations, all six packaged
behavioral logs, browser/Worker bundling, normal/minified Studio initialization,
repository regression suites, participant/host/Studio TypeScript, Worker dry
build and real local workerd verification. The latter covers all 16 canonical
models, compatible republication, restarts, receipts, sessions, subscriptions,
alarms, queued delivery and authorization. The subsequent
[Coffee fixture](#hosted-coffee-acceptance--2026-10-25) verifies remote deployment
and standalone participant sign-in; real provider delivery remains pending.

## Standalone deployment foundation — 2026-10-25

The concrete Node SQLite and Cloudflare adapters now live under the packaged
TypeScript runtime's `adapters/`, sharing indexed reads, Formula dependencies,
atomic candidate writes and durable relational execution. Public entries are
`/runtime/adapters/node-sqlite`, `/cloudflare` and `/sqlite` beneath that prefix;
existing root files are compatibility exports. Language and core execution entries
retain their browser/Worker isolation. The deployable tarball also contains the
Worker, participant assets and a Node runner through `/deployment`.

The [release/deployment contract (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/hosting/DEPLOYMENT.md) owns exact setup,
identity, credentials and acceptance. One versioned snapshot and one interface
support local Wrangler and user-owned Cloudflare targets. The runner creates
stable independent project identity, retains private runtime credentials locally,
returns a common non-secret URL/revision manifest and uses fenced publication.
Snapshots are explicit; updates retain authorization, records and receipts.
Directory releases share the package's
[recursive domain-source contract](../ontolang/spec.md#recursive-domain-source-loading--2026-11-01);
nested sources reach the same release and host admission checks as root files.
Local and hosted targets have separate persistent state. Standalone participant
identity uses operator-issued one-use codes and existing project sessions;
[auth (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/auth/spec.md#standalone-participant-codes--2026-10-25) owns that boundary.

The fresh installed consumer verifies publication, execution, restart, compatible
update, assets, standalone session claims, enrollment, retained receipts and
logout against actual local workerd. The subsequent
[Coffee fixture](#hosted-coffee-acceptance--2026-10-25) verifies actual Cloudflare
deployment/sign-in; optional Clerk handoff and provider acceptance remain pending.
Existing MCP/CLI product changes and Studio deployment
UI/secret storage remain deferred.


## QA deployment harness — 2026-10-31

The standalone v1 runner deploys only `environment: qa`, independently of the
`local`/`cloudflare` target. Its manifest and operator tokens carry that environment;
credentials additionally distinguish origins. Existing non-QA Workers/state cannot
be silently adopted. The reference host's previous authentication paths remain
available for compatibility, but standalone QA has no sign-in-code screen.

`published-app/` supplies a compact “Viewing as” strip using the shared Select and
the full actor profile picker extracted from Studio. It defaults to an outside
role with an existing actor when available, otherwise the first usable role and
actor. Per-role selections survive switching roles within the page. “New …” opens
the existing generated demo-profile form and selects the fresh actor after creation.
There is no outer app title, boxed overview, global action dropdown, visibility
toggle, authentication-mode selector or extra testing panel. Application collection
pages and record actions use the published presentation and runtime schemas; when
a QA release omits a presentation, the host derives the default from its metadata.
Where a collection has an allowed query Story without required inputs, its rows
come from that actor-bound query; broad snapshot rows are never shown while it
loads or fails. Record actions use resource discovery for eligibility and bind the
clicked record. Actions needing only that record execute directly, as in `/app`.
Creation and actions needing other inputs use the create-dialog shell extracted
from `/app`; the bound target is omitted from the form. QA has no bottom command
console or success strip. Restoring a draft never opens or executes an action;
uncertain submissions retain their exact operation for retry. The server still
validates every execution.
This is the independent published renderer, not Studio's DataScript-backed
`AppPreview`. Existing drafts and live views remain scoped to each selected actor.

The host enables simulation only when both its environment and configured identity
mode are QA. It accepts a bounded set of application operations with same-origin
checks and refuses publication, enrollment, existing-actor editing, invitations, agent
issuance and other owner operations. QA identities are per role/record, have no
operator grant, and are never returned as credentials to the browser. The runtime
checks current role membership and enforces normal Story and record permissions.
Receipts and subscription selectors include the simulated identity. Existing
WebSocket sessions recheck QA configuration, participation and current permission.

This is a shared public test deployment: visitors can simulate its seeded human
actors. Actor fixtures come from model seed data, the protected operator client,
or the bounded new-test-user operation described below. No real participant account
is implied. External provider deliveries are blocked in QA even if a queue message already exists.
Two explicit QA fixture operations generate a new human-actor profile and create
that actor through the existing validated profile service. This bounded server
capability has its own deduplicated operations and model/generation fences; it
does not return owner credentials or grant the actor management authority. It
creates test data, not a real login, and does not run domain onboarding Stories.
Separate origin, storage and credentials keep the earlier Coffee fixture intact.
See the [QA deployment guide (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/hosting/DEPLOYMENT.md#qa-actor-selection).

Verification includes restricted role/record behavior, no owner source/authority,
actor-scoped receipts, refusal outside QA, and a fresh installed package running
real local workerd through publication, actor switching, execution, restart and
compatible update. The hosted
[QA Coffee fixture](https://onto-coffee-qa-b3c77896.onto-mcp-code-mode-runner.workers.dev/apps/74fafeafdf998f913457ac4b268fc2698ee1c0e903a3b37975254fa683f510f6)
uses seeded Customer Alice/Bob and Barista Sam. Browser acceptance completed the
order → prepare → serve → collect workflow through the selectors, checked Bob's
filtered view and a live subscription, and confirmed there is no code sign-in.
The corrected harness additionally creates and selects a generated Customer,
completes that Customer's order lifecycle, checks that Bob's collection remains
empty, and disables collection once the order is collected. The installed-package
check covers new-actor deduplication, identity forgery and stale-model refusal.
Browser regressions additionally cover old-draft reload without a console or
automatic execution, the shared create dialog at phone width, Escape/focus return,
and one-click record actions with no target picker. Component regressions retain
the original operation after a lost direct-action response and prevent replacing
it with a different target before resolution.
Reference inputs now use the same authorized-record selection behavior as `/app`.
Browser checks at 390px and 1280px keep the actor/action controls visible and
confine wide query tables to their own scrolling area.
Hosted HTTP checks also passed owner/source exclusion, forged role/identity and
wrong-origin refusal, per-actor receipt isolation, exact retry deduplication and
the external-delivery pause. Redeployment preserved the generation and records.
These checks do not establish production authentication or eviction/recovery/load
readiness; those remain outside this QA release.

Integration with staging `7de66cdd` preserves its live-session fixes and recording
button treatment in the extracted shared UI. Three new fixtures were reconciled
with the already-built draft-readiness and explicit-record-binding contracts;
all 430 live-session tests pass, along with Studio types, shared UI and initial
field-generation checks.

### Presentation boundary and SDK readiness — 2026-10-31

`presentation/contract.ts` owns the versioned generator input, plan and published
artifact types. The fallback generator and validator in `presentation/plan.ts`
consume that contract; a different generator can supply a validated plan through
the existing release `--presentation FILE` path. The plan schema is unchanged.

`ApplicationPresentation` loads actor-authorized queries and resource eligibility
and projects them into `PresentationView`. `PublishedPresentationView` receives
that data plus navigation/command callbacks through `PresentationRendererProps`.
The adapter accepts a replacement React renderer; the renderer receives no request
function, actor identity or raw runtime snapshot and imports no application service,
transport or generator. Commands still return to `ParticipantApplication` for
validation, draft persistence, exact-operation retries and receipts. `QaApplication`
owns role/user selection outside this boundary. The shared action-dialog content
is supplied as a slot; its forms and execution controller remain in the application
layer. This extraction preserves the existing UI and does not add harness features.

The latest integrated Ontolang extraction (#240 at `e41b7062`) exposes language,
execution and trusted adapter APIs. It does **not** implement a browser application
SDK for snapshot/query/discovery, commands, receipts and subscriptions. The
deployment SDK is an operator API, not a participant client. PR #220 therefore
retains its internal HTTP adapter and type-only application-service coupling there;
it does not import the execution engine into the renderer. A future consumer SDK
will replace the application-side transport/types while preserving the renderer
contract. Arbitrary frontend bundle deployment remains deferred, as described in
the [custom frontend contract (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/presentation/CUSTOM_FRONTENDS.md).

Boundary checks bundle the renderer alone, exercise a replacement renderer, and
cover query loading/failure without broad snapshot fallback, late actor responses,
revision changes, action eligibility and existing submission recovery behavior.
