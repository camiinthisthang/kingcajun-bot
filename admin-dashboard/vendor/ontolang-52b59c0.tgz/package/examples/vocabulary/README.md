> Portable snapshot of maintained Onto material. [Package capabilities](../../START_HERE.md) define the shipped boundary; dated decisions and host implementation notes are context. [Source manifest](../../SOURCE_MANIFEST.json) records provenance. Links marked “Onto source” are optional host/background references.

# Scoped vocabulary examples

The [vape shop](vape-shop/model.onto) imports the definitions in
[Warehouse](warehouse/entities.onto) and [Payments](payments/entities.onto).
The [record label](record-label/model.onto) reuses that same Warehouse source.
These are small vocabulary examples; the full editable Warehouse template lives
separately in [templates/warehouse](../templates/warehouse/).

```onto
import Warehouse from "../warehouse"
import Payments from "../payments"

object StockRequirement
  product: Product @required
  item: Warehouse.Product @required
  unitsPerSale: int @required
  @rule StockRequirement.unitsPerSale is more than 0
```

The shop's `Product` describes an offer with a selling price. The utility's
`Warehouse.Product` describes a physical item tracked in individual units.
They have independent records and schemas. Seeded `StockRequirement` records
connect them:

| Offer (`Product`) | Stock item (`Warehouse.Product`) | Units per sale |
|---|---|---:|
| Single mint pod | Mint pod | 1 |
| Mint pod three-pack | Mint pod | 3 |
| Starter kit | Mint pod | 2 |
| Starter kit | Device | 1 |

This models a shared stock item and a kit requiring multiple items without
equating an offer with a stock record. `OrderPayment` similarly links a local
`Order` to `Payments.PaymentRequest`. Those relationships do not automatically
deduct stock, collect money or synchronize an external service. Such actions
need explicitly authored workflows and, for external systems, edge adapters.

If the utility's Product already means exactly what the business needs, use
`Warehouse.Product` directly in local fields and Stories. A local Product is only
needed when the business has its own concept to express.

Use the package’s Node loader to resolve the neighboring Warehouse and Payments
directories, then print the loaded model to retain exact source snapshots:

    import { parseProject } from "@trigramco/ontolang/node";
    import { printProject, parseProjectFiles } from "@trigramco/ontolang";
    const model = parseProject("./examples/vocabulary/vape-shop");
    const files = printProject(model);
    const offline = parseProjectFiles(model.id, files);

Printed files include imports.json with exact source and digests. An offline
reopen needs no original utility directories. Existing snapshots preserve the
selected revision; pass updateImports: true to the Node loader only when
deliberately selecting current utility sources. This does not migrate a runtime.
