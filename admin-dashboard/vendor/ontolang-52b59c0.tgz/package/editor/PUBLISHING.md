> Portable snapshot of maintained Onto material. [Package capabilities](../START_HERE.md) define the shipped boundary; dated decisions and host implementation notes are context. [Source manifest](../SOURCE_MANIFEST.json) records provenance. Links marked “Onto source” are optional host/background references.

# Publishing the ontolang extension — runbook for when we're ready

**Deliberately unpublished for now** (decision 2026-08-27): the language is mid-iteration
(corpus sweep released but not run, parser catch-up pending, walk rulings still landing),
and a published grammar goes stale in the worst way — this extension's whole point is
flagging retired/illegal forms, so an out-of-date version actively lies. A marketplace
install pins users to the last publish; the in-repo install (`pnpm editor:install`,
re-run after grammar changes) follows the checkout, which is the right distribution
while the grammar co-evolves with the corpus and loader.

## Publish when

- [ ] the **language name is final** (bare "onto" vs "ontolang" — the marketplace
      extension ID is claimed at first publish and should be born with the final name;
      update `name`/`displayName` in `package.json` and this folder's docs if it changes),
- [ ] the **corpus sweep has run** and the parser catch-up shipped (grammar surface stable —
      churn dropped from weekly to ~monthly),
- [ ] there's an **external audience** (announcement shipping / first outside authors) —
      until then the marketplace adds friction-free install for people who don't exist yet.

Publishing is a soft announcement of the language — ideally it rides the announcement post.

## Pre-flight checklist

- `version` bumped in `package.json`, `CHANGELOG.md` updated.
- `publisher` in `package.json` matches the registered publisher ID exactly.
- License check: the extension defaults to **MIT** (`LICENSE`) — confirm or change before
  the first publish.
- Grammar tests green (`pnpm test` — sangha pinned clean, preposition parity).
- Optional but worth it: a screenshot in the README (marketplace pages sell better with one).
- Note: `repository` points at the private `trigramco/onto` repo — the marketplace link
  will 404 for outsiders. Harmless; remove the field or make the repo public if it bothers.

## One-time account setup (owner)

1. **Azure DevOps** (the VS Code Marketplace runs on it): sign in at
   [dev.azure.com](https://dev.azure.com) with any Microsoft account (create an org if
   prompted). User settings → **Personal Access Tokens** → New token: organization
   "All accessible organizations", scope **Marketplace → Manage**.
2. **Create the publisher** at
   [marketplace.visualstudio.com/manage](https://marketplace.visualstudio.com/manage) —
   ID `trigram` (or update `publisher` in `package.json` to whatever is registered).
   Reserving the publisher can be done any time — it publishes nothing.
3. **Open VSX** (this is where **Cursor**, VSCodium, and Windsurf pull extensions from —
   they do NOT use Microsoft's marketplace): account at
   [open-vsx.org](https://open-vsx.org) (Eclipse login + sign the publisher agreement),
   then generate an access token, then claim the namespace once:

   ```sh
   pnpm dlx ovsx create-namespace trigram -p <open-vsx-token>
   ```

## Publish (each release, from the repo)

VS Code Marketplace:

```sh
pnpm exec vsce login trigram          # paste the Azure DevOps PAT (one-time per machine)
cd editors/vscode && pnpm exec vsce publish --no-dependencies
```

Open VSX (same artifact):

```sh
pnpm editor:package                   # emits editors/vscode/ontolang-<version>.vsix
pnpm dlx ovsx publish editors/vscode/ontolang-*.vsix -p <open-vsx-token>
```

## After the first publish

- Re-add the workspace recommendation so teammates get a one-click install prompt —
  `.vscode/extensions.json`:

  ```jsonc
  { "recommendations": ["trigram.ontolang"] }
  ```

- Tell the team to drop their local copies (`code --uninstall-extension trigram.ontolang`,
  same with the `cursor` CLI) so the marketplace copy and its auto-updates take over.
- From then on: every grammar change that ships should bump the version and republish
  **both** registries, or published users drift from the spec.

## Until then — local distribution

- Team: `pnpm editor:install` (packages + installs via the `code`/`cursor` CLIs;
  re-run after grammar changes, then reload the window).
- Anyone outside the repo: `pnpm editor:package`, hand them the `.vsix`, they run
  `code --install-extension ontolang-<version>.vsix` (or "Install from VSIX…" in the
  Extensions view).
