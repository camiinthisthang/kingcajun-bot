> Portable snapshot of maintained Onto material. [Package capabilities](../START_HERE.md) define the shipped boundary; dated decisions and host implementation notes are context. [Source manifest](../SOURCE_MANIFEST.json) records provenance. Links marked “Onto source” are optional host/background references.

# Changelog

## 0.3.2 — 2026-08-29

- `@correction` on a beat line scopes `storage.modifier.correction` — the
  D10d correction-channel mark (the only beats that may leave `@final`),
  now exercised by the hotel corpus's reopen beat.

## 0.3.1 — 2026-08-29

- The `@` sigil now takes its annotation's color: the semantic scope spans the
  whole `@word` (annotations and field attributes alike) with
  `punctuation.definition.annotation` layered on the sigil — the CSS
  `@media` / JSDoc `@param` convention. Punctuation-styling themes can still
  dim the `@`; default themes render `@word` as one color.

## 0.3.0 — 2026-08-29

The corpus sweep: every example corpus now carries the 2026-08-29 spellings.

- Bare `description`, `type`, and `always` block lines scope deprecated
  (the annotations `@description`/`@type`/`@rule` are the spellings), as do
  header `=` subsets (`actor X = Base where …` → `is a` + `@where`).
- A field named `description:` no longer mis-highlights as the keyword.
- Written birth: creating beats' `sets` lines and `@final` endings appear
  throughout the swept corpora; no grammar change needed (already tokenized).

## 0.2.0 — 2026-08-29

The 2026-08-29 rulings: declaration annotations + collection quantifiers.

- Declaration annotations tokenize: `@description`, `@type person|organization|system`,
  `@rule` (type-block invariant, replacing `always`), `@where` (derived-subset
  predicate on an `is a` header), `@boundary external`.
- Subset predicates highlight through the rule expression tokens, including the
  words-tier quantifier `some` and the trailing `in <[]-field>` restrictor.
- Transitional: the bare block forms (`description`, `type`, `always`) still render
  as legal until the corpus sweep re-spells the older corpora; they turn deprecated
  with the sweep. Header `=` subsets likewise await the sweep.
- Test pins updated to the current sangha corpus (renames, `@` annotations,
  `granted` unmarked, the OldStudent/NewStudent subset blocks).

## 0.1.0 — 2026-08-27

Initial release.

- TextMate grammar (`source.ontolang`) for `.onto` files, written against the
  post-walk ratified grammar (2026-08-27 state), including ratified-but-not-yet-loaded
  constructs (`type`, `Type[]` mirrors, `@final`, `finds`, `per`, `sets`/`grants`
  clauses, `about`, `Type:label`, `every`).
- Retired forms render as deprecated (`produces "…"` suffix, `ensures` under beats,
  bare `rule`, `given`, `role … over`, `has`, `@terminal`, sentence determiners
  `a`/`an`/`the`/`all`); a non-preposition lowercase word in a story sentence is
  flagged illegal, mirroring the loader's every-word-is-load-bearing errors.
- Language configuration: `#` line comments, bracket/quote pairing, indentation
  (offside) folding.
