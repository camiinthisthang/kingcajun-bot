# Ontolang collaborator kit

This package carries the current language APIs, authoring references, an agent
skill, editor grammar, execution engine and example models together. Copy the complete package
folder or share its npm tarball; the kit needs no Onto checkout to be read or used.

## Capabilities

| Entry | Provides |
|---|---|
| @trigramco/ontolang | Parse/print models, diagnostics, pinned vocabulary snapshots |
| /node | Filesystem source discovery and local/offline vocabulary loading |
| /rules | Rule/Formula parsers and semantic/workflow analysis |
| /rdf | Bounded RDF/RDFS + SHACL export and coverage |
| /editor | Story fragments, highlighting and suggestions |
| /model, /semantics | Plain model types and shared scalar/numeric/status semantics |
| /classification, /catalog | Language classification and kind lookup |
| /templates | Generic source fragments, dependencies, composition and provenance |
| /walkthroughs | Strict portable walkthrough schema and types |
| /runtime | Headless TypeScript Story, Rule and Formula execution |
| /runtime/adapters | Shared adapter contracts and helpers, not concrete databases |
| /runtime/adapters/node-sqlite, /cloudflare | Concrete platform adapters |
| /deployment | Versioned releases and standalone local/Cloudflare deployment |

Language, execution, concrete Node SQLite/Cloudflare adapters and the deployable
Worker/assets/runner ship in this one package. The [deployment guide](DEPLOYMENT.md)
covers independent local Wrangler and hosted Cloudflare targets. Account settings,
credentials and delivery recipients remain with the deploying application.
Studio and AI template detection remain separate authoring services.
The library’s single-record Rule evaluator is advisory; it is not the complete
cross-record execution engine.

## Execute a model

The [runtime guide](RUNTIME.md) describes compileModel, initializeWorld,
executeStory, inspectWorld, tick and System-step helpers. The engine runs
headlessly with explicit facts and clocks. Install one Ontolang tarball and run
`node node_modules/@trigramco/ontolang/examples/headless.mjs`.
The shipped execution logs preserve behavioral expectations for future runtimes.
Concrete adapters use explicit `/runtime/adapters/node-sqlite` and
`/runtime/adapters/cloudflare` entries; shared SQL interfaces use
`/runtime/adapters/sqlite`. `/deployment` includes the standalone runner.
The tarball includes the durable host and optional shared presentation renderer.
Broader consumer SDKs and registry publication remain separate.
Deployment accounts, bindings, domains and secrets belong to the deploying app.

## Start authoring

Read [the grammar](docs/features/ontolang/grammar.md),
[modeling guidance](docs/features/ontolang/modeling.md),
[current language behavior](docs/features/ontolang/spec.md),
[Rule/Formula grammar](docs/features/rule-dsl/spec.md), and
[Story sentence grammar](docs/features/story-authoring/spec.md).
These local pages contain the authoring rules. Dated decision notes are context;
the current grammar/specification and actual parser behavior define what is built.

For an agent, invoke [the authoring skill](skills/onto-authoring/SKILL.md) at its
location in this complete kit. Keep its sibling docs/examples when moving it.
Nothing here installs a skill or changes an editor automatically.

The [Sangha corpus](examples/ontolang/sangha/) exercises the language in a complete
model. All 16 [canonical model directories](examples/ontolang/) are included, plus
[pinned vocabulary examples](examples/vocabulary/README.md) and
[template source fragments](examples/templates/). Extra workflow/migration JSON
in examples is host fixture data, not executable package configuration.

## Install and validate

Node 24 or later is required. In a consumer project, install the shared tarball:

    npm install /path/to/trigramco-ontolang-0.1.0.tgz

For a copied package folder, install that folder from your consumer project.
The distribution includes built JavaScript/declarations; only its declared
dependencies are needed. No source build or Onto workspace dependency is required.

    import { parseProjectFiles, printProject } from "@trigramco/ontolang";
    import { parseProject } from "@trigramco/ontolang/node";
    import { exportRdf } from "@trigramco/ontolang/rdf";
    const model = parseProject("./my-model");
    const files = printProject(model);
    const reopened = parseProjectFiles(model.id, files);
    const rdf = exportRdf(reopened, { baseIri: "https://example.org/model/" });

Run parse → print → reopen to check the complete model and literal fidelity.
Loading may emit nonblocking managed-workflow advice; a compatible runtime
enforces readiness before execution/publication. Standalone descriptive vocabularies
need no Stories, producers or endings. Monetary stored values use exact minor units;
Rule/Formula numeric literals are whole units and division rounds down or up.

The [editor source extension](editor/README.md) is independently packageable as
a VSIX. Its TextMate grammar and language configuration also work as input to
compatible syntax-highlighting tools. The [package README](README.md) describes
all public API entry points and companion adapter boundaries.

## Maintaining this snapshot

Authoritative docs, skill, editor and examples currently live in the Onto source
repository. [SOURCE_MANIFEST.json](SOURCE_MANIFEST.json) maps every copied file and
records source/snapshot hashes. Generated copies are intentional for this first
package phase; edit the maintained source, then regenerate inside Onto:

    node scripts/sync-ontolang-capability-kit.mjs
    node scripts/sync-ontolang-capability-kit.mjs --check

The check fails for stale/missing/unexpected assets and is part of package CI.
An independent consumer uses the shipped snapshot and never needs this generator
or the original repository. Remaining links marked “Onto source” point to optional
host implementation/background material on the source branch.
