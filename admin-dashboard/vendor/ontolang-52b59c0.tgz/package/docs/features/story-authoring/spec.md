> Portable snapshot of maintained Onto material. [Package capabilities](../../../START_HERE.md) define the shipped boundary; dated decisions and host implementation notes are context. [Source manifest](../../../SOURCE_MANIFEST.json) records provenance. Links marked “Onto source” are optional host/background references.

> **Layer: AUTHORING-TIME** — the IDE surface where domain stories are written and classified into the model.

# Story authoring — spec (what's built)

**Status:** ✅ built. The front-end that turns prose into a classified story model: canvas input · classify-at-commit · exogenous-input detection · story decomposition · the story tree. Thin remainder → [backlog.md](backlog.md).

Built: `classifier-at-commit/` (9 categories · 4 archetypes · locus · slots · residue — 78 tests) · `classifier-at-commit/exogenous.ts` (20 tests) · `/api/decompose` + `StoryTree` drag-drop reparent · the canvas. Classifier detail below.

---

## The story grammar

- **Three primitives — Actor, Action, Object.** Every beat is the irreducible
  sentence "Actor —acts on→ Object". Remove any one term and it is no longer a
  beat. There is nothing else at the story layer to model with.
- **Entity names: one CamelCase spelling everywhere** (owner decision,
  2026-07-29 — recorded in [rule-dsl](../rule-dsl/spec.md)). A multi-word
  actor/object name is CamelCase in beat text exactly as declared
  (`Guest browses RoomClass`); there is no spaced display form. A spaced
  capitalized phrase is never a name — and never quietly becomes anything
  else: the old behavior (read the phrase as a property name, invent a field
  on the first word's type, delete the phrase from the sentence) is **ruled
  bad machinery** (owner, 2026-08-14) and is being removed — see the
  [ontolang backlog](../ontolang/backlog.md).
- **A story is a single concrete linear path.** It records one way things
  actually happened, beat after beat — no branches, no conditionals, no "if".
  Anything that varies by condition lives in **Rules**, not in the story.
- **Annotation — a fourth story-layer element.** A plain-language note that can be
  attached to any story element to capture nuance too small to deserve its own
  story. It is story-layer, not executable: raw material a modeler later turns
  into Rules.

### The sentence grammar (normative — consolidated 2026-08-14)

This is the single normative definition of the story sentence — this feature
owns it. The ontolang loader implements it strictly
([grammar](../ontolang/grammar.md) §2 carries the EBNF and the preposition
class); since the **parser port v1 (2026-09-02)** the composer parses each
beat through the same parser in app mode — warnings + suggested fixes, with
a short error list that blocks confirm (the enforcement table below). The
wrap and clause work still open ride [backlog.md](backlog.md).

**The shape:** `Subject verb Object [preposition Participant]…`
— one beat, one sentence, one action. The rules, each an owner ruling
(2026-08-13/14 unless dated otherwise), with where it is enforced today:

- **Entity names are one CamelCase token, everywhere** (2026-07-29 — the
  bullet above), **at most 24 characters** (ruled 2026-09-02, sweep case 14;
  no truncated display form — the cap is the fix). *Enforced: loader
  declaration error; composer gating `name-too-long` warning on a mint;
  generator prompts carry the cap; sangha re-versioned (its two outliers
  renamed `VolunteerAssignment` / `VolunteerApplication`).* *Enforced: loader (single-token gate, printer refuses spaced
  names); the composer warns on a spaced name with a one-click CamelCase
  rewrite and mints nothing (parser port v1); generator prompts largely
  rewritten — residue rides the [importer backlog (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/importer/backlog.md).*
- **Every beat has an object.** `Guest smiles` is not a beat. *Enforced
  (gap closed 2026-09-02, sweep case 10 — zero corpus beats were
  objectless): loader `file:line` error; composer gating `objectless`
  warning.*
- **A story never names a data operation** (owner ruling, 2026-08-14). A
  sentence names a domain act — `Manager approves Invoice` — never a
  property write: no "sets / updates / changes a property" sentences. The
  test is **"sets it to what?"** — a sentence that needs a value to mean
  anything is not a story. Each such sentence has one of three homes: the
  act's **form** (`User submits LoginForm` — the form captures its fields),
  a **rule** (`requires Task.priority is set`), or a **formula** (a derived
  value). Property paths (`Task.priority`) are the ratified property
  spelling in rules and formulas — and a story is the one place a property
  is never spoken. The verb alone is not the offense: `assigns Lead to
  Territory` is an act between things and stays legal; a property in the
  object slot is the offense. *Enforcement: spaced property phrases are
  undeclared-name errors in files already; the pointed error for a property
  path in a story's object slot, the removal of the field-minting machinery,
  and the canvas rewording suggestions ride the
  [ontolang backlog](../ontolang/backlog.md).*
- **A pronoun is illegal in every name slot** — stories name their people
  and things: `I`, since the sweep ruling 2026-09-02 the whole capitalized
  family (`We`, `You`, `He`, `She`, `They`, `It`), and since the case-hunt
  ruling 2026-09-03 the object-case forms too (`Me`, `Us`, `Him`, `Her`,
  `Them`) — in the subject, object, recipient, and participant slots alike.
  A pronoun never mints. *Enforced: the composer emits the pointed
  `first-person` error and blocks confirm (subject keeps the original
  who-acts wording; the other slots say the pronoun is not a name); the
  loader still rejects these only as undeclared names, never with a
  pointed error.*
- **The only legal lowercase words in a beat are the verb, a preposition,
  and the `every` determiner.** No filler, no adverbs. Status writes use
  indented `sets` clauses; the former `produces` suffix is rejected. *Enforced: loader (a stray
  lowercase word is a `file:line` error naming the word); the composer
  surfaces the same finding, verbatim, as an amber warning that gates
  Confirm (`blocksConfirm`, ruled 2026-09-02). The verb slot itself is
  checked since 2026-09-03: a value ("Customer $40 Order") or junk token
  ("-pays") cannot be the action — both doors flag it.*
- **Phrasal verbs are hyphenated** — `checks-in`, `kicks-off`: the verb is
  one token, so a bare `up`/`off` after the verb can only be a preposition.
  *(Ruled 2026-08-24: prepositional verbs do NOT join this rule — the thing
  acted on becomes the object (`Guest pays Invoice`); hyphens stay for true
  phrasal verbs only — and ONLY there (re-ruled 2026-09-03): any other
  hyphen-bearing token, name or label, edge or middle, is an
  illegal-character error with a strip fix, and declarations reject them; see the [ontolang backlog](../ontolang/backlog.md), D14d.)*
- **Prepositions are the single-word English closed class** (54 words,
  2026-08-13) — stored in the sentence, never interpreted; what a
  participant *means* is derived downstream by rules and formulas.
- **At most two participants per beat** (2026-08-14) — and each pair written once: the same preposition+name+label twice is an error in both doors (ruled 2026-09-03; labels distinguish pairs — `to Barista:A to Barista:B` is two participants, and the duplicate error quotes the pair as written, label included) — stored as the ordered
  list of `{preposition, name}` pairs on **every** participant sentence —
  the preposition is data, never only text (owner ruling, same day); the
  third is a `file:line` error pointing to "move the detail into a field,
  or split the story" (message copy re-ruled 2026-09-02: user-facing
  diagnostics say "story", never "beat", and start capitalized). *Built and merged 2026-08-14: pairs, the cap, word-for-word
  printing; ten seeds re-versioned. Canvas-confirmed stories persist pairs
  and labels since the parser port v1 (2026-09-02); pre-port stored
  stories still await the cleanup back-fill.*
- **`and`/`or` never appear in a beat — split it**: one beat per object
  (compound object), one beat per action (compound action). *Enforced with
  the pointed message in both doors since 2026-09-03 ("Split this into two
  stories — \"and\" never joins them"): loader error; composer amber but
  Confirm-gating.*
- **A sub-beat names its own subject** — no implied carry-over from its
  parent beat. *Structural in both parsers.*
- **Reflexive beats are legal via the colon role** — `Manager:Assigner
  assigns Task to Manager:Assignee`: one entity type wearing two story-local
  hats; the label never mints a type, and the labels are **data** (owner
  ruling, 2026-08-14): `story/subject-label`, the participant pair's
  `label`, `story/primary-object-label`; the sentence text keeps the written
  form. *Built and merged 2026-08-14.*
- **A status value is never a participant** (2026-08-13) — `marks Order as
  Ready` is a rewording target; use a domain sentence and an indented
  `sets Order.status to "ready"` clause to write the declared value.
  A creating Story writes its birth the same way; no status suffix belongs
  in the sentence. *Enforced since 2026-09-03
  (case-hunt row 13): an undeclared name after `as` gets the composer's
  gating `status-participant` warning and never mints — the old path
  offered to mint an actor named Ready; a declared name after `as` stays a
  real participant; the loader is unchanged (it already fails loud on the
  undeclared name — no pointed error yet, and no status-enum check in
  either door).*

### Composer enforcement — app mode (parser port v1, shipped 2026-09-02)

The composer runs `parseBeatFragment` ([ontolang spec](../ontolang/spec.md))
on the idle pause and once at confirm. **Errors block Confirm and Decompose.
Warnings never interrupt typing — but a warning the FILE
door would reject (`beat-word`, `name-case`, `spaced-name`) carries
`blocksConfirm` and gates Confirm/Decompose too** (ruled 2026-09-02, sweep
cases 4 and 8: the store must never hold a beat the printer/loader refuses —
the character sweep proved a confirmed filler-word beat fails at `.onto`
export, and a confirmed spaced name prints but fails to load). Only
`story-too-long` is a pure warning.

**The same gate, server-side, for every LLM story producer (2026-09-09,
`studio/app/lib/assist-gates.ts`):** the assistant's story proposals, the
folder sparkle, the scenario dump (parent and every beat), decompose, and
the question explorer's sub-stories run `parseBeatFragment` in composer
mode over the declared actors and objects before a proposal renders — an
error or a `blocksConfirm` warning refuses it, so a card never carries a
sentence the canvas would refuse. Producers that mint names by design
(the sparkle with its definitions, the scenario's roles, decompose's
emerging objects) keep that freedom; the assistant and the explorer
propose over the declared model only. Generated project seeds (the
import pipeline) are NOT gated here — they ride the deferred prompt-file
sweep in the [ontolang backlog](../ontolang/backlog.md). The severity table:

| severity | code | when |
|---|---|---|
| error | `unreadable` | `parseDSL` reads no (or more than one) sentence — or any loader-thrown beat error surfaced through the no-throw wrapper: a property path in the object slot, an object acting, an undeclared `every` noun (the loader's own message, `file:line` prefix stripped) |
| error | `first-person` | a pronoun in any name slot (ruled 2026-09-03: subject, object, recipient, participant; the set is `I`, `We`, `You`, `He`, `She`, `They`, `It` plus the object-case `Me`, `Us`, `Him`, `Her`, `Them`) — the subject keeps the who-acts wording, the other slots say the pronoun is not a name; nothing mints (the pointed error the loader still lacks) |
| error | `hash` | `#` anywhere — reads `Illegal character: "#"` (the file grammar strips comments *before* validation, so the text would silently truncate); a `#`-glued value also carries the specific-value warning |
| error | `newline` | an embedded line break — a beat is one sentence on one line; U+2028/U+2029, the line breaks the eye cannot see, count too (ruled 2026-09-03) |
| error | `illegal-character` | any character outside the story alphabet (letters, digits, whitespace, `:`, currency marks; `-` only inside a phrasal verb — any other hyphen errors with a strip fix, re-ruled 2026-09-03; a no-break space normalizes to a plain space; `.` only INSIDE a token — property paths and decimals get their own pointed messages, a stray/trailing dot is illegal, ruled 2026-09-03) — these silently corrupted the file round trip. An invisible offender (format/control/combining/zero-width) is named by code point (`Illegal character: U+200B`) instead of empty quotes (ruled 2026-09-03). U+FEFF counts as invisible, not whitespace — JavaScript's whitespace class matches it but it renders as nothing, so an interior one errors as `U+FEFF`; an edge byte-order mark is paste residue the trim drops |
| — | `@correction` | the trailing mark is legal in the composer since 2026-09-03, exactly as in files: stripped from the text, persisted as the correction-channel flag (any other `@` is an illegal character) |
| error | `empty-label` | a colon with an empty side (`Customer:` / `:Payer`) — teaches the label syntax in BOTH doors since 2026-09-05 (the file door silently dropped the empty label until then — the last accept/reject split between the doors). And the label law (ruled 2026-09-05): a label is ONE word of letters and digits — a glued phrase (`Customer:VIP Barista`), a second colon (`Customer::Payer`), or the file door's space-led leftovers are refused in BOTH doors (`A label is one word (Customer:Payer) — "…" cannot be a label`; surfaced through the no-throw wrapper in the composer) |
| warning | `beat-word` | the loader's beat-word findings, verbatim messages: a filler/stray lowercase word, a retired determiner — in ANY casing and any position since 2026-09-03 (`A Customer pays Order` gets the determiner message, never the spaced-name glue), a mis-cased `every` (`Every`/`EVERY` — taught lowercase, the composer adds a one-click fix), a third participant, a specific value (`40`, `$40`, `40%` — "please name the Object it represents"), `and`/`or` (pointed: "Split this into two stories" — and the scan ENDS there, ruled 2026-09-04: `Customer and Barista make Order` gets the one chip, never the derived filler blame on the real verb or a missing-verb stack), a digit-led would-be name (`2Room` — "A name starts with a letter"), a capitalized token carrying a value mark (`Or$der` — "A name is letters and digits only"; it could never be declared, composer chip, the loader's undeclared-name error covers the file side) (ruled 2026-09-02/03/05). Grammar words are judged on the half before a colon — a label never hides a determiner, preposition, or conjunction (`The:Label`, `to To:X`, ruled 2026-09-05). `and`/`or` split in ANY casing, and the split ends the scan ahead of every derived blame (`every`'s must-follow included, 2026-09-04/05). A LEADING `every` (either casing) teaches position with no rewrite — "`every` cannot mark the actor — a story names who acts" — because the lowercase form parses nowhere (ruled 2026-09-05); mid-sentence the mis-case fix survives, and a LABELED `every` (`every:X`) is plain filler, never "mis-cased". In a FILE the lowercase form never reaches the word scan — the line reader rejects any lowercase-leading line with its generic sentence-shape error first (the ruled leading-value precedent; accepted 2026-09-05: the teach is composer-side for both casings, loader-side for the capitalized form) |
| warning | `name-case` | a token that is a declared name mis-cased (`guest` → `Guest`) — pointed, with a one-click fix; it supersedes the filler finding the casing caused, and a mis-cased verb-slot token in an unreadable sentence suppresses the whole (wrong-verb) beat-word scan; a mis-cased name never mints a twin entity (ruled 2026-09-02). |
| warning | `preposition-case` | a capitalized preposition token (`…Order To Barista`) — pointed, with a one-click lowercase fix; it supersedes the spaced-name glue the mis-case caused. Composer-only: the loader already fails loud on the glued undeclared name (ruled 2026-09-03) |
| warning | `name-too-long` | an undeclared name over 24 characters — gates Confirm, mints nothing (ruled 2026-09-02, case 14). For a spaced phrase the cap measures the GLUED form and the message names it (`SuperBigInsuranceClaim` at 22 keeps its spaced-name fix; only an over-cap glue is too long — ruled 2026-09-03, row 11) |
| warning | `status-participant` | an undeclared name after `as` (`Barista marks Order as Ready`) — a status value is never a participant; the status is written as a `sets` line; gates Confirm, mints nothing (ruled 2026-09-03, row 13). A declared name after `as` stays a real participant. Composer-only: the loader already fails loud on the undeclared name |
| warning | `missing-verb` | stacks beside a flagged verb-slot token (`Customer $40 Order`) — "A story names its action — write the verb"; gates (ruled 2026-09-03) |
| warning | `objectless` | the story has no object (`Customer pays`) — gates Confirm; the loader throws (gap closed 2026-09-02, case 10) |
| warning | `dangling-preposition` | a bare preposition ANYWHERE (ruled 2026-09-04 trailing, completed 2026-09-05 mid-sentence: `…Order to to Barista` gets `Drop the "to" or name an object`) — gates Confirm, and the loader throws the same words; the empty pair is never silently dropped. The verb slot is exempt by construction — a preposition crowned as the verb has its own pointed chips |
| warning | `spaced-name` | a spaced capitalized phrase — carries a one-click CamelCase-rewrite fix; nothing mints; gates Confirm (ruled 2026-09-02, case 8). When EVERY word of the phrase is itself a declared name (`Customer Barista pays Order`), the glue is wrong — the warning says to write the act between them, no fix; a determiner or mis-cased preposition inside the phrase supersedes the glue entirely (ruled 2026-09-03, rows 7/10) |
| warning | `needs-definition` | composer mode only (coalesce 2026-09-04): a beat name with no saved definition and no canonical grounding — the old popover pipeline's finding, parser-owned; gates Confirm exactly as the popover count did (one gate, one list). The catalog input carries `defined` per name |
| warning | `vague-verb` | composer mode only: the verb is on the abstract list (*manage*, *handle*, *track*, …, conjugated forms included) — the old "too abstract" nudge as an advisory chip; never gates |

The canvas caps a story at **90 characters** (ruled 2026-09-02 — fixed and
screen-independent; the longest legal corpus beat is 78, so 90 is the
language's ceiling with label headroom). The font scales down to fit; a
capped keystroke is rejected with the `story-too-long` chip rather than
silently dropped.

**Rendering (the coalesce, ruled + shipped 2026-09-04 — the nine calls in
[coalesce-brief-2026-09-04.md (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/story-authoring/coalesce-brief-2026-09-04.md), one typeable
sample per finding in [chip-samples.md (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/story-authoring/chip-samples.md)):** diagnostics
render as ONE neutral stacked list under a "Things to resolve" header —
never color-coded by severity; `blocksConfirm` stays semantic and the
blocking finding is named in the Confirm/Decompose tooltips (the single
gate — the old popover pipeline and its count are deleted). The WORD
carries the red: in composer mode every worded diagnostic carries a `span`
into `sourceText`, and the active chip (hover, else the first blocking)
draws the hand-drawn arc under its word plus the cursive margin note above
it — a one-word resolution verb (*remove*, *recase*, *join*, *shorten*, …)
shared with the chip's inline quick-fix link. Pure-removal findings
(determiner, filler, empty pair) synthesize drop-the-word fixes in composer
mode; `needs-definition` / `first-person` / `vague-verb` expand in place
into a resolution card (definition input, actor/object kind toggle,
alternate-entity dropdown). Word painting is synchronous word→catalog
matching per keystroke (the dst/NLP pipeline is deleted); the fragment
parse keeps the idle debounce and Decompose reads the fragment's slots.

User-facing message copy carries no dates and no decision codes (ruled
2026-09-04 — the citations live in the specs and the code comments, never
in the sentence shown to an author).

The manual test sheet — every message the composer can produce, one
verified input line each, 45 cases — is
[composer-test-sheet.html (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/story-authoring/composer-test-sheet.html); open it in a
browser beside the running app (`pnpm dev`, localhost:3000).

**Fix safety (ruled 2026-09-05, from the second adversarial sweep):** a
one-click fix (1) inserts the user's token literally — `$` never reaches
the rewrite machinery as replacement grammar; (2) re-attaches a stripped
trailing `@correction`, so a casing click never changes the story's
correction channel; (3) rewrites whole-token occurrences of ITS word or
phrase only (all fixes are edge-anchored — the `Cat Toy` glue never edits
inside `BobCat Toy`); (4) is withheld when its product would be a DEAD END —
an error with no onward fix (a one-sided colon, a digit-led name, an
over-cap name — parity with the glue fix's own cap check); a product that
lands on a different actionable gated chip is progressive disclosure and
stays offered (accepted 2026-09-05, second pass); and (5) the glue stands down when the
phrase holds a mis-cased declared name or a conjunction — the name-case
fix or the split chip names the actual mistake, and gluing would mint
junk (`ORDERPayment`) or join what `and` never joins. The no-break space
family (U+00A0, U+202F, U+2007) normalizes to plain spaces at BOTH doors
(2026-09-05; composer-only since 2026-09-03).

### Exogenous-input detection (derived, not hardcoded)

An object is treated as **exogenous** (it enters the story from outside) when it is
**derived** to be so — the system never hardcodes a list:

- **(a)** no beat in the story instantiates or captures the object, **and**
- **(b)** an outside actor produces or hands it over, **or** its only acting beats
  sit at an external locus.

A modeler can also mark an object exogenous directly via an explicit **boundary
field / outside-token** fallback.

### The no-source lint (built)

- Every **non-exogenous** object must have a beat that creates it.
- Every **exogenous** input must have a declared external source.
- The lint flags any object that has neither, so no object appears from nowhere.

### Story folders (built 2026-08-18; subfolders same day)

Named, collapsible groups over the **top-level** story list, so a flat
sequence reads as flows ("Registration") or as outcome sets (a passing and a
failing variant side by side) instead of a sequential fact log. Folders
**nest** (owner call, same day): outcome folders live inside a flow folder —
"Reservation Accepted" / "Reservation Declined" under "New Reservation" — so
a decision tree reads as nested structure.

- **Model:** a folder entity per project (`folder/uid` — portable identity,
  minted once, survives renames — plus name, order, and an optional
  `folder/parent` uid for nesting) and an optional `story/folder` membership
  uid on the beat. Purely additive: pre-folder projects load and render
  unchanged; unfoldered stories render as before. Parent writes are
  **cycle-guarded** (`setFolderParent` no-ops on self, cycles, and unknown
  parents — deterministically, so concurrent op replays converge); the tree
  renders anything unresolvable at the top level so no folder ever hides.
  Deleting a folder destroys nothing: its stories return to the unfoldered
  list and its child folders are **promoted one level up** (the least
  destructive answer, decided 2026-08-18).
- **Mixed child order (owner call, same day):** a container's children —
  subfolders AND member stories — are ONE ordered list, arbitrarily
  interleaved (a subfolder can sit between two stories). `folder/order` and
  `story/order` share a comparable sequence per container;
  `reorderMixedChildren` rewrites both kinds to positions 1..n in one
  transact and one op (`folder/reorder-children`, the resolved sequence —
  unknown refs keep their slot, so concurrent replays converge last-writer-
  wins per container). Ties from pre-mixed data sort folders first, then by
  eid — deterministic everywhere. The **top level gets the same treatment**
  (folders and unfoldered stories interleave in one list — decided here for
  consistency: the decision-tree folders live among top-level stories).
- **Folders vs. decomposition:** orthogonal. Folders group top-level
  SIBLINGS (now recursively); the parent/sub-story tree decomposes ONE
  story into its steps. A beat nested under a parent story still leaves its
  folder (membership is top-level only; sub-stories travel with their
  parent). Outcome variants that used to need an artificial grouping parent
  are folder structure now — the parent-story view stays what it is: the
  film of one story's own decomposition.
- **UI (StoryTree):** a New-folder button beside the filter box (opens the
  naming input blank — "Name this folder"; an empty or escaped commit
  deletes the never-named folder; the empty-folder hint "Drop stories
  into ‹name›, or generate some" appears only once it has a name, 2026-09-11); folder headers select on click, collapse/expand through the disclosure or double-click, rename inline
  through ⋮ Rename, and delete via ⋮. Subfolders render
  recursively inside their parent's drawer with the same indent-guide
  grammar as sub-story rows. Folder count badges **roll up the whole
  subtree** (a collapsed flow folder still says how much lives beneath its
  outcome branches; decided 2026-08-18). Both row kinds drag through the
  mixed list: a header's MIDDLE is "into" (blue ring — a story files there,
  a folder nests there) and its EDGES are the insertion line ("between" —
  the row slots into the container's sequence at that position); the same
  edge gestures work against story rows, so a folder drops between two
  stories and vice versa. Menus mirror it: both row kinds carry ONE
  "Move to…" item whose submenu is a drill-in pane inside the same dropdown
  (owner call 2026-08-18 — the flat per-folder items grew with the folder
  count): back header on top, "Move to top level" first, then the folder
  tree indented by depth, capped at ~240px and scrolling past that. Folder
  rows also get "New subfolder"; cycle targets are excluded everywhere.
  Menu/into moves land at the END of the destination list, drag-between
  sets the exact position.
- **Glyph (2026-08-19):** every folder header — top-level and nested — uses
  ONE icon at one size: `FolderSimple` 18/regular, the right rail's
  entity-icon scale (CoachingSidebar's `UserCircle`/`CubeFocus`). No
  open/closed glyph swap — the caret alone carries state. Nested headers
  still read lighter typographically (14px / 400 / no tracking vs the top
  level's 13px / 600 / 0.02em).
- **Present a folder (2026-08-19; one-film rework 2026-08-20):** a
  hover-revealed Play button on the folder header, plus ⋮ entries —
  "Present" and indented per-face shortcuts (Storyboard / Output / Data,
  the stage's real tab names) — open the presentation overlay on the folder
  as ONE CONCATENATED film: every scene of every member story (flattened
  depth-first in mixed order, subfolders inline — the decision-tree read)
  in a single sequence. The counter reads across the whole group
  ("SCENE 3 / 7"), ‹ ›/arrows walk scene-by-scene through story boundaries
  (the changing scene sentence is the boundary marker — no extra chrome),
  the filmstrip thumbs every scene across the folder, and the folder name
  frames the group as a quiet eyebrow label ("CAR VALET · SCENE 3 / 7").
  Output/data faces follow the current scene's beat / the whole film's
  tables as before. Single-story present keeps its per-story film with
  cross-story hopping. `StoryboardPresentation` gained `initialFace` (the
  deep link) + `groupLabel`; `StoryPresentLauncher` exports
  `FolderPresentOverlay`, whose host takes the concatenated `fixedFilm`.
  The affordances appear only when something in the folder's subtree is
  committed (no empty stage).
- **Sparkle — generate stories from a folder (v1, 2026-08-18):** a
  "Generate stories" item in the folder ⋮ menu (and a quiet "or generate
  stories" action in the empty-folder drop zone) calls
  `/api/folder-stories` — one bounded Groq call over the pure lib
  `studio/app/lib/folder-stories.ts`. The folder's name + ancestor path
  LEAD the prompt as the assignment (restated: beats must belong
  SPECIFICALLY in this folder — retuned 2026-08-20 after generic
  neighborhood-paraphrase output); member stories, the surrounding
  container's stories (capped at 12, demoted to tone/format context only),
  and the project's actor/object vocabulary follow. Existing names are
  reused only where they GENUINELY fit — a folder implying a missing role
  (Car Valet → a Valet) mints it, never forces a fit. Every text suggested
  for a folder this session (accepted or dismissed) rides back as an
  `avoid` block, so regenerating gives fresh candidates; the parse floor
  drops incomplete beats, dedupes, and caps at 5, and the client
  additionally drops echoes of existing/avoided texts structurally.
  Proposals also carry one-sentence DEFINITIONS for the new entities they
  mint (validated to names the kept stories actually use — 2026-08-20).
  Results render as ghost/pending rows inside the folder
  (dashed, sparkle-led, neutral styling — never gold) with per-row ✓
  accept / × dismiss plus add-all: **nothing persists until accepted** —
  accept mints a normal DRAFT story (entities enter the catalog on confirm,
  like any draft) appended to the folder's mixed list. Loading pulse while
  generating; fail-soft quiet error line with retry.
- **Definition first pass (2026-08-20):** a needs-definition entity gets an
  AI-drafted one-sentence ghost suggestion in the definition editor
  (`DefinitionEditor` — all three hosts: sidebar pane, peek drawer, entity
  sheet), fetched via `/api/entity-definition` (bounded Groq call over
  `studio/app/lib/entity-definition.ts`; context: name, kind, fields, up to
  8 referencing story sentences) when the EMPTY input is actually
  presented, cached per entity per session. ✓ fills and saves (still
  editable after), × dismisses for the session; typing hides the ghost;
  nothing persists until accepted. Definitions riding ACCEPTED
  folder-story proposals seed the same cache (instant ghost, no network
  call) with provenance, and the confirm path auto-applies THOSE — only
  those — to entities still undefined at their mint moment, merging them
  into the confirm broadcast. Pinned by `entity-definition.test.ts`.
- **Sync:** `folder/create` / `folder/rename` / `folder/delete` /
  `folder/set-parent` / `folder/reorder-children` / `story/set-folder` ops
  (uid-addressed, echo-idempotent, cycle-guarded on replay via the shared
  helper, backfilled by `backfillProjectOps` — creates before parents
  before memberships);
  seeds/exports round-trip the whole tree (`SeedProjectInput.folders` with
  `parent`, plus `story/folder`; names resolve to minted uids). Pinned by
  `runtime/folders.test.ts`.

## The state-change rail (2026-08-31)

The story edit page's **bottom rail** (`StoryStateFooter.tsx` — docked
full-width at the canvas bottom, where the state change temporally
belongs) tells the reader what the selected beat changes, **as a
sentence, not a spec clause** (owner call, same day): a left-aligned
"After this story" label, then *"Retreat moves to [registration-open]"*
or *"a new RetreatBooking starts as [requested]"*, with the entity in
the object lilac and the value on a neutral surface pill (no accent —
state change is normal, not a warning). The ontolang written `sets`
line (*every transition carries its written sets line* — see
[ontolang's grammar](../ontolang/grammar.md), D12a) stays the storage
truth; the rail is its plain reading. Value precedence: the stored
`story/transition-to` edge (mint/confirm identity), else the
declared-aware conjugation **chipped `derived`** so the author can see
the value is calculated, not chosen ("guessed" was tried and reverted —
it read as "we don't know", owner call 2026-08-31). The rail is stable chrome — a beat
with no state change shows a quiet "Nothing changes state." instead of
the rail popping in and out.

The label reads **"What this story changes"** with one quiet helper
line beneath it ("Stories can change the status of the things they
touch") — the once-per-reader explainer for non-tech readers — while
the fact line is ontolang's own clause again
(`sets Retreat.status to "registration-open"`, owner call 2026-09-01:
with the words carrying comprehension, the clause can match the
language the model is stored in; birth beats carry an `on create` tag
since ontolang spells both the same). A **lifecycle track** (the enum values
as an arrowed stage strip) was built and reverted the same day
(2026-09-01): enum order is rank, but lifecycles branch
(accepted/declined), and an arrowed timeline asserts a linearity the
domain may not have. The gate-extracted FROM value
(`requires …status is "x"`) still rides `StoryStateInfo.fromValue`,
unrendered — reserved for a possible "only when it's currently x"
phrase, which carries the journey without claiming an order.

The value pill is the correction door: it opens the primary object's
declared `status` values to pick from (upward — the rail sits at the
viewport bottom), plus an add-new row that **extends the enum and pins
the beat in one gesture** (values normalize to lowercase-hyphenated
canon; a missing `status` field is minted as an enum field on first
add). A pick writes through `setStoryTransitionTo` — the edge becomes
identity for lifecycle reachability, the command patch, and ActionPane,
and travels on the existing `'story/set-transition'` op. Extension goes
through `updateObjectField`/`addObjectField` (whole-array enum patch,
the #33 convention).

**Rode along:** the floating **CanvasDock is removed** — the bottom
pill read as a clickable-canvas affordance the canvas doesn't have, and
the rail now owns that edge. Its one live control, the comments toggle,
moved to the right sidebar's tab-bar meta cluster beside Activity
(`CoachingSidebar.tsx` TabBar); the dock's admin cluster was already
fully commented out. `CanvasDock.tsx` stays on disk as the token-
migration exemplar its header documents, but nothing mounts it.

**The rail's second wave (2026-09-01)** — four riders, none conflicting:

- **Other writes surfaced.** `queryStoryClauses(storyId)` (store) reads
  the loader-emitted clause payloads (`story/sets` beyond the primary
  status write, `story/grants`/`story/revokes`/`story/adds`) via
  `ds.pull` — the one read that serializes the CLJS structures
  seedProject transacts verbatim (probe-verified). The rail renders them
  as quieter clause lines under the headline
  (`sets Appointment.teacher to AssistantTeacher`,
  `grants RetreatVolunteer to Student`), read-only. Studio-authored
  beats carry none (the authoring path writes only the transition edge)
  — the honest empty. An act beat with only extras (a grant) shows them
  without the status headline.
- **The spine under the card (2026-09-15).** What the value leads to is
  drawn as a small timeline dropping out of the card's left edge:
  **unlocks** (beats whose must-precondition names the landing value;
  capped at 3 + a count, scan skipped past 300 stories) and **finality**
  (`@final` via `ObjectField.finalValues`) are the spine's stops, one
  grammar for both: a mono label whose glyph sits ON the rail (the lock
  for `unlocks · N`; a square terminal stop for `final`), with the
  unlocked beats indented beneath as one-line jump links (full title in
  the tooltip) and final's note inline on its label row. A birth beat
  opens the same spine ABOVE the card — a ring stop, `on create`, "a new
  X starts with this status" — the mirror of final's square end. The
  `derived` provenance is a tiny explained pill beside the value pill.
  The card itself stays one fact. The hover popover behind an icon cluster that
  held them (with the condition) is gone: the condition is the Rules
  section's own row now, and a floating panel inside the scrolling pane
  kept sliding under the canvas (owner call, same day). The `derived` chip stays separate: it flags the VALUE's
  provenance and disappears once a value is pinned. Finality is
  AUTHORED per value in the field editor's enum chips (the matching
  checkered-flag toggle — [entity-authoring
  spec](../entity-authoring/spec.md)); multiple values may be final.
- **The mutation-verb nudge (2026-09-01).** A beat whose verb sits in
  the classifier's `modify` category ("updates", "changes", "edits"…)
  but records NO state change (no edge, no clause extras) gets a
  caution-gold warning row in the rail: *"updates" sounds like a
  change, but none is written* — with a quiet **ask about this** door
  beneath it (normal ink: the warning is gold, the way out is
  ordinary). The door switches the sidebar to DETAILS and drops a
  drafted question into the "Ask about this story…" box, focused and
  editable ("What does this story actually change — should Lead's
  status move, and to what?") — the conversation is the resolution
  path, not a silent filing. Plumbing: `askPrefill {text, nonce}`
  threaded page → CoachingSidebar → PaneFrame → AskInput's existing
  prefill contract. No clause line renders in the nudge state (a
  first cut showed the choose-a-status pill; reverted same day).
  Deliberately a nudge, never a lint: the beat may legitimately edit
  plain fields, which per-beat authoring can't express yet. Stateless
  verbs ("reviews", "contacts") stay quiet.

---

## Classifier — at commit (detail)


---

## 1. What the classifier does

The classifier runs **once at commit** over a *story tree node and its beats* and
produces a structured **classification** that downstream consumers (render layer,
verification, Scenarios, competency questions) depend on.

**It is not** a chat-time intent inferrer, nor a freeform analyzer of arbitrary
prose. It operates on **committed stories**: well-formed Actor–Action–Object beats
(per the story grammar below) inside a story-tree node, with attached **rules**
and **annotations**. Pre-commit, the system uses local nomination and coaching;
classification is what fires when the user commits.

---

## 2. Story states

A story has three states (this is the deterministic-trigger contract the classifier
operates inside):

- **Draft** — being authored; not classified.
- **Committed** — user has performed the commit gesture; classification fires here.
- **Modified** — a committed story has been edited; reverts to needing
  re-classification on next commit.

The states are built (`runtime/store.ts`: `commitStory`, `markStoryModified`;
every text edit routes through the latter). Commit runs the classifier against
the post-accept catalog and caches the structured `CommitClassification` on the
story. Every read path goes through `getValidCachedCommitClassification`
(`runtime/store.ts`), so a cached classification stops being served three ways,
each matching what changed:

- **The story text changed** — the edit flips committed → modified
  (`markStoryModified`); the accessor returns null for anything but
  'committed', so both the canvas readout and the surface derivation
  (`deriveBeatDocs`) fall back to live classification of the *current* text
  until re-commit rewrites the snapshot. A modified story never renders from
  its old text's classification.
- **An entity was renamed** — `renameEntity` retracts the cache outright
  (the stored text/entity sets are rewritten, so the snapshot is meaningless).
- **The ontology context shifted** (a status enum edited, a rule
  attached/detached, an actor boundary flipped, a parent beat reworded) —
  every cached classification carries the `ontologyContextHash` of the context
  it was derived from; the accessor recomputes the hash from the live store
  and treats a mismatched or unstamped cache as absent, falling back to live
  classification until the next commit re-caches.

(Both guards are pinned in `runtime/classification-cache.test.ts`.)

---

## 3. Inputs to the classifier

Per beat, the classifier consumes:

- **The beat sentence** — Actor, Action, Object (with slot labels per the story
  grammar; bulk is the `every` determiner before the always-singular declared
  noun — the `*` plural mark is retired, 2026-08-24).
- **The ontology context** — the actor's and object's **archetype** (moment-
  interval, role, party-place-thing, description), any phase the actor bears, and
  the entity declarations from the org's single flat ontology.
- **Attached rules** — pre/post/invariant predicates from the [rule-dsl](../rule-dsl/) feature. A
  postcondition that's a state-change is direct evidence the action is a
  `transition`; an authorization rule is direct evidence of slot-eligibility. Rules
  are a primary classification input, not just downstream artifacts.
- **The actor's markers** — human vs. agent (axis 1 of render), inside vs. outside
  the org (axis 2). These don't change the action *category* but they are read
  alongside it because they determine render targets later.
- **Surrounding beats** — the immediate predecessor and successor beats in the
  story, for orphan-effect resolution per the DST stress test.
- **Existing competency questions** — to detect whether this beat introduces
  vocabulary that resolves a previously uncovered question.

---

## 4. Outputs — what the classifier emits per beat

Per beat:

- **Action category** — one of the **nine**: `instantiate`, `modify`, `transition`,
  `associate`, `derive`, `query`, `capture`, `emit`, `log`. Closed set, derived from
  the algebra of EAV deltas. (See the story-tree / identity-scope section and the
  verifiable-rule fragment.)
- **Object archetype confirmation** — the Coad archetype the object bears:
  moment-interval, role, party-place-thing, description. The ontology already
  declares this; the classifier confirms it is consistent with how this beat
  treats the object.
- **Execution locus** — in-runtime, external-software, physical-world. Inferred
  from action semantics + actor markers; modeler may override. Drives render
  (Command vs. External-Action vs. Checkpoint).
- **Rule-derived attributes** — what rules attached to this beat assert
  (pre/post/invariant, polarity, attachment). The classifier does not author
  rules; it propagates them as inputs to downstream consumers.
- **Slot bindings (placeholders)** — for slot labels like `Employee:Requester`,
  the classifier records the slot label as a story-local role to be bound at
  Scenario time.
- **Ambiguities (LLM residue)** — explicit list of judgment points the classifier
  could not resolve deterministically; surfaced as coaching prompts.

Per story-tree node:

- **Identity-scope candidates** — when an entity name repeats across child beats,
  the node is a candidate identity scope for that entity. The scope resolves to the
  **nearest common ancestor** of the beats that share the entity; the classifier
  proposes it per slot and the modeler confirms.
- **Story-vs-rule divide check** — every committed sentence must be either a
  story beat (Actor–Action–Object) or a rule. The DST divide stress test confirms
  this is exhaustive. The classifier flags any committed sentence that isn't.
- **Orphan-effect resolution** — System-effect beats are resolved by "belongs to
  narrated story" (the story-vs-rule split); ambiguous orphans become coaching prompts.

---

## 5. The deterministic / LLM-judgment split

The classifier is **deterministic-first with LLM residue**, mirroring the render
layer's same split:

**Deterministic:**

> The verb→status tier and produced-status persistence in the first bullet are
> superseded 2026-08-24 — see the walk map in
> [full-decision-pass-2026-08-22.md](../ontolang/full-decision-pass-2026-08-22.md):
> a transition's produced status is an explicit authored `sets X.f to V` clause
> (door-proposed, author-confirmed); the declared-aware conjugator survives only
> as a typing-assist proposer, never as classification or the stored
> representation. The built derivation path below (verbToStatus classification,
> derived-form transition-to edges) is queued for the released corpus sweep.

- Action category — derivable from {verb semantics + EAV delta shape + attached
  rule shape}. Across the validation corpus (~13 seeds, FHIR additions) the
  category is determined by these inputs. Verb semantics resolve in tiers
  (`categories.ts`): the curated verb table (+ stem heuristics) always wins;
  a verb the table doesn't know classifies as **`transition` when a conjugated
  past tense of it matches (case-insensitively) one of the primary object's
  declared `status` enum values**
  ("Sales qualifies Lead" with Lead.status ∈ {new, qualified, routed}) — the
  same `verbToStatus(verb, declaredValues)` resolution the runtime uses for
  `transitionTo` (the declared spelling wins over string morphology), so the
  classified transition always produces a legal status value; then the
  corpus-distilled verb dictionary; then the `capture` default. The declared
  enum outranks the dictionary because it is object-specific declared truth
  (owner decision 2026-07-30). The status enum reaches the classifier as
  `OntologyContext.objects[].statusValues` (lifted from declared fields by
  `buildOntologyContext`) and participates in the context hash, so an enum
  edit invalidates cached classifications through the hash-validated read
  described under Story states above — remove the enum value a transition
  verdict derived from and committed beats re-classify live instead of
  serving the stale verdict.
  - **The produced status persists as model data** (2026-08-01 — *morphology
    may propose, only identity may persist*): confirm resolves the beat's
    produced-status edge and stamps it as **`story/transition-to`**
    (`confirmStory` → `setStoryTransitionTo`). Resolution priority: the
    declared-aware conjugator's output matching a declared enum value
    (canonical casing, when transition-classified) → an existing pinned edge
    that is a declared value (the unreachable-lint mint's explicit intent —
    survives curated-table disagreements like `submits`=instantiate and
    conjugation misses) → the derived form for open-vocabulary transitions →
    no edge. Every downstream reader — lifecycle reachability, the command
    patch, the ActionPane's `transitionTo` — uses the stored edge verbatim
    instead of re-conjugating the verb, the confirm broadcast carries it to
    teammates, and it round-trips through `projectToSeed`/`seedProject` like
    the uid. The conjugator remains only a proposer (draft wording, match
    candidates) — never the stored representation or the equality test.
- Object archetype — declared on the entity in the ontology.
- Slot surface marks — the `:` slot label in the DSL syntax; multiplicity comes
  from the `every` determiner word, not a noun mark (`*` retired 2026-08-24).
- Story-or-rule sort — the DST divide (the story-vs-rule split).

**LLM judgment (proposal, modeler-confirmable):**
- Genuine orphan effects (rare; the story-vs-rule split).
- Emit-with-physical-counterpart (Coffee finding — is the call in-model or
  out-of-model? this is a modeling-choice coaching prompt the classifier surfaces).
- The thin sliver of capture-of-existing-vs-new where archetype doesn't decide.

**Coaching prompts (the LLM's primary role at classification time):**
- DST-divide failures — a committed sentence that's not a story beat → "this
  reads like a standing truth/conditional/universal — should it be a rule?"
- Modeling-completeness gaps — surfaced from uncovered competency questions
  ("you said the buyer's tier matters — Buyer has no tier field").
- Emit-with-physical-counterpart resolution.

---

## 6. Downstream contracts — what consumes the classification

The classifier output is the contract consumed by:

- **Render layer** ([rendering (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/rendering/)) — uses action category + actor nature +
  org boundary + execution locus + archetype + attached rules to map each beat to
  a surface from the **surface catalog** (`surface-catalog.md`).
- **Verification** (the verifiable-rule fragment) — uses the
  classification + attached rules to evaluate properties in the named fragment
  (stratified Datalog runtime; QF-LIA + EUF verification; linear arithmetic only;
  discrete/integer timeline).
- **Scenarios** ([scenarios (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/scenarios/)) — uses the classification to know which slots
  need binding for a Scenario to demonstrate a beat or subtree.
- **Competency questions** — uses the
  classification to determine which questions a model can express (type-level
  satisfaction) and which Scenarios concretely demonstrate them (example-level
  satisfaction).

---

## 7. What the classifier does NOT do

- It does not author rules (rules come from the user via coaching, or are
  attached pre-existing).
- It does not author Scenarios (Scenarios are user-authored in play mode).
- It does not generate UI (the render layer consumes classification output).
- It does not produce business logic (no compiler-side conditionals over domain
  semantics; the no-code-generation boundary).
- It does not classify pre-commit drafts (that is the local-nomination + coaching
  layer's job).

---

## 8. Validation status

The nine-category algebra is **validated against 13 seed domains plus FHIR
clinical workflows** (~380 sentences). The DST story-vs-rule divide is **stress-
tested across 14 domains** with one ambiguous class (orphan System-effect)
resolved by the "belongs to narrated story" refinement.

The classifier **eval set** itself remains unbuilt.

---

## 9. Open

- The exact deterministic rules (verb-semantic table, EAV-delta-shape match
  patterns) that resolve action category are settled in spec but not yet expressed
  as code. Reconciling them against the existing codebase is still open.
- Pre-commit nomination vs. commit-time classification — the boundary is clear
  (pre-commit = nomination + coaching; commit = full classification), but the
  classifier currently runs partially in pre-commit (see the `classifier-at-commit/`
  package). Reconciling the existing eval loop with this commit-time spec is still open.


### The left nav — one rail, the tree inside it (2026-09-11)

Every project-scoped view shares **one left rail** (`GlobalNav`): Overview ·
Stories · Model (Actors / Objects / Schema / Records) · Simulate (Surfaces /
Scenarios) · Research (Research chat / Roleplay). **The story tree lives
inside it, under the Stories item** — the filter box first, then the tree,
then a hairline and the remaining sections — so the rail reads as one nav
and the tree is where you'd look for it (Adam, from the Paper
"left-rail-combined-expanded" artboard). The rail is **open by default** and
collapses to an icon strip from the toggle in its own header; the choice is
remembered per browser. Collapsed, an icon click goes there and the toggle
reopens — there is no hover flyout anymore. Open, the rail's right edge
drags to resize (240–480px, remembered per browser — the old tree panel's
handle, brought back the same day).

**Each section row is two gestures:** the row navigates to the section's
primary view; the caret at its right folds the section's contents open or
closed in place — the story tree under Stories (mounted on every view, so
the tree is one caret away anywhere), the child rows under Model /
Simulate / Research — without leaving the current route. Arriving at a
view unfolds its section. The filter box under Stories is outlined with no
fill (so it doesn't merge with the active row's raised fill); the SORT
menu beside it is hidden for now.

What retired with it: the 56px hover `NavRail`, the separate story-tree
panel with its resize handle and re-open strip, the tree's *All stories /
Recently viewed* tabs (no recent list — the tree is one click away
everywhere), the drill-in (push) navigation mode, the tree's bottom
*New story* button, and the top nav's `+ NEW STORY` (removed the same
day, Adam — new stories start from the Overview's add door and the
tree's row menus). The
Surfaces and Scenarios views keep their own inner beat/role rail beside
the nav, with its own collapse.

### Story list organization (2026-09-11)

New folders prepend to the root mixed list without rewriting existing relative order. Dragging can place them anywhere afterward; stored mixed order is authoritative. Sort menus in the editor and overview offer creation time (newest/oldest), primary actor, primary object, and unconfirmed-first status. Sorting is a one-time operation over complete sibling lists, preserving folder/story hierarchy and persisting the result; there is no Manual sort option. New stories and folders record creation timestamps, carried by create operations and seed/backfill round trips. Older records without timestamps use deterministic tie-breaking; their historical dates are not fabricated.

Search includes folder names and preserves ancestor context. A matching folder exposes its subtree for browsing; matching descendant stories retain their containing folders. Search does not alter folder expansion state. Empty matching folders are results too.

Selection uses plain click, Command/Control-click to toggle, and Shift-click for a visible range across folders and stories. A selected folder moves as a unit. Shared selection-root logic removes overlapping selected descendants and rejects moves into a selected folder or its descendants. The selection toolbar includes Move to folder and New folder from selection. Single and batch drags share one drop handler for root/folder ordering, nested story ordering, reparenting, and outdenting. Selected rows move as a block in visible order; affected sibling lists are rewritten once after membership changes, and story/folder cycles are rejected before mutation. Folder drops preserve the destination's open/closed state. Folder disclosure buttons and double-click toggle expansion; Rename remains in the row menu.

The shared Button forwards native props/ref so Radix triggers retain keyboard, pointer, focus, and accessibility behavior. Selection math, folder destinations, sorting, and mutation planning are shared rather than separately implemented by the overview and editor.
