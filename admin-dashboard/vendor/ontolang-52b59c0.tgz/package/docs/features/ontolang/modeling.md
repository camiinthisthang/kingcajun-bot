> Portable snapshot of maintained Onto material. [Package capabilities](../../../START_HERE.md) define the shipped boundary; dated decisions and host implementation notes are context. [Source manifest](../../../SOURCE_MANIFEST.json) records provenance. Links marked “Onto source” are optional host/background references.

# ontolang — modeling rules

> **Authority note:** this page is the accumulating source of modeling rules and best practices —
> the guidance that teaches a person or an LLM to model a domain *well*, as opposed to
> [grammar.md](grammar.md), which says what parses. The agent-facing prompts
> (`studio/app/lib/prompt-to-project-prompts.ts`, `import-prompts.ts`, `rule-suggestion-prompt.ts`,
> `studio/app/api/coach/route.ts`)
> and the studio lints are kept in step with this page: **a modeling ruling edits this page and
> those files together.** Decisions and their reasons: [backlog.md](backlog.md) (Roles over kinds).
> Rules marked *[designed]* rest on machinery that is decided but not built yet.

**Actor policy implementation, 2026-10-10:** syntax, propagation, Studio controls
and local trusted entry are built. Missing legacy policies remain private QA with
notices; participant entry requires explicit policy. See the [spec](spec.md#actor-policy--built-locally-2026-10-10)
and [runtime boundaries](../rule-runtime/spec.md#actor-entry-and-enrollment).

## Actors

**1. Every actor declares its type: person, organization, or system.**

| Type | What it means | Examples |
|---|---|---|
| `@type person` | A role that people hold. One human can hold many roles; all person roles draw from the same pool of people. The same human can be Teacher and Student. | Teacher, Applicant, Guest |
| `@type organization` | A role that organizations hold. Same sharing: one company can be both Label and Publisher. | Community, Buyer, Funder |
| `@type system` | Software that acts on its own. It is the thing itself, not a role. Automatic execution also requires the platform to own that execution, as described below. | Scheduler, MarketingSite |

Write `@type person`, `@type organization`, or `@type system` explicitly on a bare actor. A narrower role inherits its base chain's kind. The loader tolerates an omitted bare-actor kind and reads it as person, but explicit is the modeling rule: automation is opt-in, so nothing acts autonomously unless the text says so.

**Affiliation and access are separate declarations.** *[built locally, 2026-10-10]* Every actor, including a role or derived subset, declares `@affiliation internal | external` relative to the operating organization and `@access authenticated | public | none` for direct application participation. Affiliation is per role: one person may be an external Student and an internal TeacherAssistant. Authenticated access requires verified identity and role eligibility; public access requires no login; none provides no direct application access as that actor. Public access is available to signed-in people too.

The current implementation uses `@boundary external` to distinguish incoming events from internally executed system beats. The new organizational affiliation must not carry that execution behavior or bypass authentication/eligibility. System execution ownership remains a separate runtime decision in the [plan](actor-boundary-plan.md#remaining-bounded-decisions-and-deployment-work).
*Lint direction: require explicit affiliation/access; propose a missing type from evidence, never infer access, enrollment or management authority from a name.*

**2. Model agency with actors.** In a workflow, places, lists, documents, and stores are objects, even when a beat sends something *to* them. Kitchen, Board, and TaskList are objects. A device or service that acts on its own is `@type system`. Actors exist only by declaration — a parser never invents one from a preposition target ("to TaskList" does not make TaskList an actor). A descriptive vocabulary may declare an actor before any Story uses it.
*Lint direction: review the kind of an actor that never acts in the modeled workflow; absence from Stories alone does not invalidate standalone vocabulary.*

**3. Declare how a person joins each role.** *[built locally, 2026-10-10]* Use `@signup self | invite | none` on the actor. `self` permits self-service and invitation enrollment; `invite` requires an invitation for enrollment; `none` permits neither. All three still allow authorized direct grants to existing people. The mode does not specify who may invite or assign roles; that authority belongs to platform configuration. See the [mode table](actor-boundary-plan.md#signup-modes--ratified-2026-09-10) for the contract and the remaining omission/applicability decision.

Several roles may offer self-signup; the person joins the selected role using one account. Choose the actual domain role: anyone may become Student immediately if that is the intended policy. Add an Applicant or provisional role only when the domain needs that distinction. Neither absent seeds/grant stories nor the person's first action makes a role open. No self-signup roles does not by itself mean invite-only: roles may instead be granted or provisioned.
*Lint direction: inspect the declared signup policy and protected base-role prerequisites; never deduce enrollment from missing grant stories.*

**4. Never declare the substrate.** Do not write a Person or Organization block, and do not write `is a Person` — a bare actor already is a role over its kind. Use `is a` only for a role over a narrower base (`actor LegalCounsel is a Company`) or an object subtype (`object Drink is a Product`).

**5. Agency is intrinsic.** If an entity ever decides, approves, signs, or picks, it is an actor everywhere — never also declared as an object.

## Roles and grants *[designed]*

**6. Grant a role only if the domain addresses people by it downstream.** If a later beat, gate, or seed names the role, the conferring beat carries `grants X to Y`. Otherwise the object's status is the whole effect — `Teacher grants GroupMembership to Student` needs no clause; "granted" on the membership is the complete outcome.

**7. Put domain grants under the beat that decides.** The `grants`/`revokes` clause indents under the beat, like a gate. The receiver must be named in that beat's own sentence, by the role they hold *now*: `Teacher approves MembershipApplication from Applicant` + `grants Student to Applicant`. Under the ratified actor-policy design, ordinary administrative assignment uses standard platform role operations; it needs no invented business story. Both paths enforce the same identity, authority and role prerequisites.

**8. Enrollment uses standard platform flows.** *[built locally, 2026-10-10]* Signup means joining as a role: the platform creates or reuses the person's account and activates the selected eligible role through its declared flow. Login alone acquires no role. Invitation acceptance activates an offered role; a direct authorized grant to an existing person needs no invitation acceptance, even with `@signup invite` or `@signup none`. Do not model signup, login, recovery, invitation tokens or account provisioning as beats — these are platform capabilities (rule 10).

Custom domain flows use domain objects and may invoke standard grants/revocations. A Student's RetreatBooking approval changes the booking; it does not grant OldStudent or DedicatedStudent. An authorized administrator may assign assigned roles separately. The current Sangha
corpus retains attendance-derived OldStudent, which is never manually granted. A domain-triggered invitation needs the planned platform invitation operation; an immediate `grants` clause does not represent a pending invitation.

**9. Role fields are capabilities, never dates or names.** The assignment records since-when by itself (`from`/`to`), and the person carries their own name. `approvalLimit: money` belongs on a role block; `hireDate` and `name` do not. Mirror link lines are legal on role blocks too (2026-08-26 — a mirror is a link declaration, not a per-holding value): `territories: Territory[] @of(owner)`.
*Lint: time-style or identity-style field on a role block → move or delete.*

## Stories

**10. Stories model the domain's work, never the platform's machinery.** No beats for accounts, login, sessions, tokens, or saving data. Cut `Student registers with System`; keep `Applicant submits MembershipApplication`. The exception: when the machinery *is* the product (a media server's account management is its domain).

**11. Add organization actors when the domain needs their agency.** In workflow design, a beat such as `Student offers Donation to Community` supplies evidence for considering Community as an organization actor, declared with `@type organization`. Do not invent organizational parties just to fill a sentence. Descriptive vocabularies may declare organization actors without Stories; declaring a type does not create organization records.

**12. Keep process records and standing state apart.** An application, letter, or booking is immutable history — an object with a status enum. What someone *is now* is a role: an assigned role can be granted/revoked through a domain beat or, under the ratified actor-policy design, standard platform administration/enrollment. Rule 6 decides when a domain outcome needs a role grant; a derived subset uses `@where` instead of assignment.

**13. One atomic step per beat; decompose coarse activities.** "Processes", "handles", "onboards" hide multi-step phases — write the top-level beat and its ordered sub-beats.

## Naming

**14. CamelCase entity names, one spelling, every position** — declarations, beat text, rule text. `FrontDesk`, never `Front Desk`. No code, UI, or database words.

**15. Never end an entity name with a value-type word** (Type, Status, Category, Priority, Rate, Amount, Date, Count, Level). Those read as properties and fold away: `RoomClass`, not `RoomType`. Value-type words belong in field names.

**16. Verbs are single lowercase words.** The verb states what the actor does. Write its status effect explicitly in an indented clause such as `sets Loan.status to "returned"`; the loader never derives a status value from the verb. Keep that machinery out of the sentence.

## Rules layer

**17. Conditions live in rules, never in beats.** A plain "X does Y to Z" is a beat; anything with a condition, universal, prohibition, or standing truth is a rule.

**18. Write the conditions the workflow needs.** Status gates are explicit: a return restricted to checked-out loans writes `requires Loan.status is "checkedout"`. Enum declaration order supplies comparison rank, never an inferred workflow or previous-state gate. Author thresholds, cross-object guards, cardinalities and invariants in their own words too.

**19. Prefer a status enum over a boolean lifecycle.** `Claim.status is "frozen"` beats `Claim.fraudSuspected is true`.

**20. Complete managed workflows; keep descriptive enums descriptive.** A `status` enum becomes a managed lifecycle only when a Story writes it. Each creating door writes its own birth with `sets X.status to "value"`; different doors may choose different declared values. An omitted birth fills with the first value for compatibility, but canonical source writes it explicitly. Managed values need a written producer or initial record; when the list is read it needs an `@final` ending, with routes from nonfinal values to an ending. Incomplete managed workflows remain editable with readiness advice and refuse execution compilation/publication. A descriptive enum needs no Story, producer or ending, and enum rank alone supplies none of them. See [workflow readiness](spec.md#standalone-models-and-workflow-readiness--2026-10-10).

## Linking beats to records *[RATIFIED 2026-08-24 — the walk closed this (D3/D5); rules 21–22 promotion rides the released doc pass → [full-decision-pass-2026-08-22.md](full-decision-pass-2026-08-22.md)]*

**21. Declare a ref from a record to each thing it belongs to.** `RetreatBooking` carries `student: Student` and `retreat: Retreat`. Those refs are the only way a beat can ever reach the record — no ref, no link. (The runtime half of rule 12: the process record names its parties.)

**22. A beat that moves a record it doesn't name introduces it with `finds`.** The sentence keeps the domain's noun; a `finds` line introduces the record by its full definition; later clauses use the name and write the change. Nothing resolves by name; an unintroduced clause name is a pointed error. *(Spelling ratified 2026-08-26, superseding the earlier bare-name form — see [binding-backlog.md](binding-backlog.md) item 2.)*

```
Student completes Retreat
  requires Retreat.status is "completed"
  finds RetreatBooking
    where student is Student
    and retreat is Retreat
    and status is "attending"
  sets RetreatBooking.status to "attended"
```

*(Ratified word rule outside filters: a link atom — entity to entity — is always `where`; a
condition — path vs value — is always `requires`/`forbids`. Inside a `finds` filter, conditions
join with `and`, bare fields belong to the found type. The studio proposes the `finds` line at
the door; the file carries it as real text. Exactly one match or the step refuses.)*

*Lint: a transition beat with no `sets` clause → propose one from the verb and the declared enum (assist at typing, never derivation at load).*

**23. Who-did-it is never a field.** The log records the actor of every fire; a person-ref exists only where a beat, gate, or seed reads it. `Teaching.author` stays when a publish gate reads it; `lastEditedBy` never exists — a surface that wants it derives it from the log. The field's name proves nothing: `reviewer` looks like who-did-it but is standing state the review beat gates on.
*Lint: a person-ref no beat, gate, or seed reads → delete it; derive from the log.*

**24. Name a participant only when a clause consumes it.** *(Ratified 2026-09-01 — decision trail in [backlog.md](backlog.md).)* Every sentence name is a question the runtime asks at the door, and the only handle clauses can target. Before writing `prep X`, ask: **can the beat reach X through a record it already names?** If yes, don't name X — path to it (`GroupMembership.applicant`) or introduce its record with `finds` (rule 22). Name X only when the beat needs the answer from outside:
- it **fills a ref on the record the beat creates** — `Student requests GroupMembership for Group`: `for Group` fills `GroupMembership.group`, and nothing else can supply it;
- a **`finds` runs on it** — in `Student starts Retreat`, the sentence names are the keys that locate the booking;
- a **`sets`/`adds` writes it** into a field, or a gate reads it and no named record's ref reaches it;
- a **`grants`/`revokes` targets it** — rule 7's sentence-named receiver: `Teacher revokes GroupMembership from Student` keeps `from Student` for `revokes DedicatedStudent from Student`.

A participant whose only clause is a `where` pin to the object's stored ref fails the test: the door asks a question with one legal answer, and the pin re-derives what the record already stores. `Teacher approves GroupMembership from Student` + `where GroupMembership.applicant is Student` does exactly the work of `Teacher approves GroupMembership` — write the short form. The look-alike that stays: a `where` pinning the **actor** (`where Appointment.teacher is AssistantTeacher`) is a permission gate — only the assigned teacher may fire the beat — never redundant.
*Lint: a participant whose only clause use is one `where` pin to a stored ref of the beat's object → propose dropping the name and the pin together.*
