> Portable snapshot of maintained Onto material. [Package capabilities](../../../START_HERE.md) define the shipped boundary; dated decisions and host implementation notes are context. [Source manifest](../../../SOURCE_MANIFEST.json) records provenance. Links marked “Onto source” are optional host/background references.

# The full decision pass (2026-08-22)

**Status: pre-walk audit, kept as record. The walk over this board CLOSED 2026-08-24 with all 14 rows ratified; outcomes live in THE WALK MAP below, which supersedes the recommendations in sections 1–7.** Every decision made and pending,
across the 11 open PRs, the drafts, the branches, and all 17 feature backlogs, audited against
[the literature survey (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/research/business-process-modeling-survey.md), [the roles &
extension prior-art pass](../../research/roles-extension-prior-art.md) (the second machine's
companion audit), the corpus passes, and the PR-110 ratified base. Sources: a 140-item inventory
extracted from the repo docs + PR states; each item audited for what needs deciding, the
literature's bearing (cited, or honestly "none"), a recommendation consistent with the ratified
base, and urgency. The walk order at the end is the owner's queue.

## 1 · The ruling queue — needs the owner

| Decision | What needs deciding | Literature says | Recommendation | Urgency |
|---|---|---|---|---|
| **Current-ness — the amended six points** (binding queue 5) | Ratify: occurrences are instances; liveness is the occurrence's OWN state (walked, clock-derived from its own dates, or derived) — never a neighbor's position, never recency; closure only where addressed downstream; read-side plurality picks by address/pin/attribute; corrections mutate in place; period = occurrence entity or timestamps | Survey endorses all six; point 2 is the artifact school's founding tenet (Nigam & Caswell 2003) and Vernon's own-state rule; Kimball's as-of-then test is the ruling aid for point 5 | Ratify as amended; record the as-of-then test; write the party/occurrence vocabulary into modeling.md | **blocks-build** |
| **The case — scoped stories** (queue 3) | Global vs case-scoped stories; spelling; born mid-story; creating beat sets the case ref; flat vs nested | CMMN's Case + CaseFile; investment-bank is unwritable without it (corpus pass) | An ordinary occurrence record whose instance rides fire context — never a scope or log partition; born mid-story allowed; creating beat writes the case ref at birth as a real atom; one flat case per story, nesting via parent refs; the case enum gets `@terminal` | **blocks-build** |
| **`@terminal(value)`** | Add the declared, repeatable final-state mark? | Unanimous: workflow-net final markings (soundness is decidable only given one), YAWL, GSM/CMMN, Harel/UML final states, MERODE mandatory ending events, JSD, DEMO | Ratify as UML's final state (complete, record persists — never terminate/delete); missing terminal on an addressed arc lifecycle = hard load error; point-event carve-out (no enum) explicit | decide-soon |
| **Lifecycle closure checks — the graded package** | Ship the three loader checks; grading; the extra checks | Woflan lineage: model-time soundness diagnosis; a status enum + sets graph is a one-token net where classical soundness is decidable | Dead-transition + improper-completion = hard errors unconditionally; arc-stops-mid-air hard only under `@terminal`; **birth-value reachability ships with the base** (else "dead transition" overclaims); MERODE stuck-child + DEMO no-unhappy-exit as trailing lints; per-lifecycle scope line lands in the same ruling (cross-lifecycle composition is undecidable — Calvanese/De Giacomo/Montali) | decide-soon |
| **produces / conjugation retirement — formal ratification** | The retirement is decided-in-discussion, marked "pending ratification" in joins-tier-2.md | SSADM ELH ran load-time verb-derivation and the field abandoned it; frozen-in-text meaning is the audited direction | Ratify; the conjugator survives only as the studio typing assist; triggers the corpus sweep | decide-soon |
| **Ambiguity UX** (queue 4) | Where refuse-and-ask renders; the plural-by-design selection surface | RV-LTL monitoring: users act on WHICH constraint failed | One surface fed by the same conjunctive query, rendered two ways by plural-routing row: picker for plural-by-design (bound), refusal banner with per-atom attribution verbalized as domain sentences for plural-by-accident | decide-soon |
| **IR homes** (queue 7) | Homes for the sets fact, case declaration, non-party mark (dead), bound-input slot | OCEL 2.0 qualified event-to-object relations | Accept the three survey adds: adornment stored as an OCEL-style qualifier on fires' event-to-object relations; governing model-version hash on each fire; the fire id lives on the bound-input slot (pairs with idempotency below) | decide-soon |
| **Human-create idempotency** | Exactly-once for human create beats (double-publish-on-refresh, g02) | Helland 2007, verbatim recipe | Client-minted fire id at surface render; dedupe at commit on (beat, fire id); symmetric with intent keys | decide-soon |
| **Subject-scoped counts** (rule-dsl) | Rule cardinality can't scope a count to the subject through a ref | SQL ASSERTION history; the ratified conjunctive-query semantics already covers the shape | Extend decision 2's one-conjunctive-query semantics to rule cardinality — makes "one OPEN record per tuple" writable; lands with the binding runtime residue | decide-soon |
| **Handler policy — close it** (rule-runtime) | Custom handler code (tier 3)? tier-1 provider? + the intent permanent-failure gap | Saga/EIP: dead-letter channel; compensation is a business action, not machinery | One ruling: tiers 1+2 ship, tier 3 shut (fence hard if ever reopened); every intent kind declares a permanent-failure path; dead-letter = standing violation; post-execution divergence compensated by authored beats | decide-soon |
| **System-beat executor — build now?** | Owner-confirmed need (2026-07-30); design owned by the iteration answer | YAWL cancellation regions: one-event-voids-many is first-class; the sweep's cascade absences (Retreat never closes) are its evidence | Authorize building ahead of the `every` word: singular system beats + standing gates cover cascades and expiries with no new grammar; enforce the self-extinguishing check at load | decide-soon |
| **Seed refs by instance label** | Name-vs-identity rule at absorb time (`roomClass: "Standard"`) | Chen's weak entities; ORM reference schemes: identity on the party/master | Door-time resolution (absorb is an authoring gesture — no breach of loader-never-derives): label resolves against the target's declared name field, exactly-one-or-error, stores the ref | decide-soon |
| **Same-type addressing** (queue 6) | Colon labels vs positionals | Unanimous for names: CPN variables, ER/UML association ends; positionals have zero precedent and break under edits | Colon labels; no new syntax; note merged #105 already stores labels as story data | can-trail |
| **`every` — pre-ratify snapshot semantics** | Semantics now, word later | YAWL static-MI mode; OCPN variable arcs | Snapshot-only: one intent per member of the satisfying set at firing time; filtering via defined subsets; never min/max/threshold knobs; the WORD was admitted at D14b (2026-08-24), superseding the transcription tripwire | can-trail |
| **Rounding — pre-accept the shape** | Tripwired on first division formula | FEEL's decimal surprise is the cautionary tale | Explicit rounding word per division site, no global default; largest-remainder for money allocations; pre-accept so the tripwire resolves without a session | can-trail |
| **Period sugar** | Tripwire stands | No audited notation has date-bucketing syntax | Keep closed; if ever admitted: sugar over endpoint comparisons against declared calendar data, never viewer locale | rides current-ness |

## 2 · Riders on ratified decisions — approve the text, mostly

| Rider | What it is | Recommendation | Urgency |
|---|---|---|---|
| **@unique riders** (survey contradiction 1) | Three sentences: nothing may ever treat `@unique` as identity; the live-scoped cardinality idiom is the hard constraint; the allocation-domain residue named. ContactForm.email already proved the trap | Approve as doc text (ontolang spec + modeling.md), adopting ORM's alethic/deontic words | decide-soon |
| **Per-case deviation** (contradiction 2) | Onto can't unstick one occurrence; case handling warns deviation migrates to email and the log stops being truth | Rule it either way: an authored per-type override-beat convention (gated, logged, never a runtime override) — or an explicit out-of-scope statement | decide-soon |
| **Rules 19–20 riders** (contradictions 3+5) | (1) a stored status = irrevocable progress; anything revocable is a derived field or role edge; (2) rule 20 widens to "every value needs a producer: a beat, a `type system` beat, or a clock/derived transition" | Land both sentences + the widening on modeling.md | decide-soon |
| **Obligations scope line** (contradiction 4 / gap) | No "this beat is now owed" construct; DECLARE/DCR treat obligations as half the language | Record the deliberate scope: obligations in onto are system auto-fire, deadline now-invariants, or social; tripwire = first government/casework domain | decide-soon |
| **Bitemporal wording** (contradiction; architecture docs) | Replay gives transaction-time travel only, never valid time | Narrow overview.md's sentence; reword "never stored separately" to "always derivable by folding" | hygiene |
| **grammar.md determiner line** | §2 still describes the dead story-run draft | Rewrite at binding ratification (determiners ride `every`) | rides ratification |
| **Companion-audit shortlist** (roles pass) | R4 role-over-role (always-a anchored to base holding; block by default, cascade only authored) · the same-instance pin (two names may co-bind unless an atom forbids — a binding-backlog addition) · sharpened O3 interface tripwire wording · the Steimann-GPA modeling rule (non-capability role state derives from facts or lives in a process record — rule 23's R2-side sibling) | Ratify the four as listed in [the pass (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/research/roles-extension-prior-art.md) §"What to ratify now" | decide-soon |

## 3 · Ratified, unbuilt — execute, no ruling needed

In build order: **prelude** (kind catalog last in resolution; Person/Organization stay first-class IR entities — the UFO guard; Company enters as rigid subkind) → **`type` word** (three-valued `actor/type`, SYSTEM_ACTORS demotes to proposal) → **is-a collapse** → **assignment-edge fields** (loader acceptance paired with the store's edge fields — one change, never split) → **grants/revokes** (fold in explicit `from`/`to` + the period-contains-now resolution switch). Gate met — the walk closed 2026-08-24; **the corpus sweep** is RELEASED as one pass, executed only on the owner's explicit ask. The consolidated checklist, in final spellings: `sets`/`adds` write lines everywhere; link atoms materialized as written clauses; both-sides `Type[]` mirror lines + `@of`; `@final` marks (renamed from `@terminal`; the conditional is resolved — D6a ratified); the D4 terminals work list; name-join ref fixes at party entities (hotel guest/room, sangha donor/recipient); sangha Admin correction; identity off ContactForm onto a party entity; IB Deal born at pitch; lowercase status values; star-plural removal (including its doc mentions); LLM prompts + the Claude authoring skill respelled to the explicit forms (D7 rider); seeds re-versioned once (right shape first, never protect goldens) — then **seed retirement into fixtures** (after the sweep, so fixtures re-version once). Also: **the iteration-answer public writeup** (owner-priority since 2026-07-24; the survey supplies citations — FEEL chose words-not-symbols too), **binding runtime residue** (conjunctive-query resolver, sets-exclusion, refusal surfaces; route **guarded associate** through the same op path), **modeling.md 21–22 promotion + the grammar card update** (at walk-through close / queue landing), **clock in the scenario players**, **dead-branch/unsatisfiable-gate lint** (one QF-LIA call; schedule after the closure checks), **unit algebra** at the formula type-checker.

## 4 · Parked with tripwires (no action)

Value groups over flat enums (5+ values, repeated gate subsets) · REA duality lint (accounting package; sangha ref fix already in the sweep) · party merge/split (same-name minting meets real data; MDM survivorship is the model) · right to erasure (first EU/UK personal-data deployment; the party-entity move helps) · recursive roll-ups (chains tripwire; audit the Datalog-recursion canon first) · fast engine (scale trigger; differential-test against the reference loop) · `every` word admission — no longer parked: admitted at D14b, 2026-08-24.

## 5 · Studio & platform — the other features' opens

**Coaching** — six questions deliberately parked for an owner-interactive session (interruption model, answer landing place, answer scope, confirm gesture, LLM inside classify-at-commit, proposal traffic control): schedule the session; no literature bearing beyond BDD's confirm-loops. **Multimodal #116** — four product questions in the PR body (repo-LLM default, Enter behavior, chip dismissal semantics, first-website-only). **Types** — Resource kind (leaning hold — hold), canonical lookup-table membership review, soft enum values in UI (confirm), Place/Area surface timing. **Comments** — promote-to-question disposition; thread closure (need not demonstrated — wait). **Entity-authoring** — noun-kind suppression surfacing (ResiduePrompt category + copy), state-adjective folding (authorize or defer). **Importer** — iterative decomposition + new sources: both stay unauthorized. **Rendering** — scenario-to-production compile readiness (rides scenarios competency + runtime verification). **Analytics** — event list (team conversation). **Auth** — migration strategy (pick `drizzle-kit migrate`, don't mix), localStorage disposition at server move. **Authoring-sync** — activity ledger during replay (settle with the first emit-growing helper). **Rule-runtime small** — must-not advisory polarity (at rule-dsl rebuild), persistence-readiness question (is a durable browser store still needed now Postgres is truth? — likely retire), contributed-field marking (at next form-doc schema change). **Roles-permissions** — permissions over holdings, phase machine (superseded shape — ordered enum on the assignment), nomination non-default forks, LLM read-residue proposer (tripwired), viewer-keyed caches (rides read-permission); spec reconciliation pass when the queue lands (companion-audit housekeeping).

## 6 · PR hygiene — the ledger

**Executed 2026-08-22–24 — kept as record.** See handoff addendum 7 and the merge-train record
(pr-merge-train-2026-08-22): #108/#107 merged, #77/#78 closed, #110 closed (the walk carried on
draft #124), the remaining queue (#99/#103/#117/#123/#116/#76/#127) merged with docs reconciled.
Open remainder: draft #124 and #126.

| PR | State | Action |
|---|---|---|
| **#108** roles over kinds | mergeable, no blocker; only the `kind`→`type` spelling note needs updating (ratified 2026-08-19 on #110) | **Merge first** — it un-stacks #110 |
| **#110** this branch | draft; conflicts with its advanced base | Rebase onto #108's head after its merge; keep draft until the walk-through closes |
| **#99** sentence-grammar board | mergeable but a week stale; lists actor-as-direct-object as undecided (ruled, shipped in #107) and determiners as open (moved out of tier) | Refresh the board, then merge promptly — docs PRs must not queue behind feature work |
| **#107** actor as direct object | green, 902/902, mergeable; draft only for sequencing with #99 | Undraft and merge; flip #99's board row in its refresh |
| **#103** hyphenated conjugation | stranded: base `fix/colon-labels` is dead (#102 closed, superseded by merged #105) — the known stranding pattern, sitting since 2026-08-15 | Rebase onto staging; scope note: the load-time path it improves is retiring — the conjugator survives only as the studio assist, so the fix retargets there |
| **#78, #77** | based on `main`, 305 commits behind; both predate CamelCase, participants pairs, the closed class, roles-over-kinds | Retarget-or-close call; #77's seed needs a grammar-current rewrite either way |
| **#123, #117, #116, #76** | all CONFLICTING with staging after #120/#122; three touch the same hot files; #123 bundles two unreviewed intro-tour commits; #76 should follow #116's NewProjectPane rewrite | Pick a merge order (suggest #117 → #123 → #116 → #76); accept or split #123's bundling |
| **Read head + spec drift** | README lists merged streams as in flight (brand-onboarding, op transport, locking, mentions); authoring-sync spec stops at the seam while staging carries the transport; realtime backlog contradicts itself on locking; comments backlog contradicts the feature map; enum #33's PR is closed but its branch lives | One reconciliation pass: read-head refresh + spec graduations; decide enum #33's revival separately (≈85% built, needs a hard rebase) |
| **Residue phrasal-verb bug** | ' in' substring match fires inside "invoice"; parked in the coaching brief, no owner stream | Fix the word boundary — small, unowned |

## THE WALK MAP — fixed numbering, never renumbered again

**THE WALK CLOSED 2026-08-24 — all 14 rows ✅.** Do-not-build lifts: the section-3 build order, the corpus sweep (one pass), and the runtime residue are released. The position rule below is retired with the walk.

**Position rule (retired):** every walk exchange opens with its position line —
`D<n> <name> — top-level <n> of 14 · part <x> of <y>` — and this table is the single tracker:
a part gets its ✅ the moment it is ratified. "Where are we" is always answerable from this table
alone.

| # | Decision | Parts | State |
|---|---|---|---|
| D1 | Instance sources (bound / unbound / enumerated) | — | ✅ ratified 2026-08-19 |
| D2 | One conjunctive query | — | ✅ ratified 2026-08-19 |
| D3 | Atoms & the words | a atoms-as-real-text · b where/requires · c sets-exclusion · d collision · e who-did-it | ✅ all parts, 2026-08-19 |
| D4 | Current-ness | six points a–f (occurrences are instances · own-state liveness · closure-where-addressed · read-side plurality · corrections keep identity · period rule) + the as-of-then aid | ✅ ratified 2026-08-23 (point e reworded: correction = new write on the same record, log keeps the old value — no physical mutation anywhere) |
| D5 | The case → links consolidation | a existence/shape · b spelling · c born mid-story · d create-writes-case-ref · e flat + parent refs | ✅ CLOSED 2026-08-24: uniform colon declarations (`name: Type` / `name: Type[]`), named-field paths, no ownership machinery, explicit `sets`/`adds` writes, `about` stories + birth-beat & system-step rules, nested set words with recorded exclusions + `distinct` trigger; earlier `has`/born-in forms superseded |
| D6 | Lifecycle closure | a `@final` · b graded loader checks + birth-reachability · c per-list scope line | ✅ CLOSED 2026-08-24 (all parts; cross-list exploration goal logged in backlog.md) |
| D7 | produces / conjugation retirement | single ratify (releases the corpus sweep) | ✅ ratified 2026-08-24; rider: LLM prompts + Claude authoring skill must emit the explicit spellings (swept with the corpus sweep) |
| D8 | Ambiguity UX | a one-surface/two-renders · b refusal × read-permission (S3) | ✅ CLOSED 2026-08-24 (self-explaining refusal from the step's own query; unreadable matches shown as a count) |
| D9 | Fire identity | a per-run bookkeeping · b human-create idempotency | ✅ ratified 2026-08-24 (how-it-got-there labels, model version, render-minted run id deduped at the door) |
| D10 | Riders on ratified decisions | a @unique · b status discipline · c obligations scope · d corrections (three write channels) | ✅ CLOSED 2026-08-24 |
| D11 | Runtime rulings | a outside-action policy · b system-step runner · c counts through links · d seed name-pointing | ✅ CLOSED 2026-08-24 (all four) |
| D12 | Semantics batch | a ensures retire · b visibility · c multi-sets · d negated links · e creation-fill · f S7 residue · g value casing | ✅ CLOSED 2026-08-24 (a–g) |
| D13 | Companion roles shortlist | a role-over-role · b same-instance pin · c bundle trigger wording · d role-link state rule | ✅ CLOSED 2026-08-24 (a–d) |
| D14 | Trailing pre-accepts | a same-type labels · b `every` (ADMITTED, superseding the reservation) · c rounding word · d the #99 five | ✅ CLOSED 2026-08-24 — **THE WALK IS COMPLETE: 14 of 14** |

Everything else on this board is **execute-without-ruling** or parked-with-tripwire — never part of
the walk count. PR hygiene runs in its own chip session.

## The owner walk order (superseded by the walk map above — kept as the derivation)

Blocks-build first; each is one ruling.

1. **Current-ness** — ratify the amended six points, with the as-of-then test as the ruling aid?
2. **The case** — ordinary occurrence record, fire-context instance, case-ref atom at birth, flat + parent refs, `@terminal` on its enum?
3. **`@terminal(value)` + the closure package** — the mark as UML final state; two unconditional hard errors; mid-air hard only under the mark; birth-reachability in the base; per-lifecycle scope line?
4. **produces/conjugation retirement** — formally ratify (conjugator = studio assist only), releasing the corpus sweep?
5. **Ambiguity UX** — one surface, two renders (picker / attributed refusal banner)?
6. **IR homes + idempotency** — the OCEL-style qualifier, model-version hash on fires, client-minted fire id deduped at commit?
7. **@unique riders** — approve the three sentences as doc text?
8. **Rules 19–20 riders** — irrevocable-progress discipline + rule-20 widening?
9. **Obligations** — approve the scope line with the casework tripwire?
10. **Per-case deviation** — authored override-beat convention, or out of scope: which?
11. **Handler policy** — close as tiers 1+2 only, tier 3 shut, declared permanent-failure path per intent kind?
12. **System-beat executor** — authorize building now on the cascade evidence?
13. **Subject-scoped counts** — extend the one-conjunctive-query semantics to rule cardinality?
14. **Seed labels** — confirm the door rule (resolve against the declared name field, exactly-one-or-error)?
15. **Companion shortlist** — R4 role-over-role, the same-instance pin, the O3 wording, the Steimann-GPA rule?
16. **Same-type** — colon labels?
17. **Pre-accepts** — snapshot-only `every`; explicit-rounding-word shape?
18. **PR hygiene** — merge #108 now; refresh-and-merge #99; undraft #107; rebase #103; retarget-or-close #77/#78; the feature-PR merge order; accept #123's bundling?
19. **Sessions to schedule** — the coaching six; #116's four product questions; the small types/comments/analytics/auth calls.

Semantics-pass additions (fold into the same sittings):

20. **S7 field placement under the collapse** — edge-by-default with `name` on the base, or an explicit split spelling? *(blocks the type-word build — rule before step 1's build queue starts)*
21. **S1/S4/S5/S6 clause-semantics batch** — retire `ensures`; multi-`sets` rules; negated `where`; the creation-fill rule with entity-valued `sets`?
22. **S2 visibility** — cycling `published|hidden` standing state; erasure stays platform-side?
23. **S3** rides ambiguity UX (question 5) · **S8** casing sweep · **S9** the #99 four at its refresh · **S10** substrate session scheduled post-sweep.

## 7 · The semantics pass (2026-08-22, second sitting) — verification finished + the coverage matrix

The workflow's dead verify stage, finished inline, plus a systematic walk of the language surface
(every declaration form, clause word, and runtime path from grammar.md + the rule-runtime spec)
asking per cell: pinned by a ratified decision, by built code, or by nothing. **Verification
verdict:** the board held — no named decision was missing from the docs it swept; memory and the
recent-session artifacts surfaced two items doc-extraction missed (rows S10–S11); the consistency
check found no recommendation contradicting the ratified base (the deletion answer below was
adjusted once to honor the rules-19/20 irrevocable-progress rider). The matrix found the rest:

| # | Unpinned behavior | Recommendation | Urgency |
|---|---|---|---|
| S1 | **`ensures` after `sets`** — a postcondition check beside an explicit write is redundant or subtle; nobody has said which | Retire `ensures` from beat clauses behind the admission bar (postconditions were already "the verb's job"; conditions live in rules; `always` covers invariants) — readmit only when a corpus beat needs a non-write check on the candidate | decide-soon |
| S2 | **Instance deletion / hiding** — no beat vocabulary; the store can't delete; the wild corpus demands delete + restore (datahub) | Visibility is a **cycling standing-state field** (`published \| hidden` — cycles are legal, so restore breaks no rider); arcs never regress; true erasure is a platform operation, never a domain beat (rides the erasure park) | decide-soon |
| S3 | **Refusal × read permission** — the ambiguity banner can name candidate instances the firer may not read | The banner lists only readable candidates; unreadable ones appear as a count ("2 more you cannot view"); fold into the ambiguity-UX ruling | rides ambiguity UX |
| S4 | **Multiple `sets` in one beat** — same field twice? ordering? | Any number of `sets`, distinct fields; a duplicate same-field write is a `file:line` error; order is irrelevant (one candidate application) | ratify with the queue |
| S5 | **Negated links** — `where X.f is not Y` | Legal; stays a `where` (the word follows function; identity-negation already exists in the rule grammar) | ratify with the queue |
| S6 | **Creation × binding** — examples fill a created record's refs from bound/unbound names (`sets Estimate.round to Round`) but no rule was ratified; entity-valued `sets` never pinned | Ratify as shown: a creating beat fills each declared ref from a sentence name or an explicit entity-valued `sets … to Entity` clause; entity-valued `sets` is the spelling | decide-soon |
| S7 | **Field placement under the is-a collapse** — a bare actor's block fields: edge (the role) or base (the person)? `name` is identity and must live on the shared person, but the collapse leaves no declared base block | Needs an owner ruling before the type-word build: either all bare-actor fields are edge fields except the platform identity field (`name` → base), or an explicit split spelling. **Blocks the implementation queue** | **blocks-build** |
| S8 | **Enum value casing** — the card mixes `Small \| Medium` and `requested \| confirmed` | One convention: lowercase values, CamelCase reserved for entities; sweep the card's subtypes example | hygiene |
| S9 | **#99's recorded rulings** — eight written into its backlog with recommendations; several since decided elsewhere | Triage at the #99 refresh: ~four live (prepositional verbs `pays-for`, bare numbers vs digits in names, plurals, the star marker, the defined-subsets detail); adopt their recorded recommendations in one batch | decide-soon |
| S10 | **App-truth substrate revisit** (memory, owner reframe 2026-07-24) — ontolang as transport/git-interop; a Unison-style structure store for app truth; printer totality as the load-bearing discipline | Real, open, and **orthogonal to domain-building** — the current store works; schedule as its own architecture session after the ratification sweep, don't let it block building | can-trail |
| S11 | **The announcement draft's claims** — public behavioral commitments (no loops, twice) never audited as decisions | Audit rides the already-queued iteration-answer writeup — one pass, same doc | execute |

**Multi-user fire conflicts** (two users fire the same beat on the same instance) checked and found *pinned by doctrine*: commits serialize, the loser's gate re-check refuses — no new decision.

## Execute without ruling

The section-3 build queue and sweeps · iteration-answer writeup · binding runtime residue + guarded associate · doc promotions (modeling 21–22, grammar card, spec graduations, read-head refresh, bitemporal wording) · clock in players · dead-branch lint · unit algebra · residue word-boundary fix · seed retirement after the sweep.
