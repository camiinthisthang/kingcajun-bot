---
name: onto-authoring
description: Author, edit, or review Ontolang (.onto) domain models, including entities, Stories, Rules, Formulas, seeds, vocabulary imports and portable templates. Use for .onto work or converting domain descriptions into Ontolang; read the maintained grammar before choosing syntax.
---

> Portable snapshot of maintained Onto material. [Package capabilities](../../START_HERE.md) define the shipped boundary; dated decisions and host implementation notes are context. [Source manifest](../../SOURCE_MANIFEST.json) records provenance. Links marked “Onto source” are optional host/background references.

# Authoring ontolang

Use the maintained Ontolang grammar and parser to choose syntax. Keep Stories
(events), Rules (constraints), and Formulas (computations) distinct.

## Read first, in order

1. [docs/features/ontolang/grammar.md](../../docs/features/ontolang/grammar.md) — what parses; superseded forms carry notes.
2. [docs/features/ontolang/modeling.md](../../docs/features/ontolang/modeling.md) — the numbered modeling rules (actors, roles, stories, naming).
3. [examples/ontolang/sangha/](../../examples/ontolang/sangha/) — the reference corpus: every ratified construct, exercised. Copy its shapes.

Use [the current language spec](../../docs/features/ontolang/spec.md) to separate
built behavior from proposals. When a form's status is unclear, consult
[language decisions](../../docs/features/ontolang/backlog.md) and
[binding decisions](../../docs/features/ontolang/binding-backlog.md); older
decision notes do not override the current grammar, implementation or examples.

## Current spellings

- **Entities:** `actor Name` / `object Name`; CamelCase names, one spelling everywhere, at most 24 characters (ruled 2026-09-02);
  `@type person | organization | system` written explicitly on every actor; `@description` lines.
  Declaration metadata wears `@` (2026-08-29): field lines stay bare; every non-field line in a
  declaration block is an annotation (`@description` · `@type` · `@rule` · `@where` ·
  `@boundary external` · `@affiliation` · `@access` · `@signup`). Story clause words under beats stay bare.
- **Derived subsets:** `actor OldStudent is a Student` + indented `@where <predicate>` — the
  `@where` line flips `is a` from granted role to derived subset (read-only, no fields, never
  seeded or granted). Header `=` is retired; `=` marks formulas only. A quantifier atom may end
  with a trailing `in <[]-field>` (closes that one atom; bare fields are the element's):
  `@where some status is "attended" in retreatBookings`. Quantifier words are `no`/`some`/`all`;
  numeric bounds (`at least 2 …`) stay for counting. Two conditions on the same element need the
  introducer-first layout (`no RetreatBooking in retreatBookings` + indented `where`/`and` lines).
- **Links:** uniform colon lines, written on BOTH sides — `student: Student` on the record,
  `bookings: RetreatBooking[]` on the other block (actor blocks carry mirror lines too);
  `@of(field)` when several links join the same two types; two `[]`-links between the same
  types is an error — use a join record. Two scalar links pair as one-to-one.
- **Standalone vocabulary:** actors, objects, relationships, subsets, Rules and
  Formulas may exist without Stories. Object parents remain concrete. Descriptive
  status enums need no producer or ending; reading or seeding a status does not
  turn it into a managed workflow.
- **Managed statuses:** lowercase values; every creating beat WRITES its birth
  (`sets X.status to "value"`, 2026-08-29 — omitted fills with the first declared value at the
  door, but canon always writes it; per-door birth values are legal; enum order = rank only);
  a Story-written lifecycle needs a producer or initial record for every value,
  an ending when read, and routes from nonfinal values to that ending. Incomplete
  workflows remain editable with advice and fail execution compilation/publication;
  explicit writes out of final states remain source errors without `@correction`.
  Point events can have no status list.
- **Creating doors:** a status-bearing record is born where its birth line is written on a story that reads nothing about it (no gate on its status, no `where`, no `finds`). A record with NO status list (a point event — a Donation, an Invoice) is born only on a verb the classifier knows as creating (`creates`, `opens`, `starts`, `submits`, `registers`, `places`, `requests`, `files`, `draws` …); `sends`, `offers`, `pitches` are emits and create nothing at runtime — pick a creating verb or give the record a status list.
- **Stories:** sentences are domain speech — `Actor verb Object [prep Participant]`, at most
  two participants, the sentence at most 90 characters (ruled 2026-09-02); machinery lives ONLY in indented clauses. A participant must be consumed by
  a clause — it fills a ref on the record the beat creates, a `finds` runs on it, or a
  `sets`/`adds`/`grants`/`revokes` uses it (modeling rule 24, 2026-09-01). Never name a party a
  stored ref already determines just to pin it back with `where`
  (`Teacher approves GroupMembership`, not `… from Student` + a `where` pin); a `where` pinning
  the ACTOR is a permission gate and always legal.
- **Clauses:** `where` (entity-to-entity link/check) · `requires`/`forbids` (conditions) ·
  `sets X.f to v` (every transition writes its status explicitly) · `adds X to Y.f` ·
  `grants Role to Person` / `revokes` · `finds Type` + indented `where`/`and` lines (one
  condition per line) to introduce a record the sentence does not name — exactly one match or
  the step refuses. A clause name with no sentence, `about`, or `finds` source is an error.
- **Creation:** a beat creates exactly the record its sentence names as object; links fill from
  sentence names or written `sets`/`adds` lines — in an `about` story, write the context link
  (`sets CIM.deal to Deal`). The creating beat also writes the birth status
  (`sets X.status to "requested"`).
- **Rules:** `@rule` in a type block (replaced `always`, 2026-08-29); counting rules may scope
  per fields: `@rule at most 1 RetreatBooking per student and retreat where status is not "attended"`.
- **Formulas:** `field: type = expression` — aggregations scope through the linking ref;
  conditionals are value-first with mandatory `else`; integer arithmetic; money is minor units
  with decimal sugar in typed defaults, seeds and write/find clauses. Rule/Formula
  numeric literals use whole stored units. Division uses `rounded down` or
  `rounded up`; `nearest` is unsupported. Ordered enum comparisons use declaration rank.
- **Portable reuse:** pinned vocabulary imports keep shared declarations read-only
  at the loaded revision. Caller-defined template modules compose ordinary model
  content. Walkthrough and template companions carry validated configuration and
  metadata; execution, persistence and hosting belong to a compatible runtime.
- **Roles:** bare actor = role over person; `is a` only for a narrower base or object subtype;
  role blocks carry link mirrors and capability fields only — never `name`, dates, or statuses;
  person enrollment is explicit `@signup self | invite | none` with `@access authenticated`;
  declare `@affiliation internal | external`. Never infer openness from absent seeds/grants.
  Missing policies remain authoring/private QA only; participant entry requires them.
  Standard platform enrollment is separate from domain Stories. Preserve existing derived
  role predicates unless the user deliberately changes the domain model.

## Workflow organization

Suggest grouping related Stories into meaningful business workflows as their purpose
becomes clear. A workflow can span several actors and objects; name it for the work's
purpose, not the first object or an Ontolang story-block label. Do not delay a clear
Story while waiting for more Stories or a complete workflow. Leave it ungrouped when
its placement is uncertain.

When the host supports workflow groups or folders, read the current organization
through its supported API and reuse returned IDs and names; never invent IDs. Preserve
human-renamed groups, edited placement and exclusions unless the user requests changes.
Use supported organization operations for changes; otherwise offer grouping as a
suggestion. Folder organization is separate from Story decomposition, Rules and execution;
grouping alone does not change their meaning or behavior.

## Never emit (retired or rejected — pointed errors)

`produces` · `ensures` under beats · bare `rule` · `role … over` · `given` · `has` /
`has one/many` · `@terminal` · comma field modifiers · `(stamped on create)` · determiners
`a`/`an`/`the`/`all` in sentences (`every` is the only determiner) · plural nouns for
multiplicity · prepositional-verb compounds (`pays-for` — make the record the object; hyphens
only for true phrasal verbs like `checks-in`) · free-standing clause names with no `finds`
introduction · who-did-it fields (`lastEditedBy` — the log carries actors) · spaced or
non-CamelCase entity names · `always` in type blocks (now `@rule`) · bare `description`/`type`
lines (now `@description`/`@type`) · header `=` subsets (`actor X = Base where …` — spell
`is a` + `@where`).

## Validate the authored result

The parser catch-up shipped: the loader and printer speak every ratified construct above —
annotations, `@where` subsets, `Type[]` mirrors + `@of`, `@final` + managed workflow
advice and execution-readiness checks, written birth (an omitted birth line
fills with the first declared value; the printer always writes it), the full clause family,
`about`, `every`, `Type:label`, `@correction`, `per`/`some`/trailing `in <[]-field>`, and
division with a mandatory rounding word (`/ … rounded down|up` — bare `/` errors).
Run `parseProjectFiles` and `printProject`, then reopen printed files to verify
literal fidelity and the complete model. The package offers browser-safe APIs,
Node loading, RDF export, editor support and generic template/walkthrough tooling.
Story execution, persistence, scheduling and application hosting belong to Onto
or another compatible runtime. The current spec documents their boundary.
