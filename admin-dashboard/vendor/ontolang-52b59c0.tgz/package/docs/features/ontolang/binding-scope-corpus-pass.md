> Portable snapshot of maintained Onto material. [Package capabilities](../../../START_HERE.md) define the shipped boundary; dated decisions and host implementation notes are context. [Source manifest](../../../SOURCE_MANIFEST.json) records provenance. Links marked “Onto source” are optional host/background references.

> **Layer: cross-cutting** — evidence pass for the joins tier 2 decision ([joins-tier-2.md](joins-tier-2.md)).

# Binding & scope — the full-corpus pass (2026-08-19)

> **Vocabulary note (post-ratification, same day):** this survey says *selected/resolved* and
> *cast/free name*. The ratified words are **bound/unbound** ([binding-backlog.md](binding-backlog.md)) —
> bound = the instance arrives with the fire; unbound = the beat's query finds it. This dated
> survey keeps its original wording.

**Status: dated evidence pass, kept as record.** The decisions it fed are all RATIFIED (D1–D14,
2026-08-24; see [binding-backlog.md](binding-backlog.md)); parts of the designs surveyed here were
superseded at ratification. Requested by the owner in the
2026-08-19 session ("binding specific instances and scoping — scoped stories vs global — we need to
make some decisions; do a pass across the full corpus, wild as well, and not just what is there but
what we *would* want to write").

**Method.** The whole authored corpus read in full (coffee, hotel, lead-intake, investment-bank,
plus the sangha corpus in [backlog.md](backlog.md)); all 22 wild requirement sets
(`examples/wild-corpus/dalpiaz/`, ~1680 real user stories) analyzed by five parallel agents against
a fixed questionnaire: what process records a real ontolang model would declare, where beats must
reach unnamed records, where "exactly one live instance per party tuple" is true vs false, same-type
collisions, non-party refs, bulk actions, and scope containers. Verbatim quotes below are data from
those files, nothing more.

**The rule under test** (where the session left off): a beat that touches a record its sentence
doesn't name binds it through the record's declared refs, matched by type against the beat's cast;
exactly one live instance or refuse; explicit `requires` atoms as the override; nothing by name,
nothing probabilistic, nothing remembered between fires.

---

## Verdict at a glance

Coverage of each domain's reach-back beats by the rule as drafted (creation beats need no binding
and are excluded; "few" is explained below and is mostly *not* a failure):

| verdict | domains |
|---|---|
| most | recycling g04 · camperplus g12 · datahub g14 · badcamp g21 · unibath g24 · culrepo g27 · **sangha** |
| about half | federalspending g02 · loudoun g03 · scrumalliance g10 · planningpoker g13 (→ most with chaining) · mis g16 · neurohub g18 · alfred g19 · rdadmp g22 · racdam g26 · zooniverse g28 · **hotel** |
| few | openspending g05 · frictionless g08 · nsf g11 · cask g17 · archivesspace g23 · duraspace g25 · **investment-bank (unwritable without a case scope)** |

Two consistent clusters:

- **The rule's home turf is the gating record** — memberships, subscriptions, grants, bookings,
  registrations, care relationships, permissions, locks. Exactly the records sentences never name,
  in every domain, and no domain contradicted exactly-one-or-refuse for this class. The wild corpus
  even demands the refusal by name: *"prevent users from double publishing FABS submissions"* (g02),
  *"no one can submit the same answers multiple time"* (g10), *"the deployment will fail with a
  version conflict error"* (g17).
- **The "few" cluster is artifact/cataloging domains** (repositories, DAMS, content platforms):
  instances arrive by browse-search-select, ownership is plural by design, and the party refs
  correctly demote to *authorization guards*. Binding was never their bottleneck — selection is.
  (cask g17 is developer tooling — version-addressed and set-oriented; arguably outside the target
  class of domains entirely.)

---

## The decisions (each with its evidence)

### 1 · Where an instance comes from — selected, resolved, or enumerated

Every entity position in a beat gets its instance in exactly one of three ways:

- **Selected** — named in the sentence → the instance is a **fire input** (the UI row, the thing in
  hand, the scenario player's pick, the queue item). Party atoms on a selected record are
  **guards** (authorization/consistency), never resolution. A named record whose refs match nothing
  in the cast is *fine* — `Administrator accepts Session` (g21) guards on status alone; any admin,
  instance from the list view. The wild corpus's #1 binding source by far.
- **Resolved** — *not* named in the sentence but touched by clauses → bound by the clause
  conjunction (decision 2); **exactly one satisfying assignment or refuse**. The sangha booking.
- **Enumerated** — system-actor beats (and the parked `every`): fire once per satisfying
  assignment. *"lift embargoes on the release date"* (g16), 30-day ad expiry (g10), *"bulk approve
  sessions"* (g21), one LeadAlert per routed Lead (lead-intake). Refuse-on-plural is a rule for
  *human resolution*, never a ban on plural operations — the plural shapes all live here.

This trichotomy is the same axis the story-authoring backlog already holds open as the classifier's
"select-one vs apply-each" question — one decision, both layers.

Refusal also turns out to be a *lint that writes better sentences*: `Parent signs ConsentForm`
refuses across the parent's children and forces the honest sentence `… for Camper` (g12).

### 2 · Clauses are one conjunctive query

A beat's atoms form a single conjunction over the cast plus any **free record names** the clauses
mention. Resolution = the unique satisfying assignment of all free names at once. Paths are legal
on both sides (tier-1 ref-hops, as built). This is the drafted "link atoms" semantics generalized
from one free record to several — nothing new to parse beyond `sets`, and it is the runtime's
native shape (reactive Datalog).

What falls out for free, with wild evidence:

- **Chains** — planning poker's defining beat (g13): `Estimator plays Card` reaches the open round
  through the seat: `Seat.estimator is Estimator · Seat.status is "joined" · Round.game is
  Seat.game · Round.status is "open"`. The hotel's `Guest requests Service` is the one-hop version
  (guest → checked-in reservation → new Service's ref).
- **Tenancy/permission joins** — `RoleAssignment.repository is Resource.repository` (g23),
  `Membership.publisher is DataPackage.publisher` (g14), `Lead.territory.owner is
  AccountExecutive` (lead-intake): the discriminating party is reached through a ref path, not the
  cast. Already expressible; must stay expressible.
- **Existence/cardinality guards** — *"limit to one registration per day"* (g21) is the existing
  `no TrainingRegistration where …` shape; *"retire after 15 classifications"* (g28) is
  `at least 15 Classification where subject is Subject`. No inventions needed.

### 3 · Declared refs imply the obvious atoms — with two exclusions and a mark

The implied-relation direction (this session: a record's declared refs *are* its parties; no
`@anchor`) survives the corpus, with the ladder the language already uses for aggregation `via`
("required iff several linking refs"):

- **Implied**: each ref whose type matches exactly one cast member contributes its equality atom.
  Matching respects the `is a` chain (a Participant-supertype cast member vs an
  `estimator: Estimator` ref needs the rule stated — g13).
- **Sets-exclusion (new, forced by the corpus)**: a ref the beat's own `sets` writes **never**
  participates in resolution. Without it, every claim/assign/review beat locks against its own
  empty ref: `assigns Inspection to Inspector` matches only already-assigned inspections (g03);
  `Scientist reviews SubjectPrompt` selects zero because `scientist` is empty until this beat fills
  it (g28); same shape g10, g27. Triple-confirmed, zero syntax, highest-value semantic fix.
- **Collision-refusal**: two same-type candidates on either side → `file:line` error naming the
  fix (write the explicit atoms). Never a pick.
- **Non-party refs need an answer**: audit/provenance refs are a live trap in *every* file —
  `creator`/`lastUpdatedBy` (g02), `placedBy` (g03), `invitedBy` (g14), `financialContact` (g16),
  `assignedCaregiver`/`prescribedBy` (g19), `checkedBy` (g24), `Event.agent` (g25),
  `lastModifiedBy` (g23). Sets-exclusion catches the write side; *read* beats still mis-bind
  (a merely-viewing caregiver force-matches `prescribedBy`). Two-part answer proposed:
  **doctrine** — who-did-it belongs to the log, not to fields (the platform derives provenance
  from beats; a modeling.md rule) — plus an **opt-out mark** for the genuinely incidental ref
  (`@nonbinding` / `@free`, spelling open).

### 4 · Current-ness is authored data — never memory, never recency

The live-status filter is **load-bearing, not decorative**: every plural-over-time tuple in the
corpus (rescans g26, re-requests, versions g24/g27, repeat registrations g21) becomes unique only
through `status is` atoms. `Version.status is "current"` turning plural into one (g27 unpublish) is
the rule working as intended. Consequences:

- The old open question 4 (terminal-status exclusion) resolves to: **status atoms, authored or
  studio-proposed** — no convention magic.
- Plural-by-design records get modeled current-ness: a current-version pointer or `superseded`
  status (g24), the **live-singleton-inside-a-container** idiom — planning poker's open Round,
  where one actor's selected beat *creates* the singleton everyone else binds (g13). "Selection by
  one actor manufactures the singleton for the rest."
- **"Latest" is never a resolution rule.** g05 asks for *"the most recent year"* as a default —
  that is a UI selection default, not binding.
- **Period windows are the one real sugar gap**: doses per day (g19), attendance per day (g12),
  submission windows (g16), camp editions (g21). Expressible today as timestamp comparisons with
  `now` (the lead-intake deadline pattern); whether `is today`-style date bucketing enters the
  grammar is a deferred spelling with a tripwire — the first seed that needs it (a camperplus
  attendance transcription would trip it).

### 5 · Scoped stories — the case

The investment-bank corpus is unwritable under cast binding alone: 50 objects, all per-Deal, and no
beat sentence ever names Deal (`Analyst drafts CIM`) — bankers don't say "the deal" in every
sentence, the same way students don't say "booking". The same ambient container recurs wild:
loudoun's Application ("the page they're on", ~30 stories), planning poker's Game (entered by URL),
the camp edition (g21), repository/unit tenancy (g23/g25), the project (g22).

**The proposal**: a story may declare its **case**. The case is a standing cast member of every
beat in the story, and its instance arrives **selected** (fire context: which deal you're working —
the page, the queue row). Records inside carry case refs (modeling rule 21 discipline); decisions
2–3 then bind through them unchanged. Global stories (sangha) declare nothing and work as drafted.

This is the rejected story-run scope rebuilt on data: "one run of the story" = one case instance;
the shared name→instance table the first draft wanted becomes the case's ref graph — visible,
declared, re-found from data at every fire, no runtime memory. Spelling open (`story Deal about
Deal`?), and sub-questions listed at the end.

### 6 · Same-type participants — real, rare, and the smallest decision

Verbatim in the wild: *"say one collection is related to another collection"* (g25), *"map an item
from one collection to another"* (g16/g27), file↔file predicated links as a feature (g18),
owner/packager pairing, dual guardians, member-emails-member. The ladder: **roles usually
dissolve it** (seller Business vs buyer Buyer; delegate `deposits Dataset for Researcher` works
because the types differ — g24); where they can't, explicit atoms need a way to address the two
cast members. Candidates: the standing story-role **colon labels**, or written-order positionals —
**never preposition semantics** (the 2026-08-13 ruling: the preposition is stored, not
interpreted). Undecided; can trail the rest.

---

## What we'd want to write (worked forms)

The meditation example, final form under decisions 1–4 — no atoms, generated comments carry the
wiring, `sets` stays:

```
object RetreatBooking
  student: Student
  retreat: Retreat
  status: requested | confirmed | attending | attended

story Retreats
  Admin schedules Retreat
  Admin opens Retreat
  Student requests RetreatBooking for Retreat
    # parties from the cast: student is this Student, retreat is this Retreat
  Admin confirms RetreatBooking for Student
    requires RetreatBooking.retreat.status is "open"
    # party guard: RetreatBooking.student is this Student · Admin matches no ref — any admin
  Student starts Retreat
    # resolves: the RetreatBooking whose student is this Student and retreat is this Retreat
    requires RetreatBooking.status is "confirmed"
    sets RetreatBooking.status to "attending"
  Student completes Retreat
    # resolves: the RetreatBooking whose student is this Student and retreat is this Retreat
    requires RetreatBooking.status is "attending"
    sets RetreatBooking.status to "attended"
```

The investment bank, writable for the first time (decision 5; spelling illustrative):

```
object Deal
  business: Business
  status: mandated | kicked-off | marketed | closed

object CIM
  deal: Deal
  status: drafted | redlined | final

story Deal about Deal              # the case — a standing, selected cast member
  VP kicks-off Deal with Business
  Analyst drafts CIM
    # case: CIM.deal is the Deal being worked
  VP redlines CIM
    requires CIM.status is "drafted"
    sets CIM.status to "redlined"
    # resolves: the CIM whose deal is this Deal
```

The chain (planning poker, g13 — pure decision 2, no inventions):

```
Estimator plays Card
  requires Seat.estimator is Estimator
  requires Seat.status is "joined"
  requires Round.game is Seat.game
  requires Round.status is "open"
  sets Estimate.round to Round          # creation: parties from cast + resolved records
  sets Estimate.card to Card
```

The one-hop version (hotel, after the binding pass adds `guest: Guest` — today the link is a
`name: string`, the exact name-join the design forbids):

```
Guest requests Service from Concierge
  requires Reservation.guest is Guest
  requires Reservation.status is "checked-in"
  sets Service.reservation to Reservation
```

The claim beat (zooniverse, g28 — sets-exclusion doing its work):

```
Scientist reviews SubjectPrompt for Subject
  requires SubjectPrompt.status is "raised"
  sets SubjectPrompt.scientist to Scientist    # written by this beat → excluded from binding
  sets SubjectPrompt.status to "seen"
```

---

## What this changes in the drafted design

**Survives untouched**: the clause family (`requires … is` / `sets … to` / `grants … to`),
re-find-from-data at every fire, no name resolution, refuse-don't-pick, the loader explicitness
check, `produces` retirement, generated-comment annotation (now mandatory at implied-binding
sites — the page-visible wiring).

**Changes**: the per-beat identity atoms become **implied from declared refs** (decision 3) with
atoms as the override; resolution is stated as a **conjunctive query** over free names (decision
2); the trichotomy (decision 1) scopes when resolution even applies; **sets-exclusion** is added;
the **case** (decision 5) is the missing piece the sangha corpus could never have shown.

**Dissolved along the way** (agent-proposed inventions covered by existing machinery): "given /
in-hand" markers (= decision 1's selected source) · aggregate-count and not-exists guards (the
cardinality shapes) · dotted-path atom sides (tier-1 ref-hops) · "latest" selectors (modeling
idiom + UI default) · preposition-keyed slots (ruled out 2026-08-13; colon labels are the standing
candidate).

## Census — the authored corpus in the ratified vocabulary (2026-08-19, second machine)

Owner request: "the % of bound vs unbound actors and objects." Every beat position in the five
authored projects tallied — 317 sentence positions (subjects, objects, prepositional
participants), plus the clause-only names the target rewrites add. Two axes, because the question
has two halves.

### Source mix — bound / unbound / enumerated (ratified decision 1 words)

As **written today** the corpus has no clauses, so every position is bound except the five
`type system` beats: **~95% bound · 0% unbound · ~5% enumerated**. Under the **target modeling**
(the pass's rewrites — rule-21 refs, the case for investment-bank, clause-reached records):

| kind | positions | bound | unbound | enumerated |
|---|---|---|---|---|
| actors | 185 | 176 (95%) | **0 (0%)** | 9 (5%) |
| objects | 135 | 126 (93%) | 3 (2%) | 6 (4%) |
| **total** | **320** | **302 (94%)** | **3 (1%)** | **15 (5%)** |

- **Actors are never unbound, anywhere.** No rewrite in 27 domains ever queries for a person —
  people arrive with the fire (subject, clicked row, participant) or as the enumerated work list.
- **Unbound names are rare and precious**: the sangha booking under `attends` (2 under the
  starts/completes revision) and the hotel reservation reached by `requests Service` /
  `generates Invoice`. Investment-bank needs **zero** unbound names once the case exists — every
  deliverable is named in its own beat; the case travels bound.
- Enumerated: the five system beats (hotel confirm/send-invoice; lead-intake create/route/alert).

The design consequence: the unbound query is a scalpel (~1% of positions), not the daily
mechanism — which bounds the implicitness worry — while guards on bound names (the same atoms,
checking instead of finding) are everywhere.

### Declaration health — supported / free-by-design / dangling

Orthogonal to source: can the declarations actually carry each position (guard it, attach it,
resolve it)? **supported** = refs/gates exist for what the position needs · **free by design** =
no link needed (interchangeable staff, catalogs, platform actors) · **dangling** = the domain
cares which instance and no declaration supports it.

| project | positions | supported | free | dangling | the dangles |
|---|---|---|---|---|---|
| coffee | 10 | 5 (50%) | 3 (30%) | 2 (20%) | `Order.customer` missing (the cup name is the join) |
| hotel | 37 | 12 (32%) | 15 (41%) | 10 (27%) | 9 of 10 are the one missing `Reservation.guest`; 1 is `Reservation.room` |
| lead-intake | 34 | 20 (59%) | 13 (38%) | 1 (3%) | `ContactForm` ↔ Prospect is an email-string join |
| sangha | 42 | 29 (69%) | 7 (17%) | 6 (14%) | `Teaching` author ×2, `Appointment` teacher ×2, `Donation` donor+recipient |
| investment-bank | 194 | **0 (0%)** | 75 (39%) | 119 (61%) | everything: 50 fieldless objects, no case |
| **total** | **317** | **66 (21%)** | **113 (36%)** | **138 (43%)** | |

By kind: **actors** — 9% supported · 59% free · 32% dangling (locks live on refs that mostly
don't exist); **objects** — 37% supported · 3% free · 60% dangling (overwhelmingly
investment-bank). Declaration level: **12 of 71 objects (17%) declare any ref at all**; **2 of
28 actors (7%) are referenced by any ref** (AccountExecutive via `Territory.owner`, Student) —
the only actors the runtime could lock or reach today.

**Read of the numbers.** Excluding investment-bank the corpus is 54% supported / 31% free / 15%
dangling — every dangle a small, nameable missing declaration (`Reservation.guest` alone is 9
positions). Investment-bank predates rule 21 entirely (zero refs, no case) and drags the corpus
to 21%. **After the ratification sweep** every dangling position converts: **~64% supported /
~36% free-by-design / 0% dangling** — the free share being exactly the interchangeable-staff and
catalog positions decision 1 says should stay free (IB staff could further convert if the domain
authors the team lock via a Staffing record).

## Open spellings and sub-questions (the decision list for the owner)

1. **Ratify the trichotomy** (selected / resolved / enumerated) — and its story-authoring twin
   (select-one vs apply-each).
2. **Ratify implied party atoms** with sets-exclusion + collision-refusal; pick the non-party
   answer (log-doctrine + opt-out mark; mark spelling).
3. **The case**: spelling (`story X about X`?); can a case be born mid-story (the deal after the
   mandate)? does a scoped story's creation beat auto-set the case ref (symmetric with party
   initialization)? one case per story, or nested (deal → diligence)?
4. **Ambiguity UX** (unchanged from the draft): where "refuse and ask" renders; now also the
   selection surface for plural-by-design domains.
5. **Period sugar**: leave as timestamp comparisons (status quo) with the camperplus tripwire, or
   admit date bucketing.
6. **Same-type addressing**: colon labels vs positionals (trailing decision).
7. **IR homes**: the `sets` clause fact (from the draft), the case declaration, the non-party
   mark, the selected-input slot on fires.

---

## Decision-4 sweep — current-ness over the full corpus (2026-08-19, six parallel readers)

Owner request: interrogate the amended decision-4 rule ("recurring occurrence = new instance +
own closing lifecycle; never a related record's process status; never latest") across the whole
corpus before ratifying. All 22 wild sets + the 5 authored domains, read in full, counter-examples
prioritized over confirmations.

### Verdict

| verdict | domains |
|---|---|
| rule fits as stated | planningpoker g13 · loudoun g03 · badcamp g21 · archivesspace g23 · unibath g24 · duraspace g25 · **coffee** |
| fits with remodeling | mis g16 · nsf g11 · racdam g26 · zooniverse g28 · camperplus g12 (year layer fits, day layer counters) · **hotel · investment-bank · lead-intake · sangha** |
| counter-example found | federalspending g02 · recycling g04 · openspending g05 · frictionless g08 · scrumalliance g10 · datahub g14 · cask g17 · neurohub g18 · alfred g19 · rdadmp g22 · culrepo g27 |

**The rule split in two, and the halves fared differently.**

**The instance half is confirmed everywhere.** Every domain natively reifies occurrences —
rounds, registrations, inspections, review cycles, enrollments-per-camp-year (g12 states the rule
almost verbatim: "my enrolled children to the camp year … who is still pending admission"),
accessions, releases, re-applications, copy-to-create courses. No domain refuted
new-instance-per-occurrence, and the two bans that started this decision survived untouched:
**never decide liveness off a related record's process position, never pick among records by
recency.**

**The own-walked-status-as-THE-liveness-mechanism half is too narrow.** The corpus shows liveness
arriving five ways, all structural, only the first being the rule as drafted:

1. **Walked lifecycle on the occurrence** — approval pipelines, registrations, holds, rounds
   (loudoun: "Create an Inspection", "Remove a Hold"; poker's round closed by accepting).
2. **Clock-derived from the instance's own dates** — submission windows, embargoes, job ads,
   publishing windows, "upcoming" courses ("set begin and end dates for a submission window",
   g16). A date predicate over own fields, not a walked enum — expressible today (`now`
   comparisons, time-flow built).
3. **Derived transitions** — status flipped by an aggregation or expiry, not a beat (zooniverse
   prompt-the-scientist triggers; restrictions that "become open" g26). Ties to the known
   aggregation pressure on Formulas; rule 20's "every value walked" meets derived transitions.
4. **No lifecycle at all — point events and observation streams** — donations, classifications,
   vitals, transactions. Born complete; closure only matters where something downstream
   addresses the occurrence (sangha's Donation is the authored proof). Recency over an ordered
   event log is legitimate semantics there ("since I last looked" g26, "changed since last
   registered" g25, alfred vitals) — distinct from picking among records.
5. **Multi-live by design, read side** — versions and renditions kept live forever for pinning
   and citation (datahub "keep multiple versions around… so that I do not break consumer
   systems"; unibath "the right version", explicitly anti-latest; racdam's parallel scans picked
   by purpose/quality attribute; neurohub branches with provenance pointers). Unique liveness is
   a property of process targets, never of read-side plurality; "latest" is legal as a UI
   default over retained instances.

**Shapes outside the rule entirely (honest carve-outs, not failures):** identity-preserving
corrections mutate in place + revision log (culrepo: "quickly correct errors … while leaving a
record of my revisions" — the same product that versions releases); mutable-present reference
data (facility info g04, GIS g03, openspending datasets); living singletons unique by relation
(rdadmp: one DMP per project); supersession lineage (parcel split/merge — successor pointers,
retired status); ledgers folded by date (FABS corrections, where the fold IS the semantics);
standing state on a substrate (onShift, room-clean, member-ness — where the person-shaped cases
are already answered by the roles machinery: **a fresh assignment edge per tenure with its own
from/to IS this rule in edge form, independently arrived at**).

### The authored corpus's two failure modes (the sweep's work list)

- **Missing terminals, uniformly**: sangha's Retreat never closes (`scheduled | open`), so
  `requires RetreatBooking.retreat.status is "open"` stays satisfiable forever;
  ServiceApplication has no rejected; GroupMembership no revoked; hotel has no guest-side
  cancel; lead-intake's ContactForm is statusless (nothing marks it consumed).
- **Identity conflated with the occurrence record**: `ContactForm.email @unique` — the corpus's
  one hard break — permanently forbids a re-inquiry (a re-lead is a hot signal, structurally
  banned); coffee and hotel dodge only because customers/guests are name-strings, not refs.
  Identity belongs on a party entity the occurrences reference. Related: `@unique` is
  single-field and forever — "one OPEN booking per (student, retreat)" is a cardinality rule
  (existing shape), not a `@unique`.
- Rider found by g02: instance-per-occurrence needs an idempotency story for human creates
  ("prevent users from double publishing … after refreshing") — the intent keys already give it
  to system beats.

### Amended decision 4, as the evidence writes it

1. Occurrences are instances (universal).
2. A process target's liveness is answered by the occurrence's **own** state — walked,
   clock-derived from its own dates, or derived — **never a related record's process position,
   never recency among records**.
3. Closure is required only where later beats, gates, or seeds address the occurrence.
4. Read-side plurality never demands a unique live one — address, pin, or typed attribute picks;
   "latest" is a UI default and legal over ordered event logs, never process resolution.
5. Identity-preserving corrections mutate in place *(reworded at ratification: a correction is a new write on the same record — no physical mutation anywhere; the log keeps the old value)*; occurrence
   minting is for identity-bearing recurrence.
6. Period sugar unchanged: the coarse period is usually a real occurrence entity (the camp year,
   the release slot); the fine period (per-day attendance, doses) is date-keyed events +
   timestamp comparisons — tripwire stands.

---

## Containment sweep — the D5 redesign over the full corpus (2026-08-24, six parallel readers)

Owner request: sweep the containment package (the D5 walk-through's redesign of the case) across
the whole corpus before ratifying. All 22 wild sets + the 5 authored domains read in full,
counter-examples prioritized. The design under test: `has X` declared on the parent (several
parents may declare the same child type; one home per instance); `about X` on the story (context
name; instance from the fire's working context); `adds X to Y` containment write at creation;
`where X is in Y` guard; conditions read directly off declared names; type-name hop upward,
set words downward; loader validates only, name-with-no-source = `file:line` error.

### Verdict

| verdict | domains |
|---|---|
| fits as stated | **sangha** (its `for Retreat` is the global spelling verbatim) · unibath g24 · rdadmp g22 · alfred g19 · datahub g14 · zooniverse g28 · planningpoker g13 · federalspending g02 |
| fits under the born-in doctrine (movable things stay refs/joins) | **hotel · lead-intake · investment-bank · loudoun g03** · camperplus g12 · badcamp g21 · scrumalliance g10 · mis g16 · recycling g04 · openspending g05 · frictionless g08 · nsf g11 · racdam g26 |
| stress domains — mutable hierarchy is the product itself | archivesspace g23 · duraspace g25 · culrepo g27 · neurohub g18 · cask g17 |
| containment-free (construct correctly inert) | **coffee** |

### What held

- Where a part is **born into its home and dies with it** — versions, tags, sections, pages,
  bookings, registrations, properties, observation streams — the package fits everywhere tested,
  and the promised investment-bank fragment IS writable (`about Deal` + `adds` + `is in`; ~10-beat
  end-to-end fragment recorded by the reader).
- Multi-home child types (different parents, disjoint instances) are real and exercised
  correctly: loudoun's Meetings under PreApplicationRequest/Application/PlanReview; archivesspace
  Notes; duraspace Files ("associate a content file with either an object or an object
  component", verbatim). Fail-closed upward hops behave rightly.
- Join records are **natural wherever the pair carries data** (roles, dates, weights, disclosure
  state); the domains speak home-vs-appearance themselves: mis g16 #5 "an item may
  administratively belong to one collection but could appear in other collections"; culrepo #33
  "alias (or map) an item"; real VDRs are index entries (DataRoomItem). Home ≠ status confirmed
  (openspending: hide/public is a flip, never a move).
- Roots are legal and needed (Users, Repositories, Publishers, the Application itself born by its
  applicant).

### Dissolved against the ratified base (reader flags that are already answered)

- **Cross-home scans, association-scoped aggregation, reverse-association guards** ("all datasets
  by all users", `count of Lead where status is "routed"`, cask's "fail if any dataset instances
  with that version"): the ratified grammar's aggregations and rule quantifiers are TYPE-scoped
  with `via`/`where` filters and remain so; `in X` is an optional narrowing, not a replacement.
- **Find-vs-guard on unbound containers** (poker's open Round): D2 is satisfaction, not traversal
  — all clause lines evaluate as one conjunction; `adds X to <query-found container>` commits on
  the unique satisfying assignment or refuses.
- **Home-delete cascades**: no domain-layer delete exists (S2 visibility direction); platform
  erasure parked.

### The load-bearing finding — the born-in doctrine

Re-parenting evidence: **~15 concrete cases**. The corpus demands moves by name (archivesspace
#33/#34 drag-rearrange is the product's core gesture; culrepo #96 "move a collection", #74 move
item to Historical; mis #33 "move items from one collection to another"; scrumalliance #85 "move
people … to the registry"; neurohub #68 file-browser moves with #86 "metadata … is not lost when
moving" — delete-and-recreate forbidden by the corpus itself; nsf #59 indent/outdent; loudoun
parcel split/merge; IB pre-mandate artifacts and cut-section→appendix; lead-intake's late
`assigns Lead to Territory`; camperplus "add campers to the groups"; badcamp waitlist→registered).

The doctrine the data writes: **`has` is only for parts born into and dying with their home.
Anything that moves, arrives late, or is assigned is an ordinary ref or a join record — and the
corpus's own modal verb for those is `assigns`, which must never lower to containment** (hotel's
`assigns Room to Reservation` is the type case). Mutable hierarchies (file browsers, archival
trees, org charts) are then modeled as mutable parent REFS (`sets X.parent to Y` — rearrange is a
plain ref write), not `has` — which also dissolves the recursion/name-collision/ordering defects
the archives readers found in self-containment stories. No move word is added; nothing in `has`
is ever re-homed.

### Rulings the package still needs (feed the D5 piece set)

1. **Birth beat vs `about`** — every candidate story births its own subject in beat 1 (`Guest
   submits Reservation`; IB's mandate precedes the Deal). Rule needed: creating-the-context-type
   inside its own `about` story (born mid-story), or split stories. IB additionally re-versions
   (Deal born at pitch).
2. **System beats have no page** — `about` context for `type system` fires binds from the gate's
   satisfying assignment (the enumerated arm), not a gesture; needs the sentence.
3. **Singular parts** — IB is wall-to-wall has-ONE (one CIM, one DataRoom); a singular `has` form
   with the one-of downward path legal (`Deal.CIM.status` is single-valued by declaration) removes
   the dominant friction (set-speak for singletons).
4. **Nested set words** for grandchild reads/writes (Deal→CIM→sections; Project→Application→
   PlanReview→Corrections; transcript reads) — state nesting legal or add a transitive form.
5. **`for` disambiguation** — container-`for` vs stored party-`for` in global creation sentences:
   loader refuses when the type is both a declared parent and a plausible party.
6. **Headless/API creates** — with the child-side field gone, the container is a bound fire input
   supplied explicitly (today it's a label-picker field: seed-hotel.test.ts fills
   `reservation: 'Ada Lovelace'`).
7. **Doc warnings** (guidance, not machinery): "created as part of X" ≠ contained in X (cask's
   shared instances); actor collections read oddly reflexively (`for Moderator` when Moderator
   fires); singleton-root boilerplate (`for Camp`) is tolerable noise.

Reader reports: authored corpus · IB+loudoun deep · wild A (g10/12/13/16/21) · wild B
(g02/04/05/08/11) · wild C (g14/17/18/19/22) · wild D (g23–g28).
