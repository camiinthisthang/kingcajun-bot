# Standalone QA release and deployment

The `@trigramco/ontolang` tarball includes the language, execution engine,
concrete adapters, deployable Worker, participant assets and local deployment
runner. V1 deploys QA environments only, with simulated actor selection. It needs Node 24. No Onto endpoint, Studio database, organization or Clerk
account is required. The existing MCP/CLI product commands and Studio deployment
UI are separate follow-ups. Build a distribution with `pnpm runtime:deploy:build`
and pack with `pnpm --dir packages/ontolang pack --pack-destination /tmp`.
Install that tarball in a fresh directory with `npm install /path/to/package.tgz`.

```sh
npx ontolang-deploy release --source ./model --name Example --out release.json
npx ontolang-deploy deploy --release release.json --target local --origin http://127.0.0.1:8799 --state ./.onto-deploy --environment qa
```

Local deployment stays in the foreground. Ctrl-C stops it without deleting data.
Run the same command to restart. To update, create another release with the
**same `--project-uid UUID`** printed by the first command; stop the local runner
and deploy that explicit snapshot. Publication checks the current revision and
retains identity, authorization, records, receipts and sessions. Creating a new
UUID creates a different project. Source edits alone never update a deployment.

`release --export export.json` accepts the version-1 `onto-template-project`
canonical file export also used by Studio's portable model workflow. Obtain it
through the existing authorized authoring connection; the runner consumes only
its exported files. The programmatic `createRelease` also accepts captured initial
`instances` and `readRules`. It reparses and admits the source rather than trusting
executable objects. Captured instances initialize a fresh project; they do not
replace durable records on update.

Release creation applies the same source-shape, initial-ID and read-policy
validation as the host. An inadmissible release is refused before the runner
creates deployment state or changes Cloudflare infrastructure.

Select the domain root explicitly, for example `release --source ./domain` when
`domain/` sits beside `app/`. Directory releases use the package Node reader:
recursive `.onto` files form one domain, including cross-folder references.
Root files load first, direct `stories/*.onto` next, and other nested files last,
each group sorted by path. File-map releases use the same parsing order. Folders
add no namespaces or separate deployments. Invalid nested sources fail admission.

Discovery stays within the selected root, skips dot directories, `node_modules`
and descendant symlinks, and leaves sibling application code/fixtures outside the
release. Keep unrelated `.onto` fixtures outside that root. Companion files
`imports.json`, `templates.json` and `walkthroughs.json` are included only at the
root. Vocabulary imports need their portable `imports.json`
snapshot (produced by the language exporter); deployment does not follow import
paths on the host. The snapshot is included in the release hash and its module
digests are checked. Unrelated JSON files are excluded.

The release is JSON with `format: ontolang-release`, `version: 1`, project UUID,
name, canonical files, optional initial records/read rules, the supported runtime
contract (project API 1, semantics 4, package 0.1.0) and a SHA-256 `revision` over
the canonical payload. Both publisher and host validate contents and revision.
V1 sorts object keys with fixed `en-US` collation, independent of the runner's
locale, preserving the earlier English v1 hashes. Admission measures UTF-8 bytes
and detaches nested snapshot data from caller-owned objects.
The latest release is stored atomically with publication in project SQLite.
An invalid/incompatible release leaves the prior model and release intact.
Release publication also requires `expectedReleaseRevision`: use the last status
revision, or `null` for a new project. The operator client supplies this fence
automatically. This prevents two presentation-only updates from overwriting each
other even when the business revision is unchanged; a conflict requires refresh
and review before retrying.

## Presentation snapshots and API-only releases

Use `--presentation default` to create a model-bound plan with the default design:

```sh
npx ontolang-deploy release --source ./model --name Example --project-uid UUID --presentation default --out release-with-ui.json
```

`--presentation presentation.json` accepts `{ version: 1, renderer: "shared",
plan, design? }`. The programmatic `createPresentation(release, design?)` creates
that value; edit its data and rebuild the release with `createRelease` before
deploying. Plans reference the exact admitted model hash and validated entities,
fields and commands. When the model changes, regenerate or update the plan.
A stale plan is refused before publication. Design profiles use schema/resolver
version 1 and normalized allowlisted choices; `createPresentation` normalizes
supplied design choices. Arbitrary JavaScript, CSS and SQL are not accepted.

The release revision covers model, plan and design. Their JSON snapshot commits
atomically in the project's SQLite `_host_release` row and survives restart;
the shared renderer is bundled in Workers Static Assets. It renders overview,
table, catalog and queue pages using only the current authorized runtime view.
Actions use the existing command forms, receipts and drafts. Presentation updates
never replace business records. Logos must be embedded image data; fonts use
local/system fallbacks. No Studio lookup or remote font service is required.

Without a presentation, `frontend: "default"` retains the command-derived UI.
Omitting `frontend` has the same behavior and preserves earlier v1 release hashes.
Use `--frontend none` for an API-only project: the API remains available but
`/apps/<id>` returns 404. Such a release cannot contain a presentation. The
common deployment description still supplies the conventional application URL;
clients should respect the release's frontend choice.

The distribution includes `dist/deployment/CUSTOM_FRONTENDS.md` and
`custom-frontend.schema.json`. They define the descriptor for future independently
built bundles: project identity, exact compatible release, API version and hashed
assets. Custom build/upload/activation/storage/serving are not implemented. R2
has not been selected.

## Hosted Cloudflare target

On your computer, sign in once through Wrangler; there is no manual API-token
scope setup. The runner requests account/user read, Workers scripts write and
Queues write. Wrangler adds refresh access and stores the session using its OS
keychain integration. You approve Cloudflare's browser consent page:

```sh
npx ontolang-deploy login
```

For a remote terminal without a reachable localhost callback, use
`npx ontolang-deploy login --device true` and approve the displayed code in your
browser. Login deliberately happens separately from deployment: a missing,
expired or revoked session gives an actionable login error instead of opening a
browser in an unattended deployment. Existing default-profile `wrangler login`
sessions also work. The runner retrieves a current token through Wrangler on
each deployment; Wrangler refreshes expired OAuth credentials automatically.
It never prints or saves the returned access token, including in Wrangler logs.

If automatic opening chooses the wrong browser profile, use
`npx ontolang-deploy login --device true --browser false`. Open the displayed
verification address in the correct profile and enter its short code.

Use a Worker name and workers.dev subdomain belonging to your account:

```sh
npx ontolang-deploy deploy --release release.json --target cloudflare --origin https://my-app.my-account.workers.dev --state ./.onto-deploy --environment qa
```

The runner discovers accessible accounts and selects the one whose workers.dev
subdomain matches that origin, including when you belong to multiple accounts.
An explicit `CLOUDFLARE_ACCOUNT_ID` overrides discovery and must still match the
origin. Unmatched or ambiguous accounts fail before infrastructure changes.

CI can still set `CLOUDFLARE_API_TOKEN` and `CLOUDFLARE_ACCOUNT_ID` in the **local
runner**. An explicit token takes precedence over OAuth; unset it before using
the browser login command. The `CF_API_TOKEN`/`CF_ACCOUNT_ID` aliases are also
accepted, with `CLOUDFLARE_*` taking precedence. A specified account lets a
restricted token skip account-list discovery. Global API keys are not used.
Tokens stay out of release files, manifests and command arguments. The same
resolved credential/account is used for preflight and Wrangler deployment.
See [Wrangler authentication](https://developers.cloudflare.com/workers/wrangler/commands/general/).

This uses the same release, Worker, assets, session path and API. The runner
provisions its named Queue, SQLite Durable Object class and Worker in that
account. It uploads the automatically created runtime credential with the Worker
using [Wrangler's secrets file](https://developers.cloudflare.com/workers/configuration/secrets/).
Existing delivery recipients are not configured by this runner; unconfigured
outbox work remains pending. The hosting README owns that separate provider setup.
Before changing infrastructure, the runner checks account ownership and existing
[Worker settings](https://developers.cloudflare.com/api/resources/workers/subresources/scripts/subresources/script_and_version_settings/methods/get/)
against project/environment/origin, then authenticates with the
saved runtime key. Another application, a missing/rejected key, an unexpected
Worker disappearance or a changed generation stops the update. Existing Queues
with other producers/consumers are refused. New credentials are created only
after the target is verified; `connect` never mints a replacement key.
Custom domains and per-project subdomains are deferred.

The account must already have a workers.dev subdomain and permissions for
Workers, assets, Queues and Durable Objects. No Cloudflare token appears in
model exports, manifests or CLI arguments. Never send account credentials to
hosted MCP. An agent with a terminal can combine its existing MCP authoring
connection with this local runner; a second MCP installation is unnecessary.

## Connection and credentials

`deploy({ release, target, directory, environment: 'qa', participants })`, exported by
`@trigramco/ontolang/deployment`, returns `{ manifest, manifestPath, request, stop }`.
Target is `{ kind: 'local' | 'cloudflare', origin }`. Clients use the returned
`applicationUrl` (`/apps/<id>`) and `apiUrl` (`/projects/<id>`), without target
branches. `request` is an operator client; it signs short-lived project credentials
and retains generation/model fences. QA browsers select a role and actor record
through the independent frontend. They never receive operator credentials.

The non-secret `<state>/<target>/deployment.json` records project UUID/ID, target, QA environment,
URLs, release revision, runtime generation/model hash and business revision.
The signing key lives in `~/.config/ontolang/credentials` (directory 0700, files
0600), overrideable by `ONTO_DEPLOY_CREDENTIALS_DIR`. The runner temporarily
creates private secret files for Wrangler and removes them after startup/deploy.
Retain the credential store to update or manage a deployment; do not commit it.
Credentials are bound to project, environment, target and origin. Each deployment has independent persistent state. Target switching
never migrates data. A deployment directory and credential are bound to their
original project/origin; accidental reuse fails instead of overwriting another
application. A saved manifest whose generation no longer matches durable storage
is refused rather than silently initializing replacement data. Temporary secret
files are replaced atomically with private permissions, even if an older file
had broader permissions. Publication failures leave the manifest at its last confirmed
release; a deployed Worker may already have updated before model admission fails.

## QA actor selection

The deployment opens the QA harness by default. A compact “Viewing as” strip
reuses Studio's selector and actor-profile components and automatically selects
a role and user. Choose “New …” in the user dropdown to generate, review and create
a fresh test actor for onboarding tests. The application uses collection and
record actions without an outer app title, global action dropdown or bottom
command console. Record actions execute on the clicked record; creation opens
the same dialog shell as Studio `/app`.
There is no participant login or manual sign-in
code in this flow. `--participants false` keeps browser/QA entry closed on a fresh
deployment; the authenticated operator can later configure entry.

QA is a shared, public test application: anyone who can reach its URL can select
its test actors and mutate test data through their permitted Stories. Use sample
data. It is not suitable for real customers or confidential records. The server
requires both `ENVIRONMENT=qa` and `PARTICIPANT_AUTH=qa`; a browser flag cannot
enable simulation in another environment. Requests require the configured origin.
Simulated identities hold only their selected actor role and normal read access,
never publication or operator authority. Rules, ownership, live role membership,
receipts and subscriptions still use the normal runtime. External deliveries are
blocked in QA, including previously queued deliveries.

Provide actor test instances in the release's Ontolang seed data, for example:

```ontolang
seed Customer
  name: "Alice"
  name: "Bob"
seed Barista
  name: "Sam", onShift: true
```

Existing instances can also be provisioned by the authenticated operator client
using `actor-profile` and `create-actor`. The QA browser's separate fixture capability
only generates and creates human actors; it cannot edit existing actors, assign
roles, publish or issue credentials. Creation does not run domain onboarding Stories
or establish a real account. Empty creatable roles offer the same “New …” flow. Changing
actors isolates drafts and unresolved submissions; returning to the same actor
can recover its saved submission.

Target (`local` or `cloudflare`) and environment (`qa`) are separate. Staging and
production requests are refused by this v1 runner. Use a new origin and state
directory for QA when an earlier code-auth deployment exists; the runner refuses
to overwrite that environment. Legacy operator connections and reference-host
Studio/code authentication remain compatible, but are not the standalone v1 UX.

Real participant authentication and a simulation/real-auth selector are deferred
to a subsequent branch, along with additional testing panels. Ontolang's access
and enrollment declarations are unchanged. Simulation does not validate login,
account recovery or real participant enrollment.

## Deployment interruption and coordination

Serialize infrastructure deployments to a Worker name. The local directory lock
and release compare-and-swap protect ordinary updates; there is no distributed
lock over Cloudflare infrastructure or automatic Worker/assets rollback. A crash
can leave `deploy.lock`: verify that no runner still uses that directory before
removing only that lock. Keep its durable data, manifest and credential store.
Worker/assets deployment precedes model publication; a failure between those
steps requires inspection and retry, not an assumption that everything rolled back.

## Verification and acceptance

`pnpm runtime:deploy:test` packs and installs the distribution outside the
repository, runs actual local Wrangler/workerd and tests publication, asset
serving, QA actor selection, cross-actor isolation, execution, retries, restart,
compatible update and retained records/receipts. It verifies
credential permissions and a non-secret manifest. Presentation checks cover
model/design validation, saved snapshots across restart/update, forged release
refusal and API-only updates retaining receipts. Adversarial checks also cover concurrent presentation updates, unauthorized
admission, generation mismatch, session replacement, UTF-8 byte limits and
English/Turkish release hashes. Mocked Cloudflare API tests cover origin/Worker/
Queue collisions and credential failures; these are preflight tests, not hosted
acceptance. Renderer checks exercise all four
layouts against authorized data and commands. The earlier code-login flow remains
covered by the reference host tests; it is not the standalone QA entry path. Root regressions exercise the
extracted Node SQLite implementation; `runtime:host:test` retains full workerd
alarms, Queues, subscriptions and delivery scenarios.

**Hosted Coffee fixture verified — 2026-10-25.** A fresh installed tarball deployed
to the user-owned Cloudflare account through Wrangler OAuth, without a manually
created API token. Real HTTPS checks passed for assets, one-use code sign-in,
origin/role/owner boundaries, WebSocket invalidation, eight concurrent retries
producing one order, receipt conflicts and stale generations. A compatible model
update redeployed the Worker and preserved the generation, session, order and
receipt. Concurrent presentation updates refused a stale release revision.
Browser QA completed code sign-in, Customer enrollment and a plan-selected order;
the live view showed the committed record. The fixture is retained for inspection.
See the [owning evidence](https://github.com/trigramco/onto/blob/publish-runtime/docs/features/rule-runtime/spec.md#hosted-coffee-acceptance--2026-10-25).

Redeployment does not prove platform eviction/cold-start durability. Native
recovery, quotas/load, real delivery recipients, optional Clerk handoff and owner
UX acceptance remain in the runtime backlog. The reference Studio/staging
deployment is separate from this standalone fixture.
