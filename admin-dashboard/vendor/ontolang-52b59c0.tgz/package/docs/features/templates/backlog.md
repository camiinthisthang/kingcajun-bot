> Portable snapshot of maintained Onto material. [Package capabilities](../../../START_HERE.md) define the shipped boundary; dated decisions and host implementation notes are context. [Source manifest](../../../SOURCE_MANIFEST.json) records provenance. Links marked “Onto source” are optional host/background references.

# Templates — backlog

Warehouse and Accounting are implemented through one template library; [spec.md](spec.md) records their models, composition, ingestion, persistence, controls and automated evidence.

## Next: verify the pilot with real workflows

- Complete an owner browser walkthrough of ingestion, concept binding, editing, module removal and the receipt-to-dispatch flow. Run the same pieces as a stockroom without outbound work.
- Complete an owner accounting walkthrough from chart of accounts through bills, invoices, partial settlements, reversals, reconciliation and period close. Exercise both capabilities together without assuming stock movements automatically post accounting journals.
- Evaluate source matching against representative descriptions and conflicting documents. Current detection is bounded and conservative; overlapping generated concepts can require explicit binding review.
- Use that feedback to decide whether any additional labels, default columns or queue views justify project-owned presentation configuration. General layout authoring remains unbuilt.

## Model extensions

The current model handles discrete integer units, one product/source location per fulfillment line and whole-line packing/dispatch. Returns, partial picks/shipments, order grouping, reservations, lots/expiry, serial tracking, multiple stock owners, replenishment, carrier integrations and warehouse automation need separate modules and acceptance tests. Shipping currently records dispatch; it neither books carriers nor buys labels.

The ledger tracks available shelf quantities. Picked units are represented by their fulfillment records; a separate facility-wide on-hand/in-transit/reserved accounting view is not built. Counts require the user to record the current expected quantity as well as the physical count; a guided snapshot capture could reduce that manual entry while retaining stale-count protection.

Accounting extensions include atomic multiline journals, multiple currencies, historical as-of balances and frozen financial statements, dedicated preparer/approver roles, payroll, tax rules/filing, payment providers and bank feeds/imports. Current reconciliation compares a current book snapshot; historical reconciliation needs its own date-scoped ledger projection. Inventory valuation and cost-of-goods-sold links between Warehouse and Accounting remain unbuilt. These need authored semantics and execution tests before becoming template defaults.

## Composition and authoring extensions

- Use acceptance feedback from Warehouse and Accounting before adding further capabilities. Whole-business templates can bundle the same module representation; manufacturing, retail and a replacement coffee-shop template are not supplied yet.
- Extend explicit shared-concept bindings to established external order processes only with verified structure and meaning. Name-based semantic matching and automatic conflict repair are not implemented.
- Automatic template upgrades and baseline migration remain out of scope. Installed content belongs to the project; library changes must never silently replace local work.
- Destructive runtime data migration is not implemented. Removal retains definitions/lifecycle support for live records, which can leave an entire workflow detached rather than deleted.
- Dedicated visual editors for all Formula and Story clause constructs, arbitrary presentation layout and template-library authoring are future work. The bounded source-editing API remains implemented, but removing the overview setup entry leaves it without a current UI entry point; schema and Story sentence changes use the normal authoring editors.

The owning implementation is [templates/spec.md](spec.md); importer and rendering docs cross-link it rather than duplicating its rules.
