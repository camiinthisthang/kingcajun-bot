> Portable snapshot of maintained Onto material. [Package capabilities](../../../START_HERE.md) define the shipped boundary; dated decisions and host implementation notes are context. [Source manifest](../../../SOURCE_MANIFEST.json) records provenance. Links marked “Onto source” are optional host/background references.

> **Layer: AUTHORING-TIME** — the editor for rules + Formulas; emits the rule AST the runtime consumes.

# Rule DSL — spec (what's built)


The language implementation and shared AST types now live in `@trigramco/ontolang`.
Existing modules forward through its public Rule/editor entries; parser and editor
tests use built exports. Studio owns editor components and application engines own
complete execution. See the [owning package contract](../ontolang/spec.md#independent-language-package--2026-10-13).

**Status:** the **redesigned surface grammar is built** — the all-words Rule parser, the whole Formula parser (type-resolved against the declared model), the shared lexer, entity resolution, and the totality checks. The live editor (pills, autocomplete, propose-new) is what remains → [backlog.md](backlog.md).

## Built today

Catalog-backed runtime comparisons now preserve declared enum order, including
Formula aggregate filters and Rule gates. See the [runtime contract and upgrade
behavior](../rule-runtime/spec.md#declared-enum-ordering--2026-10-10); this changes
interpretation of field reads, not the Rule/Formula syntax or stored AST.

### Semantic regression review — 2026-10-13

An inherited computed field may repeat the same Formula with its explicit ancestor
qualifier, or replace that owner with the current type. This applies to object
subtypes and actor roles, including imported definitions; changing the expression
or a Story label still violates the inherited contract.

Catalog-aware numeric comparisons include legacy `float` fields. Native numeric
literals remain safe integers, and field-valued counting bounds still require
`int`. Scalar/ref `exists` checks remain supported; a collection requires a
member quantifier such as `some Entry in entries` or `no Entry in entries`.
Scalar collection existence is rejected instead of silently treating members as
missing data. See the [complete-model contract](../ontolang/spec.md#complete-model-semantic-validation--2026-10-10)
and [runtime recovery and relationship checks](../rule-runtime/spec.md).

### Studio catalog and completion checks — 2026-10-23

Studio composes the rule editor's catalog from actor/object declarations plus
the separate role catalog. Inherited role fields, capability fields and subset
bases are available to both validation and completion; incomplete draft
inheritance remains editable. Numeric scalar comparisons stop offering entity
completions once their value is complete, so Enter submits the rule. Cardinality
bounds still offer the entity to count. Browser checks cover inherited-field
completion, accepted numeric conditions and refused text-to-number comparisons.

### Workflow readiness

`analyzeWorkflows` reports incomplete Story-managed lifecycles separately from
model validity; `managedLifecycleTypes` scopes authoring guidance, and
`assertWorkflowsReady` enforces execution admission. The
[Ontolang contract](../ontolang/spec.md#standalone-models-and-workflow-readiness--2026-10-10)
owns the checks and the distinction between descriptive and managed status enums.
The shared dependency walk also supplies transitive type reads for
[runtime invariant enforcement](../rule-runtime/spec.md#dependent-invariants--2026-10-10).

### The shared lexer (`rule-dsl/lexer.ts`)

With a model catalog, the lexer keeps a [qualified type](../ontolang/spec.md#scoped-vocabulary-imports--2026-10-10)
such as `Warehouse.Product` in one entity token. A following `.sku` remains a
field path. It stops at a declared entity, preserving case-forgiving field
references such as `Product.Sku`. Catalog-free parsing keeps the legacy dotted
field behavior; pass declared entities when parsing qualified references.

Rule paths and identity comparisons preserve Story labels such as
`Warehouse.Product:left.units`. Resolution checks the declared type separately
from the exact Story binding; unknown labels remain errors. Collection counts
still name types, not labeled records. Rule comparisons, including both
collection-filter layouts, accept negative integer literals through the safe
lower boundary, while counting bounds remain
nonnegative and the old standalone `:value` syntax remains rejected.

The lexer rejects unsafe integer tokens before numeric conversion. Quoted text
preserves backslashes literally in both quote styles; there is no escape syntax.
The owning [literal contract](../ontolang/spec.md#literal-fidelity--2026-10-10)
also covers container strings, comments, money printing and runtime handoff.

One deliberately dumb tokenizer for the DSLs and the future live editor: WORD / STRING / INT / PUNCT, no keyword table — meaning is contextual (the parsers decide), casing and quoting carry through (`CamelCase` = entity, lowercase = word/field, `'quoted'` = value-by-type). Old syntax is caught here with pointed errors: `:ready` → *write `'ready'`*, `>=` → *write "is at least"*, decimals → *integer timeline; money is scaled*.

### The Rule parser (`rule-dsl/parser.ts`) — the all-words surface
Emits the **same DNFFormula AST** the old surface did; the runtime doesn't know the surface changed.

- **Relations are words:** `is` · `is not` · `is more than` · `is less than` · `is at least` · `is at most`. No symbolic operators, no `:symbols` (a `'quoted'` value is resolved by the field's type; the evaluators' symbol↔string seam keeps old stored ASTs equal).
- Catalog-aware ordered comparisons accept numeric, timestamp and enum fields; enum values use their declaration rank and literal operands must be declared. Timestamp literals must name valid dates/times. The [cross-feature contract](../ontolang/spec.md#cross-feature-contract-review--2026-10-10) covers admission and execution evidence.
- **The shapes:** state (`Order.status is 'ready'`, inline `is not`) · comparison (literal or field RHS) · identity (`Reviewer is not Author`, bare CamelCase both sides) · **quantifier cardinality** — `all | no | exactly N | at least N | at most N | more than N | fewer than N <Type> [where …]`, existence sugar (`Ticket exists`) · **field-set** — `Invoice.reservation exists` ("the field has a value"; a state atom with the `set` value, evaluated as attr-resolves in both evaluators — added when the A/B eval showed every model reaching for exactly this spelling, which fail-closed semantics otherwise make inexpressible). Where-filters are `and`-joined predicates on the counted entity (paths keep the leading type segment — the shape the evaluators slice).
- **New expressive power, same IR family:** `all` is the universal quantifier (`op: 'all'` on CardinalityAtom; vacuously true on an empty world); a **bound may be field-valued** (`at most Order.capacity Guest` — an AttrRef resolved against the subject at evaluation, fail-closed). `now` normalizes onto the field side (`now is at least X` ≅ `X is at most now`) so AttrRef stays the LHS.
- **Implicit subject:** a bare field (`status is 'ready'`) takes the attachment's type (or `resolve.subjectType`); with no subject it errors with guidance. Parenthesized ORs distribute into flat DNF at parse time; negating a group is rejected (negation lives on atoms).
- **Resolution (resolve, don't infer):** with `resolve.entities`, a CamelCase token must name a declared entity; the AST stores the **declared** name so evaluators match instance types. Unknown → a pointed error. Without the context names pass through (headless/seed parsing).
- **One spelling everywhere (owner decision, 2026-07-29):** a multi-word entity name is **CamelCase in every position** — declarations, story beat text, rule/formula text, `attachTo`/`attachToType` strings, fields/instances keys, refTypes, roles. There is no spaced-display-name vs CamelCase-reference split: the declared name IS `RoomClass`, and resolution is an exact match. The squash fallback (spaces/hyphens stripped, case-insensitive) remains **only as back-compat** for pre-decision models that declared spaced names (`LineItem` still resolves to a legacy "Line Item"). Prompts, seeds, and the importer/validator all teach and emit the one spelling; the seed-validator no longer splits CamelCase names into spaced forms (it only collapses redundant compounds like "MediaInfo" → declared "Media"). The noun-kind rule is orthogonal and still holds: never name an entity with a value-type last word (`RoomClass`, not `RoomType`) — spaced value phrases in beats ("sets Task Due Date") remain PROPERTY nouns the classifier folds into fields, which is exactly why they stay spaced.

### The Formula parser (`rule-dsl/formula-parse.ts`)
`Field = expression` → the **FormulaExpr IR the runtime evaluates** (rule-runtime). Type-resolved against the catalog (`fieldsOf`) — the parser decides, the runtime never guesses:

- `+` over strings emits a **concat** node; over numbers a **binop**; `date + 30 days` a **date-shift** (durations: minutes…years, singular or plural; the amount may be a field). `days between a and b` → days-between. Mixed kinds are rejected at parse with the offending types named. Every path must exist in the catalog; intermediate segments must be refs (traversal).
- **Aggregation:** `sum|count|min|max|average of Type[.field] [via ref] [where …]` — the linking ref back to the subject or one of its ancestors resolves automatically when exactly one exists, is demanded explicitly (`via <refField>`) when several do, and is omitted (global) when none does. The multi-ref decision is carried in the IR, never guessed at runtime. `sum/min/max/average` demand a numeric member field. Filters accept signed safe integers, including `where amount is less than -1`, using the existing integer AST. The [parser review handoff](../ontolang/spec.md#parser-review-follow-up--2026-10-10) describes republication for corrected aggregate scope.
- **Conditional:** value-first, first-match, `else` mandatory (`100 if tier is 'vip', 50 if …, else 0`); the condition is the **rule grammar** parsed over the same token stream (logic = words, math = symbols, never mixed in one statement); branches must agree on the value kind.
- The LHS type is checked against the declared field (`money` field ← string formula → rejected). Returns `{entity, field, def, resultType}`.
- **Proven on the real seed:** the Hotel seed's hand-built `Invoice.total` AST is exactly what the grammar emits from the seed's own `source` text (round-trip pinned in `examples/seed-hotel.test.ts`).

### Totality (`rule-dsl/totality.ts` + `rule-runtime/stratify.ts`)
The three restrictions that keep the DSL total and verifiable:
1. **Acyclic derivations** — `assertAcyclicFormulas` walks computed fields and derived subset membership together (ref traversals, aggregations, conditional gates, collection filters and subtype spans included). Every cycle is rejected and named, including positive and negative subset recursion. The full [semantic contract](../ontolang/spec.md#complete-model-semantic-validation--2026-10-10) owns the admission rules and missing-data truth table.
2. **Stratified rules** — enforced at ruleset compile (rule-runtime `stratify`): no cycle through negation or a count.
3. **Bounded iteration** — the grammar has no loop construct; iteration only arrives as determiners over finite collections.

`money` / `percent` are scaled-integer field types (numeric operands like int; always rendered with their sign — the `$`/`%` dressing is the renderer's).

### Wired in
- **Shared semantic validation (2026-10-10):** `parseRule` with `resolve.fieldsOf` checks field paths and operand types through `assertPredicate`; `parseFormula` validates conditions and aggregate filters through the same module. Without a catalog, rule parsing remains syntax-only. Complete file/model admission also supplies inherited catalogs and record bindings. The live editor uses inherited fields and displays nonblocking missing-data advice with the rule's actual polarity.
- **Studio authoring** (`studio/app/[[...path]]/page.tsx` + `CoachingSidebar`'s RULES tab): **one flat rules list, one input** — no polarity sections, no timing toggle (2026-07-06; the earlier "Must be true" / "Cannot be true" split asked authors to pre-categorize rules they don't think of that way, and the BEFORE/AFTER choice was a client-side overlay that reset on reload). Every hand-authored rule persists as a **must precondition** on the beat — the shape the fire-and-derive loop actually guards (the authored-rule-shape fix: the old `invariant`+story shape was one the loop never evaluated, so live-authored rules were inert); "cannot be true" is written in the rule's own words (`is not` · `no … where …` · `not`) — and the exact dual of a must-not comparison is the `not`-prefixed form, NOT the flipped comparison: `compare` returns false on a missing operand, so `not x is more than y` stays **fail-open** on unset fields (as must-not was) while `x is at most y` fails **closed**. The editor steers there: atom start suggests `not`/`no`, and a failed parse containing prohibition vocabulary (cannot / never / must not …) answers with the negation forms instead of a bare parse error. Rows show **derived tags** only where the persisted axes differ from that default (an AI-suggested must-not rule → MUST NOT; a postcondition → AFTER) — read from the stored rule, never asked of the author. Accepted rule rows are **click-to-edit** (the row swaps to the live editor; commit re-parses and swaps the stored rule, preserving its axes). Validation resolves entities against the declared actors + objects. The tab's **ask box maps plain English onto the DSL** (`/api/rules-from-text`): the LLM segments the description into atomic claims and drafts one rule each, the REAL parser gates every draft, and a review card shows each candidate with the verbatim fragment it came from — parsed claims accept through the same add path as hand-typed rules, ambiguous claims come back as ONE question with parsed option chips (plus "write it myself" → the live editor), and unmappable claims are BOTH filed as Open Questions on the beat (tagged `source: 'ai'` — the LLM wrote them) and shown as couldn't-map rows keyed to the question they filed, so dismissing the row retracts it (nothing silently dropped, and dismiss means what it looks like; the card's header × only closes the card — its questions stay). Field edits on the entity pages are **guarded** (`studio/app/lib/field-refs.ts`): rules and computed formulas reference fields by name and nothing propagates a change, so a rename or enum-value removal first scans every stored rule + formula source and puts the hits in a confirm; renaming onto an existing name is blocked (the update path dedupes like the add path).
- **prompt-to-project**: `pruneRules` parses with the seed's declared entities (a rule about an undeclared entity is dropped); the generation + critique prompts teach the new grammar.
- **Story-context suggestions** (`studio/app/api/story-context`, prompt + gauntlet in `studio/app/lib/rule-suggestion-prompt.ts`): rules have their OWN grammar-first prompt (worked examples incl. the taught empty answer), grounded in declared fields/enums, the beat's attached rules, its type invariants, and a computed PINNED-fields ban. Every emission passes the mechanical gauntlet: exact-text dedup → entailment (`suggestionRedundant`/`mustStatePins`) → contradiction (`suggestionContradicts` — reversed comparisons vs attached invariants are unsatisfiable) → the evaluability floor (`suggestionFloor`: declared fields, real enum values, objects-only counts, no identity, no ref-hops, no beat-freezing bare `now`, and **subject-locality** — the loop binds only the subject, so a state/comparison about another entity is an invisible beat-freezer). A surviving suggestion previews in the DSL's colors and, on accept, is persisted through `parseRule` + `addRule` as a firing story precondition; questions and legacy prose items keep the old Constraint path. The A/B harness (`evals/rule-suggestion-ab.ts`) measures the whole pipeline per model over the real seeds — gpt-oss-120b 77% survivor precision vs claude-opus-4-8 89% on the 2026-07-03 run.
- **Seeds migrated:** coffee / hotel / record-label rule text is the new surface (same ASTs; seedVersions bumped so stores re-seed the new display source).
- The advisory evaluator (`rule-dsl/evaluate.ts`) is unchanged — same AST in, same enablement out.

### The live editor (`rule-dsl/editor-support.ts` + `studio/app/components/DslEditorInput.tsx`)
The authoring input for Rules (and Formulas), in two halves:

- **The headless half** (`editor-support.ts`, tested with the parsers): `highlight(source, model)` classifies the shared lexer's tokens into colored spans (entity / field / keyword / value / number; an unresolvable CamelCase word marks `unknown`); `suggest` / `suggestFormula` give context-aware completions — atom start → entities + quantifiers + subject fields + atom-level `not` (never after itself); after `Entity.` → its fields (ref hops traverse); after a path → the relations; after `is` → the field's **declared values** (enum values as pills, true/false for bools); after a bound/`of` → entities; after `where` → the counted entity's fields; formula value positions add the aggregators and `days between`. An enum partial matching nothing offers **`propose new value 'x'`** — the explicit-confirm gesture for extending a declared set.
- **The studio component** (`DslEditorInput`): one editable line — a transparent-text input over a span-painted overlay (exact same font metrics, so alignment is by construction), the completion dropdown (arrow keys / Tab / Enter, mouse), inline parse errors. A constrained value renders as a **pill** (background + radius behind the same glyphs — click-to-edit, no second mode). Mounted in the sidebar's flat RULES list (`CoachingSidebar` → `RulesPane`: the add-row, and each accepted rule row's click-to-edit swap), upgrading from the plain input when the model context is threaded in; the completion context and the parser's resolution are the SAME model object built in `page.tsx` (entities + fields + the beat's primary object as subject), so what the editor completes is exactly what the parser accepts. Verified live: field/value completion on the hotel seed, a committed rule persisting as a story precondition, and the unknown-entity error with the dashed underline.
- **AUTHORING LAYER ONLY** — the pill + propose-new + forced autocomplete never reach runtime forms (pick-only selects; the [load-bearing boundary (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/architecture/ide-and-runtime-separation.md), crossed once in 2026-06 and corrected).

## Not built
The **formula editor mount** — `DslEditorInput` supports `mode="formula"` and `suggestFormula` is live, but no studio surface authors a computed field yet (rides with entity-authoring's field editor, where `ObjectField.computed` would be written). **Propose-new persistence** — accepting `propose new value 'x'` inserts the value; actually extending the enum's declared set joins entity-authoring's enum-domain work (PR #33). The **multi-ref ask flow** (today the parser demands `via` in text; the editor should ask). → [backlog.md](backlog.md)

## Why / history
The old surface drifted SQL-ish and outran its own parser → redesigned 2026-06-27 (decisions inline in [backlog.md](backlog.md)) → built 2026-07-02 with the full-DSL push.
