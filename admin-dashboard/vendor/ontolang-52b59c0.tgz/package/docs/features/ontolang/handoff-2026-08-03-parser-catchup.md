> Portable snapshot of maintained Onto material. [Package capabilities](../../../START_HERE.md) define the shipped boundary; dated decisions and host implementation notes are context. [Source manifest](../../../SOURCE_MANIFEST.json) records provenance. Links marked “Onto source” are optional host/background references.

# Handoff — ontolang parser catch-up (2026-08-03)

Session log for the owner. Everything below is also in the PR description, which is
the copy that survives a computer move.

## Where things stand

- **Branch:** `feat/ontolang-parser-catchup` (3 commits), PR open against `staging`.
  The work: `61c378e` (the catch-up), `cf58760` + `22395bf` (doc flags from Q&A).
- **Tests:** `pnpm test` → 804/804 pass. 56 of those are the ontolang suites,
  including the un-stripped goldens and the new lead-intake pins.
- **Exit test verified live:** `examples/ontolang/lead-intake/lead-intake-and-routing.onto`
  parses through `ontolang/parse-project.ts` and loads through the studio
  new-project paste door with zero errors — 14 beats, 19 rules, 4 objects,
  3 seeded territories, 3 roles. (It's still loaded in the dev-preview studio on
  port 3010 on the old machine.)
- **What shipped:** gate headers (`requires`/`forbids`/`ensures`/`always`, bare
  `rule` retired) · `, unique` · `(stamped on create)` · refs targeting actors ·
  `given` / `role` lines · automatic produced-status derivation +
  `produces "value"` fallback · goldens compare `story/transition-to` edges
  included (HOTEL_SEED gained `Guest pays Invoice → paid`, seedVersion 20) ·
  lead-intake normalized to the canonical grammar · docs graduated, read head →
  **joins tier 1**.

## Q&A log (owner questions, both rounds)

### 1. "The gate headers are rules, right? Can the UI add them as rules?"

Yes — they're ordinary Rule records: `{text, attachTo/attachToType, timing, polarity}`.
The words are just the text spelling of timing+polarity. The UI already authors
three of the four: a **requirement** on a beat = `requires` (must precondition), a
**"cannot be true" constraint** = `forbids` (must-not precondition — the mapping is
in `studio/app/[[...path]]/page.tsx` ~line 1589), a rule in an entity's section =
`always` (invariant). **`ensures` (postcondition) has no UI path** — it parses and
persists, but nothing authors one and the runtime loop doesn't fire postconditions.
Corpus has zero; dormant grammar, not a blocker.

### 2. "unique — there will need to be UI for this, right?"

Yes, two pieces, both recorded in the rule-dsl backlog's "ontolang riders":
(a) entity-authoring's field editor needs a unique toggle (authoring side);
(b) the runtime needs the index check surfacing duplicates as a standing ⧗
violation banner (same surface as the SLA invariants). Shipped now: the schema key
(`ObjectField.unique`) and the text form. The model can *say* it; the app can't yet
*author or enforce* it.

### 3. "wtf is stamped?" / "do we need a default value field? isn't this how other
### systems author this (DB schemas)?"

`submittedOn: timestamp (stamped on create)` = the runtime writes the current time
into the field when the instance is created; the user never types it. It is
`created_at DEFAULT now()` in database terms. In lead-intake it's when the
prospect's form arrived, and the deadline formulas hang off it
(`triageDeadline = submittedOn + 2 days`). The phrase came verbatim from your own
2026-07-30 lead-intake draft.

**Caveat found while answering:** nothing *reads* the marker yet — the runtime
write + excluding the field from capture forms is open, now recorded in the
rule-dsl riders (`cf58760`).

**On general default values:** yes — SQL `DEFAULT`, Prisma `@default(now())`,
Rails `t.timestamps` all author this as a column attribute. Ontolang deliberately
shipped only the narrow case, for three reasons, now recorded as a parked item
with a tripwire in the ontolang backlog:

1. **The admission bar** — nothing enters the grammar until a corpus model can't
   be written without it. The corpus needs exactly one default today: "now, at
   create".
2. **The `=` position is taken by Formulas.** `score: int = sizeBoost + sourceBoost`
   is *computed* — continuously derived, never editable. A default is written once
   and then user-editable. Overloading `=` would conflate them; a general default
   needs its own word, which is a design discussion.
3. **Status defaults are already derived** — an enum's birth value is its first
   declared value (`status: new | qualified | …` ⇒ born `new`), per the lifecycle
   derivation. So the biggest class of "defaults" is never authored at all.

Tripwire to reopen: the first corpus model needing an author-set, user-editable
default.

### 4. "Actor refs — how do we do this in UI?"

A `ref` field renders as a catalog picker (a select over instances of the target
type). `Territory.owner: AccountExecutive` renders that picker, but there are no
AccountExecutive *instances* to list — individual actors are what the
roles-permissions **instance layer** (schema-only today) adds. This field is that
layer's recorded first runtime test. Model ✓, form renders ✓, dropdown empty until
actor instances exist.

### 5. "When did we decide on `over`?" → "over is not correct, need to discuss"

Honest answer: **nobody formally decided the word.** `role SalesRep over Employee`
came from your own lead-intake draft file (commit `08dda92`, 2026-07-30); the
ontolang backlog item said "given/role scaffolding as used by the lead-intake
file", so the catch-up implemented that spelling. The prose precedent is all over
the roles docs ("seniority phases **over** Employee", "Business/Buyer/LegalCounsel
**over** Company") — the file turned existing prose into syntax.

**Per your flag, `over` is now marked PROVISIONAL in the ontolang backlog,
grammar.md, and spec.md (`22395bf`) — do not build on the word until discussed.**
Changing it is three lines: the parser regex, the printer line, the corpus file.
The *mechanics* stand regardless of the final word: role name must be a declared
actor; base is a bare kind name; a role-base actor (Employee) is exempt from the
actor-must-act rule; emits `roles: {Name: {kind: 'role', base}}`.

Candidate alternatives when you discuss: `role SalesRep of Employee` ·
`role SalesRep on Employee` · `role SalesRep for Employee` ·
`SalesRep is a role of Employee` — or fold it into the already-designed
`actor SalesRep is a Employee` form once the `assignment/*` runtime lands (that
form is currently a deliberate loader error so it can't silently mint a subtype).

### 6. "More examples of produced status; why do we keep using 'stamped'?"

The word collision was my prose: `(stamped on create)` is the field feature; when
the docs say the classifier "stamps the edge" that's the story-authoring spec's
verb for "persists the fact" — read it as **writes**. Unrelated features.

Examples of the derivation (you write nothing):

    SalesRep qualifies Lead            → edge "qualified"
    System routes Lead to AE           → edge "routed"
    Receptionist checks-in Reservation → edge "checked-in"   (irregular table)
    Guest pays Invoice                 → edge "paid"
    Guest requests Service             → NO edge — "requests" is a create verb;
                                         the Service is *born* requested
    Housekeeper cleans Room            → NO edge — Room declares no status enum

The authored fallback, only when the action word and status word are different
terms of art:

    Broker binds Policy produces "in-force"   → edge "in-force"
    Broker binds Policy produces "bound"      → file:line ERROR if Policy declares
                                                pending | in-force — the enum is
                                                never silently extended

The printer writes `produces` back only when derivation would disagree with the
stored edge, so the whole current corpus prints clean with zero suffixes.

### 7. "What's a rider? Why do we keep saying goldens?"

**Rider** — project docs jargon: a small work item that *rides with* another
feature's work instead of standing alone. "Compaction prints ontolang, riding
authoring-sync"; "the extended prep set rides with story-authoring". The
"ontolang riders" section sits in the **rule-dsl** backlog because those owner
decisions (2026-07-30) were recorded during the rule-DSL/lead-intake session —
decisions live in the feature where they were made, cross-linked (the one-owning-
feature rule). The grammar halves have now graduated into the ontolang spec; what
remains in that section is the runtime residue (the unique check + banner, the
stamped-on-create write).

**Goldens** — standard testing term (golden file / golden master): a test that
compares output against a pinned known-good artifact exactly, rather than spot-
checking properties. Concretely: `ontolang/parse-project.test.ts` asserts
`parseProject('examples/ontolang/hotel')` **strict-deep-equals** `HOTEL_SEED` —
every actor, field, rule, and edge, nothing extra, nothing missing. So yes: the
`.onto` corpus is the canonical examples, and "the goldens" are the tests holding
corpus and hand-built seeds identical — the grammar's enforcement harness. "Un-
strip" meant: the tests used to delete `story/transition-to` before comparing
(the grammar couldn't express it); now edges compare too.

## Does the intake example parse and give the expected UI?

**Parses and loads: yes** — pinned by tests and verified live in the studio
(project home, canvas, actors/objects/stories views all render). **Running the
scenario end-to-end hits four known runtime gaps**, all pre-existing and all
recorded:

1. `submittedOn` won't auto-fill (stamped isn't wired) → the two deadline
   formulas stay unset until a value is typed.
2. **Two-hop rule paths fail closed at runtime**: `rule-runtime/world.ts` attr
   resolves single-segment paths only, so
   `Lead.territory.openLeadCount is less than Lead.territory.capacity` parses but
   the routing gate won't open. This is exactly the **joins tier 1** gap — the
   read head's next item — and lead-intake is now its forcing test case.
   (`Lead.region is Territory.region` similarly needs cross-entity binding.)
3. `unique` isn't enforced (no index check yet).
4. The `Territory.owner` picker is empty (no actor instances until the
   roles-permissions instance layer).

The simple spine — submit form → create lead → qualify/disqualify on status +
computed score → contact → convert/drop — gates on single-hop paths and Formula
results, which the runtime handles today.

## Anything else to know

- The lead-intake file was **normalized into the canonical grammar** — its
  2026-07-30 draft spellings (`about`, `(person, outside)`, `one of`, colon-less
  fields, a separate `rules` section) were one-off dialect, not decisions. Logged
  in backlog item 4's deltas.
- `given` is an accepted *input* form; the printer emits `seed` blocks (same
  pattern as `is an` → `is a`). The quoted label becomes the instance's `name`.
- Edge derivation runs through the shared classifier (`detectActionCategory`) so
  the file door and the canvas commit stamp identical edges — create beats never
  carry transition edges.
- Next up per the read head: **joins tier 1** (ref-hop paths in where-filters),
  which the lead-intake runtime gaps above make concrete.

---

# Appendix — final session response (PR + last Q&A round, verbatim)

PR is open and everything is logged. Here's what you need before you switch machines:

**PR:** [trigramco/onto#85](https://github.com/trigramco/onto/pull/85) — `feat/ontolang-parser-catchup` → `staging`, 3 commits (the catch-up + the two doc-flag commits from this Q&A). Local `staging` is reset back to `origin/staging`, so the branch is the only home of the work. The PR description carries the full handoff, so it travels with you.

**The handoff log:** `/tmp/onto-handoff.md` on the authoring machine (canonical copy also in the session scratchpad; now also THIS file, committed in the repo). Since /tmp doesn't move computers, the PR description and this doc are the durable references — same content.

The three new answers, short form:

**3. Default values — you're right that other systems author this as a schema attribute** (SQL `DEFAULT now()`, Prisma `@default`). Ontolang shipped only the narrow case deliberately: the admission bar says nothing enters the grammar without a corpus model that can't be written without it, and the corpus needs exactly one default — "now, at create". Two design reasons a general default isn't a quick add: the `=` position is already taken by Formulas (computed = continuously derived, never editable; a default = written once, then editable — overloading `=` would conflate them), and status defaults are already derived (an enum's birth value is its first declared value, never authored). Parked in the ontolang backlog with a tripwire: reopens on the first corpus model needing an author-set, user-editable default.

**4. A "rider" is project-docs jargon** — a small item that *rides with* another feature's work instead of standing alone ("compaction prints ontolang, riding authoring-sync"). The "ontolang riders" section lives in the **rule-dsl** backlog because those 2026-07-30 owner decisions were recorded during the rule-DSL/lead-intake session — decisions stay in the feature where they were made, cross-linked. The grammar halves have now graduated to the ontolang spec; what's left in that section is the runtime residue: the `unique` index check + banner, and (added today) the `stamped` runtime write.

**5. `over` — acknowledged, and now flagged.** To be straight about provenance: nobody decided the word — it came from the owner's own lead-intake draft file, and the backlog said "as used by the lead-intake file," so the catch-up implemented that spelling. It's now marked **PROVISIONAL** in the backlog, grammar.md, and spec.md — "do not build on the word until discussed." Changing it is three lines (parser regex, printer line, corpus file); the mechanics (role name must be a declared actor, bare-string base, role-base actors exempt from must-act) stand under any word. Candidates for the discussion: `of`, `on`, `for`, or folding it into the already-designed `actor SalesRep is a Employee` form once the assignment runtime lands.

One heads-up for the review: the intake example **loads and renders fully, but won't *run* end-to-end** — four pre-existing runtime gaps (stamped unwired, two-hop rule paths fail closed, unique unenforced, empty actor picker), all listed in the PR. The two-hop gap is exactly **joins tier 1**, the read head's next item — lead-intake is now its forcing test case.
