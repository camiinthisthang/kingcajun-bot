> Portable snapshot of maintained Onto material. [Package capabilities](../../../START_HERE.md) define the shipped boundary; dated decisions and host implementation notes are context. [Source manifest](../../../SOURCE_MANIFEST.json) records provenance. Links marked “Onto source” are optional host/background references.

> **Layer: CROSS-CUTTING** taxonomy + **RUNTIME** surfaces — this backlog holds the proposed **kind vs role** nomination behavior and the rest of the *instance* layer of [roles-permissions](spec.md); the instance layer's first slice (assignments written + read) graduated to the spec 2026-08-04.

# Roles & phases — backlog

## Permission architecture research

The [shared-model agent spike (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/research/shared-model-agent-spike-2026-09.md)
now tests direct scoped roles, denies, one-hop delegation, action/input discovery,
exact-operation human approval, revocation and budget/retry accounting through
one model. SQL and Cedar pass the same bounded authority and domain scenarios.
[Rule-runtime's spec](../rule-runtime/spec.md#built-today) owns this isolated
implementation; [its backlog](../rule-runtime/backlog.md#architecture-reassessment)
owns the remaining agent authoring and recursive permission work. The
[published baseline](../rule-runtime/spec.md#published-application-baseline)
now integrates real authoring, verified identity, direct agent role grants,
revocation and discovery in the application. Delegation/approval/budget authoring
remain unintegrated. Concrete Guest bindings, own-record policies and trusted
agent bindings are now built in the published runtime. A restartable
[Hotel persona demo (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/rule-runtime/baseline.md#hotel-persona-demo) supplies
concrete records for every role. Staff grants remain application-scoped;
two-hotel scope and multiple roles for one person are still to prove. The broader Person +
scoped-role instance model remains future work; see the
[Guest QA guide (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/rule-runtime/baseline.md#guest-binding-in-the-hotel-qa-model).

The [SHACL and permission-library review (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/research/shacl-permission-library-fit-2026-09.md)
recommends retaining shape-inspired constraints while keeping grants and operation
authority explicit. CASL, Cerbos and Casbin remain candidate integrations with
different purposes; the executable SQLite/DataScript/Cedar comparison did not
benchmark them. The linked research defines the adoption evidence needed. This
is production instance-permission work still to do, not a change to the built type-level engine
or the nomination decisions below.

**Actor access and enrollment (planned, 2026-09-10):** standard role administration, self-service enrollment and invitations must share the role operations used by domain grant/revoke stories. Identity, affiliation and role holdings remain distinct. The owning [build plan](../ontolang/actor-boundary-plan.md) records the contract and remaining authority/inheritance decisions.

## 1. Kind vs role at nomination

**Status:** designed (audit 2026-07-04) · **the three open decisions are DECIDED (owner, 2026-07-23)** — see below; unblocked for code. **Revised by Roles over kinds** ([ontolang backlog](../ontolang/backlog.md), owner 2026-08-18): the is-a collapse makes every bare person/organization-kind actor a role over its kind *by language semantic*, so the attach-proposal below applies only to the non-default forks (own rigid kind vs role; a narrower base like Company) — the ordinary person-noun case needs no nomination at all. Same session: `hold/*` schema renamed `assignment/*` (runtime/store.ts; was dead schema), and the ontolang spellings landed (`actor Employee is a Person` = role, fields on the assignment; `actor Analyst = Employee where seniority is "analyst"` = defined subset) — see [ontolang](../ontolang/backlog.md).

**Target behavior.** Nouns classify on a second axis, orthogonal to Actor/Object agency: **kind** (rigid — the thing can't stop being it and still exist: Person, Organization) vs **role** (anti-rigid + relational — played contingently, always "X of/in Y": Employee, User, Customer, Payee). A role is **not a subtype** of its kind — it attaches to a shared kind *instance*. Nominating "Employee" must not mint a new top-level entity type: the system resolves it to **Person (kind) + Employee (role)** and surfaces the attach as a non-coercive proposal the user can confirm or redirect ([interface axiom 3 (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/interface-axioms.md)). Two role-nouns for one person (Employee + User) land on **one** Person instance, not two entities.

**What exists today (the audit).** The distinction already lives in three type-level places that agree — and none is consulted at minting; the instance level is empty:

| system | what it knows | wiring today |
|---|---|---|
| kind-catalog archetypes (`kind-catalog/archetypes.ts`) — kinds are rigid + nature-bearing, archetypes anti-rigid + field-contributing; Employee→Person is the worked reference | `canonicalLookup` returns `{kind, archetype, fields}` — the exact kind+role answer | consumed **only** by the needs-definition pill gate; the grounding is discarded |
| role catalog (`runtime/store.ts` `role/*`) — `role/base` = "the rigid kind beneath", `role/kind` role vs phase, `role/fields` | live in the IB seed (seniority phases over Employee; Business/Buyer/LegalCounsel over Company) | seed-declared only; `role/base` is a **bare string** — IB's bases Employee/Company aren't entities in the project; nothing writes the catalog at nomination |
| role lexicon (`classifier-at-commit/noun-kind.ts` `isRoleLabel`) — "an actor wearing one is Person + role, not a new type" | ~37 generic labels (user, customer, guest, buyer, admin…) | `nominateRoles()` (`runtime/store.ts`) was built to surface "register as role?" prompts — **zero call sites** |

Minting (`ensureActor`, `runtime/store.ts`) dedups on exact `(project, name)` only, so Employee + User always mint two entities as TYPES. At the *instance* level this is no longer true: the assignment slice (section 2 — built) makes a role-typed instance create/query resolve through `assignment/*` edges to one shared base instance, so two role-instances CAN be the same person once the catalog declares the roles. What nomination still has to do is get the catalog entry + base written at commit time.

**The design (minimal, additive — the Actor/Object agency axis is untouched):**

- **(a) Classifier emits the tag.** One resolution order per nominated noun: declared roles → archetype terms → kind dictionary → role lexicon → LLM fallback; **declared always wins** (same lesson as the noun-kind declared-overrides fix). For catalog terms the answer already exists — `canonicalLookup`'s `archetype` present ⇒ role-noun, its `kind` = attach target — so the commit path just has to *read* it. Extend the planned per-entity `/classify` return ([types backlog](../types/backlog.md)) and the importer actor shape with `rigidity: 'kind' | 'role'` + `attachesTo: string | null`. The tag is named `rigidity` deliberately — "kind" and "role" are already overloaded in this codebase (`NounKind`, `role/kind`, the Coad `'role'` archetype).
- **(b) Store: role-on-kind reuses the two existing slots — no new schema concept.** On confirmed attach: write a role-catalog entry (`role/name: Employee · role/kind: role · role/base: Person · role/fields:` the archetype delta) **and ensure the base is a real entity** (`ensureActor('Person')`), with a new invariant: `role/base` must name an existing entity. The role-noun keeps its actor row — stories reference the name (IB precedent: every declared role name is an actor) — but the catalog entry demotes it from independent instance-bearing type. At the instance level a role instance = a shared kind instance + an **assignment** edge — **this half is BUILT** (section 2 / [spec](spec.md)): once the catalog entry exists, the store's role-aware create/query does the rest, and same-name creates converge on one base instance. Capture UIs resolve *which* Person via the runtime's pick-only select, proposing the same instance when labels match.
- **(c) Nomination surfaces the attach.** In the commit path, before `ensureActor` mints on a name-miss, run the resolution order; on a role verdict surface a proposal chip — *"Employee — reads as a role of Person. Attach / own kind / attach elsewhere."* Confirm ⇒ (b); redirect ⇒ today's plain mint (non-coercive by construction). Wire the existing `nominateRoles()` as the retroactive sweep for already-seeded projects.

**Decisions (owner, 2026-07-23):**

1. **Role field values live on the assignment** (the edge — né "hold"): `hireDate` is a fact about the employment, not the person. The role's declared fields ARE the assignment's schema; the surface name is always the domain noun, never "assignment."
2. **Roles are domain-scoped; NO Party kind.** Two domains' Buyers are two roles (an IB Buyer over Company, a retail Buyer over Person) — nothing forces one global role. Correction: gist does **not** have a Party class (verified in the ontology source — it uses `Person ∪ Organization` unions inline plus a `hasParty` property); if a single domain ever mixes bases, the spelling is a union on that role's base, gist-style. Relatedly: **Company is NOT Organization** — it's a rigid subkind (a commercial organization); enters the kind catalog as a subkind entry (implementation rides with the prelude/kind-roster work), and IB's `role/base: 'Company'` resolves there.
3. **Phases stack on roles — and the phase machinery itself is superseded.** Seniority is an ordered **enum on the Employee assignment** (declaration order = rank), with story-actor names as **defined subsets** (`actor Analyst = Employee where seniority is "analyst"` — live, read-only). Promotion is an ordinary field transition; `role/partition`/`role/order`/`role/kind: 'phase'` retire when the ontolang loader lands.

Also to unify (small, no owner call needed): the `User` disagreement — the kind dictionary grounds `user` → bare Person (as-if-kind) while the role lexicon calls it a role; resolve as role-of-Person.

**Falsifiable check (seed corpus).** No seed uses bare Person or Organization — every Person-ish noun is a role (Guest, Receptionist, Housekeeper, Concierge, Customer, Barista, Chef, Driver, Moviegoer, Cashier, User, Admin, Developer, Reviewer, Artist, Producer, Manager, Fan, Analyst…ManagingDirector, Guesser, GameMaster…); Vendor/Supplier/Distributor/Business/Buyer are roles over Organization; Invoice→Document and Booking→Transaction show the same shape object-side. Where composition would leak without a mapping (competing kinds):

- **Company vs Organization** — IB's `role/base: 'Company'` vs the catalog kind `Organization`: two names, one kind, zero mapping. Invisible today because bases are dangling strings; making bases real entities forces it to surface.
- **Employee** — role in the kind-catalog, rigid base in IB (decision 3 — decided, see above).
- **Variable-base roles** — Buyer/Payee/LegalCounsel (decision 2 — decided, see above).
- **Label / Business** — plausibly rigid subkinds of Organization (what the org *is*), not roles; the proposal's "own kind" redirect must handle these gracefully.
- **System actors** (Server, Database, AuthService, Browser, Transcoder, Platform) — the System kind is designed in the [types backlog](../types/backlog.md) but not in the shipped `KINDS`; these have no rigid home yet.
- **Money-ish nouns** (Royalty, Advance, Commission, Revenue) — no Money home; object-side, out of scope here, same leak shape.

**Non-goals.** The Coad `objectArchetype: 'role'` tag (an object classification) and story-local slot bindings (`Employee:Requester`, which evaporate outside the story) are different concepts and unchanged. Nothing replaces agency-based Actor/Object classification.

## 2. Instance layer — assignments (né holds), transitions, bearer facts

**Status:** the **assignment slice is BUILT** (2026-08-04, graduated to [spec.md](spec.md)): role-typed `instanceStore.create`/`query` write and resolve open `assignment/*` edges (base-kind instance + edge, one person under many roles), role-typed seed rows mint through the same path, and the lead-intake `Territory.owner` picker fills. The seed path — not section 1's nomination — turned out to be the first writer; nomination's confirmed-attach plugs into the same create when it lands. Everything below stays open.

### What's built → [spec.md](spec.md)
- Type level, as before: role/phase **catalog** (`queryRoles`, `nominateRoles`), the **conformsTo** graph, phase **partitions + ranks** (superseded by Decision 3 — retire when the ontolang loader lands), the **read-permission engine** wired to the PermissionMatrix and "view as role".
- **Assignment edges + role-held actor instances** (the assignment slice): create/query of open, time-stamped edges through the store; closed edges (`to` set) stop resolving — the *read* side of revocation exists, but nothing writes a close yet.
- **Role fields on the edge + readable holdings** (2026-08-30): capability fields split onto `assignment/fields` at create, route there on transition, and merge into every read; role-typed type scans / ref hops / aggregations resolve through holdings. Decision 1 and "role fields are readable," running.

### What's left to build (instance level)
- **Grant/revoke surfaces** — the **reference loop executes `grants X to Y` / `revokes X from Y`** (2026-09-05, the runtime catch-up: `grant`/`revoke` assertions on the execution's batch; re-granting a held role is a no-op; a revoke closes the holding and drops its capability facts; a holding counts only while its base roles are held — D13a; eligibility refuses a non-holder at commit; an open role is conferred by the first act — see the [rule-runtime spec](../rule-runtime/spec.md)). What remains here is the **store's writer** (`assignment/to` is only ever read; no UI or API grants a role to an existing person or closes an edge) and the surfaces — see **Roles over kinds** in the [ontolang backlog](../ontolang/backlog.md).
- **`assignment/context`** — declared, never written: the "Reviewer *of which* PR" leg of the relational pattern.
- **Capability-field rename hygiene** — `renameField` (runtime/store.ts) migrates declarations (`actor/fields`), instance blobs, rules, and formulas, but not the role catalog's `role/fields` or the edges' `assignment/fields` (both landed 2026-08-30 after it): renaming a role's capability field would strand the old key on the catalog entry and every open edge. Small — extend the migration to both blobs when role-field renaming becomes reachable.
- **Phase machinery — superseded by Decision 3 (above).** No partition-closing state machine:
  promotion is an ordinary field transition on the assignment's ordered seniority enum. The only
  remaining work is retiring the `role/partition`/`role/order`/`role/kind: 'phase'` schema when the
  ontolang loader lands.
- **Bearing-vs-realization at runtime** — the bearer fact EXISTS (an open edge is one) and the
  READ side is built (2026-08-30, graduated to [spec.md](spec.md)): the snapshot carries holdings,
  and role-typed type scans, ref hops (`Territory.owner.x`), and aggregations resolve through
  them. **Enforcement is built in the reference loop** (2026-09-05): a execution that names its actor refuses `not-eligible` when the actor does not hold the story's actor role (a derived subset counts by base + predicate; an open role is conferred instead). What stays open: the studio's doors do not pass the actor yet, and `mayRead` doesn't key `self`/role audiences off holdings.

## Open questions & deferred (read-permission)

- **LLM read-residue proposer.** After the two derived arms run, a language-model pass
  could *propose* extra narrowings a person would then confirm. Three narrowing kinds:
  **self-scoping** (a record is visible only to its own bearer), **rank-gating** (only
  senior-enough viewers), and **condition-gating** (visible only when some state holds).
  Paired with a **value-name sensitivity lexicon** — field names like cost / fee / price
  / rate that hint "money, keep it tight." Deferred until a tripwire (a real case where
  the deterministic arms miss something they shouldn't). Also pending: wiring the
  role-label check into role nomination, so a proposed audience is grounded in a real role.
- **Viewer-keyed caches.** Read-permission is **viewer-dependent** — the same document
  renders differently per audience. Once that lands, rendered-surface caches and the
  view identity / hash must **key on the audience**, or one viewer's projection could be
  served to another.

## Source / references
- Type-level truth lives in [spec.md](spec.md).
- Kind catalog + archetype grounding (the recognition side of section 1): [types backlog](../types/backlog.md).
- The commit-path hook (where the attach proposal fires): [story-authoring backlog](../story-authoring/backlog.md).
