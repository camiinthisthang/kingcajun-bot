> Portable snapshot of maintained Onto material. [Package capabilities](../../../START_HERE.md) define the shipped boundary; dated decisions and host implementation notes are context. [Source manifest](../../../SOURCE_MANIFEST.json) records provenance. Links marked “Onto source” are optional host/background references.

# Handoff — joins tier 2 design session (2026-08-19)

**For the next session (updated 2026-08-24 — the walk closed).** On "get up to date":
read this file's addenda, then **[full-decision-pass-2026-08-22.md](full-decision-pass-2026-08-22.md)**
(the board) and [binding-backlog.md](binding-backlog.md) (the ratified base). Say where things
stand in one breath (branch `claude/mystifying-bhabha-1da32a`, **draft PR #124** base staging —
#110's successor after #108's merge deleted its base — **THE WALK CLOSED 2026-08-24, D1–D14 all
ratified**). Released work: the board's section-3 build order + the one-pass corpus sweep + the
runtime residue + the system-step runner. Building starts only on the owner's explicit ask;
PR #124 (this branch, docs) awaits the owner's undraft/merge word.
The verbatim closing block at the end of this file is the 2026-08-19 record only — do not print it.

**How we got here, in one paragraph.** The session started from the story-run draft (one pass
through a story shares a name→instance table; `a`/`another` opt out) and the owner rejected it in
stages: hidden runtime state is magical; loader derivation of any kind is against the latest work
(#95–#98 — declarations decide, guessing killed); resolution must never lean on names; the link
must be visible on the page but not crammed into one long line; the sentence keeps the domain's
noun; `=` collides with Formulas. Each rejection and the surviving mechanism are recorded with
examples in [joins-tier-2.md](joins-tier-2.md) (*Considered and rejected*). modeling.md gained
proposed rules 21–22; the story-authoring backlog holds the `produces`-suffix item and carries the
new clause-assist item.

---

## The first session's closing state (superseded later the same day — do not print; kept as record)

**The mechanism (not settled — owner review pending):** sentences stay domain language; machinery
is indented clauses; a beat links a record its sentence doesn't name with **written `requires`
atoms**, writes it with **`sets Path to value`**, and the runtime re-finds the record from data at
every fire — unique match or refuse, no memory between fires, nothing derived at load.

```
object RetreatBooking
  student: Student
  retreat: Retreat
  status: requested | confirmed | attending | attended

story Retreats
  Admin schedules Retreat
  Admin opens Retreat
  Student requests RetreatBooking for Retreat
  Admin confirms RetreatBooking for Student
    requires RetreatBooking.retreat.status is "open"
  Student starts Retreat
    requires RetreatBooking.student is Student
    requires RetreatBooking.retreat is Retreat
    requires RetreatBooking.status is "confirmed"
    sets RetreatBooking.status to "attending"
  Student completes Retreat
    requires RetreatBooking.student is Student
    requires RetreatBooking.retreat is Retreat
    requires RetreatBooking.status is "attending"
    sets RetreatBooking.status to "attended"
```

The domain corrections are the owner's: Admin (not Teacher) schedules/opens/confirms, and a
month-long retreat is two beats — `starts` → `attending`, `completes` → `attended`. The month is
the argument for the mechanism: nothing is remembered across it; the clauses re-find the booking
from data when `completes` fires.

**The clause family:** `requires … is` — check · `sets … to` — write · `grants … to` — confer
(as ratified). All words, no symbols; `sets … = …` was rejected.

```
Teacher accepts ServiceApplication from Student
  requires ServiceApplication.status is "reviewed"
  sets ServiceApplication.status to "accepted"
  grants ServiceVolunteer to Student
```

**Two legal sentence styles, the domain's language decides per beat:** name the record as the
object when the domain says it (`Student requests RetreatBooking for Retreat`), or keep the
domain's noun and link through clauses (`Student attends Retreat` + atoms).

**Retires, pending ratification:** the `produces` suffix and word (pointed replaced-syntax error);
load-time verb→status conjugation (demotes to a studio typing assist, origin ladder). Every
transition beat carries its `sets` clause in the file → corpus sweep, seeds re-version.

**Open — the owner is not settled** (full list at the end of [joins-tier-2.md](joins-tier-2.md)):
1. the explicit tax — link atoms + `sets` on every transition beat, acceptable once the studio proposes the text?
2. ambiguity UX — "two matches → refuse and ask": where and how the ask renders.
3. IR home for the `sets` clause (successor of the derived `story/transition-to` edge).
4. uniqueness scope — which instances count as candidates for "exactly one match".

**Next action when the owner returns:** review [joins-tier-2.md](joins-tier-2.md) and draft PR
#110; settle or rework the open questions. Nothing is to be built until then.

---

## Addendum — the session continued (2026-08-19, later)

The owner returned on this branch and the discussion moved past the closing state above. In order:
the atoms' verbosity and the unintroduced-record confusion were both rejected as written; a `with`
block was rejected; declared-anchor marking (`@anchor`) was proposed and the owner countered that
**declared refs should imply the relation by themselves** — accepted direction, with the worry
that implicitness bites; the owner then named the real issue — **binding specific instances, and
scoped stories vs global** — and ordered a full-corpus pass (authored + all 22 wild sets, "not
just what is there but what we would want to write").

That pass is done and recorded: **[binding-scope-corpus-pass.md](binding-scope-corpus-pass.md)** —
verdict table over 27 domains, six decisions with evidence, worked rewrites, and the open
spellings — with the live queue split into its own sub-feature backlog,
**[binding-backlog.md](binding-backlog.md)** (the general ontolang backlog now holds only
pointers; owner call, 2026-08-19: sub-feature backlogs instead of one accreting file). Still
nothing to build — the six decisions await the owner.

## Addendum 2 — the walk-through started (2026-08-19, original machine)

The owner is stepping the six decisions one at a time. Position so far: **decision 1 RATIFIED**
(trichotomy + plural-routing table + explicitness clarifications — recorded in
[binding-backlog.md](binding-backlog.md)), and the **`type` spelling ratified** (`type person |
organization | system`, was the proposed `kind` — recorded in the Roles-over-kinds set and
modeling.md). Also ratified: the **bound/unbound vocabulary** (Datalog's adornment words;
supersedes selected/resolved and cast/free-name), and **Out of the Tar Pit** joined the
theoretical-foundations doc. **Position: decision 2 RATIFIED (satisfaction, not traversal). Decision 3 part 1 (implied party
atoms, comment-visible, per-ref override, static checks) RATIFIED after the mutation walk — the
walk-through is on ONE example only (sangha Retreats/Service; owner ruling: never switch examples
mid-thread). Decision 3 part 2 (sets-exclusion) RATIFIED. Then the collision case (two same-type refs) made the
owner reopen where-atoms-live; after side-by-side examples the owner ruled: **decision 3 RATIFIED
(owner, 2026-08-19)** — atoms are real text materialized once at the door (origin ladder), loader
validates only, and the word rule: **links are always `where`, conditions always `requires`**
(lexical only; one conjunction). See binding-backlog queue item 2 for the full form. Decision-3
part 4 RATIFIED ("if we don't need it, dump it") — who-did-it is never a field, modeling.md rule
23; decision 3 fully closed. **Decision 4: the owner amended it live (container-closes: `Retreat open|closed`, new instance
per edition) then ordered a full-corpus sweep before ratifying — done, six readers, written into
the corpus pass (decision-4 sweep section) with the amended six-point rule; PENDING the owner's
ruling. Then: the case, ambiguity UX, same-type addressing, IR homes.** On catch-up, resume there; the closing
state below is the pre-walk-through response, kept for the record.

## Addendum 3 — the corpus census (2026-08-19, second machine)

Owner asked for "the % of bound vs unbound actors and objects" across the example corpus;
answered in the ratified vocabulary, recorded as the census section of
[binding-scope-corpus-pass.md](binding-scope-corpus-pass.md). Headlines: source mix under the
target modeling is **~94% bound · ~1% unbound · ~5% enumerated** (317 sentence positions + the
clause-only names; **actors are never unbound anywhere** — no rewrite in 27 domains queries for a
person; investment-bank needs zero unbound names once the case exists). Declaration health,
orthogonal axis: **21% supported / 36% free-by-design / 43% dangling** today (investment-bank 0%
supported — zero refs, no case; excluding it: 54/31/15), converting to **~64/36/0** after the
ratification sweep. The two sessions' work merged on this branch the same day.

## Addendum 4 — the literature audit (2026-08-21)

Owner ordered a deep grounding pass mid-walk-through: every ontolang decision (171 inventoried)
audited against the process/business-modeling canon across eight fields —
**[business-process-modeling-survey.md (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/research/business-process-modeling-survey.md)**:
127 rows (59 convergent · 20 deliberate divergences · 5 contradictions argued · 31
pending-informs · 8 gaps), adversarially fact-checked. The pending decisions (current-ness,
@terminal, closure pieces, the case, same-type, ambiguity UX) now each carry the literature's
net recommendation in that doc. Resume the walk-through from the binding backlog queue with the
survey open beside it.

## Addendum 5 — the roles & extension prior-art pass (2026-08-22, second machine)

Owner ordered the companion deep pass: role system + object extension (is-a, abstract,
interfaces) audited against role theory (Steimann/OntoClean/UFO-OntoUML/ORM), BPM resource
models (CMMN/WS-HumanTask/resource patterns/S-BPM), access control (RBAC/ARBAC/ABAC/Zanzibar/
Cedar/OrBAC), Palantir (Foundry + Gotham), enterprise ontologies (gist/FIBO/REA/ArchiMate/
Schema.org/PROV/TOVE), OO & data patterns (Fowler/Coad/DCI/Silverston/FHIR), the Datalog
tradition (LogiQL/Rel/Datomic/Eve), plus round-2 DEMO/SBVR/XACML —
**[roles-extension-prior-art.md (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/research/roles-extension-prior-art.md)**. Result: current
design confirmed essentially intact; the role-chain question resolved (always-a anchored to the
base holding · admitted-from stays grants-shaped · block-by-default revoke); rule 23 was derived
independently and matched (recorded as convergence); a ratify-now shortlist and consolidated
tripwire list included. It covers the literature audit's declared gaps (access control in full,
Datalog practice). Known open tail: an HL7-RIM/BFO-CCO agent and a claim-verifier failed on
usage limits — four flagged claims stay hedged in the doc, RIM/BFO is the one unread thread.

## Addendum 6 — the full decision pass + the semantics pass (2026-08-22)

Owner ordered a full pass over ALL open work: every PR, draft, branch, and feature backlog,
audited against the survey + the companion roles pass →
**[full-decision-pass-2026-08-22.md](full-decision-pass-2026-08-22.md)** — the six-group board
and a 23-step walk order. A semantics pass (grammar surface × runtime paths) then finished the
dead verification stage inline and added rows S1–S11 (ensures-after-sets, deletion/visibility,
refusal × read-permission, multi-sets, negated links, creation-fill, field placement under the
collapse, enum casing, the #99 four, the substrate revisit, the announcement audit). The board is
now the single walk queue.

## Addendum 7 — PR cleanup, the successor PR, and the walk protocol (2026-08-22)

Cleanup executed: **#108 MERGED** (branch deletion closed #110; carrier is now **draft PR #124**,
base staging) · **#107 MERGED** · **#77/#78 CLOSED** with reasons · **#103 retargeted** to staging
(conflicting — queued) · #99/#117/#123/#116/#76 queued in the "PR merge train" chip. Merging
staging surfaced the **Follow-on ratifications (owner, 2026-08-18)** — ~14 further decided items
now in backlog.md (open/closed roles, account join, enforcement-at-commit, seed identity, receiver
slot, toy-seed cleanup, unmanned actors; `type` decided there independently), plus "scope on
grants" spun off and role-holding rules parked. **DECIDED — never re-open in the walk.** They
shrink board row S7 (built-in Person carries name; role fields are capability edge fields).

**The walk protocol (owner-set):** the fixed queue is **THE WALK MAP** in
full-decision-pass-2026-08-22.md — 14 top-level decisions with lettered parts, numbers frozen
forever. **Every exchange opens with the position line** (`D4 Current-ness — 4 of 14 · part b of
f`); one decision (or one part) per exchange — present (question, one sangha example,
recommendation + cost), discuss, and only on an explicit "ratify" commit immediately (owning doc
+ walk-map ✅ + this file), push, move on. D1–D4 done; D5 core (containment redesign + born-in
doctrine) ratified 2026-08-24 after the six-reader containment sweep, then CONSOLIDATED the same
day into the final form (owner-driven): uniform colon declarations `name: Type` / `name: Type[]`,
named-field paths (`Deal.cim.status` — the field, never the type), no ownership machinery,
explicit `sets`/`adds` writes, `about` stories + birth-beat & system-step rules (tick rider on
D11b); the `has`/born-in forms are superseded. Nested set words ratified with exclusions +
`distinct` trigger — **D5 CLOSED 2026-08-24** (amended same day: links written on both sides,
loader-paired, `@of` ties; `@final` ratified as D6a). D6 closed (cross-list exploration goal logged); D7 ratified with the
LLM-authoring rider. **THE WALK CLOSED 2026-08-24 — D1–D14 all ratified.** D14d rulings: prepositional verbs NOT
admitted (simpler sentence forced); numbers = values never sentence words; plurals = determiner,
`every` ADMITTED with full parse spec (supersedes the reservation); star marker removed; defined
groups confirmed. Do-not-build lifts: the released work is the board's section-3 build order +
the corpus sweep as ONE pass (sets lines, both-sides `Type[]` mirrors, `@final` marks, the D4
work list, value casing, star removal, LLM prompts + Claude authoring skill per the D7 rider,
seeds re-version) + the runtime residue + the system-step runner. Building starts only on the
owner's explicit ask; PR #124 (this branch, docs) awaits the owner's undraft/merge word.
Single-yes parts may be offered in threes. The walk runs in its own chip session for fresh context.
Building never happens at ratify time: do-not-build stands until the queue closes; ratifications
release work into the board's section-3 build order + the corpus sweep, executed as one pass after
the walk.

**Owner amendment (2026-08-22, verbatim):** "clean, clear, terse but descriptive technical
language about each decision - no hats, no gates, no spines or other analogies say plainly what
we're talking about - and i need a clear example in onto lang and keeping our place make sure to
use this instruction along with the other instructions on each turn progression". Applied as: every
presentation states plainly what the decision is about, in technical language with no analogies or
coined terms; the example is written in ontolang, not prose; the position line keeps our place;
this holds on every turn.

**Owner amendment 2 (2026-08-23, verbatim):** "this is too dense and verbose - I am getting
confused … I need smaller chunks of decision, terser but clearer … say simply what we are trying
to decide, what currently happens and what you recommend with examples or what case it solves".
Applied as: every presentation is four short labeled pieces — deciding / today / recommend /
example — one small chunk per exchange, never three threads at once.

**Owner amendment 3 (2026-08-24, verbatim):** "you're speaking too confusing i need plain terse
technical language - i literally can't understand the density with which you talk about gates and
residue etc stop saying all of these things". Applied as: project shorthand is banned in
presentations — no "gate", "residue", "enumerated", "satisfying assignment", "arm", "adornment";
say "the conditions", "the remaining open questions", "runs once per matching record", etc. Plain
words a first-time reader gets. This holds every turn.

---

The 2026-08-19 closing state below is kept as record only — superseded; do not print.

```markdown
The pass is done — all 27 domains (coffee, hotel, lead-intake, investment-bank, sangha, plus all 22 wild requirement sets), written up in [binding-scope-corpus-pass.md](binding-scope-corpus-pass.md) and pushed to PR #110.

**The headline:** your instinct held up, with sharp edges found. Implied-from-declared-refs binding covers **most or half** of the reach-back beats in 17 of 22 wild domains. It's strongest exactly where the sentence never names the record — memberships, grants, bookings, registrations, care relationships — and no domain contradicted exactly-one-or-refuse there. The wild corpus even *demands* refusal by name ("prevent double publishing", "no one can submit the same answers multiple time"). The "few" cluster is artifact/cataloging domains where instances arrive by browse-and-select and refs correctly demote to authorization guards — binding was never their bottleneck. And investment-bank is flat **unwritable** without scoping: 50 objects, all per-Deal, no sentence ever names Deal.

**The six decisions the evidence forces** (my recommendation on each):

1. **Instance sources are a trichotomy** — *selected* (named in the sentence → fire input; atoms become guards), *resolved* (unnamed → clauses bind, exactly-one-or-refuse), *enumerated* (system beats / `every` → fire per match). This absorbs the admin-beat problem, the coffee two-drinks problem, and every bulk sweep. It's also the classifier's open "select-one vs apply-each" axis — one decision, both layers. **Ratify.**
2. **Clauses are one conjunctive query** over the cast plus free record names — the drafted atoms generalized from one unnamed record to several. Chains fall out free (planning poker's `Estimator plays Card` → seat → open round; hotel's guest → checked-in reservation → new Service). It's the runtime's native Datalog shape; nothing new to parse. **Ratify.**
3. **Implied party atoms need one new exclusion: a ref the beat's own `sets` writes never binds.** Without it every claim/assign/review beat locks against its own empty ref (`assigns Inspection to Inspector` matches only already-assigned ones) — found independently in four domains. Plus the non-party answer: who-did-it refs (`approvedBy`, `lastModifiedBy`…) trapped **every** file — recommend the log-doctrine (provenance derives from beats, never fields) with an opt-out mark for the rare incidental ref.
4. **Current-ness is authored data.** Live-status filters are what make plural tuples unique everywhere — which settles your old terminal-status question (status atoms, authored or proposed, no convention). "Latest" is never resolution. The one real gap is period windows (doses/attendance per day) — expressible today as timestamp comparisons; date-bucket sugar gets a tripwire, not a decision.
5. **Scoped stories: the case.** A story may declare its case; the case becomes a standing *selected* cast member of every beat (which deal you're working = the page you're on); records carry case refs and everything else binds unchanged. This is your story-run instinct rebuilt on data — run identity = case instance, the shared table = the case's ref graph. IB becomes writable; loudoun's Application, poker's Game, camp seasons, repo tenancy are the same shape. **The biggest decision here.**
6. **Same-type participants** ("map an item from one collection to another") — real, rare; roles dissolve most; colon labels or positionals for the rest, never preposition semantics. Can trail.

The doc has the worked forms — sangha lands exactly as we sketched it this morning (zero atoms, generated comments), and investment-bank gets its first-ever writable fragment. Also recorded: which agent-proposed inventions **dissolved** into machinery you already have (not-exists guards, aggregate counts, dotted paths — all existing shapes).

The decision list is at the bottom of the doc, ordered. Ready to walk through them whenever you are.
```
