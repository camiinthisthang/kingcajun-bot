> Portable snapshot of maintained Onto material. [Package capabilities](../../../START_HERE.md) define the shipped boundary; dated decisions and host implementation notes are context. [Source manifest](../../../SOURCE_MANIFEST.json) records provenance. Links marked “Onto source” are optional host/background references.

> **Layer: AUTHORING-TIME** — recognises object kinds & specialization during authoring. (The type taxonomy it produces is CROSS-CUTTING / part of the IR.)

# Kind Catalog & Entity Grounding — Plan

**Date**: 2026-06-04
**Status**: Proposed — asap slice ready for Claude Code; full structure specced, population accrues
**Supersedes nothing**: extends the earlier vocabulary + story-grammar work, the UI DSL value-type list, and the eval-loop classify pipeline.

---

## The problem

Every entity — including `Customer` and `Order` — currently fires **NEEDS DEFINITION**.
For canonical business entities this is wrong, and it contradicts the axioms: the Tier 1
corpus *is* pre-accumulated grounding (Axiom 2), so a clean hit means grounding is already
partly done. Flagging `Customer` as undefined is the system pretending it knows nothing
about one of the most universal entities in business.

The deeper observation: **there is no useful description for `Customer`** because the term
is its own definition. The grounded-ness and the no-useful-description-ness are the same
fact. An entity that grounds cleanly to a kind is an entity whose meaning is already pinned.

---

## The decision (thesis)

Ground entities into a **closed set of ~12 kinds** we own. A kind hit supplies **nature**
(Actor/Object, deterministically) and a **field skeleton**, and means **no description is
requested** — because the kind *is* the meaning. The frontier model (Opus) authors the
catalog at design time; the catalog is then **frozen** and content-addressed, so runtime is
a deterministic lookup, not inference.

Three layers, distinguished by who supplies fields:

| Layer | What | Who authors | Determinism |
|---|---|---|---|
| **1 — Kind baseline** | Universal fields of the kind (`Person`: name, email, status) | Opus, cited to gist | Frozen → deterministic |
| **2 — Archetype** | Canonical role fields (`Employee`: hire-date, manager…) | Opus, canonized by us | Frozen → deterministic |
| **3 — Domain decoration** | Genuinely domain-specific fields (`Barista`: shift) | Runtime LLM, user-editable | Per-domain, non-deterministic by design |

An entity grounds to **exactly one kind** (rigid, nature-bearing) and may wear
**zero-or-more archetypes** (anti-rigid, field-contributing). Fields compose; nature does not.

**Description is a function of grounding distance.** Grounded → not requested (kind says it).
Specialize → optional delta ("how does this differ from {kind}?"). Novel → required (the
only anchor the system has).

---

## Why a closed set, and why not just call the model at runtime

- **Consistency needs a fixed codomain.** A free model asked "what kind is this?" answers
  Customer→Person, Guest→Patron, Fan→Listener — each locally correct, but they no longer
  converge. Consistency is every judgment landing in the *same small space*. An unbounded
  codomain has no convergence point.
- **It converts grounding into the regime we trust.** Per the no-code-generation boundary, open generation is
  distrusted; constrained classification ("which of these known kinds?") is trusted. The
  closed set is what makes the LLM safe to use for grounding at all.
- **Frozen = zero runtime model dependency.** Opus is the *author*, not a runtime
  component. A better model later produces a new *version* under a new hash; it never
  drifts under an existing one.

---

# Part A — The asap slice (this week)

Goal: type **"Customer places Order"** and get no definition nag. This needs four things,
three of which already half-exist in the codebase.

### A1. Kind baselines — minimum two

```
Person        nature: actor
  name        text      required
  email       email
  status      enum      [active, inactive, suspended]   # values are SOFT/editable

Transaction   nature: object
  id          text      required
  status      enum      [pending, confirmed, fulfilled, cancelled]  # SOFT/editable
  total       number
  created-at  datetime
```

Both are already drafted in the earlier vocabulary work. **Enum *values* are soft defaults**
(real Coffee `Order` uses `[ordered, prepared, served, collected]`) — field *presence* is
confident, enum *values* are editable. Recommended: also write the ~4-field baselines for
`Organization`, `Document`, `Agreement`, `Product` in the same pass (cheap, same method) so
the dictionary below recognizes more than two entities. An entity that hits a kind with no
baseline yet still grounds (nature + chip) — it just carries no field skeleton.

### A2. A near-instant pass in the local on-type pipeline (the whole mechanism)

The story canvas already runs a **local, synchronous, on-type pipeline** — an extensible
chain of passes that fire at keystroke with no network. The canonical check is **one such
pass**: a near-instant dictionary lookup added to that chain. Not a new subsystem — a
function in the pipeline that does an arbitrary near-instant thing, which here is a `Map`
get. Satisfies Axiom 4 by construction (local first, no network for first feedback); no
`pending` flash; dictionary is small enough (~20 now, a few hundred at full catalog) that
lookup is trivially within the keystroke budget.

**Return contract** — the pass is not a boolean; it returns enough for the three downstream
consumers (text coloring, kind chip, field skeleton):

```ts
canonicalLookup(term: string) → { kind: string; nature: 'actor'|'object';
                                   fields: FieldSpec[] } | null
```

`null` → not canonical → the entity flows through the existing path untouched (LLM
classify; pill fires as it does today if also absent from user vocab). The excluded
false-friends below deliberately return `null` and get context-disambiguated downstream.
**Nothing is written to the store** — this is a recognition pass, not a seeding step; the
DataScript store and `toVocabularyMap()` are untouched.

**Dictionary contents.** Membership rule: include a term only if (a) its nature is
invariant across every plausible domain, and (b) its dominant kind is right far more often
than wrong. The rule *is* the false-friend protection.

| Term | Kind | Nature |
|---|---|---|
| Customer, User, Member, Applicant, Person | Person | Actor |
| Employee, Manager | Person | Actor |
| Vendor, Supplier, Organization, Department | Organization | Actor |
| Order, Payment, Booking, Reservation | Transaction | Object |
| Contract | Agreement | Object |
| Invoice, Receipt | Document | Object |
| Product, Service | Product | Object |

**Explicitly excluded — return `null`, fall through to the LLM path that can read neighbors:**

`Client` (person vs software-client), `Ticket` (support-task vs entitlement), `Master`
(recording vs branch vs primary), `Token` (session vs api vs physical), `Account`
(customer vs bank vs login), `Session`, bare `Request` (too generic). These are the
false friends; a lexical match on them grounds to the wrong kind. The LLM disambiguates
by context ("Client" next to Server/Transcoder/Codec is not a Person).

### A3. Behavior on a canonical hit (the literal fix)

This is mostly *changing one trigger condition*, not building new. Today the pill fires when
an entity is in the text but absent from user vocab. After this, it fires only when absent
from user vocab **and** `canonicalLookup` returned `null`.

- Canonical hit → quiet, low-contrast **kind chip** ("Person" / "Transaction"), no red.
- The term is **recognized**, so the pill never fires and **no definition is requested** —
  the description affordance simply isn't relevant for a recognized term. This is not
  suppression of a field; it's the trigger declining to fire.
- Field skeleton from the kind (A1) rides along for coloring and downstream use.
- **Nothing written to the store.** No seeding, vocabulary map untouched. The canonical
  pass is a *parallel source of known-ness*, not a write.

> **The load-bearing integration line:** whatever boolean currently gates the
> NEEDS-DEFINITION pill must also consult the canonical pass. If the hit doesn't feed that
> gate, the lookup runs and nothing visibly changes. This is the one place to verify against
> the real trigger in `page.tsx` — the architecture doc describes the gate as vocab
> membership, but confirm the exact expression.

### A4. Soft pre-verdict state for unmatched terms

- A term that misses the canonical pass *and* isn't in user vocab is **not** immediately
  red. While the debounced `/classify` is in flight it reads as neutral/recognizing.
- The NEEDS-DEFINITION pill fires only on the **settled** LLM verdict for a genuinely novel
  entity — never as an interim, never as a default. Nothing flashes red while you type.
- (If the current pill already only renders post-classify, this is mostly confirming there's
  no red interim state, not adding one.)

### A5. API + data-flow changes

Grounding for canonical terms comes entirely from the **local pass** (A2) — *not* from the
server return. The `/classify` extension is only for the **non-canonical** cases the local
pass returned `null` for (novel verdicts, ambiguity, later specialize):

```ts
entities: {
  actors:  Array<{ name: string; kind: string|null; nature: 'actor'|'object';
                   state: 'novel'|'specialize'; ambiguous: boolean }>
  objects: Array<{ name: string; kind: string|null; nature: 'actor'|'object';
                   state: 'novel'|'specialize'; ambiguous: boolean }>
  activities: string[]
}
```

Flow (Axiom 4 local-first):
1. **Keystroke → local pass** → `canonicalLookup(term)`. Hit → `{kind, nature, fields}`
   instantly → quiet chip, pill stays quiet. No network for these.
2. **Debounced `/classify`** → only for entities the local pass missed → returns
   `{kind, nature, state, ambiguous}` → updates chips; pill fires only where `state==='novel'`
   and settled.
3. **Pre-response** → missed entities read neutral, never red (A4).

> This rides the **live eval-loop `/classify`** pass. It is **not** the commit-time
> action-category classifier — do not conflate the two. They are different passes.

### A6. Claude Code checklist — this week

- [ ] Write kind-baseline data file (Person, Transaction minimum; +Organization, Document,
      Agreement, Product recommended). Mark enum values as soft/editable.
- [ ] Build the canonical dictionary (A2 contents) + the explicit exclusion list, and
      `canonicalLookup(term) → { kind, nature, fields } | null`.
- [ ] Add `canonicalLookup` as a near-instant pass in the existing local on-type pipeline
      (alongside `classify-local`). No store writes.
- [ ] **The load-bearing line**: make the NEEDS-DEFINITION pill's fire condition consult
      `canonicalLookup` alongside the user-vocab check — pill fires only when *absent from
      user vocab* **and** *`canonicalLookup` returned null*. Verify the exact gating
      expression against `page.tsx`.
- [ ] On a canonical hit: render quiet kind chip + color by `nature`; attach the field
      skeleton. No red.
- [ ] Confirm there's no red *interim* state while `/classify` is in flight (A4).
- [ ] Extend `/classify` return with per-entity `{kind, nature, state, ambiguous}` (A5) for
      the non-canonical path only.

**Out of asap scope** (later work, not blockers): Specialize proposals (a later pass);
domain-specific attribute seeding / Layer 3 (its own separate pass — wrong default fields are
their own noise); archetypes; Place/Area render surface.

---

# Part B — Full structure (spec now, populate as domains demand)

Ships as structure so the schema has the slots and the model is coherent. **Not gated to
the asap path.**

### The kinds catalog (~12 + escape)

Derived from the eight gist top-level classes, the UFO kind/role grounding, the
agentive split required by the grammar axioms, and the twelve-seed coverage test.

| Kind | Nature | Baseline (sketch) | Notes |
|---|---|---|---|
| **Person** | Actor | name, email, status | Highest coverage across all seeds |
| **Organization** | Actor | name, type, status | Label, Publisher, Business, Vendor |
| **System** | Actor | name, type | Parser already treats as first-class |
| **Transaction** | Object | id, status, total, created-at | Order, Payment, Booking |
| **Agreement** | Object | id, parties, status, effective-date | Contract, Mandate, NDA |
| **Product** | Object | name, price, category | Drink, Pizza, Service |
| **Task** | Object | id, status, assignee, due-date | **Real "Ticket" lives here** |
| **Event** | Object | id, type, timestamp | Show, Meeting, Milestone |
| **Collection** | Object | name, items | Menu, Library, Cart — Jellyfin's only hit |
| **Document** | Object | id, title, status | **Our addition, not in gist** — IB demands it |
| **Place** | Object | address, coordinates, timezone | Spatial root; **no parent** |
| **Area** | Object | `within` (req), label, function | **Defined by containment**; no coordinates |

**Bare Object** (not a kind — the explicit *absence* of one): identity + state, no business
kind. The correct answer for ~half the seed corpus (Branch, Commit, WinCondition, Token,
Transcode Session, most of Jellyfin). Without this escape the LLM force-fits technical
objects into Transaction to avoid a blank. The empty slot is doing work.

**Candidate, not seeded — Resource** (Room, Seat, Key, Device): real entities, genuinely
not Product, but conditional on inventory/booking being a core vertical. Hold until evidence
demands it; let it enter via content-addressed accumulation, not upstream authority.

The two divergences that justify owning this instead of extracting gist's leaves:
**System** as a first-class agentive kind (the parser already decided this) and **Document**
as a non-agentive kind (IB and Music demand it; gist has no clean home).

### Place + Area + the `within` relation (spatial — specced this session)

The cut is **containment vs. coordinates**:

- **Place** — coordinate-located, absolute, root. Has its own address. No parent.
- **Area** — located *within* a Place or another Area. **Mandatory parent.** Its position
  *is* its parent relationship; it has no coordinates of its own.

`Area` is defined by being `within` something — the `within` edge is **constitutive**, not
an attribute it happens to have. Strip the parent and it isn't an under-specified Area; it
isn't an Area. The naming disambiguation lives in the **structure**, not the word:
bare "Area" is general, but "Area that must be `within` a Place" is unambiguous. ("Location"
was rejected — its cold reading inverts to *address*, a false friend.)

Nesting composes through one recursive edge: `Hotel (Place) ← Floor (Area) ← Front Desk
(Area)`. The awkward middle (a floor is both contained-by and containing) stops being
awkward — a Floor is an Area with a parent that other Areas are `within`.

**Structural rule**: an Area with no `within` is a compile error (same character as
"activity with no authorization rule"). The "needs definition" problem never arises for an
Area — its meaning comes from what it's `within`, exactly as `Customer`'s comes from
grounding to `Person`. Same principle, spatial instance.

**Render surface (open decision — the Place/Area render surface, below)**: Area detail shows parent + contained children; Place
renders its Areas; compiler enforces `within`-required. Confirm whether this surface is in
the spatial-vertical timeline or structure-only for now.

### Archetype layer (role-layer between kind and domain)

Found via `Employee`: it adds fields that are **canonical but not universal** —
`employee-id`, `hire-date`, `manager`, `department`, `title` — invariant across domains,
so *not* Layer 3, but not on `Person` either (a `Customer` is a Person with no hire date).

- **Anti-rigid role-layer**: one entity grounds to exactly one kind (rigid, nature-bearing)
  and wears **zero-or-more archetypes** (field-contributing). An Employee-who-is-also-a-
  Customer = one `Person`, one Actor, both field bundles unioned. Roles compose;
  multiple-inheritance trouble avoided.
- **Sparse and growable**: covers the dozen-ish roles that genuinely recur; silent on
  everything else (Branch, Transcode Session go kind→LLM, skipping Layer 2). Sparseness is
  correct, same principle as Bare Object one layer up.
- **Object archetypes exist too**: `Invoice` → `Document` + {invoice-number, amount-due,
  due-date, line-items}; `Booking` → `Transaction` + {start, end, party-size}. Not just an
  actor-side phenomenon.

> **Nomination-attach (2026-07-04):** the behavior that *consumes* this grounding at commit —
> a role-noun resolves to kind + role, the attach surfaces as a proposal, the role catalog is
> written, instances share the kind — is designed in the
> [roles-permissions backlog](../roles-permissions/backlog.md) (which also tracks the candidate
> **Party** kind for variable-base roles like Buyer/Payee). The recognition pass here stays
> store-write-free; the store write happens in that flow.

**Reference archetype — `Employee`** (the worked pattern, `typical-attributes` format):

```
Employee  archetype-of: Person
  employee-id        text
  hire-date          date
  manager            reference → Person
  department         reference → Organization
  title              text
  employment-status  enum [active, on-leave, terminated]
```

Starter set to canonize: `Employee`, `Customer` (delta: `joined-date`), `Vendor`,
`Invoice`, `Booking`. `Customer` needs **no** archetype for asap — its fields are `Person`'s
plus `joined-date`; it ships on Layer 1.

### Value-types (extend the UI DSL list — small, owned, not schema.org)

Field *types* (what a value conforms to) are distinct from field *sets* (which fields an
entity has). For types, a tiny owned closed list is useful; **schema.org is not the source**
(too loose — its `email` is just Text — and built for markup, not validation).

- **Existing (UI DSL)**: text, number, date, datetime, boolean, enum, reference, computed,
  rich-text, file.
- **Add (semantic shapes)**: email, phone, url, money, duration, address.
- **Render-only shapes**, not sub-ontologies. `money` = "render with currency symbol,
  validate decimal" — *not* a monetary-amount ontology with exchange rates.
- **Graduation rule**: the moment a value-type wants relationships or lifecycle, it's an
  **entity** (structured Address with parts) or an **archetype**, not a primitive. This is
  what keeps the list at a dozen instead of becoming schema.org.
- Cross-check the stringy ones against **JSON Schema `format`**; cite, don't import.

Not on the asap path — `Customer`/`Order` fields are all covered by existing types
(`total`=number, `status`=enum). Add `money`/`address` when an entity needs them.

---

# Part C — Authoring method & provenance

What this conversation did *is* the method: Opus generated candidate kinds and fields, then
they were **disciplined by the seed corpus and the grammar axioms** — kinds tested against
the twelve-seed coverage table, actor/object split against the agency axiom, Customer-vs-
Client against the false-friend cases, Place against the containment cut. The discipline is
what made the output fitted rather than generic.

**The loop**: Opus generates candidates → test against seeds + axioms → iterate → human
review → **freeze** → content-address + version. A cold "give me a business catalog" prompt
yields the median, untested; the loop yields something fitted to these domains.

Cautions: Opus gives the **consensus** answer — exactly right for a *consistency* layer
(convergence is the goal; the median *is* convergence) — but consensus isn't truth. Human
review is the step that catches where the median is wrong for our domains. The catalog will
be **confidently generic** exactly where a domain is weird; that weirdness is Layer 3's job
(runtime, per-domain, user-editable), not the frozen catalog's.

**Provenance line (the whole vocabulary strategy in one sentence):**

> Layer 1 derived-from and cites **gist**; Layer 2 **Opus-authored, canonized by us**,
> cross-checked against HR-XML / FIBO Foundations / schema.org as sanity lists; Layer 3
> **runtime LLM**, per-domain, user-editable. Frozen layers are content-addressed; a better
> model produces a new version under a new hash, never drift under an existing one.

---

# Part D — Publish play (gated on usage, NOT now)

The catalog's value as a *public* artifact — the "npm for business vocabulary" moat — comes
from being **battle-tested, not authored**. Anyone can prompt Opus for a catalog this
afternoon; that's the commodity version. `domain-package-format.md` already says it:
packages earn legitimacy by being derived from *actual practice, not invented from
description*. Publishing an authored-but-untested catalog ships the commodity version of the
one asset whose worth is non-commodity.

- **Sequence**: solve in-app → let real usage across real domains harden it → *then* the
  proven catalog is the publishable artifact. Publishing is **downstream** of in-app, not a
  parallel track. Don't split attention.
- The thing published later is **not** what we'd publish today.
- The grammar-as-standard window is real but months out; rushing a thin version forfeits the
  credibility that makes it land.

---

# Open decisions (need input)

1. **`actor/definition` / `object/definition` is load-bearing — but no longer a blocker.**
   `toVocabularyMap()` feeds ghost autocomplete and the popover definition check, so
   `definition` *is* read downstream. The canonical-pass approach **sidesteps this entirely**
   by not touching the store: it's a parallel recognition source, not a write, so the
   vocabulary map is untouched and nothing is starved. Kept here as a note, not a gate. The
   only thing to verify is the pill's gating expression (see A3 load-bearing line).
2. **Resource — seed or hold?** Leaning hold until inventory/booking is a core vertical;
   let it enter via accumulation.
3. **Place/Area render surface** — in the spatial-vertical timeline now, or structure-only?
4. **Lookup table final membership** — review the ~20 rows + exclusion list in A2.
5. **Soft enum values** — confirm the UI treats baseline enums as editable defaults, not
   locked, so `Order`'s `[pending…]` → `[ordered, prepared…]` is a frictionless edit.

---

# Open questions & deferred

### Future primitives (not built)

- **Link Types** — first-class typed object-to-object relationships (a named, typed edge that stands on its own), distinct from a plain reference field on an entity. A future primitive.
- **Action Types** — governed object mutations, declared as their own kind of thing. Adjacent to but *not* the same as runtime intent facts. A future primitive.

### Deferred refinements

- **Disjoint / rigid subtype modifiers** — mark a subtype as either permanent (a **Subkind** — an entity keeps it for life) or changeable (a **Phase** — an entity moves in and out of it). Specced; deferred as a later, non-breaking refinement.
- **Per-user vocabulary memory** — as an owner creates entities, those choices enrich a recognition memory that grows over time and feeds future suggestions. This is a memory *about the person's vocabulary*, distinct from per-field decoration on a single entity.
- **Kind-catalog population step** — parse the gist ontology (~135 classes), extract class names + definitions, and evaluate each for relevance. The direction stands: the ~12 kinds we own, drawn and disciplined from that source rather than adopting it wholesale.
- **One ontology per org** — flat and global. A type's *definition* is global (there is one definition of a kind), while its *relevance* is local (a given project draws on a subset). This vocabulary is separate from the story tree.

# Sequencing summary

| When | What |
|---|---|
| **This week (asap)** | Part A — two kinds + a near-instant canonical-recognition pass in the local on-type pipeline; pill consults it alongside user-vocab; no red interim. Kills the screenshot bug for commerce terms. |
| **Same doc, lower urgency** | Part B — full ~12 kinds, archetype role-layer, Place/Area/`within`, value-types. Structure ships; population accrues as domains demand. |
| **Months out, gated on usage** | Part D — publish the catalog once real usage has earned it legitimacy. |
