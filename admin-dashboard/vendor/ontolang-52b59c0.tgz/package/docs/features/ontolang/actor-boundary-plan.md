> Portable snapshot of maintained Onto material. [Package capabilities](../../../START_HERE.md) define the shipped boundary; dated decisions and host implementation notes are context. [Source manifest](../../../SOURCE_MANIFEST.json) records provenance. Links marked “Onto source” are optional host/background references.

# Actor access and enrollment — implementation and remaining work

**Ratified 2026-09-10; local implementation built 2026-10-10.**
[Language spec](spec.md#actor-policy--built-locally-2026-10-10) owns declarations;
[runtime spec](../rule-runtime/spec.md#actor-entry-and-enrollment) owns enforcement.

## Language contract

| Declaration | Meaning |
| --- | --- |
| `@type person / organization / system` | Kind of actor; narrower roles inherit it. |
| `@affiliation internal / external` | Relationship in this role to the operating organization; never authority. |
| `@access authenticated / public / none` | Verified and eligible participation, explicit anonymous participation, or no direct entry. |
| `@signup self / invite / none` | Standard enrollment of an assigned authenticated person role. |
| `is a` plus `@where` | Derived membership; cannot be invited, enrolled or granted. |
| `grants` / `revokes` | Domain decisions using validated role operations. |

Affiliation, access and applicable signup must be explicit at participant entry.
Incomplete models stay editable and private-owner publishable with notices.
Invalid/conflicting/misplaced declarations refuse parsing. No missing seed, grant
or actor name is an enrollment policy. Legacy `@boundary external` remains
separate from affiliation and controls which systems Onto does not execute.

## Signup modes — ratified 2026-09-10

| Mode | Self-service | Invitation | Authorized assignment |
| --- | --- | --- | --- |
| `self` | Allowed | Allowed | Allowed |
| `invite` | Unavailable | Required for enrollment | Allowed without invitation |
| `none` | Unavailable | Unavailable | Allowed |

Login authenticates; it does not enroll. Derived/public/no-access actors and
organizations/services do not use ordinary person signup. A narrower role cannot
implicitly confer a protected base role. Domain grants and standard administration
share validated role operations. Current management authority is the verified
publication owner; internal affiliation or an actor called Admin is not authority.

## Implemented migration choices

- Invitations target verified same-organization identities, expire within 30 days,
  persist only a token hash, can be revoked and activate only on acceptance.
  Invitation delivery is a provider boundary; no message is sent by the adapter.
- Suspension blocks enrollment and stale sessions. Revoking an assigned domain
  role removes its eligibility; self-enrollment policy and suspension are distinct.
- One account may enroll in multiple roles. A role hierarchy shares a base person
  record. Independent bare roles currently have distinct linked domain records.
  A universal person store remains a separate migration, not an authored Person.
- Sangha **keeps** attendance-derived NewStudent/OldStudent and its existing
  AssistantTeacher-is-a-Teacher relationship. Student self-enrollment is explicit;
  teacher invitations require an established Teacher. The earlier assigned
  OldStudent sketch is not a completed or implicit corpus migration.
- Coffee no longer grants Customer on first action. Enrollment is explicit,
  orders are customer-bound, and browse/collect refusals use the same eligibility.
- Owner QA remains available for incomplete models. Participant APIs fail closed
  on missing policies. Do not describe that compatibility mode as a deployed app.

## Remaining bounded decisions and deployment work

Broader configurable management authority, cross-organization participant entry,
organization representation and production service bindings; participant-facing
signup/invitation screens and invitation delivery; a universal person identity
migration; new occurrence identifiers for recurring effects; and an explicit typed
story-requested invitation operation. Domain Stories do not implement credentials,
login, token transport or recovery. Hosting/transport and providers remain owned by
the [runtime backlog](../rule-runtime/backlog.md).

## Verification

Parser/printer tests cover policy combinations, invalid values, duplication,
placement, applicability and omission without defaults. Coffee exercises verified
entry, self/invite enrollment, targeting, expiry/revocation, replay, suspension,
lifecycle refusals and private orders. Sangha exercises live subset entry,
protected teacher prerequisites, shared hierarchy identity and stale revocation.
Real local HTTP checks cover explicit public entry and refusal of spoofed identity,
no-access actors, anonymous enrollment, scheduler operations and oversized bodies.
