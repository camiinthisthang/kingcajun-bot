> Portable snapshot of maintained Onto material. [Package capabilities](../../../START_HERE.md) define the shipped boundary; dated decisions and host implementation notes are context. [Source manifest](../../../SOURCE_MANIFEST.json) records provenance. Links marked “Onto source” are optional host/background references.

# Walk verification (2026-08-26)

**Status: verification report. Nothing here is a ruling.** The walk closed 2026-08-24 (D1–D14).
This report checks the ratified record three ways: (1) is each ratified text self-contained and
readable one way only; (2) did the walk leave anything open that is not a recorded park; (3) can
the corpus actually be written in the final grammar. Verified against branch tip `e00bc18`
(the 2026-08-24/26 close-out pass included). Findings are for the owner to rule on. This report
does not choose a reading anywhere.

Sources read in full: the [handoff](handoff-2026-08-19-joins-tier2.md), the walk map in
[full-decision-pass-2026-08-22.md](full-decision-pass-2026-08-22.md),
[binding-backlog.md](binding-backlog.md), the walk entries in [backlog.md](backlog.md),
[binding-scope-corpus-pass.md](binding-scope-corpus-pass.md), [grammar.md](grammar.md),
[modeling.md](modeling.md), [spec.md](spec.md), [joins-tier-2.md](joins-tier-2.md), the four
`examples/ontolang/` projects, and the named wild-corpus files.

---

## 1 · Clarity findings

Each row is a ratified text a builder can read more than one way, or two ratified texts that
disagree. Rows 1–4 block parts of the released corpus sweep. Severity: does it block the sweep,
the build queue, or only reading.

| # | Where | The problem | The readings | Severity |
|---|---|---|---|---|
| 1 | D5 (binding-backlog item 3) vs D12f + the role-field law | ✅ **RATIFIED (owner, 2026-08-26): reading (a).** A mirror line is a link declaration — legal on actor blocks; both-sides covers every link, actor targets included; the role-block field error narrows to value fields; the `payer`/`occupant` illustration is replaced (`Student.bookings: RetreatBooking[]` for the plain pair, Transfer source/target with `Collection.outgoing/incoming @of` for the several-links case). Recorded in binding-backlog item 3. | Reading (a) chosen. | Closed. |
| 2 | D5 pairing rule | ✅ **RATIFIED (owner, 2026-08-26): reading (a).** Two one-links between the same two types pair as one one-to-one relation (only-pair automatic, `@of` otherwise); self-pairs inside one block are legal. Recorded semantics: re-link on either view is the plain move (displaced views clear); scalar↔scalar means at-most-one both directions, permanently — declare `[]` where occurrences repeat (modeling.md line rides the promotion pass). Recorded in binding-backlog item 3. | Reading (a) chosen. | Closed. |
| 3 | D14a | ✅ **RATIFIED (owner, 2026-08-26): the sentence token verbatim.** `Type:label` is the name in every clause position; paths hang off it (`Collection:target.status`); beat-scoped; no bare labels; unmatched label = `file:line` error. Recorded in backlog.md D14a, binding-backlog item 6, grammar.md §2. | Full token chosen. | Closed. |
| 4 | D5 loader rule vs the D2 evidence | ✅ **RATIFIED (owner, 2026-08-26), with a spelling supersession reached through a prior-art sweep** ([unnamed-record-prior-art.md](unnamed-record-prior-art.md)): an unnamed existing record is introduced by a `finds` line (`finds Type` + indented `where`/`and` conditions, one per line; bare fields = the found type's; exactly one or refuse; later clauses use the type name) — the bare unbound-name spelling is superseded. `finds` never creates: a created record is always the sentence's object (poker re-words). Engine semantics unchanged. Recorded in binding-backlog item 2 (amendment), grammar.md, modeling.md rule 22. | Introduction line chosen; creation = sentence object. | Closed. |
| 5 | D12e creation fill | ✅ **RATIFIED (owner, 2026-08-26), parts (a)+(c):** the `about` name never fills by itself — a creating beat in an `about` story carries the written `sets` line, door-proposed; sentence-name fill is the stated one exception to "every link write is a written line". Recorded in backlog.md D12e amendment + binding-backlog item 3. Part (b) — fill routing when two links of one type could take a sentence name — rides the closing batch. | Written line chosen. | (a)/(c) closed; (b) in the batch. |
| 6 | The entrant-role reshape vs ref typing | ✅ **RATIFIED (owner, 2026-08-27): reading (a).** Person comparisons compare the person, never the role — a role-typed link stores the underlying human; the declared role type governs filling only (pickers, grants discipline). Extends D13b from sentences to links. Guidance: type a person link by the role held at write time. Recorded as a D13 amendment in backlog.md. | Reading (a) chosen. | Closed. |
| 7 | D11c | ✅ **RATIFIED (owner, 2026-08-27): the `per` phrase** — quantifier, type, `per` + fields of the counted type, then the filter; the bound applies within each distinct field-value combination (`always at most 1 RetreatBooking per student and retreat where status is not "attended"`). Placement unchanged. Recorded in backlog.md D11c + grammar.md §3. | `per` phrase chosen. | Closed. |
| 8 | D5 `adds` | ✅ **CLOSED (owner, 2026-08-27, batch A3):** deliberate — removable membership is a join record with a status, or the visibility field; a one-to-many link never loses a member without a new home. Recorded in binding-backlog item 3. | — | Closed. |
| 9 | D6a `@final` parse | ✅ **CLOSED (owner, 2026-08-27, batch A1):** attachment is per attribute kind — `@final` binds to the value it follows, field attributes bind after the full type; both may share a line. Recorded in backlog.md D6a + grammar.md. | — | Closed. |
| 10 | D14b `every` × D9 | ✅ **CLOSED (owner, 2026-08-27, batch B2):** per-member run ids derive from the render-minted id plus the member — dedupe key (step, render id, member). Recorded in backlog.md, every admission. | — | Closed. |
| 11 | D10b producers list | ✅ **CLOSED (owner, 2026-08-27, batch B1):** a clock-driven change IS a clock-conditioned system step; no third construct. Recorded in backlog.md D10b. | — | Closed. |
| 12 | grammar.md (close-out text) vs D10d | ✅ **CLOSED:** the grammar note was aligned to D10d in the walk branch's close-out fixes; per-attribute attachment added 2026-08-27. | — | Closed. |
| 13 | Stale text the close-out did not reach | (a) [joins-tier-2.md](joins-tier-2.md) still opens "NOT settled — do not build", and its "Open — the owner is not settled" list stands unmarked; all four items closed (1 → D3 door assist; 2 → D8; 3 → absorbed by D9; 4 → D4). (b) [modeling.md](modeling.md) §"Linking beats to records" is still headed "[proposed — joins tier 2, in discussion]"; rules 21–22 are ratified, promotion is released work. (c) The corpus pass still says corrections "mutate in place" (twice); the ratification reworded point 5 to the opposite spelling ("no physical mutation anywhere") and only the blanket kept-as-record header covers it. | A fresh reader takes retired text for law. | Low — rides the doc-promotion pass; listed so it is not lost. |

---

## 2 · Open items

Hunted: "open", "pending", "TBD", "not decided", "awaiting", "residue" and their neighbors across
the walk-touched docs, reconciled against the ratifications. Excluded as recorded deliberate
parks: scope on grants (spun-off session), role-holding rules, recursion/closure, period sugar,
the `distinct` trigger, the items that died with the ownership machinery, the cross-list
exploration backlog goal, the app-truth substrate session, the coaching six. What remains:

| # | Item | Where | State | Question for the owner |
|---|---|---|---|---|
| 1 | Per-case deviation (survey contradiction 2) | full-decision-pass §2 | ✅ **CLOSED (owner, 2026-08-27, batch C1):** ruled by D10d — the authored `@correction` beat is the override convention. Recorded in backlog.md D10d. | — |
| 2 | ContactForm consumption | corpus pass vs the D4 work list | ✅ **CLOSED (owner, 2026-08-27, batch C2):** joins the sweep work list — a status marking the form consumed at Lead creation. Recorded in binding-backlog D4. | — |
| 3 | Sangha reshape sequencing | backlog.md, follow-on section | ✅ **CLOSED (owner, 2026-08-27, batch C3):** the sweep runs ALL of sangha — the service position resolved out of the role-scope park (`ServiceRole.holder` is a plain link); the park keeps only instance-scoped permission checks and blocks nothing authored; the owner kicks off that walk after sangha lands. | — |
| 4 | Roles prior-art tail | handoff addendum 5 | ✅ **CLOSED (owner, 2026-08-27, batch C3):** dropped unless a domain surfaces it; the four hedged claims stay hedged in that doc. | — |
| 5 | Spellings deferred to build time | D8a, follow-on seed ids, D14c | Deliberate deferrals, listed so none is lost: the authored refusal sentence's keyword ("exact word chosen when the sweep lands it"); the seed person-id spelling ("spelling at build time"); the rounding words themselves (D14c requires a rounding word per division site and names none). | None now — confirm they are tracked for the build. |
| 6 | D14d text reconciliation | backlog.md D14d preamble | "Texts live on staging's backlog rows, reconciled at merge." The reconciliation lands with PR #124's merge. | None — flagged so the merge includes it. |

Everything else the walk discussed traces to a ✅ ratification, a released execute item, or a
recorded park. The board's sections 1–2 rows all map onto walk parts except open item 1 above.

---

## 3 · Corpus representability

### 3.1 Sangha — the generation pass (2026-08-27, post-ratification)

The corpus regenerated under every ratified decision — the walk (D1–D14) plus verification
decisions 1–7 and the closing batch. Zero exceptions remain: every story, rule, and formula
below is writable with ratified constructs only. This is the reference text for authoring a
new domain; CHECKED IN at `examples/ontolang/sangha/` (2026-08-27, owner ask) — it becomes the
loader's exit test when the parser catch-up ships.

```
project SanghaCommunity
  description "Students practice with teachers: retreats, appointments, teachings, service, and dana."

actor Applicant
  type person
  description "The entrant role — anyone becomes one by their first act. Open: no seed, no grant."
  memberships: GroupMembership[]

actor Student
  type person
  description "Anyone practicing with the community."
  bookings: RetreatBooking[]
  appointments: Appointment[]
  applications: ServiceApplication[]
  donations: Donation[]

actor Teacher
  type person
  description "Reviews membership and service; publishes teachings; receives dana."
  teachings: Teaching[]
  dana: Donation[]

actor AssistantTeacher is a Student
  type person
  description "Holds appointments with students; still a student of the lineage."
  appointments: Appointment[]

actor ServiceVolunteer
  type person
  description "A student serving in a position after an accepted application."
  positions: ServiceRole[]

actor Admin
  type person
  description "Schedules, opens, closes retreats; confirms bookings."

object GroupMembership
  description "Admission to the practice group."
  applicant: Applicant
  status: requested | granted | revoked @final

object Retreat
  name: string
  capacity: int
  status: scheduled | open | closed @final
  bookings: RetreatBooking[]
  confirmedCount: int = count of RetreatBooking where status is "confirmed"
  always Retreat.confirmedCount is at most Retreat.capacity

object RetreatBooking
  description "One student's place at one retreat."
  student: Student
  retreat: Retreat
  status: requested | confirmed | attending | attended @final
  always at most 1 RetreatBooking per student and retreat where status is not "attended"

object Appointment
  student: Student
  teacher: AssistantTeacher
  status: requested | confirmed | held @final

object Teaching
  author: Teacher
  title: string
  status: draft | published @final

object Donation
  description "Dana — born complete; no status list (point event)."
  donor: Student
  recipient: Teacher
  amount: money

object ServiceApplication
  applicant: Student
  status: submitted | reviewed | accepted @final | rejected @final

object ServiceRole
  description "A service position — the volunteer assignment's context."
  name: string
  holder: ServiceVolunteer

story Membership
  description "A stranger is admitted; membership can be revoked."
  Applicant requests GroupMembership
  Teacher approves GroupMembership from Applicant
    where GroupMembership.applicant is Applicant
    requires GroupMembership.status is "requested"
    sets GroupMembership.status to "granted"
    grants Student to Applicant
  Teacher revokes GroupMembership from Student
    where GroupMembership.applicant is Student
    requires GroupMembership.status is "granted"
    sets GroupMembership.status to "revoked"

story Retreats
  description "Scheduling, booking within capacity, attending, closing."
  Admin schedules Retreat
  Admin opens Retreat
    requires Retreat.status is "scheduled"
    sets Retreat.status to "open"
  Student requests RetreatBooking for Retreat
  Admin confirms RetreatBooking for Student
    where RetreatBooking.student is Student
    requires RetreatBooking.status is "requested"
    requires RetreatBooking.retreat.status is "open"
    sets RetreatBooking.status to "confirmed"
  Student starts Retreat
    finds RetreatBooking
      where student is Student
      and retreat is Retreat
      and status is "confirmed"
    sets RetreatBooking.status to "attending"
  Student completes Retreat
    finds RetreatBooking
      where student is Student
      and retreat is Retreat
      and status is "attending"
    sets RetreatBooking.status to "attended"
  Admin closes Retreat
    requires Retreat.status is "open"
    sets Retreat.status to "closed"

story Teachings
  Teacher drafts Teaching
  Teacher publishes Teaching
    where Teaching.author is Teacher
    requires Teaching.status is "draft"
    sets Teaching.status to "published"

story Appointments
  Student requests Appointment
  AssistantTeacher confirms Appointment for Student
    where Appointment.student is Student
    requires Appointment.status is "requested"
    sets Appointment.teacher to AssistantTeacher
    sets Appointment.status to "confirmed"
  AssistantTeacher holds Appointment with Student
    where Appointment.student is Student
    where Appointment.teacher is AssistantTeacher
    requires Appointment.status is "confirmed"
    sets Appointment.status to "held"

story Dana
  Student offers Donation to Teacher

story Service
  description "Submit, review, accept or reject, grant, position."
  Student submits ServiceApplication
  Teacher reviews ServiceApplication
    requires ServiceApplication.status is "submitted"
    sets ServiceApplication.status to "reviewed"
  Teacher accepts ServiceApplication from Student
    where ServiceApplication.applicant is Student
    requires ServiceApplication.status is "reviewed"
    sets ServiceApplication.status to "accepted"
    grants ServiceVolunteer to Student
  Teacher rejects ServiceApplication from Student
    where ServiceApplication.applicant is Student
    requires ServiceApplication.status is "reviewed"
    sets ServiceApplication.status to "rejected"
  Teacher assigns ServiceRole to ServiceVolunteer
    sets ServiceRole.holder to ServiceVolunteer

seed Teacher
  name: "Sona"
seed AssistantTeacher
  name: "Mira"
seed Admin
  name: "Devin"
seed ServiceRole
  name: "Kitchen"
  name: "Registrar"
```

**Decisions exercised, by line.** `type person` on every actor (modeling rule 1) · the entrant
role, open by construction, `grants Student to Applicant` at approval (2026-08-18 set) · mirror
lines on actor blocks (verification 1) · one-to-many pairing throughout; `ServiceRole.holder` ↔
`positions` (verification 1+2, batch C3) · `@final` on every read status list, point-event
exemption on Donation (D6a) · every status value has a producer beat, no stuck values (D6b) ·
written `sets` on every transition (D7) · `finds` with multi-line conditions on the two beats
whose sentence keeps the domain phrasing (verification 4) · creation fill from sentence names
only (D12e + verification 5) · cross-role person comparison in the revoke beat (verification 6)
· the `per` counting rule (verification 7) · guards between sentence names as `where`/`requires`
lines (D3 word rule) · multi-`sets` + entity-valued `sets` with the claim-beat exclusion in the
Appointments confirm (D12c, D3c) · lowercase values, CamelCase entities (D12g) · verbatim
domain verbs in the sentence slot, machinery only in clauses (position rule) · seeded roles
closed, `Admin` seeded so no powerful role is open (modeling rule 3).

**One loader detail this generation exposes, for a one-line confirmation:** mirror pairing
should match declared types exactly, never through the `is a` chain — `Appointment.teacher:
AssistantTeacher` pairs with `AssistantTeacher.appointments`, and must not also see
`Student.appointments` as a candidate even though an AssistantTeacher is a Student. Nothing
ratified says this yet.

### 3.2 The authored domains — fragment level

**Coffee** — containment-free; smallest deltas.

```
actor Customer
  type person
  loyaltyTier: none | member | gold    # role-link field, legal
  # name: string dropped — the built-in Person carries name (D12f)

object Order
  customer: Customer                   # the cup-name join becomes a real link (FINDING 1 mirror)
  product: Product
  name: string                         # stays as plain data if wanted; identity is the ref
  status: ordered | prepared | served | collected @final

  Barista prepares Order
    requires Order.status is "ordered"
    sets Order.status to "prepared"
  Customer collects Order
    where Order.customer is Customer
    requires Order.status is "served"
    sets Order.status to "collected"
```

Verdict: writable. Rides finding 1 (Customer mirror). Sweep items confirmed in scope: option
enums re-case (`small | medium | large`, D12g); `Barista.onShift` moves off the role block
(standing state is computed or its own record — D13d); `name` fields leave both actor blocks.

**Hotel** — writable; two findings and one meaning change to re-model.

```
object Reservation
  guest: Guest                         # replaces the name string (FINDING 1 mirror)
  room: Room                           # assigned later; re-linking is a plain write
  roomClass: RoomClass
  services: Service[]                  # pairs with Service.reservation
  status: requested | confirmed | declined @final | checked-in | checked-out @final | cancelled @final

object Invoice
  reservation: Reservation             # FINDING 2: one invoice per stay — one-to-one pairing undefined

  Receptionist assigns Room to Reservation
    sets Reservation.room to Room
  Guest requests Service from Concierge
    where Reservation.guest is Guest
    requires Reservation.status is "checked-in"
    sets Service.reservation to Reservation
  Guest cancels Reservation
    requires Reservation.status is "requested" or Reservation.status is "confirmed"
    sets Reservation.status to "cancelled"
```

Verdict: writable, blocked only by findings 1 and 2. Two sweep notes: (a) the standing
invariant's disjunction must gain `cancelled`; (b) **the confirm/decline branch changes meaning
under the ratified system-step rule** — `System confirms Reservation` now fires by itself once
per requested reservation, so `Receptionist declines Reservation` can never win the race. The
sweep must re-model the pair (this report does not choose how).

**Lead-intake** — writable; the identity move is under-specified.

```
actor Employee
  type person
  # name: string dropped — the built-in Person carries name (D12f)

object ContactForm
  # email loses @unique; identity moves to a party record (ratified D4 work list).
  # The party record's shape (which entity, which fields) is not written anywhere — sweep
  # needs the one-line answer (open item 2 is the related consumption question).

object Lead
  contactForm: ContactForm             # FINDING 2: one lead per form — one-to-one
  territory: Territory

  System routes Lead to AccountExecutive
    where Lead.territory.owner is AccountExecutive
    requires Lead.status is "qualified" and Lead.territory exists
    requires Lead.territory.openLeadCount is less than Lead.territory.capacity
    sets Lead.status to "routed"
  System sends LeadAlert to AccountExecutive
    where Lead.territory.owner is AccountExecutive
    requires Lead.status is "routed"
    requires no LeadAlert where lead is Lead
    # the last line is new: without it the step re-fires forever — the ratified
    # self-stopping load check (D11b) would reject the beat as it stands in the corpus
```

Verdict: writable. Rides findings 1 (`Territory.owner` mirror) and 2 (`Lead.contactForm`). The
formulas (conditional values, counts through the linking ref, date arithmetic) are all built
shapes — nothing changes. Terminals: `converted @final`, `dropped @final`, `disqualified @final`.

**Investment-bank** — writable for the first time, as an `about` story; the pairing gap is its
main blocker.

```
actor Employee
  type person
  seniority: analyst | associate | vp | director | md   # role-link field

actor Analyst = Employee where seniority is "analyst"    # defined groups, confirmed D14d-5
actor VP = Employee where seniority is "vp"

object Deal
  business: Business                   # FINDING 1 (mirror on an actor)
  cim: CIM                             # FINDING 2 — the domain is mostly one-of-each parts
  teasers: Teaser[]                    # pairs with Teaser.deal
  status: pitched | mandated | marketed | closed @final

object CIM
  deal: Deal
  status: drafted | redlined | final @final

object Teaser
  deal: Deal
  buyer: Buyer                         # FINDING 1

story Deal about Deal
  ManagingDirector pitches Deal to Business
    # birth beat: creating the context type is exempt; the newborn is this fire's context
  Analyst drafts CIM
    sets CIM.deal to Deal              # FINDING 5a: written line, or does the about name fill?
  VP redlines CIM
    requires CIM.status is "drafted"
    sets CIM.status to "redlined"
  Associate sends Teaser to Buyer
    sets Teaser.deal to Deal           # FINDING 5a; fires once per buyer — reality repeats it
```

Verdict: writable end to end (the corpus pass promised this and the final grammar keeps the
promise), blocked by findings 1, 2 (dominant here), and 5a. Deal is born at the pitch per the
ratified re-version. The remaining ~45 part objects follow the two patterns shown.

### 3.3 Wild-corpus spot checks (the containment sweep's stress cases)

| Case | The requirement (paraphrased, file cited) | Final-grammar form | Verdict |
|---|---|---|---|
| archivesspace tree rearrange (g23 #33–34) | Move an archival object to a new position in the tree | Self-link `parent: ArchivalObject` + `children: ArchivalObject[]`; beat `Archivist moves ArchivalObject to ArchivalObject:target` + `sets ArchivalObject.parent to ArchivalObject:target` | **Blocked by findings 3 (label in a clause line) and 2 (self-type pairing).** The mutable-parent-ref doctrine itself holds. |
| culrepo move (g27 #96) | Move a collection at an owner's request | Same shape: `sets Collection.parent to Collection:target` | Same two blocks. |
| datahub delete/restore (g14 #11, #19–20) | Delete a data package; restore it later | `visibility: published | hidden` cycling field (D12b); permanent deletion stays a platform operation | Writable. |
| datahub membership removal (g14 #58) | Remove a person from a publisher's membership | Many-to-many is a join record by rule; removal is a status write on it (the sangha Membership shape) | Writable. Finding 8 only bites if someone models it as a bare list. |
| planning poker chain (g13) | An estimator plays a card in the open round of their game | The find side (`where Seat.estimator is Estimator · where Round.game is Seat.game · requires Round.status is "open"`) is writable | **The create side is blocked by finding 4** — the Estimate the beat creates is in no sentence and no `about` line. |
| badcamp registration (g21 #38, #45, #6) | Register for a summit; seats left; one registration per day | `Attendee submits Registration for Summit` (the record noun as object, per D14d-1); capacity = count formula + at-most rule | Registration and capacity writable. The per-day limit lands on the recorded period park — a day-keyed remodel or the tripwire. Not a new gap. |

### 3.4 Overall representability verdict

| Domain | Verdict | Blocked by |
|---|---|---|
| sangha | Fully writable — zero exceptions (generation pass, §3.1) | — (all three former exceptions ratified away 2026-08-26/27) |
| coffee | Writable | Finding 1 |
| hotel | Writable | Findings 1, 2; confirm/decline re-model note |
| lead-intake | Writable | Findings 1, 2; the party-record shape (one line needed) |
| investment-bank | Writable as an `about` story | Findings 1, 2, 5a |
| wild stress cases | As tabled | Findings 2, 3, 4; two recorded parks |

**The short version.** The final grammar covers the corpus. No story sentence, rule, or formula
needs a construct the walk did not ratify — with five precise exceptions, and all five are
under-specifications of ratified decisions, not missing decisions: mirror lines on actor blocks
(1), one-to-one pairing (2), labels inside clause lines (3), records created but not named (4),
and creation fill in `about` stories (5a). Rulings on those five unblock every rewrite in this
report, including the full sangha file.

**Resolution addendum (2026-08-27).** Every blocking finding and open item above is ratified
(rows marked ✅); §3.1 now holds the post-ratification generation pass — the corpus is fully
writable with zero exceptions. The remaining un-ratified rows are finding 13 (stale text —
rides the doc-promotion pass) and the deferred-to-build spellings inventory (open item 5).
