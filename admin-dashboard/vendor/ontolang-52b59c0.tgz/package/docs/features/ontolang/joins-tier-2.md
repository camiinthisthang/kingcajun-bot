> Portable snapshot of maintained Onto material. [Package capabilities](../../../START_HERE.md) define the shipped boundary; dated decisions and host implementation notes are context. [Source manifest](../../../SOURCE_MANIFEST.json) records provenance. Links marked “Onto source” are optional host/background references.

> **Layer: cross-cutting** — AUTHORING owns the clause grammar and IR; RUNTIME resolves and enforces. The pure loop gains one capability (clause-bound records); nothing else changes.

# Joins tier 2 — linking beats to related records (design, CLOSED — the mechanism trail)

**Status: CLOSED — the walk ratified this territory 2026-08-24 (D1–D14; see the walk map in [full-decision-pass-2026-08-22.md](full-decision-pass-2026-08-22.md)); this page is the mechanism trail, kept as record.** Session handoff (read this first when catching up on another machine): [handoff-2026-08-19-joins-tier2.md](handoff-2026-08-19-joins-tier2.md). **Later the same day the discussion moved past this page's mechanism**: the owner reopened implicit resolution on new terms (declared refs imply the link; explicit somewhere; generated comments at the site), named the bigger issue — instance binding and scoped-vs-global stories — and ordered a full-corpus evidence pass, wild sets included: **[binding-scope-corpus-pass.md](binding-scope-corpus-pass.md)** — six decisions with corpus evidence, superseding this page's open-questions list as the live decision surface. This note records where the design stood so the branch carries it. It **replaces** the first draft ("story-run as binding scope"), which the session rejected — see *Considered and rejected* below. The exit cases are unchanged ([backlog](backlog.md) item 1, the sangha corpus): `Student attends Retreat` must reach the booking of *that student for that retreat*, and the acceptance gate must read *the application that student submitted*.

## Where the discussion landed

**One mechanism: the beat links its record explicitly, in clauses, and the runtime re-finds it from data at every fire.** No runtime memory, no derivation, no name matching.

```
object RetreatBooking
  student: Student
  retreat: Retreat
  status: requested | confirmed | attending | attended

story Retreats
  Admin schedules Retreat
  Admin opens Retreat
  Student requests RetreatBooking for Retreat
  Admin confirms RetreatBooking for Student
    requires RetreatBooking.retreat.status is "open"
  Student starts Retreat
    requires RetreatBooking.student is Student
    requires RetreatBooking.retreat is Retreat
    requires RetreatBooking.status is "confirmed"
    sets RetreatBooking.status to "attending"
  Student completes Retreat
    requires RetreatBooking.student is Student
    requires RetreatBooking.retreat is Retreat
    requires RetreatBooking.status is "attending"
    sets RetreatBooking.status to "attended"
```

The pieces, each on the page:

1. **Sentences stay domain language.** `Student attends Retreat` — never `Student attends RetreatBooking` when the domain doesn't talk that way, and never a suffix. Machinery lives indented under the beat, where gates and `grants` already live (the 2026-08-14 sentence ruling; the Roles-over-kinds clause family). Naming the record *as* the object stays legal where the domain does say it (`Student requests RetreatBooking for Retreat`).
2. **The link is written rule atoms.** `requires RetreatBooking.student is Student` / `requires RetreatBooking.retreat is Retreat` — the tier-1 cross-participant comparison shape, nothing new to parse. A clause entity the sentence doesn't name binds to **the one instance that makes every clause true**. Zero matches → refusal ("no confirmed booking of yours for this retreat"). Two or more → refuse and ask, never pick silently.
3. **The loader enforces the link.** A `sets` (or gate) on a record with no atom tying it to a sentence name is a `file:line` error. Explicitness is checked, not hoped for. Rename any entity — nothing breaks, because nothing resolves by name.
4. **`sets Path to value` is the write clause.** All words, no symbols: checks read `requires … is`, writes read `sets … to`, conferrals read `grants … to` — one clause family, one shape. The value must be declared for the field, `file:line` otherwise.
5. **Resolution is from scratch, every fire.** A retreat lasts a month; when `completes` fires, nothing was remembered — the clauses re-find the booking from data at that moment. Ordering derives from the data too: you can't complete what never started, because the `attending` gate fails.
6. **Person constraints are the same atoms.** `requires RetreatBooking.student is Student` is what makes the attending student the requesting student. Interchangeable roles simply lack the atom — nothing points at an Admin, so any Admin confirms. Locking is authored, never derived.

The second exit case, same shape plus the ratified conferral:

```
story Service
  Student submits ServiceApplication
  Teacher reviews ServiceApplication
  Teacher accepts ServiceApplication from Student
    requires ServiceApplication.status is "reviewed"
    sets ServiceApplication.status to "accepted"
    grants ServiceVolunteer to Student
```

The application is the named object (the thing acted on); `from Student` reaches the submitter through `ServiceApplication.applicant` — a forward ref read, tier 1 as built. The grant lands on that person.

## What this retires — ✅ RATIFIED (owner, 2026-08-24; walk-map D7)

- **The `produces` suffix and the word.** The clause replaces it; the suffix becomes a pointed replaced-syntax error ("use a `sets` clause"). The story-authoring backlog item that would teach the canvas the suffix goes on hold.
- **Load-time verb→status derivation** (`verbToStatus` → `story/transition-to`, [parse-project.ts (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/ontolang/parse-project.ts)). The 2026-08-03 "automatic with fallback" decision predates the no-inference turn (#95–#98: declarations decide, guessing killed, mismatch = pointed error); produced status catches up. **Every transition beat carries its `sets` clause in the file.** The conjugator demotes to a **studio typing assist** — it proposes the clause text as you type the beat; you see it land before committing (origin ladder: proposed → confirmed; the same demotion the `SYSTEM_ACTORS` lexicon got).
- **Consequence: corpus sweep.** Every transition beat in the seeds and `.onto` corpus grows its clause; seeds re-version (the standing rule: right shape first, never protect goldens). The sangha corpus also takes the domain corrections from this session: an `Admin` actor for schedule/open/confirm, and attendance as two beats (`starts` → `attending`, `completes` → `attended`) — a month-long retreat is not one flip.

## Decided along the way (this session, still informal)

- **Repetition control is authored, not scoped.** "How often can this beat fire" is a cardinality rule when you care (`at most 1 RetreatBooking where …`); nothing is scoped by a hidden pass.
- **The determiners (`a`/`another`/`the`) leave this tier.** With no runtime scope there is nothing for them to opt out of; they ride the later `every` work ([backlog](backlog.md), the iteration answer). The [grammar.md](grammar.md) §2 determiner line ("co-refers within the story run") describes the rejected draft and needs revisiting when this ratifies — left untouched until then.
- **Comments never carry meaning.** Where behavior isn't visible in the story text, the **printer and studio annotate** with generated comments (derived, regenerable, ignored at parse) — hand-written comments stay inert.

## Considered and rejected (the session's trail)

- **A story run as runtime binding scope** (the first draft: one pass through a story block shares a name→instance table, carried on the log; bare = same one, `a`/`another` opt out). Rejected: an invisible table the runtime remembers between fires — "magical" no matter how explained. The one instinct kept: grouping a story's beats around shared things — now done by written atoms instead of memory.
- **Widening produced-status derivation to the story's cast** (verb matches another entity's enum). Rejected immediately: a new derivation arm in the loader, against the target-format doctrine ("the loader validates, it is not owed cleverness") and the grants ruling ("no derivation arm, ever").
- **A `where` join packed into the clause** (`produces RetreatBooking "attended" where student is Student and …`). Right content, wrong ergonomics — long and confusing. The same content as separate `requires` lines reads clean and *is* the accepted design.
- **Resolving through the record's refs implicitly** (no atoms written; the loader finds the connecting refs). Rejected: the link must be on the page, not in a distant object block — "no clear link between RetreatBooking and Retreat" otherwise.
- **Forcing the record into every sentence** (`Student attends RetreatBooking`). Rejected: misquotes the domain; the sentence keeps the domain's noun and the clauses carry the machinery.
- **`sets … = …`.** The symbol collides with Formula `=` (computed) and breaks the all-words character; `to` also rhymes with `grants … to`.

## Follow-through in this PR

- [modeling.md](modeling.md) gains the proposed linking rules (marked *[proposed]* — see the page).
- [story-authoring backlog](../story-authoring/backlog.md): the canvas `produces`-suffix item goes on hold; a new item covers the clause assist (propose link atoms + `sets` when a typed beat needs an unnamed record) and the annotation surface.

## Open — the owner is not settled *(all four since closed by the walk: 1 → the D3 door assist; 2 → D8 ambiguity UX; 3 → absorbed by D9 fire identity; 4 → D4 current-ness — kept as record)*

1. **Weight of the atoms.** Two link `requires` lines per beat, per record, plus a `sets` on every transition beat — is the explicit tax acceptable once the studio proposes the text? (The session leaned yes; not confirmed.)
2. **Ambiguity UX.** "Two matches → refuse and ask" — where and how the ask renders (banner family? picker?) is undesigned.
3. **IR home for the clause.** `sets` needs a stored fact on the beat (the successor of the derived `story/transition-to` edge — likely the same edge, now sourced from the clause, plus the field name). Shape undecided.
4. **Uniqueness scope.** "Exactly one instance satisfies the clauses" — over live instances of the record's type; whether terminal-status records (attended, closed) should be excluded from matching by convention or by an authored atom (`status is "confirmed"` already does it in practice).
