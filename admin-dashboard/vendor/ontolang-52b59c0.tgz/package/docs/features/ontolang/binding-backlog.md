> Portable snapshot of maintained Onto material. [Package capabilities](../../../START_HERE.md) define the shipped boundary; dated decisions and host implementation notes are context. [Source manifest](../../../SOURCE_MANIFEST.json) records provenance. Links marked “Onto source” are optional host/background references.

> **Layer: cross-cutting** — AUTHORING owns the clause grammar and IR; RUNTIME resolves and
> enforces. Sub-feature backlog of [ontolang](backlog.md) (the general backlog holds one pointer
> here, never the queue itself).

# Binding & scope — backlog

**Status: THE WALK IS COMPLETE — D1–D14 ALL RATIFIED (2026-08-24). Do-not-build has lifted; the build order + corpus sweep are released (see the walk map + handoff). Building starts on the owner's explicit ask.**
The evidence: [binding-scope-corpus-pass.md](binding-scope-corpus-pass.md) (27 domains — full
authored corpus + sangha + all 22 wild sets; verdict table, worked rewrites). The literature
audit — every decision here checked against the process/business-modeling canon, with guidance
per pending item and five argued contradictions: [the survey (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/research/business-process-modeling-survey.md) (2026-08-21). The mechanism trail
and rejections: [joins-tier-2.md](joins-tier-2.md). Catch-up protocol:
[handoff-2026-08-19-joins-tier2.md](handoff-2026-08-19-joins-tier2.md).

**What this sub-feature is.** How a beat's entity positions get their instances (the successor of
"joins tier 2"), and whether a story runs global or scoped to a case. Sentences stay domain
language; machinery is indented clauses; nothing resolves by name, nothing is remembered between
fires, nothing is ever probabilistic.

## The decision queue (owner)

1. ✅ **The instance-source trichotomy — RATIFIED (owner, 2026-08-19).** See the ratified section
   below for the full statement, the owner's clarifications, and the plural-routing table.
   Twin decision in [story-authoring](../story-authoring/backlog.md): the classifier's
   select-one vs apply-each axis is the same choice (language half now ratified; the classifier
   surface stays that feature's item).
2. ✅ **Atoms are real text; links are `where` — RATIFIED (owner, 2026-08-19).** The same-type-ref
   collision proved type-matching untenable ("the matching seems like a bad idea if you can have
   more than one of the same ref"); an opt-in `@party` mark was rejected as backwards. Final form:
   - **The canonical file carries every atom as real clause lines.** A beat's meaning is frozen
     in its own text; adding a declaration later affects nothing that exists; the **loader
     validates only** (unknown field/type/value, wrong clause word = `file:line` error) — nothing
     is ever matched or derived at load, anywhere. No generated binds-comment: the atoms are the
     visibility. Explicit field paths are how Formulas and Rules already reference the model —
     beat atoms are the same kind of reference, not duplication.
   - **The word follows the atom's function** ("where says which things; requires says what must
     hold"): an entity-to-entity **link** is always `where` (bound or unbound); a path-vs-value
     **condition** is always `requires`/`forbids`. Purely lexical — one conjunction underneath
     (decision 2 unchanged; a `requires` on an unbound record still narrows the query, which the
     plural-routing table depends on). Clause family: `where` link · `requires`/`forbids`
     condition · `sets … to` write · `grants … to` confer.
   - **Hand-sparse input stays legal at the doors:** the studio/printer **materializes the link
     atoms into the text once, from the declared refs, under the author's eyes** (origin ladder:
     proposed → confirmed; the assist picks the word by function). Door rule: an unbound record
     with no link atom gets the proposal; any written link atom → touch nothing.
   - **Sets-exclusion (ratified) lives in the door assist:** it never proposes an atom for a ref
     the beat's own `sets` writes (the claim beat; already-claimed protection is the status
     condition, authored data). **Collision** (two same-type refs) is a door question — the
     assist asks which ref is meant; a pasted sparse file with the ambiguity gets the
     `file:line` error demanding the written atom. Canonical files can never collide.
   - **Renames** rewrite atoms via the rename op (visible diffs); a deleted ref leaves atoms
     naming a missing field → pointed validation error at the beat. Marks are dead (`@party`,
     `@nonbinding`).
   **Part 4 ✅ RATIFIED (owner, 2026-08-19: "if we don't need it, dump it"):** who-did-it is
   never a field — the log records every fire's actor; a person-ref exists only where a beat,
   gate, or seed reads it ([modeling.md](modeling.md) rule 23). Decision 3 fully closed.
   **AMENDED (owner, 2026-08-26, verification decision 4): unnamed records are introduced by a
   `finds` line — the bare unbound-name spelling is SUPERSEDED.** A step reaches a record its
   sentence does not name with `finds <Type>` plus indented `where`/`and` condition lines, one
   condition per line (canonical layout; one line is legal for a single condition; the printer
   emits the multi-line form). Bare field words in the conditions belong to the found type — the
   `count of … where` anchoring; sentence and `about` names appear as values. Exactly one match
   or the step refuses, rendered per D8 (each condition line with what it found). Later clause
   lines address the record by its type name; two finds of one type use `Type:label`. A clause
   name with no sentence, `about`, `Type:label`, or `finds` source = pointed `file:line` error
   naming the fix ("introduce the record with finds"). **`finds` never creates** — a record a
   beat creates is always its sentence object (the planning-poker sketch in the D2 evidence is
   corrected by re-wording the beat to name the created record). The word rule is unchanged
   outside filters (`where` link · `requires`/`forbids` condition); the engine's ratified query
   semantics are unchanged — this is surface spelling only. The door proposes the `finds` line
   at typing time (origin ladder unchanged). Ruled on the sangha sentence: `Student starts
   Retreat` keeps the domain's phrasing (~2 beats per authored domain need the construct).
   Evidence: [unnamed-record-prior-art.md](unnamed-record-prior-art.md) — 35 systems; the
   bare-variable form exists only in programmer-facing engines; every business-readable system
   uses a visible named find step; Foundry bans reach in form rules and re-admits exactly this
   as a derived hidden parameter.
   ```
   Student starts Retreat
     finds RetreatBooking
       where student is Student
       and retreat is Retreat
       and status is "confirmed"
     sets RetreatBooking.status to "attending"
   ```
3. ✅ **Links & scope — RATIFIED (owner, 2026-08-24; walk-map D5, consolidated form).** The arc
   ran case → parent-side containment (`has` + born-in doctrine, ratified earlier the same day)
   → this final consolidation, owner-driven at each step; the earlier forms are **SUPERSEDED**
   (parent-side `has`, the born-in doctrine, one-home-per-instance, type-name path hops — all
   dead). The containment sweep (this doc, 2026-08-24 section) is the evidence trail. Final:
   - **Declarations are uniform colon lines.** `name: Type` = link to one; `name: Type[]` =
     link to many; values as shipped (`status: pipeline | active`). Links are named fields with
     author-chosen names; two links of one type are two named fields (`source: Collection`,
     `target: Collection` on a Transfer record). `has`, `has one/many`, and `as` naming do not
     exist.
     **AMENDED (owner, 2026-08-24): links are written on BOTH sides.** The child's block carries
     the mirror line (`retreat: Retreat` beside `bookings: RetreatBooking[]`); the loader PAIRS
     the two lines into one relation — a one-link and a []-link between the same two types pair
     automatically when they are the only pair; with several links between the same types each
     mirror names its partner via `@of` (`Collection.outgoing: Transfer[] @of(source)` and
     `Collection.incoming: Transfer[] @of(target)` beside Transfer's `source: Collection` /
     `target: Collection`); unpaired, mismatched, or
     ambiguous = pointed load error, so the sides can never drift. Two []-links between the same
     types = error (use a join record — the many-to-many doctrine now enforced, not assumed).
     The author writes one side; the studio door materializes the mirror (proposed → confirmed);
     the studio renders links by reading text, never deriving.
     **AMENDED (owner, 2026-08-26, verification decision 1): mirror lines are link
     declarations — legal on actor blocks; both-sides covers every link, actor targets
     included.** `Student.bookings: RetreatBooking[]` pairs with `RetreatBooking.student:
     Student`. A mirror line declares the relation between two types and stores nothing per
     person or per holding — so the role-block field error NARROWS to value fields (per-holding
     facts, still a pointed error until assignments carry fields); link lines are the one line
     kind legal on a role block today, beside `type` and `description`. Mirror names are
     author-chosen domain words; a mirror with no sensible domain name is a modeling smell the
     door surfaces, never a grammar exemption. (This ruling replaced the earlier `payer`/
     `occupant`-on-Guest illustration, which modeled nothing real.)
     **AMENDED (owner, 2026-08-26, verification decision 2): two one-links between the same
     two types pair as ONE one-to-one relation.** Same mechanics as scalar+list: automatic when
     the only pair, `@of` when several, unpaired = pointed error; a pair may sit inside one
     block (`parent: ArchivalObject` beside `children: ArchivalObject[]` — self-links pair the
     same way). Two semantics recorded as law, not surprise: (1) **re-linking on either view is
     the plain move** — one written `sets` updates both views and clears every displaced view
     (the old holder's slot empties; a replaced child's slot empties); a domain that forbids the
     move writes the condition (`requires no Deal where cim is CIM`). (2) **scalar↔scalar
     declares at-most-one in both directions, permanently** — declare `[]` wherever occurrences
     repeat (a re-issued invoice is a new record and must keep its link; the rule line lands on
     modeling.md with the promotion pass). Prior art checked (Rails): one-side-stores +
     other-side-declares matches; implicit clearing on reassign matches; its advisory-only
     one-to-one is weaker (pairing here is structural); its has_one→has_many regret is the
     `[]` rule's evidence.
   - **No ownership machinery.** A link is a typed slot with a cardinality — nothing more. No
     born-in rule, no one-home rule, no context lifting, no move problem: re-linking is an
     explicit write (the sweep's re-parenting cases all become plain writes).
   - **Every link write is a written line** (door-proposed real text under D3):
     `sets Deal.cim to CIM` (one-link) · `adds Document to Deal.documents` (many-link) ·
     membership check `where Document is in Deal.documents`. `adds` has no inverse —
     deliberate (confirmed 2026-08-27): membership that can end is a join record with a status,
     or the visibility field; a one-to-many link never loses a member without a new home.
   - **Paths are field names, exactly today's grammar** (owner: the field, never the type):
     `Deal.cim.status`. Many-links never appear mid-path; reads over them use set words
     (`count of`, `every … in Deal.documents where …`); type-scoped forms (`count of X where …`,
     `no X where …`, `via`) unchanged.
   - **Stories:** `story Name about Deal` declares the bound name; each fire supplies its
     instance from the working context (the record view it happens in). A creating beat links
     its newborn to the context with a written `sets` line — the `about` name never fills by
     itself (owner, 2026-08-26, verification decision 5; the door proposes the line). Birth
     beats: a beat creating the context type is exempt, the newborn is that fire's context. System steps take
     theirs from their own conditions, once per matching record (tick rider on D11b). Global
     stories name things in sentences (`for Deal` is ordinary participant naming — the
     container/party ambiguity died with ownership).
   - **Loader validates only:** a clause name with no source (sentence, `about` line, or a
     `finds` line — the 2026-08-26 amendment under item 2) = `file:line` error; the runtime
     receives and checks, never infers.
   **Birth beats ✅ RATIFIED (owner, 2026-08-24):** in a story `about X`, a beat that creates X
   is exempt from the context requirement, and the newborn instance is that fire's context — its
   own clauses may use the name; the firer lands on the new record's view. Stories keep the
   single-arc style; IB re-versions so the Deal is born at the pitch (rides the corpus sweep).
   **System steps ✅ RATIFIED (owner, 2026-08-24):** in a story `about X`, a step whose actor is
   `type system` needs no page — its X comes from its own conditions, and it runs once per record
   that passes them. One loader rule; the engine's match lists already exist. **Tick rider,
   recorded so it is not missed:** the clock tick is BUILT for hand-driven time (rule-runtime
   `tick`, ClockBar advances `now`, re-derivation + invariant re-check); the SCHEDULED production
   tick and the sorted-deadline check are NOT built — they land with the system-step runner
   (walk-map D11b) and are named requirements of that build.
   **Nested set words ✅ RATIFIED (owner, 2026-08-24) — D5 CLOSED.** Two sentences: a counting
   word may name a many-link field (`count of RetreatBooking in Retreat.bookings where status is
   "confirmed"` — `in <field>` narrows); counting words nest for two-level reads (`every CIM in
   Deal.cims where count of Section in CIM.sections is at least 5`). FEEL's `every x in L
   satisfies` is the direct precedent; the inventory now matches the OCL/FEEL/Prisma
   intersection. **Deliberate exclusions, recorded:** sort/first/last (D4: "latest" is a UI
   default, never resolution); group-by (reporting — the analytics surface owns it); closure/
   tree-walks (recursion stays parked with its trigger). **Trigger note:** add `distinct` the
   first time a real domain needs a count of different values. (Former residue items that died
   in the consolidation: singular `has`, `for` disambiguation, headless-create context supply,
   `as` naming.)
4. ✅ (part a) **Ambiguity UX — RATIFIED (owner, 2026-08-24; walk-map D8a).** One machinery, two
   renders, both fed by the step's own query (never a separate explanation that can drift):
   - **Choice legal** (record named in the sentence, person picks): an ordinary picker/list.
   - **Exactly-one required, two or zero found:** the step refuses with a notice showing each
     condition line as a plain sentence with what it found ("status is \"confirmed\" — 2
     bookings match"), so the person sees which line failed and whether the model needs a
     narrower condition or the data needs fixing.
   - **Optional authored refusal sentence per beat** overrides the generated one (the
     Foundry-proven pattern — bare machine refusals push people to email); one optional line,
     exact word chosen when the sweep lands it.
   Runtime display rides the build queue.
   **Part b ✅ RATIFIED (owner, 2026-08-24) — D8 CLOSED.** The notice lists only records the
   viewer may read; the rest appear as a count, never content ("2 match — 1 shown · 1 more you
   cannot view"); zero readable matches still shows the counts. One renderer rule: filter the
   listed records through the viewer's read permission, show the remainder as a number.
5. ✅ **Current-ness (decision 4 / walk-map D4) — RATIFIED (owner, 2026-08-23).** The six points
   as amended by the sweep ([corpus pass](binding-scope-corpus-pass.md), decision-4 section);
   point 5 reworded at ratification:
   1. Occurrences are instances — each occurrence of a recurring thing is its own record.
   2. A process target's liveness is read from the record's **own** fields — a walked status, a
      clock comparison on its own dates, or a derived value; **never a related record's process
      position, never recency among records**.
   3. Closure is required only where a later beat, gate, or seed addresses the occurrence
      (sangha's Donation: born complete, no lifecycle). Enforcement machinery is ratified as
      walk-map D6 (owner, 2026-08-24): `@final` trails a status value; the loader runs lifecycle
      checks (unreachable value, stuck value, leaving `@final`); corrections leave `@final` only
      through authored `@correction` beats — see the walk map in
      [full-decision-pass-2026-08-22.md](full-decision-pass-2026-08-22.md) and the handoff.
   4. Read-side plurality (versions, renditions) never demands a unique live one — address, pin,
      or typed attribute picks; "latest" is legal as a UI default and over ordered event logs,
      never as process resolution.
   5. **A correction keeps the record's identity — a new write on the same record; the log
      carries the old value. A new record is minted for a new occurrence, never for a fix.**
      (No physical mutation anywhere: every write appends; "in place" spellings retired —
      owner, 2026-08-23.)
   6. Periods: the coarse period is usually a real occurrence entity; the fine period is
      date-keyed events + timestamp comparisons; period sugar stays tripwired.
   **Ruling aid, recorded with the ratification** (Kimball's as-of-then test, for point 5):
   would anyone later need the value as it was then? Yes → new record or dated edge; no →
   correction on the same record.
   Authored-corpus work list (rides the sweep): Retreat `closed`, ServiceApplication `rejected`,
   GroupMembership `revoked`, hotel guest-side cancel, identity off `ContactForm.email @unique`
   onto a party entity, ContactForm consumption (a status marking the form consumed at Lead
   creation — added 2026-08-27, verification batch C2).
6. ✅ **Same-type addressing — RATIFIED (owner, 2026-08-24).** The merged `Type:label` spelling
   for the rare beat with two same-type bound names (`Collection:source` / `Collection:target`);
   clauses address by label; written-order positionals are dead. Never preposition semantics —
   the 2026-08-13 ruling stands. **Clause spelling ratified 2026-08-26 (verification decision
   3): the sentence token verbatim** — `where Item.home is Collection:source` · `sets Item.home
   to Collection:target`; paths hang off the labeled name (`Collection:target.status`);
   beat-scoped; no bare labels; label with no matching sentence token = `file:line` error.
7. ✅ **Fire identity — RATIFIED (owner, 2026-08-24; walk-map D9 a+b).** A run = one execution
   of one step, recorded in the log. Its entry stores: (a) per touched record, HOW it got there
   — picked, condition-found, or page-supplied — as a label on the run↔record link; (b) the
   model version the run executed under (replay uses the rules as they were); (c) the run's own
   id. The id is minted when the form renders, sent with the submission, and the server keeps
   one run per (step, id) — a refresh re-send is recognized and ignored (the wild corpus's
   double-publish demand). Build-queue work only; no grammar. (The old "IR homes" list is
   absorbed: the `sets` fact and `about` declaration are ordinary model text now; the non-party
   mark is dead.)

## Ratified — vocabulary: bound / unbound (owner, 2026-08-19)

A name in a beat is **bound** — its instance arrives with the fire (who fired, what they clicked) —
or **unbound** — its instance is found by the beat's one query. These are Datalog's own adornment
words (bound/free). Superseded spellings: *selected/resolved* (the first ratification pass) and the
survey's *cast/free name* — the dated survey doc keeps its original wording with a note; everything
live uses bound/unbound.

## Ratified — 1 · the instance-source trichotomy (owner, 2026-08-19)

Every entity position in a beat gets its instance in exactly one of three ways; the runtime never
mixes them.

- **Bound** — named in the sentence → the instance is a **fire input** (the clicked row, the
  firing actor). Atoms on a bound record are **guards**: they check, they never find.
  `Admin confirms RetreatBooking for Student` — the booking is the clicked row; `Student` is read
  off it; `Admin` matches no ref → any admin.
- **Unbound** — not named in the sentence, touched by clauses → the beat's one query finds it;
  **exactly one satisfying assignment or refuse. No exception: a human-fired unbound name
  never tolerates two matches** (owner ruling in the walk-through) — a silent pick anywhere would
  be hidden state one layer down. Every plural case routes to another source (table below).
- **Enumerated** — beats whose subject is `type system`: no person fires,
  so no fire input exists; the gate's satisfying set **is** the work list — **one fire per
  member**, each through the guarded commit and the intent lifecycle (exactly-once keys, refusal
  leaves the intent open). Not inherently global: it enumerates whatever the atoms admit — narrow
  with more atoms, or with the case (decision 3). Refuse-on-plural is a rule for human resolution
  only. (`every` is admitted — owner, 2026-08-24 — as a plain closed determiner for human-fired
  bulk: one per beat, before a singular noun, snapshot at firing, one run per member. A person
  fires it, so it is not in this no-person-fires bucket.)

**The plural-routing table** (owner: capture verbatim — where "two matches" cases go):

| Situation | Route | Example |
|---|---|---|
| Plural because a filter is missing | stay unbound; author current-ness (decision queue 5) | `Editor unpublishes Version` — many versions; `Version.status is "current"` makes it one (culrepo g27) |
| Plural because the sentence hides a party | refusal forces the honest sentence | `Parent signs ConsentForm` refuses over two campers → `… for Camper`; with Camper bound, the form is unique (camperplus g12) |
| Plural by design — a real choice exists | the record belongs in the sentence: **bound**; picking is the UI's job | `Curator publishes Dataset` — the cataloging cluster; selection, never resolution |
| All matches should be acted on | **enumerated** (system) or `every` (human-fired bulk) | expiries (g10), embargo lifts (g16), bulk approves (g21), one alert per routed Lead |

**Clarifications recorded with the ratification:**

- The firing actor is never implicitly bound — it is a fire input like the clicked object.
  Nothing is implied anywhere: the atoms tying an *unbound* record to the fire's bound names
  (queue item 2) are real written clause lines, door-proposed and author-confirmed; the beat
  inspector shows the written atoms in force and the refusal names the candidates. No generated
  comments — the atoms are the visibility.
- The refusal doubles as a sentence lint (the ConsentForm case): refusing is how the language
  tells the author a party is missing from the sentence.

## Ratified — 2 · clauses are one conjunctive query (owner, 2026-08-19)

A beat's clause lines evaluate as **one query**, never a series of checks: given the bound names,
find values for the unbound names that make **every line true at once**. Unbound names are solved
**jointly** — a line may relate one unbound name to another (`Round.game is Seat.game`), which is
what makes chains work (planning poker: seat and open round found together). Exactly one satisfying
answer for a human fire, else refuse; a `type system` beat fires once per answer (decision 1).
Ref paths (`Seat.game`, `DataPackage.publisher`) are terms inside atoms — tier-1 forward reads,
never a traversal strategy. `sets` was the only new word as of this 2026-08-19 ratification; the
later D5 consolidation (queue item 3) added `adds X to Y.field` (many-link write) and the
`where X is in Y.field` membership guard. Guards the wild corpus asked for are existing shapes
(`no … where`, `at least N … where`).
Semantics are Datalog's — satisfaction, not traversal; bound/unbound are the adornment words — and
the substrate executes it natively (DataScript joins; O'Doyle's Rete maintains each conjunction's
satisfying set). One deliberate restriction: a beat's conjunction is non-recursive (recursion stays
in the rules layer under stratification; closure parked). Evidence and worked examples:
[the corpus pass](binding-scope-corpus-pass.md) §2.

## Dependencies and riders

- **Two pins from the roles/extension prior-art audit**
  ([roles-extension-prior-art (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/research/roles-extension-prior-art.md), 2026-08-22):
  (a) two names in one beat MAY bind the same instance unless an authored atom forbids it
  (payer = payee must not silently refuse); (b) for the ambiguity UX (queue item 4), per-gate
  authored refusal text is the proven shape (Foundry submission criteria; the SBVR stall shows
  bare refusals rebuild the authoring wall).

- **`every`** is ADMITTED (owner, 2026-08-24) as a plain closed determiner for human-fired bulk:
  one per beat, before a singular noun, snapshot at firing, one run per member, no quantity
  knobs. System steps stay bare — they ride the enumerated arm (decision 1).
- **Corpus sweep on ratification** (carried from the tier-2 draft): every transition beat grows
  its `sets` clause; seeds re-version; the binding pass also fixes the name-joins the survey
  found (coffee `Order.name`, hotel `Reservation.name` → real refs; hotel `Reservation.room`
  missing; sangha `Appointment.teacher` missing).
- **Studio riders** ([story-authoring backlog](../story-authoring/backlog.md)): the door/clause
  assist that materializes link atoms as real written clause text (proposed, author-confirmed) at
  implied-binding sites. No generated-comment annotation — per ratified item 2, the atoms are the
  visibility.
- **Runtime residue** once ratified: the conjunctive-query resolver (tier-1 cross-participant
  binding generalized to unbound names), sets-exclusion, refusal surfaces →
  [rule-runtime](../rule-runtime/spec.md).
