> Portable snapshot of maintained Onto material. [Package capabilities](../../../START_HERE.md) define the shipped boundary; dated decisions and host implementation notes are context. [Source manifest](../../../SOURCE_MANIFEST.json) records provenance. Links marked “Onto source” are optional host/background references.

> **Layer: AUTHORING-TIME** — the editor for rules + Formulas; emits the rule AST the runtime consumes.

# Rule DSL — backlog (the live editor, to build)

**Status:** the **grammar is built** (parsers + totality + resolution + seed migration → [spec.md](spec.md)); what remains here is the **live editor**.

**Build order (owner, 2026-07-02) — the full DSL before the fast engine:** (1) ✅ Formula **runtime** completion in [rule-runtime](../rule-runtime/spec.md); (2) ✅ **the surface grammar** (one parser, same ASTs) + the authored-rule-shape fix + totality enforcement — all landed, see [spec.md](spec.md); (3) **▶ the live editor**; (4) time-flow (`now` + clock + standing violations) in [rule-runtime](../rule-runtime/backlog.md). The Clojure fast engine is parked until scale demands it.

This is the one-place design for the three DSLs (Stories, Rules, Formulas). The Rule + Formula grammars below are **built** (kept here as the design reference the editor implements); the Story-grammar evolution and the editor remain.

## The shape — three DSLs, one shared core
- **story** — an *event*: `Actor verb Object` (acts on facts)
- **rule** — a *condition*: `Field is …` (checks facts → true/false)
- **formula** — a *computation*: `Field = expression` (produces a value)

**Guiding principle — resolve, don't infer.** A token's meaning comes from looking it up against the declared model, never from guessing at spelling/position. Impose a convention only where resolution can't recover meaning.

## Shared core (the reference layer, identical in all three)
| form | means | resolved by |
|---|---|---|
| `CamelCase` | entity | declared entity set (declared names are CamelCase too — one spelling everywhere, see [spec.md](spec.md)); new one needs explicit confirm |
| `Entity.field` | a field | the entity's declared fields |
| `'quoted'` | a value | the field's **type** (enum→forced pick+propose-new · ref→instance · string→free) |
| `42` · `true`/`false` | int · bool | — |

- `money`/`percent` are scaled-integer types, always shown `$`/`%`; `float` may not be a rule operand.
- **Value rendering:** constrained values render as an **editable pill** (autocomplete the set, propose-new with confirm, click-to-edit, no second mode); free values are plain text. The field's *type* — not the quote/casing — decides.

## Story grammar
```
Beat       := Actor verb Object [preposition Secondary]
value-set  := Actor verb Field to 'Value'        # User sets Task.priority to 'High'
capture    := Actor verb Field                    # value supplied at runtime
```
- Lowercase verb; phrasal verbs matched greedily. Status is **derived from the transition verb** (`serves`→`served`), shown/overridable, never hand-set (a lint nudges `sets Order.status` → use a verb). Dots are the one way to set a field (the old property-noun inference is dropped).
- **Determiners carry multiplicity** (`a`/`the`/`each`/`every`/`all`) — recognised, not stripped.

## Rule grammar (predicate, flat DNF)
```
Atom        := [not] Predicate | ( Disjunction )
Predicate   := state | comparison | identity | cardinality | existence
state       := Field is [not] Value
comparison  := Field ( is more than | is less than | is at least | is at most ) ( number | Field )
identity    := Entity is [not] Entity | Field is [not] Field        # ref forms
cardinality := Quantifier Entity [where Condition]                   # at least 3 Review where status is 'submitted'
existence   := Entity exists                                         # sugar for `at least 1 Entity`
Quantifier  := all | no | exactly N | at least N | at most N | more than N | fewer than N
N           := a whole number, or a Field                            # a bound may be field-valued: `at most Room.capacity Guest`
```
- One relation vocabulary (all words, no symbols): `is` `is not` `is more than` `is less than` `is at least` `is at most`.
- Subject is implicit (the attached beat's entity); scope flows through refs — no `where`-correlation, no bound vars.

## Formula grammar (compute)

> **BUILT, both halves:** the IR + evaluator in [rule-runtime](../rule-runtime/spec.md), the surface grammar in `rule-dsl/formula-parse.ts` ([spec.md](spec.md)) — type-resolved, emitting that same IR, round-trip-pinned on the hotel seed. What follows is the design reference the live editor implements.

- **`=` means "computed as"** (formula-only; never overloads `is`). **Math = symbols** (`+ - * /`), **logic = words**; the two never mix in one statement. Multiply is `*`.
- **Two forms only:** **expression** (`LineItem.lineTotal = quantity * product.price`, ref-traversal allowed) · **aggregation** (`Order.subtotal = sum of LineItem.lineTotal`).
- Aggregators `sum|count|min|max|avg of <Entity>[.field] [where <condition>]`; empty → sum/count `0`, min/max/avg null.
- **Conditional value:** `Field = <v> if <cond>, … else <v>` (value-first, first-match, else mandatory).
- Date/duration math (`startDate + 30 days`, `days between a and b`); string concat via `+` (type-resolved). Derived fields are read-only (value + formula).

## Timing & decidability boundaries
- **Timing** adds two **value-level** primitives — no new predicate shape: **`duration`** (a whole number + unit: minutes · hours · days · weeks · months · years), a comparable value; and **`now`** (the runtime clock), referenceable in any predicate. So a deadline or delay is just a *comparison*, a recurrence is several rules, and a time-triggered beat is a rule whose precondition references `now`.
- **Two restrictions keep the fragment verifiable** (a rule violating either is rejected at authoring time): **linear arithmetic only** — you may add attribute values or multiply by a *constant*, but never multiply two variables (undecidable); **integer timeline** — `now`/`duration` are whole-number valued (a dense/rational timeline with negation is undecidable). A product of two variables (`quantity * price`) is still *computable* in a Formula, but its result is opaque to verification — the accepted math/verification trade-off.

## Semantics & guarantees (what makes it verifiable)
- Fact base · **stories = guarded transition system** · rules = invariants · formulas = computed facts.
- **Total / sub-Turing** ≈ stratified temporal Datalog + bounded aggregation + linear arithmetic. Constraints in **QF-LIA + EUF** → automatic SMT verification (consistency, invariants, counterexamples, dead-status). A per-lifecycle state machine is derivable ("weak TLA+").
- **Three totality restrictions (must be enforced):** acyclic formulas · stratified/non-recursive rules · bounded iteration. *Control flow is emergent* (branching from preconditions; iteration from determiners).
- **Effects via intent facts** (the pure core decides/derives but cannot act; an executor fulfills typed intents and writes results back as facts).

## Open questions & known limitations
- **Recursive roll-ups** (bill-of-materials, org-chart, tree totals) are excluded by the acyclic-Formulas restriction. Whether to allow bounded tree-recursion or push it to the runtime is **undecided** — the expressiveness hole to watch.
- **Subject-scoped counts — the expressiveness both suggestion models keep reaching for.** The A/B eval's recurring floor/parse failures are all one family: `at least 1 Room where roomClass is Reservation.roomClass` (a where-value read from the SUBJECT), `no Invoice where reservation is Reservation` (count scoped to the subject through a ref). The AST carries AttrRef where-values but the runtime resolves them against the counted member, and there is no member-to-subject ref filter for rule cardinality (Formula aggregation has `via`; rules don't). This rides the same scope-flows-through-refs design as the identity/binding gap — when it lands, the suggestion floor can relax and the models' best drafts (per-reservation invoice uniqueness, class-availability checks) become expressible.
- **Multi-ref scoping.** When the counted/aggregated entity reaches the subject by more than one reference, the editor **asks** which one to use: one ref → automatic; multiple → confirm; never guess. *Today the parser demands an explicit `via <refField>` in the text when several refs exist (the error names the candidates); the editor's ask-flow rides the live-editor build.* Same rule for rule cardinality and Formula aggregation.
- **Date/duration typing.** Duration literals are `<n> <unit>`; `date ± duration` = a date (built); `<unit> between <date> and <date>` = an integer count (`days between` built; other units when needed). **Unit algebra is still open**: `int × money = money`, `money × percent = money`; mixing incompatible units should be an error — today money/percent are numeric operands with no unit tracking.
- **Calculate-beats retire into Formulas.** An explicit "X calculates Y" beat becomes a derived field, and a lint nudges a leftover calculate-beat into a Formula — derive-don't-hardcode applied to math (the parallel of the status-verb carve-out).
- **Boolean modelling guideline (unenforced).** Use a bare `true`/`false` only for a genuine binary flag; model a lifecycle as a status enum, not a bool. Enum propose-new governance — who may extend an enum and what gates it — is deferred to the coaching loop; the grammar-level "explicit confirm" is already settled.
- **Non-linear completeness.** A product of two variables is opaque to verification, so a property that depends on the actual computed value is **computable but not verifiable** — the accepted math/verification trade-off.
- **Attached rules feed the classifier.** A postcondition asserting a state change is evidence of a "transition"; an authorization rule is evidence the actor slot is restricted — which is why rules and stories are co-authored, not sequenced.

## Build task
1. ✅ Rewrite `rule-dsl/parser.ts` to this grammar (CamelCase resolution / dotted / `'quoted'`-by-type / all-words relations). *(Story-grammar determiners ride with story-authoring.)*
2. ✅ Add the **Formula** DSL (expression, aggregation, conditional, dates, strings) — `rule-dsl/formula-parse.ts`.
3. ✅ **The live editor** (rule mode): highlight + autocomplete + value pills + inline errors, mounted in the studio's rule sections ([spec.md](spec.md)). **Still open:** the *formula*-mode mount (needs an authoring surface for computed fields — entity-authoring's field editor); propose-new actually extending the enum set (joins PR #33's enum-domain plumbing); the multi-ref ask flow (parser demands `via` in text today).
4. ✅ Enforce the **three restrictions** (formula cycle-check in `rule-dsl/totality.ts`; stratification at ruleset compile; iteration is grammatically impossible).
5. ✅ Migrate seeds (coffee/hotel/record-label rule text; `money`/`percent` scaled-int field types added to the schema — seed fields adopt them as touched).

## Decisions (why) — the trail
Dropped `:symbol` + symbolic operators (resolution recovers them); `=`/`!=` rejected as aliases; `*` not `x`/`×`; arithmetic confined to formulas (rules see EUF-opaque results).

## Dependencies
Pairs with [rule-runtime](../rule-runtime/backlog.md) — the new AST is what the firing engine consumes.

## ontolang riders (owner decisions, 2026-07-30 — from the lead-intake model)

**✅ The grammar/loader side of all three shipped with ontolang's parser catch-up (2026-08-03)**
— gate words, `@unique`, actor refs are parsed, printed, and golden-pinned →
[ontolang spec](../ontolang/spec.md). **✅ `@default`'s runtime side — the create-time write —
shipped 2026-08-04** (the loop's create fills every declared default, `now` = the clock at the
creation instant; capture forms stop demanding defaulted fields) →
[rule-runtime spec](../rule-runtime/spec.md). The runtime residue is now closed; the per-item
trail:

- **`@unique` field constraint — ✅ runtime enforcement shipped (2026-08-04).** The index check
  (`rule-runtime/unique.ts`) enforces the locked semantics (**unset never collides**, matching is
  **exact** — no case-folding/normalization) as **standing violations** — the ⧗ banner family,
  never a write refusal → [rule-runtime spec](../rule-runtime/spec.md). What remains is the
  authoring half — the field editor's unique toggle, in the
  [entity-authoring backlog (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/entity-authoring/backlog.md). Verifier-side it sits fine in the
  QF-LIA+EUF fragment.
- **`requires` / `forbids` / `ensures` / `always` — shipped as the one rule phrasing.** The beat
  (or bare entity) is the header; the gate's word carries timing+polarity. **The prompt creator
  (prompt-to-project) must emit this form** wherever it authors ontolang rule text. (`ensures`
  parses and persists as a must postcondition; nothing in the corpus uses one yet, and the
  runtime loop does not fire postconditions — the verb's produced status covers the corpus.)
- **A `ref` may target an actor — shipped.** `owner: AccountExecutive` is legal (one type
  catalog). First runtime test: the instance picker needs actor *instances* — which is the
  roles-permissions instance layer's territory.
