> Portable snapshot of maintained Onto material. [Package capabilities](../../../START_HERE.md) define the shipped boundary; dated decisions and host implementation notes are context. [Source manifest](../../../SOURCE_MANIFEST.json) records provenance. Links marked “Onto source” are optional host/background references.

> **Layer: AUTHORING-TIME** — the **canonical text representation** of the model. The studio does not run on files — it **loads** `.onto` in (import door, initial snapshots) and **prints** `.onto` out (export, compaction, the publish artifact); the truth of live authoring is the **op log** ([authoring-sync (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/authoring-sync/backlog.md), decisions 2026-07-28).

# ontolang — backlog (loader + printer built → [spec.md](spec.md); what's left)


## Repository extraction

The [independent package boundary](spec.md#independent-language-package--2026-10-13)
is built. Next: move the package with its history into a separate repository,
transfer the owning language specifications, corpus and editor tooling, and replace
Onto's workspace dependency with a deliberately tested package version. Publication,
release policy remain future work. Ship one package version for language and
execution. The portable executor is owned by the same package’s
[runtime entry](../rule-runtime/spec.md#independent-execution-package--2026-10-13). Onto keeps
AI proposal interpretation, template library/UI and production runtime hosts.
Generic template/walkthrough companions and composition are package-owned.

The [local policy implementation](spec.md#actor-policy--built-locally-2026-10-10)
has graduated to the spec. Remaining onboarding and provider integration work
is tracked in the [runtime backlog](../rule-runtime/backlog.md).

## Vocabulary imports — remaining scope

The first pass is [built](spec.md#scoped-vocabulary-imports--2026-10-10): local
source imports, qualified names, exact source snapshots, read-only contracts,
transitive resolution and offline portable reopening through authoring replay and
publication. [Worked examples](../../../examples/vocabulary/README.md) connect
business offers to Warehouse stock through explicit relationships.

The earlier package-manifest / `bind` / `as` proposal is superseded. Native
imports preserve utility definitions; independently shaped concepts stay distinct.
External translation belongs at the system edge and is not implied by an import.

Deferred until a concrete use requires them:

- Registry distribution, package identifiers, version ranges and simultaneous
  revisions of one local source. Current identity is a normalized local directory
  plus pinned source digest, scoped to a project.
- An upgrade preview and migration workflow for existing projects and records.
  `--update-imports` selects sources for a newly bundled model only.
- A Studio dependency inspector and explicit local fork operation. Current
  authoring helpers reject edits to imported contracts; source editing happens in
  the utility, with a deliberate new revision, or in a separate local definition.
- Separately selected workflow installation and utility capability contracts.
  Vocabulary imports currently reject Story, project and seed blocks.
- Edge adapters with explicit identity, validation and create/update behavior.
  No generic `map`, bidirectional synchronization or type equivalence is planned
  for the first pass.

## Actor access and enrollment — ratified 2026-09-10

**Owner ruling; local implementation built 2026-10-10:** explicit `@affiliation internal | external`, `@access authenticated | public | none`, and actor-scoped **`@signup self | invite | none`**. `self` permits self-service or invitation enrollment; `invite` requires an invitation for enrollment; `none` permits neither. All three allow authorized direct grants to existing people. Signup means joining as a role and reuses an existing account; it does not specify who may invite or grant.

Standard accounts, login, invitations and administrative role flows belong to the platform. Domain stories express actual domain decisions and may reuse `grants`/`revokes`; derived subsets keep `@where`. This supersedes the bare `@signup` / boolean `@canSignup` proposals and older guidance that a role becomes open because no seed or grant story exists. External affiliation must no longer bypass identity or role eligibility.

The [implementation contract](actor-boundary-plan.md) records omission/applicability,
owner management authority, preserved Sangha inheritance and system ownership.
[Grammar](grammar.md#actor-policy-extension--built-locally) and
[modeling guidance](modeling.md#actors) now describe supported syntax. Remaining
participant UI, provider bindings and broader management configuration are runtime
deployment work.

## Existing implementation and remaining work

**2026-10-10 supersession:** [standalone models](spec.md#standalone-models-and-workflow-readiness--2026-10-10)
are now legal by default. Earlier actor-must-act restrictions and blanket
load-time workflow-completeness requirements below describe superseded behavior.
The current spec separates declaration validity from managed-workflow readiness;
object parents are concrete regardless of Story usage. The earlier parent
abstractness inference is also retired.

**Status:** **steps 1–4 shipped** — `parseProject(dir)`, both goldens strict-deep-equal **with `story/transition-to` edges included** (hotel + coffee), the printer with its round-trip pins, and the **parser catch-up (2026-08-03)**: gate headers, the `@` field attributes (`@required`/`@unique`/`@default(value)`), actor refs, roles as actor `is a`, produced-status derivation + `produces` (retired 2026-08-24 by D7 — statuses come from written `sets` clauses; see the D7 entry below) (`given`, briefly a second world-setup spelling, retired 2026-08-04 — seed-only) — the lead-intake corpus loads through the studio door → [spec.md](spec.md). **Grammar reference: [grammar.md](grammar.md).** Worked examples: [`examples/ontolang/`](../../../examples/ontolang/) (the coffee directory renamed `coffee-shop` → `coffee`: the directory basename IS the project id). The plan:
1. ✅ **`parseProject(dir)`** — built as planned (container owns blocks + indentation; fragments delegate to `parseDSL`/`parseRule`/`parseFormula`; two-pass whole-model resolution + totality; errors carry file:line) → [spec.md](spec.md). *One logged change from the pre-build phrasing:* the container is line/indent-based, not "on the shared lexer" — it never tokenizes; only the delegated fragments do.
2. ✅ **The goldens** — hotel and coffee strict-deep-equal their seeds (minus `seedVersion`); `HOTEL_SEED.rules` reordered to story order (seedVersion 18 on staging, atop the CamelCase sweep's 17) since rules are a flat unordered set and transcription order is canonical. The `.onto` corpus is now the maintained transcription of the example seeds; **retiring the hand-built seed code into an expected-output fixture is still open** (parseDSL and the supersedes rule move into `ontolang/` with it).
3. ✅ **Printer** — canonical file map, `parse(print(m)) = m` + idempotence pinned; unprintable models **fail loud, never silently** (names that can't lex as one token — `Q&A`, spaced names; strings with embedded quotes — the grammar has no escapes). ✅ **The money marker** shipped with the staging merge (2026-07-30): `money` is first-class in the schema, the loader emits it, and the printer writes decimals (450 → `4.50`) — see [spec](spec.md). **Open riders:** (a) ✅ CLOSED 2026-08-30 (owner: "we should keep it — no dropping") — story title + description now live in the model (`storyBlocks` + per-beat `story/block`) and print back; the story-as-entity work keeps its own track. (b) ✅ the **preposition closed class** landed (2026-08-13): all single-word English prepositions accepted, stored-not-interpreted, with the loader's no-filler + second-preposition guards (at most two participants per beat — owner ruling 2026-08-14, see grammar.md §2) — see [grammar.md](grammar.md) §2 and [spec.md](spec.md). Actor `is a` emits the role-catalog entry (the role spelling — ratified 2026-08-03, see item 4); role-block **fields** load (the 2026-08-26 narrowing) and since 2026-08-30 reach the catalog entry as the assignment edge's schema — the [assignment slice](../roles-permissions/spec.md) now carries them per holding.
4. ✅ **The parser catch-up (2026-08-03)** — everything decided since the port, exit-tested: `examples/ontolang/lead-intake/lead-intake-and-routing.onto` loads through the studio paste door with no errors. Shipped: the `requires`/`forbids`/`ensures`/`always` gate headers (bare `rule` is a pointed replaced-keyword error) · the `@` field attributes (`@required`/`@unique`/`@default(value)` — see the attribute decision below; the interim comma/parenthetical spellings were flipped by owner call before merge) · refs targeting actors · roles as actor `is a` (see the resolution below) · **`produces "value"` + automatic edge derivation at load** (the decision below, implemented via the shared classifier — see spec) · both goldens un-stripped (`HOTEL_SEED` gained the `Guest pays Invoice → paid` edge the derivation pins, seedVersion 20). *Logged deltas from the pre-build phrasing:* the lead-intake file was **normalized into the canonical grammar** (its 2026-07-30 draft spellings — `about`, `(person, outside)`, `one of`, colon-less fields, a separate `rules` section — were one-off dialect, not decisions; the beat/entity header IS the story beat / entity block, attachment stays indentation) · a role-base actor (`Employee`) is exempt from the actor-must-act rule — the rigid kind under the hats exists as substrate · `given` shipped as a one-line input form normalizing into `instances` — **and was retired the next day (owner, 2026-08-04): seed-only**, the `role … over` rationale (one concept, one spelling; the printer had only ever emitted `seed`); it is now a pointed retired-keyword error. **RESOLVED (owner, 2026-08-03): `role … over` is retired — the role spelling is actor `is a`** (`actor SalesRep is an Employee`; one concept, one spelling — the standalone line had duplicated the already-designed form and bypassed its deliberate loader block). The line is now a pointed retired-keyword error; the base must be a **declared** actor (the bare-string tolerance died with the line — matching roles-permissions' "role/base must name an existing entity" direction); the must-act exemption and the `roles:` emit are unchanged; role-block capability fields ride the catalog entry onto the assignment edge (built 2026-08-30 — [roles-permissions](../roles-permissions/spec.md)); the printer writes roles on the actor header.
5. ✅ **Joins tier 1 — the runtime landed (2026-08-03).** Ref-hop paths evaluate to **any depth** in rule predicates (state/comparison sides, where-filters, field-valued bounds) — forward-only, catalog-resolved, label→instance, fail-closed on any break — and the **cross-participant comparison** (`Lead.region is Territory.region`) binds the beat's secondary participant per fire (implicitly from the write's own ref, or explicit `Assertion.bindings`). The grammar already accepted both spellings; nothing new to parse. Forced and pinned by the lead-intake corpus routing gates → [rule-runtime spec](../rule-runtime/spec.md), `examples/lead-intake-routing.test.ts`. **Tier 2 — instance binding & story scope** — decisions RATIFIED 2026-08-24 (walk closed: story `about` context, explicit `sets`/`adds`/`where … is in` clauses); `every` admitted as the sole determiner (see the walk rulings below); build queued on the owner's ask. Decision trail: [binding-backlog.md](binding-backlog.md), [joins-tier-2.md](joins-tier-2.md), evidence in [binding-scope-corpus-pass.md](binding-scope-corpus-pass.md); tier 3 stays parked.
6. Later, riding [authoring-sync (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/authoring-sync/backlog.md): compaction prints ontolang at the op-log head, and the **publish contract** is an ontolang artifact + content hash. *(The earlier "studio write-through — every gesture edits files, store becomes derived" idea is **superseded** by the 2026-07-28 decisions: the studio edits through **ops**; it outputs ontolang, it doesn't run on it.)*

**Why the text representation matters** (unchanged by the op-log decision): agents author through the same parser gate as humans; git diffs/PRs make a model reviewable; packages and the publish contract need a distribution artifact; the printer makes drift impossible for anything loaded or published (`parse(print(m)) = m`). What changed on 2026-07-28: live authoring truth is the **op log**, with `.onto` as the canonical representation at its edges — files load in as initial snapshots/merges, and print out on compaction/publish ([authoring-sync (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/authoring-sync/backlog.md)).

## ▶ The sentence-grammar consolidation (2026-08-14)

The hardening push merged as one stack (2026-08-14): **declarations decide kind** (beat position never reclassifies a declared entity), **whole-input kind inference** (line order never decides a name's kind), and the **preposition closed class with loud beat-word errors** (plus the decompose route on the shared set) — all in [spec.md](spec.md) and [grammar.md](grammar.md) §2 now. The **normative sentence grammar** — every ratified rule in one write-up — lives in [story-authoring's spec](../story-authoring/spec.md) (that feature owns the sentence; the loader implements it strictly). Canvas-side work rides [story-authoring's backlog](../story-authoring/backlog.md); generator-side naming discipline rides the [importer backlog (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/importer/backlog.md). What's still open from the push:

**✅ The participants build — SHIPPED 2026-08-14** (the design ratified the same day): at most two participants per beat (the third is a `file:line` error: move the detail into a field, or split the beat) · **every** participant sentence stores the ordered `{preposition, name}` pairs — the preposition is data, never only text (owner ruling; ten seeds re-versioned) · the preposition is stored raw, never interpreted — rules/formulas derive meaning downstream · `recipient` stays the derived convenience · the printer gives participants back word-for-word (pinned). Kills both participant bugs: the glued fake name (`from Shelf to Truck` → "Shelf Truck") and the untraced object participant. **Residue:** canvas-authored stories carry no pairs until the parser port ([story-authoring backlog](../story-authoring/backlog.md)); stored stories back-fill in the cleanup pass (below).

**✅ When a participant belongs in the sentence — RULED 2026-09-01 (owner).** A sentence name is a runtime input (a door picker) and the only handle clauses can target — so name a participant only when the beat needs it from outside: it fills a ref on the record the beat creates, a `finds` runs on it, a `sets`/`adds` consumes it, or a `grants`/`revokes` targets it (the sentence-named-receiver rule). A participant whose only clause is a `where` pin to the object's stored ref fails the test: the door asks a question with one legal answer, and the pin re-derives what the record already stores (`Teacher approves GroupMembership from Student` + `where GroupMembership.applicant is Student` does the same work as `Teacher approves GroupMembership`). Actor-pinning `where` lines (`where Appointment.teacher is AssistantTeacher`) are permission gates, untouched. Grew out of the sangha walk-through: creation fills its refs silently from sentence names while reading them back demands a written pin, and the decorated shape re-derives stored links line by line. Encoded as [modeling.md](modeling.md) rule 24 + the generator prompts (prompt-to-project TELL/CRITIQUE, importer passes 1 and 3), the coach prompt, and the authoring skill. **✅ The corpus sweep ran (2026-09-02, owner call):** the seven beats (approve GroupMembership · confirm RetreatBooking · confirm/starts/completes Appointment · both reject beats) dropped their determined participants and the `where` pins that re-derived them; the two Appointment actor-pins (`where Appointment.teacher is AssistantTeacher`) stay as permission gates; round-trip + line-stable re-verified, test pins retargeted to beats that keep their clauses. The studio's composer nudge (rule 24's deterministic lint, both directions) is queued → [coaching backlog (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/coaching/backlog.md).

**✅ Colon labels — SHIPPED 2026-08-14**: `Manager:Assigner` registers ONE `Manager`; the labels are **data** (owner ruling: "we will need it") — `story/subject-label`, the pair's `label`, `story/primary-object-label` — and the sentence text keeps the written form.

**Remaining bugs (in the order found):**
- ✅ **The beat-effect statement — RESOLVED by the walk (2026-08-24; kept as the design trail).** The effect statement is the `sets … to` / `adds … to` clause family (D7 + D12: every transition carries its written line; `=` rejected — Formula collision; `ensures` retired; collection writes are `adds`). Original text: **design opened (2026-08-14), its own session.** Grew out of the field-minting removal: with "a story never names a data operation" ratified, the question became how a beat's write IS stated. **Settled (owner):** the beat narrates; a write is stated explicitly under the beat — never derived from word-shape or participant position. The actuals force this: the written side varies per sentence (`Territory.owner = AccountExecutive` writes the object side; a Cart gaining a Product writes the participant side — `Cart = [Product:Pizza]`, a collection; `Cookie.XYZToken = Token` names a field only domain knowledge supplies). **The rule extends: a story never narrates DERIVED state either** — `System moves Task to CompletedList` is a formula in story clothing (the list populates itself from `Task.status`); todo's two System beats fall to this and re-author with the design. This direction **overturns the 2026-08-03 automatic status derivation** once designed: `produces` retires into the general effect statement, the conjugation machinery demotes to a studio suggestion, and the loader only validates. **Open for the design session:** the statement's spelling (`Thing.field = value` under the beat — `=` is unclaimed there) · collection writes (forces declared many-valued fields — the parked cardinality item's forcing case) · instance references vs relation edges with metadata (`Pallet.location` — owner thinking) · effect vs `ensures` (write vs check, no inference between them) · the sweep scope when it lands.
- **Remove the field-minting machinery — RULED (owner, 2026-08-14): bad machinery, should never have existed.** Today a spaced capitalized phrase after the verb (`sets Task Priority`) is read as a property name: a field is invented on the first word's type and the phrase is deleted from the sentence, leaving the beat with no object. Ruled with it: **a story never names a data operation** (the normative grammar in [story-authoring's spec](../story-authoring/spec.md) carries the rule and the three homes — form, rule, formula). Scope of the removal: the property arm on the beat-parse path and its re-attach pass (`resolvePropertyField`; the `derivedFields` bucket dies with its only source — taking the todo printer failure with it) · a pointed loader error for a property path in a story's object slot, naming the three homes · the canvas coach suggests the act rewording (`sets Task Priority` → an act like `triages Task`) · re-author the three seeds that lean on the harvest (todo, login; git's `Code` is a mis-read — declare it an object) · import passes keep harvesting **fields** from prose but re-author the sentence as an act (rides the shared grammar constant, [importer backlog (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/importer/backlog.md)).
- **✅ Hyphenated verbs conjugate wrong — SHIPPED 2026-08-22** (PR #103): the head word conjugates and the particle rides along — "kicked-off", never "kicks-offed". Scope note: the load-time `verbToStatus` path this fixes is slated for retirement (the beat-effect design demotes the conjugator to a studio typing assist); the fix remains valid today and retargets to the assist when that lands.
- **✅ The investment-bank corpus doesn't load — RESOLVED 2026-08-16** by the actor-as-direct-object ruling (shipped in #107): the corpus loads whole (84 beats, 10 actors, 8 roles) and is the ruling's exit test.
- **The seed sweep (re-measured 2026-08-30, kept as a standing test in `print-project.test.ts`): 9 of 13 seeds round-trip print → parse EXACTLY**; music and todo were made lawful in the sweep (music's "calculates the value of their Assets" re-authored to `values Assets`; todo's Task lifecycle made whole — born open, completes writes done; both re-versioned), the printer now refuses beat text the loader must reject (the music lesson), and story blocks + canonical colors are pinned across the parseDSL seeds. **11 of 13 round-trip after the owner's 2026-08-30 rulings** (no special characters in names — `A&R Scout` → `ARScout`, plus `LabelHead`/`StreamingPlatform`; cinema's one quoted-label description reworded — string escapes stay on their tripwire: the first client string that must carry embedded double quotes). Record-label's walls all fell in one pass, each to a standing ruling: the pre-collapse role-over-Person entry dropped (a bare actor IS the role), StreamingPlatform reclassified a system actor (it acts — the unmanned-actors ruling's own example), `royaltyRate` int (no float surface), the lifecycle made lawful (births + written transitions + `@final` + the missing accepts beat), catalog canonicalized. **2 stay unprintable, each pinned with its honest reason:** jellyfin (names compounded; the wall is the import-era beat TEXTS — 150 of 239 violate the word discipline, the stored-story cleanup class — owner: leave it) · investment-bank (the ADR-006 interface slice — multi-target `is a` is deliberately CUT (D13c), still load-bearing for the type-level specialization tests).

**Decisions needed (each carries the standing recommendation):**
- **✅ May a declared actor be a beat's direct object? — RULED 2026-08-16 (owner), shipped in #107.** Allowed: real domains act ON actors (the bank researches the Business; the Business selects the Buyer). Declarations still decide kind — nothing re-registers, "an object cannot act" stays fatal, and the catalog stays declared in both directions. The normative statement lives in [spec.md](spec.md); exit test = the investment-bank corpus.
- ✅ **Prepositional verbs — RULED 2026-08-24 (owner, D14d item 1): NOT admitted.** The hyphenation recommendation was REJECTED in favor of forcing the simpler sentence — the thing acted on becomes the object (`Guest pays Invoice`); hyphens only for true phrasal verbs. Full text in the D14d block below.
- ✅ **Bare numbers vs digits in names — RULED 2026-08-24 (owner, D14d item 2), as recommended:** digits inside names legal; a freestanding number as a sentence word is a pointed error naming the value homes. Full text in the D14d block below.
- ✅ **Plurals — RULED 2026-08-24 (owner, D14d item 3):** a noun is always its declared form; plurality is a determiner word (`every`), never the noun's form; the same-stem lint stands. Full text in the D14d block below.
- ✅ **Determiners — RULED 2026-08-24 (owner, the `every` admission below):** `every` is the language's ONLY determiner (full parse spec in the admission block); `a`/`an`/`the`/`all` stay non-words; `each` rejected as a synonym. The old binding-semantics draft for `a`/`another`/`the` is dead.
- ✅ **The star marker — RULED 2026-08-24 (owner, D14d item 4): removed** (rides the corpus sweep); `@every` rejected the same exchange. Full text in the D14d block below.
- ✅ **Defined subsets — CONFIRMED 2026-08-24 (owner, D14d item 5):** the form stands exactly as taught; the saved-model home is queued build work; the card-vs-loader contradiction resolves in the form's favor.

**Resolved in discussion (owner, 2026-08-14):**
- **Property paths (`Task.priority`)** are the ratified property spelling in ontolang — in rules and formulas, where they already work. A story never speaks a property (the rule above); a property path in a story's object slot gets the pointed three-homes error when the machinery removal lands.
- **Word-for-word participant printing** — yes; pinned in the merged tests.

**Gaps (no decision needed, just work):**
- **The stored-story cleanup pass.** One store migration (`runtime/migrations.ts` seam): re-derive each stored story's fields from its own text through the shared parser — pair lists and labels back-filled, old shapes dropped. Covers pre-sweep projects and canvas-authored stories.
- **A corpus-wide declarations check — build early.** No test asserts every corpus beat's parsed slots against the file's own declarations (a check that does not compare the parser to itself). It measures everything else in this section.
- **The wild harness** (`examples/wild-test.ts`) is not in `pnpm test`, and its default dir points at the dissolved `build-docs/` path (the data lives at `examples/wild-corpus/dalpiaz`).
- **String escapes** — the grammar has none; blocks the cinema seed from printing (see the printer bugs above).
- **Loader gaps vs the ratified grammar:** (objectless beats CLOSED 2026-09-02 — loader error both doors); bare `I` fails only as an undeclared name, never a pointed error (the composer door emits the pointed error since the parser port v1 — the loader still doesn't); `and`/`or` now gets the pointed split message in both doors (2026-09-03).
- **Composer feeder divergences (parser port v1, 2026-09-02 — recorded non-goals; both close with the clause slice, [story-authoring backlog](../story-authoring/backlog.md)):** (a) **no birth `sets`** — the file door's birth fill persists `story/sets` on every creating beat, but the composer path has no sets-op vocabulary yet, so a beat confirmed in the studio lacks the written birth line the same sentence would carry from a file; (b) **kind override doesn't re-slot** — a confirm-time actor/object override on a new name adjusts only the confirmed actor/object sets, while the persisted slots (recipient, participant pairs) keep the name where the parse put it, diverging from the loader's re-slot for the same sentence once the name is declared (next-slice fix: re-run the fragment parse with the override injected into the catalog). The wrap (printed context + synthetic files + a `parseProjectFiles` mode flag) is the clause slice's opening move — v1 shipped as thin composition because the per-beat clause loops run empty for a bare sentence.
- `parseDSL` still lives in `examples/seed-projects.ts` — the move into `ontolang/` rides seed retirement (plan item 2 above).

## The card (the whole grammar)

> **Note:** the actor examples below predate **Roles over kinds** (end of this file, 2026-08-18) — the `type` word (spelling ratified 2026-08-19), the bare-actor collapse, and `grants`/`revokes` revise actor declarations; the card updates when the set lands. The card also predates the 2026-08-24 walk ratifications — `@final` marks (D6a), the `produces` suffix retired (D7), `ensures` retired from beat lines (D12a), lowercase status values (D12g), `Type[]` link declarations — and is swept with the released corpus sweep when building starts.
```
project CoffeeShop
  description "Coffee shop ordering flow"

actor Customer
  description "A patron who orders and collects products."
  name: string
  loyaltyTier: none | member | gold

actor Business
  boundary external                    # only when the derived inside/outside heuristic is wrong

actor Employee is a Person             # actor `is a` = role: a Person + an edge;
  hireDate: timestamp                  #   the block's fields live on the edge
  seniority: analyst | associate | vp | director | md

actor Analyst = Employee where seniority is "analyst"   # defined subset — derived, read-only, no fields
object OverdueInvoice = Invoice where status is "issued" and dueDate is less than now

object Product
  name: string
  price: money

object Drink is a Product              # object `is a` = subtype: one record, forever
  size: Small | Medium | Large @required
  milk: Whole | Oat | Almond | None @required

object Reservation
  checkIn: timestamp
  checkOut: timestamp
  bookedOn: timestamp @default(now)          # written at creation (the creation instant)
  confirmationCode: string @unique           # no two instances share a set value
  serviceCharges: int = sum of Service.charge where status is "fulfilled"   # computed (Formula)
  always Reservation.checkOut is more than Reservation.checkIn              # in a type block = invariant

story CoffeeOrder
  description "Order to pickup"
  Customer places Order
  Barista prepares Order
    requires Order.status is "ordered" # under a beat: requires/forbids = must/must-not (ensures retired 2026-08-24, D12a)
  Broker binds Policy
    sets Policy.status to "in-force"   # produced status is a written sets clause (produces retired 2026-08-24, D7)
  Customer collects Order
    Customer pays Barista              # sub-beats indent under their beat = substory

seed Drink
  name: "Latte", price: 4.50           # decimal sugar: parses to 450; store/eval stay integer

# comment
```

**Five principles:** keyword-first blocks · colon means field · `@` means field attribute (`@required` · `@unique` · `@default(value)`) · CamelCase means entity (compounded, everywhere; `is an` accepted; story sentences use the same compounds) · indentation means attachment.

**One language, three embedded grammars.** ontolang is the container; the text inside `rule` lines is the **Rule grammar**, after `=` the **Formula grammar** (both normatively defined in [rule-dsl](../rule-dsl/spec.md) — built, tested, round-trip-pinned), and beat lines are the **Story sentence grammar** (owned by [story-authoring](../story-authoring/spec.md)'s classifier). This doc owns only the container; no grammar is duplicated here.

## Decision log (2026-07-19)

**Added, each backed by a seed that can't be written without it:**
- `project` name + description · `seed` blocks (world-setup; runtime facts never in files) · `boundary external` (IB Business, cinema Moviegoer — exception-only; derived otherwise) · `is a` (coffee subtypes; role entries in IB/record-label) · `=` defined subsets (IB seniority actors; object side kept for symmetry by owner call) · `, required` (coffee — sugar for the field-set rule, kept as standard vocabulary) · field `description` lines.
- **Roles:** actor `is a Kind` stores as base instance + edge (“assignment”, renaming the dead `hold/*` schema); the role block's fields live on the edge; one Person, many roles; membership of `=` subsets re-derives live. Phases eliminated: an ordered enum on the role edge + defined actors (`actor Analyst = Employee where seniority is "analyst"`) replace the `role/kind|partition|order` schema; promotion is an ordinary field transition. Roles are domain-scoped (two domains' Buyers are two roles); **no Party kind** (gist verified: no Party class — unions inline when a single domain ever mixes bases).
- **Money:** integer core everywhere (QF-LIA verifiability + minor-units correctness). **Decimal sugar:** literals legal only where the typed context declares a scale (`price: 4.50` → 450; `is more than 10.00` → 1000; `* 8.25%` → ×825/10000, constants stay linear); exact-or-error (never silent rounding); printer emits decimals. Rounding policy for division/`avg` results: deliberately open, decided once when the first real percentage/division formula lands (closed 2026-08-24, D14c: rounding word required at each division site, no global default; money splits largest-remainder). `percent` as a field type: cut (zero users); returns as the `%` operation literal.

**Deliberately cut — do not re-add without new evidence (each was a type-level restatement of what the story/structure already says):**
- `requires` + any pre/post keywords — one `rule` keyword; position = attachment (beat gate vs type invariant); timing/polarity never authored (matches the 2026-07-06 flat-rules-list decision); postconditions are the verb's job (`verbToStatus`); corpus has 0 postconditions. *[superseded 2026-07-30: the gate words `requires`/`forbids`/`always` are the spelling and bare `rule` is the pointed replaced-keyword error (plan item 4, grammar.md §1); and 2026-08-24 D7: load-time verb conjugation (`verbToStatus`) retired — postconditions are written `sets` clauses.]*
- `expands into` + substory names — substories nest by indentation (indentation = attachment).
- `abstract` — no language keyword. Parents remain concrete regardless of Stories;
  absence of a creating Story only means there is no Story creation action. The
  [current spec](spec.md#standalone-models-and-workflow-readiness--2026-10-10) also
  records how legacy internal flags are handled.
- `phase` — see roles above.
- Interfaces / multi-target `is a` — the IB "interface slice" decomposed: Distributable/Signable fields are facts about the distribute/sign beats; Confidential's are plain fields. Multi-target `is a` returns the day a real domain produces a genuine shared property bundle.
- Per-beat annotations of any kind — beat kind, produced status, effects, exogenous are derived, never written.
- `catalog` → `seed`; `hold` → assignment; `outside` → `external`.

**Admission bar (rescoped by the target-format doctrine, 2026-08-03):** for the *model vocabulary* (stories, rules, formulas, types), nothing enters until a real corpus model cannot be written without it. For the *transport*, the bar is totality: the grammar must encode whatever the IR stores.

**SUPERSEDED 2026-08-24 by D7 (below) — kept as record.** `produces` is now a
pointed replaced-syntax error; conjugation is editor typing-assist only; produced
status is a written `sets` clause.

**Produced status — DECIDED (owner, 2026-08-03): automatic with an explicit
fallback.** Context: the runtime stores a beat's produced status as the
**`story/transition-to`** fact instead of re-deriving it from spelling at
read time (the Submittes-class fix — [story-authoring](../story-authoring/spec.md)).
The 2026-07-19 cut ("produced status … derived, never written") is narrowed,
not overturned:

- **Automatic (the default).** The loader derives the edge by matching the
  beat's verb against the primary object's declared status values —
  `verbToStatus(verb, declaredValues)` + the irregular table (wins→won,
  pays→paid). No declared match → no edge stored (the runtime's read-time
  fallback covers it). This handles the whole current corpus; no file needs
  to say anything.
- **The fallback: `produces "value"`** — a beat-line suffix, e.g.
  `Broker binds Policy produces "in-force"`. For the business whose action
  word and status word are genuinely different terms of art (rewording the
  beat would misquote how they actually talk). It is **story sentence
  grammar** (owned by [story-authoring](../story-authoring/spec.md)), so the
  canvas accepts the same phrase and pins the same fact — one grammar, two
  doors — and it **stays visible in the sentence** (no lifting into a pill;
  keep it simple, owner call). The named value MUST be a declared status —
  loader error with file:line otherwise; never silently extend the enum.
- **Printer:** writes `produces` only when automatic derivation would
  disagree with the stored edge — round-trip safe, since the automatic rule
  reconstructs everything else identically.
- ✅ **Shipped with plan item 4** (see the plan above): derivation runs
  through the shared classifier (`detectActionCategory` — curated table
  first, then declared-enum evidence — so a create beat never carries a
  transition edge), the goldens compare edges included, and the printer's
  `produces` contract is pinned in `print-project.test.ts`.

## Lifecycle closure — walk-map D6 (ratifications land here)

**D6a `@final` ✅ RATIFIED (owner, 2026-08-24).** The mark trails the status value it marks:
`status: scheduled | open | closed @final`; several endings mark each (`attended @final |
cancelled @final`). A record reaching a `@final` value is finished — complete and kept, never
deleted, never reopened by an ordinary step. Loader error: a status list that later beats,
conditions, or seeds read, with no `@final` value = `file:line` error at that field. Records
with no status list are exempt (point events — Donation). The wrapper form (`@final(closed)`)
was rejected so the list stays a list of bare values; `final` chosen over `terminal` (owner).
**Attachment rule (owner, 2026-08-27, verification batch):** attachment is per attribute kind —
`@final` binds to the status value it follows; `@required`/`@unique`/`@default` bind to the
field after the full type; both kinds may appear on one line.
Prior art family: the mark rides the state itself (SCXML `<final>`, XState `type: 'final'`,
Step Functions `"End": true`); the meaning is UML's final state — complete, record persists.
**D6b loader checks ✅ RATIFIED (owner, 2026-08-24).** The loader traces every status list from
its birth value through the written `sets` lines. Always hard errors: an unreachable value (in
the list, never set, not the birth value); a step writing a record out of a `@final` value
(final means final — running again is a new record, per D4). Hard when the list carries
`@final`, warning when it carries none: a stuck value (no path to any ending). The trace always
starts from the actual birth value. Load-time text analysis only, no runtime cost. Queued
behind as follow-up warnings, not in this ruling: parent-finishes-before-child; no-unhappy-exit.
**D6c per-list scope ✅ RATIFIED (owner, 2026-08-24) — D6 CLOSED.** Each status list is checked
on its own; the loader never reasons across two lists' joint behavior (undecidable in general —
a checker that tries returns confident wrong answers). Cross-story breaks stay caught by the
layers that don't need it: name/value validation (D3) and the per-list trace itself (all
stories' writes feed one list's graph — deleting the only writer of a value errors, wherever
the reader lives).

**D7 produces/conjugation retirement ✅ RATIFIED (owner, 2026-08-24).** The `produces` suffix is
a pointed replaced-syntax error ("use a `sets` clause"); load-time verb-conjugation is dead; the
conjugator survives only as the editor's typing assist (suggests the `sets` line from the verb —
suggestion in the editor, never meaning at load). Releases the corpus sweep into the build queue
(runs when the walk closes). **Rider (owner, same ratification): every LLM authoring path must
author the explicit form** — the prompt-to-project prompts and the Claude authoring skill must
emit written `sets` lines (and the rest of the ratified spellings: `Type[]` mirrors, `@final`,
`about`), never `produces`, never conjugation-dependent text. Sweep the prompt files and the
skill with the corpus sweep. (The skill EXISTS as of 2026-08-27 —
`.claude/skills/onto-authoring/SKILL.md`, created on owner ask with the full
post-verification spellings; the prompt files still ride the sweep, and the sweep keeps the
skill in step with any further rulings.)

**D10 a+b+c riders ✅ RATIFIED (owner, 2026-08-24, as amended in discussion).**
- **a — `@unique` three sentences:** `@unique` is never identity (nothing may match or merge on
  it); "one open X per pair" is a rule counting live records, not a `@unique`; the allocation-
  domain residue is named, not solved. (Text lands on spec + modeling.md in the doc-promotion
  pass.)
- **b — status discipline, reworded at ratification:** a status is never a revocable flag —
  "currently a member / currently allowed" are computed values or role links, never statuses
  walked back and forth; authored return arcs are legal (cycles ratified); silent reversal is
  not; mistakes are corrections (part d). And: every status value needs a producer — a person's
  step, a system step, or a clock-driven change (enforced by the D6b unreachable-value check).
  (Wording confirmed 2026-08-27: a "clock-driven change" IS a system step whose conditions read
  the clock — no third construct exists; the D6b trace sees its written `sets` line.)
- **c — obligations scope, with the two-meanings line:** owed money/goods are ordinary records
  with amounts and statuses (fully in scope — hotel invoices); what onto deliberately lacks is
  owed-STEP machinery ("this approval is now owed by Alice, due Friday"); deadlines are time
  conditions, reminders are system steps; trigger to revisit = first government/casework domain.

**D10d corrections ✅ RATIFIED (owner, 2026-08-24, extended in discussion) — D10 CLOSED.**
Three write channels, exhaustive: (1) steps — normal operation, full law; (2) authored
`@correction` beats — the domain's named fixes: gated per domain, logged as corrections, the
only beats that may leave `@final`, ignored by the D6b trace; (3) the studio's direct edit on a
LIVE record IS a correction — the platform's generic one: same log kind (who, when, old→new,
marked correction), admin-tier permission, may leave `@final` with a visible warning. Scenario
and seed data stay freely editable (building is building). Every change to a live record is a
step or a logged correction; nothing else exists. (Confirmed 2026-08-27: the survey's
per-case-deviation question is ruled BY this decision — the authored `@correction` beat is the
override convention; nothing further needed.)

**D11 runtime rulings ✅ RATIFIED (owner, 2026-08-24, all four).**
- **a — outside actions:** built-in actions + configured integrations ship; arbitrary custom
  code is shut (hard-fenced if ever reconsidered). Every outside-action kind declares its
  permanent-failure path; a permanently-failed action is a visible standing problem in the app,
  never a silent drop; cleanup after partial failure is authored steps.
- **b — system-step runner authorized** (queued in the build order; nothing builds until the
  walk closes). Named requirements: the scheduled production tick + sorted-deadline check (the
  D6 tick riders); the self-extinguishing check at load (a system step must falsify its own
  conditions when it runs, else it would loop).
- **c — rule counts scope through links:** "at most 1 open RetreatBooking per student and
  retreat" is writable; same condition machinery as beats. **Spelling ratified (owner,
  2026-08-27, verification decision 7): the `per` phrase on the counting rule** — quantifier,
  type, `per` + one or more of the counted type's own fields, then the ordinary filter; the
  bound applies within each distinct combination of the named fields' values:
  `always at most 1 RetreatBooking per student and retreat where status is not "attended"`.
  Placement unchanged (an `always` line in the counted type's block); rule-grammar `per` — no
  collision with the sentence preposition (different parser).
- **d — seed name-pointing:** `roomClass: "Standard"` resolves against the target's declared
  name field when the seed is absorbed (authoring gesture — loader-never-derives untouched);
  exactly one match or error; the stored thing is the link, never the text.

**D12 semantics batch ✅ RATIFIED (owner, 2026-08-24, a–g).** (a) `ensures` retired from beat
lines — `requires` checks, rules cover standing conditions; readmit only on real need. (b)
Hide/restore = an ordinary cycling field (`visibility: published | hidden`); real deletion is
platform-side, never a domain step (erasure stays parked). (c) Several `sets` per beat legal,
distinct fields; same field twice = error at the line; order irrelevant. (d) `where X.f is not
Y` legal. (e) A new record's links fill from a sentence name or a written `sets`/`adds` line —
nothing else, ever. **AMENDED (owner, 2026-08-26, verification decision 5):** the story's
`about` name does NOT fill by itself — a creating beat in an `about` story carries the written
line (`sets CIM.deal to Deal`; the `about` name is a legal value; the door proposes the line on
every creating beat, author confirms). Sentence-name fill is the one and only exception to
"every link write is a written line", now stated. And (2026-08-27 batch): when a new record
declares two links of one type, automatic sentence-name fill refuses as ambiguous at load —
write the `sets` lines (with labeled names the door proposes them from the labels). (f) S7 residue confirmed: built-in Person carries `name` only; all other
role fields live on the role link (2026-08-18 set confirmed; actor build items unblocked at
queue close). (g) Values lowercase, capitals reserved for type names; the grammar card's mixed
example swept with the corpus sweep.

**D13 roles shortlist ✅ RATIFIED (owner, 2026-08-24, a–d).** (a) Role-over-role: `actor
SeniorTeacher is a Teacher` legal; revoking the underlying role blocks the dependent one
immediately (grant persists, confers nothing); removal is an authored step; nothing cascades
unauthored. (b) Two names in one beat may bind the same person unless a written line forbids it
(`requires Teacher is not Student`) — the system never silently refuses self-pairing. (c) The
shared-field-bundle construct stays out; sharpened trigger recorded: same fields + same meaning
+ steps/rules over "anything with the bundle" AND a type needing TWO bundles at once — one
bundle is already covered by `is a` (a base-typed position accepts every subtype; the base gets
no instances because no beat creates one — owner-confirmed on coffee's Product/Drink/Pastry).
(d) A role link carries only what the role needs to act; everything else is computed or its own
record (`hoursServed` = count; application notes live on ServiceApplication).
**AMENDED (owner, 2026-08-27, verification decision 6): person comparisons cross role types.**
A role-typed link stores the underlying person; an identity line comparing a link to a sentence
name holds when both resolve to the same human, whatever role either side names
(`where GroupMembership.applicant is Student` with `applicant: Applicant` — legal after
`grants Student to Applicant`). The declared role type governs FILLING only — pickers list that
role's holders, the grants discipline is unchanged — never identity comparison. Extends (b)
from sentence names to links. Modeling guidance (rides the promotion pass): type a person link
by the role held at write time — the honest record; `applicant: Applicant` stays true forever.

**D14 a+b+c pre-accepts ✅ RATIFIED (owner, 2026-08-24).** (a) Same-type pairs: the merged
`Type:label` spelling (`Curator moves Item from Collection:source to Collection:target`) IS the
answer — clauses address the two by label; positionals dead permanently; prepositions never
carry meaning (2026-08-13 ruling stands). **Clause spelling ratified (owner, 2026-08-26,
verification decision 3): the sentence token verbatim.** `Type:label` is the name in every
clause position (`where Item.home is Collection:source` · `sets Item.home to
Collection:target`); paths hang off it like any name (`Collection:target.status`); the label
scopes to its beat; a clause label with no matching sentence token = `file:line` error (the
no-source rule, unchanged); a bare lowercase label is illegal (capital-means-entity stands). (b) `every` — a meaning reservation ONLY, nothing
enters any grammar: cascades are already covered by the system-step once-per-match rule; if the
marked-bulk trigger ever fires (person-fired bulk, the media-library case), the word means
list-taken-once-at-firing, one run per member, no quantity knobs; spelling/placement decided at
admission (leaning: sentence word, not an `@` mark). (c) Division: a rounding word is required
at each division site (`/` without one = error at the line — BigDecimal's rule in words); no
global default; splitting a total distributes leftover cents largest-share-first (Fowler's
allocate) so totals reconcile exactly. JS-float silence is the recorded cautionary tale.

**D14d — the #99 five (rulings recorded one at a time; texts live on staging's backlog rows,
reconciled at merge).**
1. ✅ **Prepositional verbs NOT admitted (owner, 2026-08-24)** — the recorded recommendation
   (hyphenate: `pays-for`) is REJECTED in favor of forcing the simpler sentence: the thing
   acted on becomes the object (`Guest pays Invoice`, `Attendee submits Registration for
   Summit`). The authored corpus never needed a prepositional verb (evidence: hotel/IB payment
   beats); the wild corpus's cases all dissolve by surfacing the record noun. The objectless
   bare form stays the existing pointed error, with teaching copy: "make the thing acted on the
   object." Hyphens remain ONLY for true phrasal verbs (`checks-in`, `picks-up`). If a domain
   ever genuinely cannot surface a record noun, hyphenated admission is additive later.

2. ✅ **Numbers (owner, 2026-08-24):** digits inside names are legal (`spo2`, `zoning: r1 |
   r2`, `sha256` — real corpus fields); a freestanding number as a word in the sentence line is
   a pointed error. A number is always a value — in a condition (`is at least 2`), a write
   (`sets Estimate.value to 5`), a formula, or data (seeds, form fields) — never sentence text;
   the error names those homes.

3. ✅ **Plurals (owner, 2026-08-24):** a noun is always its declared form — no singularizing,
   no plural noun forms (`Transactions` never appears unless the type is genuinely plural-named,
   like IB's `Financials`). **Plurality is a determiner word, never the noun's form**: one-at-a-
   time is the plain singular beat (fired per record); all-at-once is `every` (the reserved bulk
   word — this ruling confirms its spelling from the demand side; admission trigger unchanged).
   `each` rejected as a synonym (one concept, one spelling). The same-stem lint stands: an
   accidental `Transaction`/`Transactions` catalog pair gets a proposed merge, author decides.
   Studio rider (owner): the story-authoring plural/multiplicity UI corrects to this — noted in
   that backlog.

4. ✅ **Star marker removed (owner, 2026-08-24):** `Transactions*` deleted — one code path
   (classifier slot parser), never grammar-defined, never corpus-used, and now contrary to the
   ratified plurals rule (plurality = determiner word, never a noun mark). Removal + the three
   dangling doc mentions ride the corpus sweep. **`@every` rejected (owner, same exchange):**
   `every` is a plain word, specially parsed, like every structural word in the grammar
   (prepositions, `where`, `at least`); `@` marks are declaration annotations, not spoken
   sentence content; position + closed word-class prevents collisions. Confirmed as the
   spelling-when-admitted.

**`every` ADMITTED (owner, 2026-08-24 — supersedes the D14b reservation and the transcription
tripwire; the plurals ruling was the demand).** Spec: a closed determiner immediately before a
noun in the sentence — object or participant position; ONE per beat (two = cross-product,
pointed error); parsed structurally like the prepositions (lowercase word before a CamelCase
noun — collision-free); the sentence line's first meaning-bearing word, admitted deliberately.
Meaning as fixed: list taken once at firing, one run per member through the normal write path
with its own run id; indented conditions and defined groups narrow the set; no quantity knobs.
Human-fired only — system steps keep their bare once-per-match rule. The determiner family
closes: `every` is the language's only determiner; `each` rejected (synonym); `a`/`an`/`the`/
`all` stay non-words. Noun stays singular: `every Transaction`. Builds with the queue. Run identity (confirmed
2026-08-27): per-member run ids derive from the render-minted id plus the member — dedupe key
(step, render id, member); build-time detail, no grammar.

5. ✅ **Defined groups confirmed (owner, 2026-08-24) — D14 CLOSED, THE WALK COMPLETE.** The
   form stays exactly as taught (`actor Analyst = Employee where seniority is "analyst"` —
   derived, read-only, no fields, membership recomputes live); the saved-model home is queued
   build work; the card-vs-loader contradiction resolves in the form's favor.

**Backlog item (owner, 2026-08-24): explore cross-list breakage detection to the practical
limit.** Full proof is impossible; the goal is best-effort tooling that catches real cases:
the parent-finishes-before-child warning and the unsatisfiable-condition check (one solver
call) are the first two; beyond them, explore bounded checking over small instance counts,
scenario-replay against stored scenarios, and any heuristic that reports *warnings* (never
claimed proofs) about two lists' interplay. Success measure: the sangha strand case (a retreat
closes while bookings sit requested) gets flagged by something.

## Declaration annotations + collection quantifiers ✅ RATIFIED (owner, 2026-08-29, in session) — ✅ BUILT (the parser catch-up, same day)

> **The parser catch-up shipped 2026-08-29** ([spec.md](spec.md)): the loader and printer speak the
> full ratified grammar — this section, written birth below, and every walk/verification ruling
> above (annotations · subsets · mirrors + `@of` · `@final` + the D6b trace · the clause family ·
> `about` · `every` · `Type:label` · `@correction` · `per`/`some`/trailing-`in` · collection
> aggregation · rounding words). All five corpora load whole and round-trip; the eight no-corpus
> constructs gained corpus exemplars; the goldens re-pinned (HOTEL_SEED v22 / COFFEE_SEED v12).
> Still open from the build's rider list: the **LLM prompt-file sweep** (deferred by owner call
> until the parser was tested on pure ontolang — now unblocked), **seed-code retirement**
> (parseDSL moves into `ontolang/`). ✅ **The runtime execution of the emitted clause shapes
> is BUILT (2026-09-05, the runtime catch-up — owner ruling 2026-09-04):** `story/sets` ·
> `story/finds` · `story/where` · `story/grants` · `story/revokes` · `story/adds` ·
> `story/about` · `story/every` · `story/correction` all execute in the reference loop's story
> execution, each pinned by a replayed execution log on its corpus exemplar → [rule-runtime
> spec](../rule-runtime/spec.md). Rode along: the creating-door rule sharpened (ancestors'
> gates count, `where`/`finds` on the primary count, the written line decides for a
> status-bearing primary — a sub-story under a gated story no longer gets an invented birth
> line); lead-intake gained `ContactForm.status` (consumed at Lead creation — the 2026-08-27
> sweep item) and its alert became `System opens LeadAlert for AccountExecutive` with a `finds
> Lead` and the `requires no LeadAlert in Lead.alerts` guard the D11b check demands;
> investment-bank gained the `Deal` lifecycle (born at `originates`, the verification's
> re-version) and `ProcessLetter` as a record per buyer; canna's sample is `draws TestSample`
> (born there). **Open:** the point-event creation gap — a status-less object's creating door
> is the classifier's verb verdict, so `Student offers MonetaryDonation to Teacher` creates
> nothing at runtime; a written mark would close it (owner ruling asked for).
>
> **Spellings RATIFIED (owner, 2026-08-30):** the rounding words are `rounded down` · `rounded
> up` (`rounded nearest` CUT until a corpus formula demands it — the admission bar); `avg` names
> its rounding the same way (`avg of X.f rounded down`; bare avg = pointed error — the D14c
> "division/avg results" residue is closed); `@correction` trailing the beat line stands;
> the money split got its formula surface same day (owner: "lets just solve
> money splits"): `split of <money-total> across <[]-collection>` — member-side, largest-remainder,
> reconciles exactly; and the aggregation word renamed `avg` → **`average`** (surface only; the IR
> op stays `avg`). A corpus exemplar for split/average waits for the first domain that splits a
> bill (nothing natural in the five). **Story blocks
> are KEPT (same ruling):** titles, `about`, and `@description` now live in the model
> (`storyBlocks` + per-beat `story/block`) and print back — the old "no IR home, parsed then
> dropped" rider is CLOSED. **Role-block capability fields ACCEPTED** (over the 2026-08-26
> pointed-error note): declared under the role in `fields`; making them WORK at runtime
> (assignment edges carry them — the 2026-08-18 design) is queued as its own PR.

**Derived subsets re-spelled — header `=` retired.** A derived subset is the role spelling plus
an indented predicate annotation: `actor NewStudent is a Student` + `@where no status is
"attended" in retreatBookings`. The `@where` line is what flips `is a` from granted role to
derived subset (read-only, no fields, membership recomputes live — semantics unchanged from
D14d-5); a block carrying `@where` rejects fields, `seed` rows, and `grants` targets as pointed
errors; the object side is symmetric (subtype bare, derived subset with `@where`). Header `=`
becomes a pointed replaced-syntax error — `=` survives only as the computed-field formula marker
(symbol discipline: `=` introduces math; logic is words). The IB seniority actors re-spell in
the corpus sweep.

**Trailing collection restrictor.** A quantifier atom may end with `in <[]-field>`: the phrase
closes exactly the one atom it ends, and bare fields inside that atom are the element's (the
`finds` convention). Reads condition-first, source-last — SQL's order. Single-condition by
construction: two facts about the same element are unwritable in this form; multi-condition asks
use the introducer-first layout already ratified for `every` (`no RetreatBooking in
retreatBookings` + indented `where`/`and` filter lines), which this ruling extends from `every`
to the whole quantifier family.

**`some` — the words tier completes.** The quantifier family splits into polarity words
(`no` / `some` / `all`) and counting bounds (`exactly`/`at least`/`at most`/`more than`/`fewer
than` + N). `some` = at least one over the restricted set. Over an empty collection `some` fails
and `no` holds vacuously, so paired subsets (NewStudent/OldStudent) partition. Not a synonym
admission: `no` already holds the word seat where `exactly 0` could have been demanded.

**Declaration metadata = annotations.** In declaration blocks, field lines stay bare
(`name: type @attrs`); every non-field line wears `@`: `@description "…"` (block, field, story,
and project positions alike) · `@type person | organization | system` · `@rule <invariant>`
(replaces `always` in type blocks — named for the layer, since blocks admit only the invariant
kind) · `@where <predicate>` (subset membership) · `@boundary external` (same principle).
`always` in a block and bare `description`/`type` lines become pointed replaced-syntax errors at
the sweep. `rule` un-retires ONLY in annotation position — bare `rule` stays the pointed error
(the 2026-07-30 gate ruling stands). Story machinery under beats stays bare words
(`where`/`requires`/`forbids`/`sets`/`adds`/`grants`/`revokes`/`finds`). Rider: sangha carries
all these spellings now (applied this session); the tmLanguage, prompt files, modeling.md
examples, and the older corpora ride the corpus sweep; the loader gains them in the parser
catch-up.

**Written birth ✅ RATIFIED (owner, 2026-08-29, same session) — ✅ BUILT (the parser catch-up; see the banner above).** Every creating beat writes its
birth status — `sets X.status to "value"`, the value a declared status; different creating doors
may write different birth values (per-door births are first-class). Hand-sparse at the door,
complete in canon: an omitted line fills with the first declared value at load, and the printer
always emits the line — the canonical corpus is never missing one. Enum declaration order now
means RANK ONLY — reordering is cosmetic, no longer a semantic edit; the `@default`-on-status ban
stands with its rationale updated (birth lives in the creating beat, which beats `@default` — it
is per-door). Seed rows may write `status:` like any field row (omitted → first value; printer
emits). The lifecycle trace (D6b) starts from each creating beat's written birth value — multiple
roots legal. Owner's reasons on record: per-door births; explicitness (the D7 trajectory);
stories are read without the enum in view, so the story is now self-contained about the whole
lifecycle. The one-more-channel-to-sync objection is answered by demoting enum order — one
channel, nothing to drift. Applied to sangha in session (five creating beats gained their lines;
`announces` was already compliant); the other corpora, prompts, and docs ride the sweep.

## The doctrine — ontolang is a target format (owner, 2026-08-03)

Ontolang is a **target**: simple, human-readable, **complete in its definitions**. Its writers — the studio and agents — do the derivation heavy lift *before* encoding; the loader **validates**, it is not owed cleverness. Authoring ergonomics (affordances, derivations, editability, form behavior) belong to the UI layer ([entity-authoring (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/entity-authoring/backlog.md), classify-at-commit) — never to the language; no invented terms in the grammar (the `stamped` lesson). Hand-sparse input stays legal at the doors (`is an` — loading is an authoring gesture; but a whole second spelling for one concept is over the line — `given` was retired 2026-08-04, seed-only); the printer always emits the complete canonical form. When an agent-facing prompt teaches `.onto` authoring, it teaches this grammar.

**Field attributes — DECIDED (owner, 2026-08-03), Prisma-shaped.** `@word` / `@word(value)` after the type is THE extension point for field facts — new facts enter as attributes, never as new English forms. Shipped: `@required` · `@unique` · `@default(value)` — written once at creation then ordinary; bare `now` (the creation instant) is the only timestamp default; type-checked at load; never on computed fields or **status** enums (birth = first declared value); money defaults store minor units and print decimals. The comma modifiers and `(stamped on create)` are retired — pointed replaced-syntax errors; the `stamped` schema key is gone (`ObjectField.default`). Printer order canonical: `@required @unique @default`. Runtime residue: both halves **shipped 2026-08-04** — the create-time default write and the `@unique` index check (standing violations) → [rule-runtime spec](../rule-runtime/spec.md); the field-editor affordances ride [entity-authoring (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/entity-authoring/backlog.md).

## ▶ The iteration answer — settle soon (owner priority, 2026-07-24)

**Why urgent:** ontolang announces as a language with **no loops** ([the draft (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/blog/introducing-ontolang.md) says it twice) but never answers the first question every developer will ask: *"then how do I iterate?"* The doctrine is decided; the one admission landed — `every` ADMITTED 2026-08-24 (see the walk ruling above). What remains is only the public write-up (the "Do next" item).

**The doctrine — quantity words, not repetition words.** The grammar admits words that say *how much of the world* a statement covers, and bans words that say *do it again* (`while`/`until`/`repeat` — none exist, ever). Every iteration need in the corpus reduces to four shapes, none authored as a loop:
1. **Folds** — aggregation formulas (`serviceCharges = sum of Service.charge where …`); the spreadsheet argument: `=SUM()` is not a loop.
2. **Multiplicity** — a sentence describes one occurrence; the event stream repeats it (`Guest requests Service` fires per request; `Associate sends Teaser to Buyer` fires per buyer). Reality is the loop; the story never says "again".
3. **Whole-set checks** — quantifier rules (`all Buyer where …`, `at most Order.capacity Guest`).
4. **Time** — the clock tick; "every month" is events arriving, not a loop over months.

The engine does all actual looping (fixpoint derive, per-instance evaluation) — bounded and unauthorable, so every classic loop bug is unwritable. Totality survives by construction. Concurrency is the mirror image and belongs in the same public answer: **sequencing is authored (gates); concurrency is the ambient default** — stories are per-instance, commits serialize, invariants are the race control (the loser is refused, `at most N` is the lock you never write), and an open intent is the await.

**The designed extension — system-as-actor fan-out (broadcast / mail-merge), the one shape multiplicity can't cover.** A server broadcasting to 30 sessions is not a clerk clicking 30 times; jellyfin's imported beats literally read `to all Sessions` / `from each Metadata Provider`. Three pieces, only one of them a word:
- ✅ ADMITTED 2026-08-24 (see the walk ruling above — human-fired bulk, one per beat, singular noun; this older entry kept for the mechanics it records) — **`every` — the distributive determiner** [superseded: the walk closed the determiner family — `every` is the language's only determiner; `a`/`an`/`the`/`all` are non-words]: `Server broadcasts SyncCommand to every Session`. Firing derives **one intent per current member** (snapshot semantics); the intent lifecycle already supplies exactly-once, per-intent retry, and replay safety (`executeIntents`). Filtering reuses defined subsets (`every ApprovedBuyer`) — no where-clauses in story sentences. With a human actor it's the mail-merge button: one gesture, N intents.
- **System-actor auto-fire — zero syntax:** a beat whose actor is a System kind fires automatically whenever its gate holds (`step` is the seam; the classifier already treats System as first-class agentive). Ongoing coverage — late joiners included — is then an ordinary singular beat + standing gate, no `every` needed.
- **The self-extinguishing check:** an auto-fired beat's produced status must falsify its own gate (`sends` ⇒ sent, which the gate negates) or the agent loop spins — mechanically checkable from the beat's written `sets` clause (load-time conjugation retired by D7; the check is ratified as D11b); the totality argument extended to the agent loop.

**Dependencies:** participant binding — the loop now binds a fire's non-subject participants (joins tier 1, item 1 below), but `every` needs to ENUMERATE the members and derive one intent each, which is still open · an IR slot for the distributive marker on a story participant (the seed story format has none).

*SUPERSEDED 2026-08-24 — `every` was admitted via the plurals ruling, not the transcription tripwire; kept as record.* **Admission: not yet — the bar is met by transcription, not argument.** Tripwire: **transcribing jellyfin SyncPlay into `examples/ontolang/`** (`broadcasts … to all Sessions` cannot be written singular), or the first hand-built seed needing one-gesture fan-out. Land the word and its runtime together (rides the joins tier) — never a parsed word the loop ignores (the authored-rule-shape lesson).

**Not covered, deliberately:** chains (transitive closure — a link followed repeatedly: manager-of-manager, BOM rollup). `every` distributes over a flat current set; chains are recursion and stay parked (tripwire added below).

**Do next (no code):** write the public answer — a "where iteration went" section in [grammar.md](grammar.md) and an iteration + concurrency FAQ in the announcement — so the answer ships before the question arrives.

## Open — reprioritized by the 2026-07-23 Foundry / Open Ontology comparison

The comparison (4-agent workflow; relations + coverage lenses vs both systems) **added nothing new to this list** — it confirmed the cuts (Foundry's canonical interface example is a beat restated as a type; its link-metadata guidance routes to the intermediary object ontolang starts with) and upgraded priorities on items already here:

1. **Cross-entity identity/joins.** Triple-confirmed: onto's own corpus (4/8 domains + FHIR), Foundry (links bidirectional by definition; searchAround), OO (Datalog shared-variable joins). **Tier 1 ✅ built (2026-08-03, plan item 5 above): ref-hop paths in rule predicates + the cross-participant bind** — traversal stays forward-only (`via`-aggregation the lone reverse mechanism). **Tier 2 — instance binding & story scope** — decisions ratified 2026-08-24 (walk closed; story `about` context declaration, explicit binding clauses); build queued; its decision trail: [binding-backlog.md](binding-backlog.md); tier 3 parked. Rides with [rule-runtime](../rule-runtime/spec.md)'s remaining identity gap (slot-labeled identity across beats). **Still the binding substrate for the `every` fan-out + system auto-fire (the iteration answer above).**
2. **The prelude — DECIDED (owner, 2026-07-23): implicit fallback.** Resolution checks the platform kind catalog last, after project declarations; zero syntax. Domains extend by reopening a block (whole-model merge permits it). Explicit imports arrive with packages; semver/packaging stays parked.
3. **Guarded `associate`** — not grammar; completes the runtime's stated semantics (rule-runtime's accepted boundary). Foundry gates link edits in action transactions; onto's associate beats fire unguarded today.
4. **Company vs Organization — DECIDED (owner, 2026-07-23): not the same kind.** Company is a rigid subkind of Organization (a commercial organization); enters the kind catalog as a subkind entry (implementation rides with the prelude/kind-roster work). IB's `role/base: 'Company'` resolves there; no seed re-basing.
5. **Seed refs by instance label** (`roomClass: "Standard"`) — ✅ DECIDED (2026-08-24): resolves against the target's declared name field at absorb, exactly one match or error, the stored thing is the link — see D11d (seed name-pointing) above.
6. **Story names** remain prose titles (own namespace, positional); compounding them stays open.

**Parked with named tripwires** (from the comparison; each reopens only on its trigger): **field default values** — no longer parked: shipped as `@default(value)` (decided 2026-08-03, runtime 2026-08-04 — see the field-attributes decision above); `(stamped on create)` is retired (a pointed replaced-syntax error); `=` stays taken by Formulas (computed ≠ default — continuously derived vs written once), and an enum's birth value is already its **first declared value**, so status defaults are never authored · many-valued refs / declared cardinality — ✅ RATIFIED 2026-08-24 (the walk): `name: Type[]` is the link-to-many spelling, mirror lines on both sides, `@of(field)` disambiguation; two []-links between the same types = error · as-of/history queries → first seed rule needing "as of" (XTDB substrate planned) · field-level visibility → roles-permissions instance layer · struct/array/geo/vector field types → FHIR probe's nested structures · time-series properties → none (history lives in the log by design) · branching/proposals → tooling over content-addressing, not vocabulary · external agent surface (MCP over the guarded loop) → platform work, announcement-relevant · scheduler → the automatic tick source rider · **chains / transitive closure** (a link followed repeatedly: org-chart rollup, BOM, FHIR references) → first corpus domain needing one; `every` distributes over flat sets only (see the iteration answer).

**Boundary cases filed, not designed:** a genuinely rigid actor subtype (System actors) · actor-side contracts — both likely resolved by "is a to an abstract type = contract; to a concrete kind, nature decides". *(The **Roles over kinds** set below ratifies the nature-decides half: `type system` actors are rigid.)*

## Roles over kinds — the actor-model decision set (owner, 2026-08-18)

> **Prior-art audit (2026-08-22):** the deep pass over role theory, BPM resource models, access
> control, Palantir, enterprise ontologies, OO/data patterns, and the Datalog tradition —
> [roles-extension-prior-art (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/research/roles-extension-prior-art.md) — confirms this set
> essentially intact, resolves the role-chain question (always-a anchored to the base holding;
> block-by-default revoke; admitted-from stays grants-shaped), and carries the consolidated
> tripwire list + a ratify-now shortlist. Companion to the
> [process-modeling literature audit (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/research/business-process-modeling-survey.md).
Ratified in conversation over a worked domain (the sangha corpus below, this set's exit example). Grammar/runtime **unbuilt unless marked**; instance-layer execution rides [roles-permissions](../roles-permissions/backlog.md) (cross-linked there). Spellings marked *proposed* await the usual owner spelling call.

**Supersedes / leaves standing.** This set **revises the default actor spelling**: the 2026-08-03 "roles as actor `is a`" ratification stands as the *mechanism*, but `is a` becomes the **exception** spelling (a role over a declared narrower base; object subtypes) — the default case is a bare actor under the collapse (item 2 below). It **dissolves the default case of kind-vs-role nomination** ([roles-permissions backlog §1](../roles-permissions/backlog.md), marker added there): no attach-proposal for ordinary person-nouns — the chip survives only for the genuine forks (own rigid kind vs role; narrower base). It **retypes `actor/type`** from two values to three. The grammar card above **predates this set** (its `actor Employee is a Person` + `hireDate` examples await the spelling calls — noted at the card). **Standing untouched:** the prelude entry (this set's queue depends on it), defined subsets (`= … where`), phases-on-assignments (owner decision 3, 2026-07-23), story-roles/colon labels, and the built loader behavior recorded in [spec.md](spec.md) — which stays the truth of what's built until the queue lands.

**Terms — role stays the word, always qualified.** The concept keeps the literature's name; ambiguity is resolved by **naming the base**: "a **role over Person**" (speech: "person role"), "a role over Organization" — never a bare "role" in studio chrome or error copy. This kills every collision without renaming anything (domain nouns like a corpus's `ServiceRole`, story-role colon labels, the Coad `'role'` archetype, the `role/*` schema — all stand). "Hat"/"persona" considered and rejected. The word never appears in ontolang text itself.

**1. The `type` word — DECIDED: explicit agentive kind, person default. Spelling RATIFIED `type` (owner, 2026-08-19; `kind` was the proposed spelling and never shipped).** An actor declares its kind — `type person | organization | system` (the value set is the catalog's agentive trichotomy, which is also PROV-O's agent set and domain storytelling's own people/groups/software-systems). **Omission = person** — the storytelling default and the safe failure direction: automation is opt-in, so *nothing acts autonomously unless the text says so*. Explicit is **best practice** (studio lint), never a loader error. Nature is a projection of the agentive kind — person/organization act by gesture; system auto-fires (the iteration answer's auto-fire keys off the **declaration**, never the name: the `SYSTEM_ACTORS` lexicon demotes to a studio proposal). `is a` and `type` must agree (`is a System` implies it; a contradiction is a pointed error). Fixes a real IR misfiling: the two-valued `actor/type` files Organization actors as `'person'` — it becomes three-valued, and the IR key's word now matches its grammar spelling.

**2. The is-a collapse — DECIDED: a bare actor IS a role over its kind.** A person/organization-kind actor is an anti-rigid role over that kind's shared substrate **by language semantic** (deterministic and uniform — the produced-status character, never per-model inference), backed by the corpus law: no real domain uses bare Person; every human actor is a role. Same-kind roles share instances — one human, many roles, same-name convergence (the built assignment-slice behavior becomes the default reading). Consequences: with the prelude, no substrate block is ever declared, and the nomination attach-chip disappears for the default case. **`is a` retreats to the non-default cases:** a role over a *declared narrower base* (`actor LegalCounsel is a Company`) and object subtyping. `type system` actors are rigid (nature decides — see the boundary-case note above). Role-block fields stay the assignment's schema (already card-canon).
**3. `grants X to Y` / `revokes X from Y` — DECIDED (inversion + binding; words RATIFIED, owner, 2026-08-18).** Conferral is an **effect-word in the gate family**, indented under the conferring beat — never a remote reference (no sentence duplication; beat edits carry the clause, deleting the beat deletes the conferral) and never in the sentence (the 2026-08-14 ruling governs sentences; indented clauses speak model machinery, as gates already do). **Binding: Y must be a participant (or the subject) of the beat's own sentence — load-checked**, which mechanically enforces the proleptic discipline: an admission beat names the person by the role they hold *now* (`Teacher accepts ServiceApplication from Student`). **Execution:** the commit emits an assignment intent; the executor opens/closes the edge — the same write path as seeds and role-typed creates (one writer, three triggers). Re-granting a held role is a no-op; `revokes` closes the edge (`assignment/to`'s first writer); a grant after a close opens a fresh edge beside it. **No derivation arm, ever** — nothing in a sentence mechanically names the conferred role (unlike status conjugation), so the studio may only *propose* a clause on grant-shaped beats, origin ladder governing. **The word is `grants`** (`confers` considered, rejected as confusing): its homonym with the ordinary sentence verb resolves by **position** — the `produces` precedent — a verb-slot "grants" is domain language and only the indented clause-position word is machinery, so a beat whose verb is "grants" carrying no clause still reads as what it is: an act with no standing consequence. **Conferral-by-create stands:** the first beat a new person fires as role R mints the Person + R's edge; clauses are for roles added to existing people.

**4. The interval is the when — DECIDED.** Every assignment carries `from`/`to`, written by the machinery (a grant sets `from`, a revoke sets `to`). "Since when is she a Teacher" is the edge's `from` — **never a declared field** (an `authorizedOn` would duplicate it). Declared role-block fields are **capability-style** (`approval_limit`), not time-style; backdating is a seed or grant setting `from` explicitly, defaulting to now. (The card's `hireDate` example wants revisiting under this rule.)

**5. Three riders — standing rules, applied here and kept.**
- **The platform/domain seam:** stories model the domain's work, never the platform's own machinery — the sangha corpus cut `Student registers Registration with System` / `System verifies Registration` (accounts are the platform's job; binding Persons to accounts is the platform join, not a domain story). The authoring-side twin of IDE/runtime separation.
- **The org enters through a story:** taxonomy never mints it. No beat names the Community, so it isn't modeled; the day a beat needs it (`Student offers Donation to Community`) it arrives as `type organization`, with evidence.- **Process record vs standing state:** an admission object (`ServiceApplication`) is immutable history; a role is revocable standing. A beat gets a `grants` clause **iff the domain addresses people by the resulting role downstream**; otherwise the object's derived status is the whole effect (`Teacher grants GroupMembership to Student` → `granted`, no role — the verb-slot "grants" with no clause, read by position — and the one-line upgrade sits ready if member-ness ever becomes addressable).

**The worked example — the sangha corpus.** All-human after the seam rider (so no `kind` line even appears: in a fully role-modeled domain the word's ceremony is near zero). Four fieldless roles over Person, eight objects, one `grants` clause, one invariant; Students are event-born (no seed), teachers seeded. CHECKED IN at [`examples/ontolang/sangha/`](../../../examples/ontolang/sangha/) (2026-08-27, owner ask) in the post-walk ratified grammar — the 2026-08-26/27 verification generation pass, superseding the block below as the current text; it becomes the loader's exit test when the parser catch-up ships (nothing parses it yet; no test globs it).

```
project SanghaCommunity
  description "Students practice with teachers: retreats, appointments, teachings, service, and dana."

actor Student
  description "Anyone practicing with the community — the binding role; born the first time a person acts as one."

actor Teacher
  description "Leads retreats, publishes teachings, decides membership and service."

actor AssistantTeacher
  description "Holds appointments with students; still a student of the lineage."

actor ServiceVolunteer
  description "A student serving in a position after an accepted application."

object GroupMembership
  description "Membership in the practice group — a domain object, not a role."
  member: Student
  status: requested | granted

object Retreat
  name: string
  capacity: int
  status: scheduled | open
  confirmedCount: int = count of RetreatBooking where status is "confirmed"
  always Retreat.confirmedCount is at most Retreat.capacity

object RetreatBooking
  description "One student's place at one retreat."
  student: Student
  retreat: Retreat
  status: requested | confirmed | attended

object Appointment
  student: Student
  status: requested | confirmed | held

object Teaching
  title: string
  status: draft | published

object Donation
  amount: money

object ServiceApplication
  applicant: Student
  status: submitted | reviewed | accepted

object ServiceRole
  description "A service position — the volunteer assignment's context."
  name: string

story Membership
  description "A student is admitted to the practice group."
  Student requests GroupMembership
  Teacher grants GroupMembership to Student
    requires GroupMembership.status is "requested"

story Retreats
  description "Scheduling, booking within capacity, attending."
  Teacher schedules Retreat
  Teacher opens Retreat
  Student requests RetreatBooking for Retreat
  Teacher confirms RetreatBooking for Student
    requires RetreatBooking.retreat.status is "open"
  Student attends Retreat

story Teachings
  Teacher drafts Teaching
  Teacher publishes Teaching
    requires Teaching.status is "draft"

story Appointments
  Student requests Appointment
  AssistantTeacher confirms Appointment for Student
  AssistantTeacher holds Appointment with Student
    requires Appointment.status is "confirmed"

story Dana
  Student offers Donation to Teacher

story Service
  description "Submit, review, gate, accept, grant, position."
  Student submits ServiceApplication
  Teacher reviews ServiceApplication
  Teacher accepts ServiceApplication from Student
    requires ServiceApplication.status is "reviewed"
    grants ServiceVolunteer to Student
  Teacher assigns ServiceRole to ServiceVolunteer

seed Teacher
  name: "Sona"
seed AssistantTeacher
  name: "Mira"
seed ServiceRole
  name: "Kitchen"
  name: "Registrar"
```

**Implementation queue (distance to loadable):** prelude fallback (decided, item 2 above) → the `type` word → the is-a collapse → ✅ assignment-edge fields (BUILT 2026-08-30 — [roles-permissions spec](../roles-permissions/spec.md)) → `grants`/`revokes` → joins tier 2 (`Student attends Retreat` stays inert until it carries its explicit clauses — now the binding & scope queue: [binding-backlog.md](binding-backlog.md)). Built substrate it rides today: the assignment slice, tier-1 ref-hop gates + participant binding, Formulas, the intent lifecycle.

### Follow-on ratifications (owner, 2026-08-18, same-day session)

Stepped through in conversation after the set above landed. Best-practice phrasings live in [modeling.md](modeling.md) (created this session — the accumulating modeling-rules page); this list is the decision record. The sangha corpus above predates these — it gets reshaped (Applicant front door, a system actor, the Community, scoped grants) once the two open spellings below are ruled. It also predates the 2026-08-24 walk closure and picks up its spellings in the same reshape/sweep: `@final` marks on every status list that beats read, `Type[]` mirror lines on both link sides.

- **Open vs closed roles — SUPERSEDED 2026-09-10** by [explicit actor enrollment](#actor-access-and-enrollment--ratified-2026-09-10). Historical ruling: a role with no seed and no `grants` clause anywhere in the model was **open**; a person's first beat as it created the person and role-holding. This zero-syntax inference, the mandatory low-power entrant actor, and the Applicant → Student approval example are replaced by the new policy and retreat scenario. The current reference loop still infers open roles until the actor-policy build lands.
- **Role fields are readable — DECIDED, BUILT 2026-08-30.** Gates and formulas may read a role's declared fields (`AssistantTeacher.appointmentLimit`) — role-typed type scans, ref hops, and aggregations resolve through the holding, and the holding's facts arrive merged into the instance read ([roles-permissions spec](../roles-permissions/spec.md)). Writers: seed rows and runtime forms; beats never write them. (A promotion beat writing an assignment field is a filed tripwire — no corpus asks yet.)
- **System actors act on their own — DECIDED.** A system-kind actor's beat fires automatically whenever its gates hold; its produced status must falsify its own gate (the self-extinguishing check). This admits the system half of the iteration answer now; `every` fan-out stays parked on its transcription tripwire.
- **`is a` over a role — DECIDED.** When the base of actor `is a` is itself a role, holding the narrower role implies holding the base: `actor AssistantTeacher is a Student` — granting AssistantTeacher opens both holdings. Covers IB seniority and lead-intake staff once their substrate blocks dissolve.
- **Bulk granting is tooling — DECIDED; entry mechanism updated 2026-09-10.** Rosters, pasted ID lists and email invites remain platform surfaces. The [actor enrollment ruling](#actor-access-and-enrollment--ratified-2026-09-10) replaces the old open-role first-act path with standard enrollment and authorized role operations; no new story grammar.
- **Machinery words translate — DECIDED.** Import and studio translate auth-state nouns (AnonymousUser, AuthenticatedUser, bare User) to the domain's entrant actor, or drop them with the platform machinery they describe. The rule governs defaults only — a domain may still deliberately declare such a name as its own vocabulary.
- **The account join — SUPERSEDED 2026-09-10** by [platform enrollment](actor-boundary-plan.md#signup-modes--ratified-2026-09-10). The earlier ruling deferred person/role creation until an open actor's first beat. The new contract creates or reuses the account/person through explicit enrollment, supports grants to existing people and acquires no role merely by logging in. Account provisioning remains platform machinery.
- **Enforcement — DECIDED.** A beat fired by someone who does not hold the beat's actor role is **refused at commit** — one enforcement point for every path (UI, API, agent, import), the same wall invariants use. Hiding or disabling controls in the UI is derived courtesy, never the guarantee. (For system actors the question dissolves: an unmet gate simply never fires.)
- **The declaration word — DECIDED: `type`.** `type person | organization | system`, an indented actor line (the `boundary external` shape); matches the stored `actor/type` key. Loader default on omission stays person, but best practice writes the line always — `type person` explicit, never omitted ([modeling.md](modeling.md) rule 1).
- **The built-in Person — DECIDED.** The platform-defined Person carries `name` only. Contact and login live on the account; capabilities live on role-holdings.
- **Seed identity — DECIDED: explicit ids.** A seed row may carry an id (spelling at build time); same id = same person across roles; **no id = no merge**, even when names match — names are labels, never identity (a lint flags the duplicate name and asks). The printer writes ids only for people holding more than one role, and an authored id persists as a fact so print → load → print is stable. Store identity stays uids; runtime identity stays the account join.
- **The receiver slot — DECIDED: any slot.** The grants check is satisfied by any position in the beat's own sentence — subject, object, or participant: `AandRScout signs Artist to Deal` may carry `grants SignedArtist to Artist`. The rule's purpose (beat edits carry the grant; people named by a role they hold now) holds regardless of slot.
- **Toy-seed cleanup — DECIDED.** (a) The 13 non-agent actors (Kitchen, Board, TaskList, Cart, Cookie, the Hangman drawing…) reclassify as objects; the seeds re-version under the standing sweep rule. (b) In ontolang an actor exists **only by declaration** — nothing is ever minted from a preposition target; the studio story parser / paste door (parseDSL) flips its default the same way: a name seen only after prepositions classifies as object. [modeling.md](modeling.md) rule 2 carries the practice.
- **Unmanned actors — DECIDED, split on boundary.** Internal and unmanned → `type system`, and there the type is load-bearing: the engine fires its beats. External (`boundary external`) → nothing behavioral hangs on the type — the platform never fires an external actor's beats; they arrive as events from outside. Declare `type system` for software honesty (music's Platform/Spotify), and the lint doesn't nag externals.

**Scope on grants — NARROWED, spun off to a design session.** Owner reading of the three candidate cases: a service *position* is ordinarily plain data on the role-holding (an enum or ref field), not a scope — scope-as-grant earns itself only where access keys off the specific thing (Repository Manager *of this* repository, a key-card door); the repository case is real but the `for Z` phrasing is suspect (misreads as duration); the per-game case (PlayerX *of this* game) may dissolve into story-run binding instead. Tension the design must resolve: if position is a holding field, beats never write holding fields (ratified above) — so what does the appoint beat do? Chip opened; the wild evidence (role-of-thing is the modal wild pattern) rides along.

**RE-SCOPED (owner, 2026-08-27, verification batch C3):** the sangha service position resolved
OUT of this park — `ServiceRole` is an ordinary domain object; `holder: ServiceVolunteer` is a
plain link the assign beat writes (`sets ServiceRole.holder to ServiceVolunteer`, both names in
the sentence); no role-holding field is touched, so the 2026-08-18 tension does not arise. The
park keeps only the genuine access question — **permission checks keyed to a specific instance**
(Repository Manager of THIS repository; key-card doors; the wild-corpus role-of-thing evidence)
— which blocks nothing in the authored corpus. **The owner kicks off this design walk after
sangha lands.** Also dropped the same day: the roles prior-art pass's HL7-RIM/BFO reading tail
(its four hedged claims stay hedged in that doc; reopen only if a domain surfaces it).

**Still open in this set:** rules testing role-holding ("no one holds both PlayerX and PlayerO for the same Game") — **PARKED until both design sessions land** (story-run binding; role scope) — story-run binding (joins tier 2) landed: ratified 2026-08-24 (walk closed; story `about` context), so the rule spelling now waits only on the role-scope session. Their deliverables answer what a holding and a scope *are*, not the rule spelling — the spelling becomes its own focused ruling riding [rule-dsl](../rule-dsl/spec.md) afterward. **Story-run binding (joins tier 2) was spun off to its own design session — that walk closed 2026-08-24.**
