> Portable snapshot of maintained Onto material. [Package capabilities](../../../START_HERE.md) define the shipped boundary; dated decisions and host implementation notes are context. [Source manifest](../../../SOURCE_MANIFEST.json) records provenance. Links marked “Onto source” are optional host/background references.

> **Layer: RUNTIME** — authoritative Story execution and persistent applications.

# rule-runtime — backlog

## Runtime cost and error-boundary review — 2026-11-02

The independent review after the [#302 fixes](spec.md#host-read-and-notification-cost--2026-11-02)
covered complete request paths against current staging, including zero/one/multiple
subscribers, record-count growth, query selectors, idle alarms, expiry/revocation,
compatible/incompatible publication, rollback and receipt retries. It reproduced
three adjacent defects now fixed: expired bearers accepted after queue waits,
whole-project authorization on every ping, and clock refreshes bypassing cursor
invalidation. It also caught two test gaps, now fixed: swallowed exceptions could
omit error cases, and connection handshakes discarded their cost measurements.
Existing correctness tests alone did
not constrain SQL work or subscriber amplification. The new local cost suite is
a guard against those specific regressions, not a general performance guarantee.

The two measured query/catalog findings are now fixed in the
[built runtime](spec.md#host-read-and-notification-cost--2026-11-02): safe SQL
filters precede discovery, and ordinary queries share bounded fact reads while
retaining the shared Story interpreter. Follow-up review caught and fixed an
aggregate read-budget regression and added a failing-guard test after the first
400 candidates. Real Workerd tests exposed its smaller SQL parameter limit,
now handled by the adapter's batch sizes.

The deeper pass found additional correctness defects now fixed: an explicitly
masked record ID could become a target binding in the optimized query; failed
requests could omit invalidation after a committed clock refresh; a failed
alarm could hide an earlier successful crank; and a provider retry could hide
the clock refresh committed by its delivery claim. The load harness also shared
mutable counters between concurrent requests and refreshed only one notified
subscriber. It now isolates counters and measures every subscriber's refresh.
These discoveries are why passing earlier targeted tests was insufficient to
claim all related defects were covered.
Clock-only subset membership and direct temporal read rules/Story guards also
need a view sequence change even when business revision is unchanged. The host
now tracks the committed model/day stamp, advanced without domain writes for
clock-independent projections.

The separate #295 budget work remains: enforce the shared spending cap and
throttling policy, measure billed rows as well as SQL calls, and budget scheduler,
projection and first-use QA identity validation. Exact query counts/search still
examine candidates; cost-bearing and other unsupported query shapes retain their
original evaluation path. Hosted p50/p95 acknowledgement and visible refresh,
billed rows and queue contention still require deployment acceptance.

The delivery, aggregate/projection and subscriber-refresh follow-ups are now
[built in the same PR](spec.md#host-read-and-notification-cost--2026-11-02).
Remaining capacity acceptance must include aggregate-heavy and binding-dependent
models, first-use QA identities, full reference forms, many distinct actors and
real providers. The optimized query's semantic/read ceiling is a bounded refusal,
not a guarantee that every valid model fits. Cost-bearing/approval/ID-masked query
fallbacks and Formula/scheduler work retain their existing per-execution budgets;
the separate #295 work must unify operational/spending policy and billed-row
accounting across those paths.

The 100-subscriber local Workerd probe now completes combined page refreshes with
far less SQL, but repeated bursts can still encounter local transport failures.
The client and harness exercise bounded read recovery and report retry counts;
passing with retries is not clean host capacity acceptance. Diagnose the local
proxy/platform connection failure and verify deployed p50/p95 latency and error
rates before promising 100-subscriber service levels. Standard participant forms
still use full snapshots for reference choices, while QA browsing uses the compact
page path. Broader form/reference paging is follow-up work if its measured cost
becomes material.

Issue #303's attachment byte-PUT handler is absent from current main/staging and
the available source branches. The commits cited in the related #302 report
cannot be resolved on GitHub. Obtain the CARDS deployment source/release before diagnosing or changing
that handler. The local shared error mapper preserves 403/404 across nested
Workerd transactions; that result does not reproduce or resolve #303. Once source
is available, verify read-only PUT denial, unchanged bytes/state, finalize/delete
denials and the authorized upload lifecycle through its actual routes.

## Release scope: QA deployment — 2026-10-31

V1 ships the Cloudflare QA harness with a compact role/user strip, default
selection and the existing generated-profile form for creating fresh test actors.
Target and environment are separate, and the standalone runner accepts QA only. This supersedes real participant authentication as a v1 acceptance gate.
See [built behavior](spec.md#qa-deployment-harness--2026-10-31).

A separate branch will add real authentication and the explicit choice between
simulated identities and real login in QA. Staging and production will use real
authentication with simulation disabled. Additional harness panels, fixture reset/lifecycle
controls and access-sharing options belong in that later branch. Reuse the current
UI; no harness collapse toggle is requested. Preserve current actor policies.

After #220, implement the Ontolang browser application SDK (typed reads/discovery,
commands, receipts, subscriptions and generation/model fences), then migrate the
participant transport and application adapter to it. The package's execution and
operator deployment APIs are not substitutes. Keep the built
[presentation boundary](spec.md#presentation-boundary-and-sdk-readiness--2026-10-31)
and its data/callback renderer contract; do not delay QA landing for this SDK work.
New generators can already supply validated plans. New layout primitives or
arbitrary frontend bundles remain separate work.

## Published application architecture — decision 2026-10-23

Studio and published applications are separate deployable systems. This boundary
guides implementation now; choosing and connecting the project domain can wait.

| Component | Where it runs | Address |
| --- | --- | --- |
| Studio: authoring and model export | Vercel | `app.onto.space` |
| Published project: browser UI and project API | User's Cloudflare account for v1 | Deployment URL or configured custom domain |
| Runtime logic and project state | Cloudflare Workers / Durable Objects | Behind the project API |

Studio owns authoring data; the v1 deployment path consumes a versioned export
or standalone Ontolang files. The runtime owns published state, execution,
authorization, receipts, live subscriptions and effects. It must not import Studio, query its authoring
database during ordinary execution, or require its browser store. A project UUID
is publication identity, not a dependency on Studio's name-based database layout.

The independent participant frontend and project session exchange are built and
locally verified (2026-10-24); see [rendering (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/rendering/spec.md#published-participant-interface--2026-10-10)
and [auth (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/auth/spec.md#published-application-identity--2026-10-10). Studio's legacy
application page redirects to Cloudflare when configured; its compatibility API
is not used by the independent client. Ordinary participant requests do not need
Studio. The existing account sign-in handoff remains explicit and issues only
project-scoped participant authority. This describes the current bridge, not a
mandatory dependency for standalone deployment. The built operator-issued
one-use code path establishes participant identity without Studio or Clerk,
while retaining project access policies and authorization checks.

**One Onto MCP connection:** keep a unified user-facing connection with separate
adapters for Studio authoring/publication and published-application operations.
Each service enforces its own permissions; a participant does not receive Studio
editing authority. Runtime requests go to the independent project API, not a
second local database. Separate services do not require two MCP installations.
The existing Node MCP runtime adapter still needs Cloudflare authentication,
generation/model fences and receipt compatibility; the integration work here does
not claim hosted MCP parity or disable existing Studio MCP tools. The browser's
origin-bound WebSocket ticket is not itself an MCP subscription protocol.

### Next todo: headless publication in three stages — 2026-10-25

Stage 1 integrates PR #240 at `e41b7062` and preserves the independent participant
frontend. Combined-branch verification is recorded in the [built spec](spec.md#ontolang-host-integration--2026-10-25).
Stages 2 and 3 are built and locally verified. The standalone Coffee fixture has
also passed real hosted deployment, participant sign-in and compatible update
checks; see the [hosted evidence](spec.md#hosted-coffee-acceptance--2026-10-25).
Reference Studio/staging acceptance and the operational drills below remain open.

The PR #220 security review also calls for further dependency maintenance before
production rollout. The repeated pass updates Studio to Next.js 16.4.3 and pins
patched DOMPurify / proxy-addr transitives, removing the six critical audit
matches. The root audit still reports 58 high, 49 moderate and 16 low matches;
these require affected-path triage and targeted upgrades. The pinned Wrangler 4.130.0 development
toolchain brings Miniflare dependencies with advisories in the independent hosting
lockfile; these tools are not bundled into the deployed Worker. Check the actual
affected APIs and upgrade/retest both lockfiles and the installed consumer. The
reachable host validation amplification issue is fixed in this PR; passing its
tests does not make the entire repository dependency audit clean.

**V1 deployment decision:** use one standalone deployment path into the user's
Cloudflare account. Source can come from local Ontolang files or a versioned
Studio model exported through MCP. Setup, updates and execution must work without
an Onto-operated publishing endpoint, Studio database or mandatory Clerk account.
Studio model export still uses its existing authoring authorization; running the
exported application does not depend on that connection.

V1 publishing will be agent/MCP/CLI-driven. Build the reusable deployer and release
contract first; updates to the user-facing MCP/CLI can follow. An agent uses the
existing hosted MCP for model export and a local runner for deployment. Hosted
MCP cannot access local Cloudflare credentials. Cloudflare credentials and any
automatically established publishing credential stay in the runner's credential
storage; no new Studio deployment UI or secret storage is required. Save project
identity, deployment URL and deployed revision in a non-secret local manifest.
Studio-side non-secret deployment metadata is optional. Updates explicitly
publish a snapshot; Studio
edits do not automatically change a running application. Onto-operated hosting
and Studio's deployment/credential-management UI are deferred.

**Interchangeable local and Cloudflare targets:** one deployer accepts the same
model, runtime and optional presentation release plus a target configuration.
Wrangler `dev` supplies the local target; Wrangler `deploy` supplies the hosted
Cloudflare target. Both expose the same project API and participant frontend
contract and return a common deployment description containing project identity,
release revision and the relevant application/API URLs. Clients consume this
configuration rather than branching on Wrangler mode or using separate local
and hosted publication protocols. Target-specific credentials, bindings, origins
and lifecycle belong behind the deployer interface. The Node SQLite adapter
does not replace Wrangler as the local Cloudflare-host test target.

The local target is useful for development and verification; v1 published
applications normally use hosted Cloudflare. Target interchangeability does not
imply shared data or automatic migration: local and hosted state stay isolated.
Keep origin/authorization and generation checks intact. Real hosted acceptance
remains separate from emulator checks. A project URL comes from the selected
deployment and routing configuration, not from Studio's `app.onto.space` origin.
Preserve `/apps/<project-id>` participant routing and `/projects/<project-id>`
API routing where applicable; the selected origin changes without requiring a
different client. `runtime.onto.space` and `staging-runtime.onto.space` are reference
deployment origins, not required domains for users bringing their own accounts.
Custom domain selection and per-project subdomains remain deferred; project
identity and release compatibility must not depend on the chosen hostname.

1. **Integrated: [PR #240](https://github.com/trigramco/onto/pull/240).** The
   single package, semantic fixes and host transaction boundaries are combined in
   #220. This is branch integration, not a merge into staging. See the
   [integration evidence](spec.md#ontolang-host-integration--2026-10-25).
2. **Built locally: standalone deployment/publication foundation.** Concrete
   adapters, the complete tarball, stable headless identity, common target interface,
   credential storage and standalone participant authentication are in the
   [built spec](spec.md#standalone-deployment-foundation--2026-10-25) and
   [distribution/acceptance guide (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/hosting/DEPLOYMENT.md).
3. **Built locally: optional presentation artifacts.** Validated model-bound
   plans/designs are stored atomically with the release in project SQLite and
   rendered from Static Assets. API-only projects and the default renderer work.
   The [built contract](spec.md#published-presentation-releases--2026-10-25)
   records validation, storage and compatibility; [rendering (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/rendering/spec.md#published-plan-renderer--2026-10-25)
   records the extracted branch modules and migration reconciliation. Custom
   frontend descriptors are defined; custom builds/upload/storage remain deferred.

**Agreed package organization:** use `packages/ontolang/` without a `src/`
wrapper. The descriptions below name responsibilities, not files. Concrete
adapters are built; SDK folders are created only as needed.

```text
ontolang/
  language/
    Parsing, printing, validation and model definitions

  runtimes/
    typescript/
      engine/
        Story, Rule and Formula execution
      adapters/
        Shared adapter contracts and helpers
        node-sqlite/       Concrete Node adapter
        cloudflare/        Concrete Durable Object adapter

  sdks/
    typescript/            Future consumer-facing SDK
    python/                Possible future SDK

  examples/
  test/
  package.json
```

Node SQLite and Cloudflare are adapters for the same runtime. SDKs provide
consumer APIs for publishing, invoking projects and subscribing to updates;
an SDK language does not imply another runtime implementation. Additional
runtimes, Python SDKs, runtime discovery, plugins and selection machinery remain
deferred. Preserve behavioral conformance fixtures for future implementations
without requiring them to share internal compiled objects. Public imports need
not expose implementation directory names. Do not create empty scaffolding.

These boundaries support later repository extraction; the single package is the
immediate distribution boundary. Studio-specific authoring/authentication stays
in Studio; deployment consumes a versioned export. Final project-domain
setup is deferred and must not block this work.

After the three stages:

1. Add the v1 MCP/CLI publishing workflow over the standalone deployer, including
   repeatable export/deploy/update and local deployment manifests/credentials.
   Adapt runtime operations to the independent project API with authentication,
   generation/model fences and receipts. Preserve one user-facing Onto MCP
   connection where the agent already has local command execution; a separate
   MCP installation is not required just to call the deployer.
2. Complete hosted staging acceptance (including standalone participant identity
   and the actual Clerk handoff where that optional integration is configured),
   production configuration and release/recovery validation. Provider delivery
   needs its own configured, verified recipients. Decide whether upstream
   account revocation needs to revoke independent application sessions before
   rollout; current application sessions expire after eight hours.
3. Connect optional custom domains and project-host routing after these boundaries
   work. Public project labels must be DNS-safe; the 64-character internal runtime
   ID cannot be used verbatim as a DNS label. Domain choice must not change the
   permanent runtime identity or grant access to another project.

[Rendering (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/rendering/backlog.md#custom-published-frontends--deferred-requirement-2026-10-11)
tracks later custom frontend assets. R2 versus separately deployed Static Assets
is undecided for generated code; the shared renderer already uses Static Assets.

## Hosted verification still required

The standalone correctness review fixed Worker/Queue collision handling,
credential replacement, release concurrency and generation-reset paths; see the
[built review](spec.md#standalone-correctness-review--2026-10-25). The
[hosted Coffee fixture](spec.md#hosted-coffee-acceptance--2026-10-25) now verifies
OAuth deployment, standalone sign-in, subscriptions, concurrent execution and a
compatible redeployment retaining state and receipts. The
[browser login flow](spec.md#standalone-cloudflare-browser-login--2026-10-25)
now handles scopes, refresh and account discovery; manual API-token setup is
optional for local runners. Serialize infrastructure deployments per
Worker name; distributed infrastructure locking and automatic Worker/assets
rollback are not implemented. Hard-crash recovery may require verifying the old
runner is stopped and removing its stale lock while preserving all state.

**Publication implementation:** the real application runtime now runs in local
Wrangler Durable Objects, with stable project routing, generation checks and durable receipts,
participant drafts, live views, signed webhooks and delivery pause/resume.
See [built scope](spec.md#local-publication-host--2026-10-10)
and [setup (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/hosting/README.md). PR #216 has merged into staging.
The standalone Coffee fixture is deployed; the reference Studio/staging host and
production delivery providers have not been configured by this acceptance run.

Alongside the architecture work above, hosted verification requires operator
configuration and external acceptance:

- Preserve the frontend-independent API for deferred custom UI; review draft and
  provider payload handling before admitting sensitive data.
- Apply Studio migration `0026` before deploying the new Studio code; provision the staging custom domain, Queue and
  Worker with the plan-first tooling. Install matching issuer secrets.
- Configure delivery and alert recipients that verify signatures and deduplicate
  stable keys; exercise delivery pause/resume and failed-delivery retries.
- Run the isolated staging fixture drill, then validate real cold starts,
  concurrent load, quotas, platform durability and issuer key rotation.
- Complete owner acceptance of participant enrollment, invitations, reconnects,
  draft/receipt recovery and delivery controls against the deployed staging system.
## Package release and host integration

The [single Ontolang package](../ontolang/spec.md#single-package-organization--2026-10-25)
is integrated into PR #220 with standalone deployment and optional presentation
artifacts. Complete hosted acceptance, establish one package
release version and decide repository ownership. Until registry publication,
share one Ontolang tarball.

Before rollout, republish applications with compiler-version `1` command schemas
to install the [compiler-version `2` defaults and capture mappings](spec.md#extraction-regression-review--2026-10-13).
Interpreter stamp `semantics:4` refreshes persisted runtime state and wakes cached
System schedules without a source edit; completed receipts and completion keys
remain valid. Review existing inconsistent stored relationships separately and
repair them through explicit relinks; the new seed checks do not migrate facts.

The combined host uses packaged semantics and concrete Node SQLite/Cloudflare
adapters. Their extracted implementation retains indexed reads, refusal rollback,
dependency metadata, receipts, restart, alarms and effect delivery. Language and
pure execution imports remain platform-independent. See the
[built foundation](spec.md#standalone-deployment-foundation--2026-10-25).

Consumer-facing publication/API/subscription libraries belong in future
`sdks/typescript/` and possibly `sdks/python/`. Neither SDKs nor empty future
folders are part of #240. Other execution languages should use the preserved
behavioral conformance fixtures; do not add discovery/plugins/selection machinery
or a speculative universal execution interface.

## Language review runtime follow-up — 2026-10-10

The confirmed arithmetic overflow, allocation and calendar defects are fixed;
see [numeric safety and deployment](spec.md#numeric-safety-and-calendar-arithmetic--2026-10-10).
Ship the shared runtime changes with Ontolang, then recompile and republish
existing applications to refresh saved formulas. Review sources newly rejected
by semantic validation and Rule/Formula strings whose backslashes were
previously consumed by the lexer. These are deployment checks, not remaining
interpreter implementation work for this language pass.

## Read head — 2026-10-10

The local runtime corpus build is described in the [spec](spec.md#local-corpus-enrollment-and-scheduling--2026-10-10).
It includes PR #210's Investment Bank/every work, Coffee
enrollment, public System/timer log replay, canonical sources for all 16 projects
and ten additional persistent workflow fixtures. The [generated matrix (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/reports/runtime-corpus-sweep/matrix.md)
separates publication, isolated probes and actual workflow evidence.

### Recovery and sensitive-data review — 2026-10-11

**Decision: defer application backup exports and project restore beyond v1.**
Cloudflare SQLite DOs provide [30-day point-in-time recovery](https://developers.cloudflare.com/durable-objects/api/sqlite-storage-api/#pitr-point-in-time-recovery-api),
covering stored SQL and KV data. This is the v1 backup baseline. Custom scheduled
R2 exports, backup selection, import jobs, fresh-DO routing cutover and restore UI
have been removed. Normal process restart still uses the same persistent project
storage; it does not require a restore. Request deduplication, generation checks,
live refresh and an owner-controlled external-delivery pause remain built.

Deferred recovery work, in order:

1. **Validate an operator procedure against Cloudflare.** Native PITR is not
   supported by the local emulator. Use an isolated staging fixture to exercise
   bookmark selection, restore/restart and the pre-restore bookmark for undo.
   Record the available window and failure handling before claiming supported
   application recovery. Emergency recovery requires taking the whole project
   offline, stopping scheduled/external work, restoring, verifying data and
   permissions, then explicitly reopening. Closing participant entry or pausing
   delivery alone is insufficient: owners, agents and System Stories still run.
2. **Coordinate recovery outside the database being rewound.** Persist the
   recovery operation and maintenance state independently. Gate HTTP, WebSockets,
   Queue consumers and alarms through restart, then install a fresh generation
   before reopening. Restoring a DO also restores its old flags, receipts and
   permissions; an in-database maintenance flag cannot be the sole control.
   Reconcile access revocations and invitation state, invalidate cursors/sessions
   and require review of uncertain commands with missing receipts. Do not replay
   them automatically under a new key.
3. **Reconcile effects and release versions.** Retain provider idempotency keys
   and review already-sent emails/other effects before resuming restored outbox
   work. Data rollback cannot undo external work. Verify restored model/schema
   compatibility with deployed runtime code and the selected frontend release;
   PITR does not roll back Worker code or future R2 UI assets.
4. **Add a product restore flow only after the operator path is proven.** Scope
   authorization, target-time selection, explicit data-loss confirmation, status,
   interruption/retry handling and failure recovery. Keep the protocol usable
   by generated and custom frontends. Test failure/restart windows and stale
   browsers/Queue messages against real Cloudflare recovery.
5. **Revisit optional exports when there is a concrete need.** Long retention,
   portability, cross-environment migration or analytics may justify logical R2
   exports. Design consistent bounded paging, resumable jobs, versioned manifests,
   checksums, rowid/sequence fidelity and full facts/receipts/permissions/outbox
   coverage together with a restore drill. Do not recreate them as a default
   nightly backup layer without those requirements.

Before real sensitive data, decide access, retention/deletion, audit and whether
application-managed encryption is required. Cloudflare encrypts
[DO storage](https://developers.cloudflare.com/durable-objects/reference/data-security/)
at rest using managed keys; native recovery history remains a retained copy.
Review browser drafts, invitation payloads, logs and provider records. Future
exports need a separate decision about field redaction, encryption, private
storage and retention of replaced authorities. Keep public frontend assets
separate from any future private snapshots and secrets. No sensitive-data policy
has been signed off.

Hosted owner actor switching remains available. Standalone QA now has an isolated
deployment boundary and restricted actor selection; richer preview datasets,
reset and lifecycle controls remain deferred; Node persona-demo creation is not implemented
by the Worker protocol. Invitations are currently owner initiated; model-driven
or delegated invitation management is a separate extension. Custom frontend
requirements are owned by the [rendering backlog (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/rendering/backlog.md#custom-published-frontends--deferred-requirement-2026-10-11).

### Before deployment

1. **Sangha owner acceptance:** attendance/capacity rules and the indirect-invariant
   runtime fix are [built](spec.md#sangha-attendance-and-capacity--2026-10-10).
   Confirm the policy assumptions and follow the [owner checklist (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/rule-runtime/baseline.md#sangha-owner-acceptance--2026-10-10)
   in a fresh version-5 model, including
   attendance changing derived membership, application-driven grants, refused
   actions and browse visibility. Hotel and Investment Bank already have recorded
   owner acceptance; preserve those records. Review the new Coffee enrollment and
   representative remaining-model workflows. Automated checks do not sign off UX.
2. **Runtime PR merged:** #216 incorporates PR #210 and is now on staging.
   PR #240's consolidated Ontolang package is integrated in this host branch;
   the standalone deployer and presentation releases are built locally. Hosted
   acceptance is next.
2. **Review and merge the runtime PR.** It incorporates PR #210; avoid merging a
   competing copy of that branch. The Ontolang integration adds its semantic
   validation, standalone vocabulary and RDF exporter against current staging.
   The [deep review (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/reports/runtime-corpus-sweep/deep-review.md) records
   reproduced runtime defects and fixes from the follow-up passes. Owner acceptance
   remains separate from technical verification.
3. **Validate the deployed host** using the preserved
   [architecture proposal (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/runtime-v1/README.md). The local Node/SQLite worker
   is built; the Durable Object/Worker gateway, alarms, Queues and delivery
   controls now have local coverage. Secrets, provider configuration and operational rollout
   are not deployed. Run hosted
   restart, concurrency, clock and authorization checks before release. Database
   rewind/export acceptance belongs to the deferred recovery work above.
4. **Configure real participant entry and effects.** The local trusted adapters
   and authenticated/public API are built. Participant-facing signup/invitation
   screens and external-organization account entry have local coverage.
   Signed invitation delivery is built; real recipients and service identities
   require deployment configuration. Configure management
   authority explicitly; current authority is the verified project owner.
   Provider handlers must deduplicate stable effect keys. No provider is selected
   or called by the current fixtures; the signed recipient in tests is local.

### Remaining language/host boundaries

- Automatic system `every` needs a frozen durable system-batch plan; it is not
  silently treated as a one-shot command. Current corpus automatic paths do not
  use it. Person-triggered `every` is already durable and resumable.
- A genuinely recurring effect over the same bindings needs an occurrence token.
  Successful effect completion is not reset by changing an unrelated model field.
- Computed/ambiguous role capabilities remain rejected. None of this corpus uses
  computed role fields. Independent bare actor roles have separate domain records
  linked to one account; a unified person substrate is a deliberate migration.
- Legacy models missing policies remain private owner QA only. Ratified full
  participant deployment requires explicit affiliation/access/applicable signup.
  Do not replace Sangha's derived roles as an incidental data migration.
- Some imported/narrative Stories remain external event contracts or need more
  domain fixtures. Publication and a successful isolated probe are not proof of
  every workflow. See fixture coverage and probe gaps in the generated matrix.
- A broader UI DSL, authored refusal copy, scenario clock
  presentation and provider-specific effects remain separate features. Shared
  TypeScript interpretation is the engine; the abandoned separate fast-engine
  port is not a next step.

### Working data and verification

The build uses an isolated checkout and disposable test databases. Do not reset
`studio/.onto-projects` or `studio/.onto-runtime` in an existing owner environment.
Committed seeds and walkthroughs travel with Git; local databases do not.
`pnpm dev` starts the local scheduler; `pnpm dev:server` starts only the web server.
Use `ONTO_RUNTIME_DIR` consistently for the server, worker and integration tests.
See [baseline (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/rule-runtime/baseline.md) for existing Hotel/Investment Bank acceptance records
and [data/transport proposal (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/rule-runtime/data-and-transport-stack.md) for production design.
