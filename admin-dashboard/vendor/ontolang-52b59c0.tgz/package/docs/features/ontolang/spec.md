> Portable snapshot of maintained Onto material. [Package capabilities](../../../START_HERE.md) define the shipped boundary; dated decisions and host implementation notes are context. [Source manifest](../../../SOURCE_MANIFEST.json) records provenance. Links marked “Onto source” are optional host/background references.

> **Layer: AUTHORING-TIME** — the **canonical text representation** of the model. The studio does not run on files — it **loads** `.onto` in (import door, initial snapshots) and **prints** `.onto` out (export, compaction, the publish artifact); the truth of live authoring is the **op log** ([authoring-sync (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/authoring-sync/backlog.md), decisions 2026-07-28).

# ontolang — spec (what's built)


## Single package organization — 2026-10-25

`@trigramco/ontolang` is one installable package containing the language and its
current TypeScript execution engine. `packages/ontolang/language/` owns parsing,
printing, validation and language/model definitions. `runtimes/typescript/engine/`
owns Story, Rule and Formula execution, and `runtimes/typescript/adapters/` owns
shared contracts/helpers and the concrete Node SQLite/Cloudflare adapters. There is no `src/`
wrapper. `examples/`, `test/` and `package.json` stay at the package root, alongside
the portable documentation/editor kit. The redundant runtime workspace is removed.

The root entry retains language APIs; `/runtime` supplies execution and
`/runtime/adapters` supplies trusted shared adapter contracts/helpers, not complete
database implementations. Existing `/node`, `/rdf`, `/editor`, `/rules`, `/model`,
`/semantics`, `/classification`, `/catalog`, `/templates` and `/walkthroughs`
entries remain public with JavaScript and declarations. Implementation directories
are private. Parser-only imports do not load the engine; browser/Worker entries
exclude Node-only and Studio dependencies. One packed tarball can parse and execute
outside Onto without dependency overrides, Studio, Clerk or an authoring database.

`runtimes/typescript/adapters/node-sqlite/` and `cloudflare/` are concrete
adapters for the same runtime. Future `sdks/typescript/` and possibly `sdks/python/`
are consumer libraries for publication, project API calls and subscriptions;
an SDK language does not imply another execution runtime. Only SDK folders remain reserved and unscaffolded. Additional
runtimes can use the existing behavioral fixtures; no runtime discovery, plugins,
selection machinery or universal execution interface is introduced.

The six existing execution logs ship with the example models and run against the
installed package. Root reference/SQLite conformance and persistent workflow
fixtures remain intact. Execution behavior and persistence upgrades are owned by
[the runtime spec](../rule-runtime/spec.md#independent-execution-package--2026-10-13).

Studio browser verification executes the combined store/editor/package bundle in
both normal and minified forms (`pnpm test:studio-ontolang`), covering inherited
field completion, highlighting, Rule validation and publication followed by
execution. Language module initialization is retained during bundling; applying
`sideEffects: false` to the entire consolidated package drops initialization in
Studio’s mixed ESM/CommonJS graph and crashes field highlighting. Runtime helpers
remain tree-shakeable, with a packed-consumer bundle-size check. This regression
check runs in the full test suite and package CI.

Concrete adapter entries and the deployable host/runner are built in PR #220;
see the [owning deployment spec](../rule-runtime/spec.md#standalone-deployment-foundation--2026-10-25).
Optional model-bound presentation snapshots are also built. Broader SDKs follow.
Deployment accounts, bindings,
domains and secrets remain the deploying application's responsibility.

## Independent language package — 2026-10-13

`packages/ontolang` is the private `@trigramco/ontolang` workspace package. It owns
`ProjectModel`, the Story/Rule/Formula parsers, canonical printer, semantic
validation, vocabulary pins, RDF export, shared scalar/classification helpers,
portable template composition and walkthrough configuration.
Built public entries separate browser-safe language/editor/RDF code from Node
filesystem loading. Language source does not import Studio, registered example/template libraries,
application services or execution/storage adapters.

`ProjectModel` includes optional walkthroughs, template applications, Story
folders and inert template extensions. Root parse/print APIs and Node directory
loading validate and round-trip `templates.json` and `walkthroughs.json` alongside
source and vocabulary pins. Empty lists remain explicit. Stable Story identities
use sentence, parent and occurrence, preserving repeated sentences and canonical
child ordering; invalid identities, folder references or hierarchy cycles refuse
before any companion mutation.

The `/templates` entry owns generic definitions, module dependency selection,
source fragments, pure composition, conservative detach/removal and provenance.
Its input is ordinary model content, with caller-provided definitions. Unknown
companion fields travel as bounded inert `templateExtensions`; they cannot replace
version, applications, identities or folders. The `/walkthroughs` entry owns the
existing strict schema and portable types. Walkthrough configuration is guidance;
command/reference validation and runtime navigation belong to the application.
Fragment ownership uses the loader's declaration headers, including flexible
whitespace, comments, full Story titles and their `about` contexts.

Onto's facades add AI proposal interpretation and seed versions. The business
library, picker UI, detection, persistence and runtime hosts remain in Onto.
The assembly hook runs after portable companions and before model-wide validation,
with companion structure rechecked after the hook. It may update companions,
opaque host metadata and Story identities, folders and ordering. Parsed language
source remains read-only, including defaults, initial records and Formula source
and expressions. Imported definitions, actor policies and loaded vocabulary
revisions remain immutable. Execution is owned by the same package’s
[runtime entry](../rule-runtime/spec.md#independent-execution-package--2026-10-13);
persistence and application hosts stay in Onto, with reference/SQLite and
publication tests.
See the [template behavior](../templates/spec.md) and
[host walkthrough validation](../rule-runtime/spec.md#portable-walkthrough-configuration--2026-09-28).

`pnpm build:ontolang` emits JavaScript and declarations; `pnpm watch:ontolang`
rebuilds language and engine edits alongside Studio development. Install, development,
tests and production builds prepare the package before consumers run.
`pnpm test:ontolang` runs built-API tests and checks a packed distribution in an
isolated Node/TypeScript consumer and browser bundle. Package CI runs these checks.
The package README lists its public entries. The specification, full corpus and
editor extension remain here; [repository extraction](backlog.md#repository-extraction)
is the next step.

## Actor policy — built locally, 2026-10-10

Actor declarations accept `@affiliation internal | external`,
`@access authenticated | public | none` and `@signup self | invite | none`.
Values, duplication, declaration placement and signup applicability are validated;
printer, model transport, source/op replay, copying, importer guidance and Studio
actor controls preserve them. `self`/`invite` are only valid for assigned,
authenticated person roles; derived subsets and other actor kinds cannot enroll.
A system cannot use anonymous public entry.

**Omission policy:** incomplete authoring and legacy models remain editable and
private-owner publishable with explicit notices. Participant entry requires
explicit affiliation/access and signup on authenticated person roles. Omission
never infers openness, privilege or default enrollment. External affiliation
never bypasses eligibility. `@boundary external` still records legacy system
execution ownership and is not an alias for affiliation.

The [runtime spec](../rule-runtime/spec.md#actor-entry-and-enrollment) owns verified
entry, invitations, record linking, base prerequisites, suspension and persistence.
Sangha preserves its derived OldStudent and AssistantTeacher-to-Teacher relationship;
changing those domain decisions is not part of this migration. Owner provisioning
is the management authority of the local adapter. Broader management configuration,
participant-facing onboarding and external-provider deployment remain in the
[runtime backlog](../rule-runtime/backlog.md).

Investment Bank's current seed and durable `every` application integration are
documented in the [runtime spec](../rule-runtime/spec.md#investment-bank-and-durable-every-execution--2026-10-01).
The canonical seed uses explicit document fields; multi-target inheritance
remains outside the language. Walkthrough guidance is companion JSON, not new
Ontolang syntax.

**Status:** the loader and printer speak the ratified grammar and the actor-policy annotations above. `parseProjectFiles(id, files)` / `parseProject(dir)` load canonical Ontolang into a ProjectSeed; `printProject(seed)` writes it back. All **16 registered projects** have canonical source with matching round-trip exports. The six established corpora retain golden fixtures and complete execution logs; ten additional models have persistent workflow fixtures. Coffee seed version 16 includes explicit policies and a concrete Product parent; Investment Bank is version 12 and Sangha version 5. The error surface is pinned by parser and runtime tests. → [grammar](grammar.md) · [runtime evidence and limits](../rule-runtime/spec.md#local-corpus-enrollment-and-scheduling--2026-10-10) · [backlog](backlog.md).

Seed generators preserve the committed Coffee version 16 and Record Label
version 7, so regenerating their canonical source fixtures does not downgrade
the version metadata.

## Studio package parity review — 2026-10-23

Publication export recovers named Story blocks and their `about` contexts from
committed top-level Stories, using the same helper as source export. Models with
legacy rows lacking block metadata retain the existing printer fallback.
The 16 canonical examples preserve compiled entities, fields, roles, gates,
writes, Formulas and block membership through browser and MCP authoring stores.
The [rule editor contract](../rule-dsl/spec.md#studio-catalog-and-completion-checks--2026-10-23)
covers role inheritance and numeric completion at the Studio boundary.

Seed records have an existing host distinction: Studio's `seedProject` fills
empty reference fields from available target records in round-robin order.
The standalone package preserves authored absence. Lead Intake therefore gains
three Territory owners when imported into Studio; the other 15 canonical example
seed sets agree after normalizing host record IDs and reference labels. This
review preserves that Studio setup convention; it is not package execution.

## Scoped vocabulary imports — 2026-10-10

Local vocabulary directories can be imported by namespace. Their definitions,
fields, inheritance, roles, subsets, Rules and Formulas retain their contracts.
Imported names are distinct from every independently declared local name:

```onto
import Warehouse from "../warehouse"
import Payments from "../payments"

object Product
  name: string @required
  price: money @required

object StockRequirement
  product: Product @required
  item: Warehouse.Product @required
  unitsPerSale: int @required
  @rule StockRequirement.unitsPerSale is more than 0
```

`Product` is the business's offer; `Warehouse.Product` is the imported physical
stock concept. `StockRequirement` connects records with an explicit quantity.
One offer can require several stock items, and several offers can use the same
stock item. Refer directly to `Warehouse.Product` when that definition already
fits. Neither an import nor a relationship asserts type equivalence. Local
subtypes can use imported parents under the existing inherited-contract checks.
There is no `bind`, `as`, `map`, shape conversion or implicit schema merge.

**Source and scope.** An import is a top-level line in any loaded `.onto` file;
its path is relative to the importing vocabulary/project directory. It selects
the directory's root `.onto` files and `stories/*.onto`. Vocabulary files may
contain actor/object definitions, type annotations and imports. A project header,
Story or seed block in those files is an error. Utility imports install no
workflows, records, permissions, payment execution or warehouse integration.
The consuming project can author its own Stories and seeds using qualified types.
Module references resolve only within that module or its explicit imports;
host definitions cannot accidentally satisfy a missing module dependency.

Names use `Warehouse.Product`, and field access uses
`Warehouse.Product.sku`. Rules, Formulas, inheritance, references, Story
participants/clauses and seeds accept qualified types. Namespace names and
imported local type names have at most 24 characters per segment. Imported
declarations are read-only, including actor affiliation, access and signup
policies. Changed or removed policies fail printing, compilation, publication and
RDF export; local/replayed policy edits refuse before mutation or op emission.
Each imported name must appear exactly once across actor and object declarations;
a duplicate cannot override its pinned policy or kind. An identical policy is an
allowed idempotent write. A local declaration cannot claim a qualified name.
Imports cannot shadow a local type name. Transitive imports are supported;
cycles fail. Repeated references to the same normalized local source use one
definition, with a deterministic canonical namespace. This is local source
identity, not a claim about globally shared ontology identity.

The declared catalog separates qualified type names from field paths, including
capitalized fields (`Warehouse.Box.Product`). `finds` filters remain relative
field paths. `import` is still a legal field name. Comments and quoted annotation
values are inert during qualification; a `|` inside a quoted default is text,
not an enum separator.

Local authoring renames retain qualified policy scopes and imported contracts
through browser and headless replay; see
[read-policy-safe renames (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/entity-authoring/spec.md#read-policy-safe-renames--2026-10-23).

**Pinning and portability.** The first filesystem load captures exact source
files and a SHA-256 digest per module in `ProjectSeed.vocabularyImports`.
`printProject` emits import declarations plus generated `imports.json`, containing
all transitive source snapshots. Reopening prefers that snapshot over the current
source directory and works without the directory. Invalid hashes, missing/unused
modules and changed imported contracts fail explicitly. There is no second
hand-authored package manifest: `.onto` expresses imports and `imports.json`
stores generated pins. A loose source directory without `imports.json` resolves
current local files each time; save the printed files or portable bundle to retain
the selected revisions.

```sh
pnpm onto:bundle examples/vocabulary/vape-shop /tmp/vape-shop.onto-project.json
```

The command writes a new file in the existing portable project format and
refuses to overwrite an artifact. Studio's project import accepts that bundle;
direct source-file imports also accept `imports.json`. Browser import does not
read sibling filesystem directories, so unresolved imports require a bundled
snapshot. To deliberately select changed local sources, use
`--update-imports` with a new output path, or
`parseProject(directory, {updateImports: true})`. This creates a new model revision;
it does not upgrade a running project or migrate its records.

The pure `parseProjectFiles(id, files, {loadVocabulary})` API accepts a synchronous
loader returning `.onto` source files for a normalized relative directory. Supply
`imports.json` instead for portable use. Limits are 64 modules, depth 16, 200 source
files per module and 2 MB of source content across the snapshot; authoring sync's
existing compressed payload limit also applies.

**Authoring and execution.** Source snapshots survive store persistence,
backfill/replay and application publication. Imported definitions cannot be
edited or renamed through authoring helpers; replay validates candidate mutations
before installing them. Compilation, printing and RDF export independently compare imported
contracts with the pinned source. Runtime actor identity fields are added to a
runtime copy after this check. Qualified types execute through the existing
Rule/Formula engine. There is no utility-specific runtime behavior.

Host read policies remain application metadata, separate from vocabulary
invariants. They survive [authoring replay (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/authoring-sync/spec.md#read-policy-preservation-2026-10-10)
and model source edits; the application source carries them in `readRules`.

The [worked examples](../../../examples/vocabulary/README.md) include Warehouse
and Payments, a vape shop with singles/multipacks/kits, and a record label using
the same Warehouse revision. [Vocabulary tests (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/ontolang/vocabulary.test.ts)
and [authoring tests (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/runtime/vocabulary.test.ts) cover independent names,
contract enforcement, source diagnostics, offline reopen and replay/publication.
The [application test (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/rule-runtime/application/current-application.test.ts)
also executes locally authored warehouse movements and payment captures against
these imports, compares the reference and SQLite engines, checks refusals and
reopens the published application. Dependent balance invariants are enforced by
the shared [runtime check](../rule-runtime/spec.md#dependent-invariants--2026-10-10).
Remote registries, version ranges, edit/fork UI and data migrations remain
[deferred](backlog.md#vocabulary-imports--remaining-scope).

## Bounded RDF/RDFS + SHACL export — 2026-10-10

`exportRdf(seed, {baseIri, identifiers?, records?})` in
[`ontolang/export-rdf.ts` (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/ontolang/export-rdf.ts) exports a deterministic
file bundle. It validates model semantics but does not demand workflow readiness.
The pure API and local CLI are built; there is no Studio export menu for this format.
The native `.onto` model remains the editable, executable source. This is one-way
interchange, with no full OWL reasoning, lossless RDF import or runtime replacement.

```sh
pnpm onto:export-rdf examples/ontolang/coffee /tmp/coffee-rdf \
  --base https://example.org/coffee/ \
  --records examples/rdf/coffee-records.json
pnpm onto:validate-rdf /tmp/coffee-rdf
pnpm onto:validate-rdf /tmp/coffee-rdf --complete
```

The output directory must be new. The namespace is explicit and must be an
absolute IRI ending in `/`, `#` or `:`; `example.org` is illustrative. No network
request, upload or publication happens. Omit `--records` for a schema-only export.
The independent validation command requires `data.ttl` and uses the development
RDF dependencies; it exits nonzero on a violation.

| Output | Contract |
|---|---|
| `schema.ttl` | RDFS classes, object inheritance and actor/role/subset class structure; labels, descriptions and declaration-qualified properties. |
| `shapes.ttl` | SHACL Core value types, safe integer bounds, scalar maximum cardinality, enum membership, reference IRI/class checks, inherited field contracts and inverse collection paths. Stored records may omit capture-required fields. |
| `complete-records.shapes.ttl` | The same constraints plus `minCount 1` for unconditional explicit `@required` scalar fields and `qualifiedMinCount 1` for required inverse collections; required strings/enums must be nonempty. This is a static completeness profile, not the whole capture workflow. |
| `data.ttl` | Optional explicitly supplied records. Refs use supplied record IDs, not labels. No defaults, formulas, inverse scalar writes or membership inference run. |
| `identifiers.json` | Public class/property/record IRIs, reusable as explicit overrides. |
| `coverage.json`, `README.txt` | Per-type, per-field, per-Rule, per-Story and seed-data coverage, with partial mappings and omissions named. |

The data graph must include `schema.ttl` so SHACL can see subclass relationships.
Choose one shape profile and validate without additional RDFS/OWL materialization:
domain/range entailment can add classes instead of detecting mistaken references.
Shapes are open to extra properties. A validation pass means only the exported constraints
hold. The validator's reports do not reproduce Onto's commit refusals versus standing
violations.

**Identity:** for a fixed namespace, type/field names and persistent record IDs
produce the same IRIs across exports; labels and input ordering do not affect
record IDs. An inherited field uses its original declaration's predicate. Unrelated
`Customer.name` and `Supplier.name` are separate properties. A rename needs an
explicit mapping from the new local name to its existing public IRI, supplied via
`identifiers` or `--identifiers identifiers.json`; automatic rename tracking is not
built. Colliding IRIs (including generated shape/project IRIs) fail. Native names
are not silently promoted to globally established vocabulary identities.

**Value representation:** strings/enums → `xsd:string`, integers/money/percent →
`xsd:integer`, booleans → `xsd:boolean`, legacy floats → `xsd:double`. Money stays
in exact minor units; currency is not invented. Timestamp date text or integer
timeline values are preserved without guessing a timezone or asserting XSD calendar
validity. Source types and Formula text are annotations. Defaults are annotations
only. Invalid scalar encodings, unsafe integers, unknown fields, duplicate record
IDs, dangling/wrong-type references and unresolved mirrors fail before files are
written. Input records contain only `id`, `type` and `fields`; extra top-level
holdings/metadata are refused rather than silently lost. Native single-parent inheritance is supported; legacy multiple parents
are explicitly outside this profile.

**Inverse collections:** a mirror is a view filtered by its target type, including
descendants. Several collections may share the same inherited reference predicate:
`Account.credits: Credit[]` must ignore valid `Debit` or base `Entry` records that
also reference the account through `Entry.account`. The inverse path uses a
[qualified value shape and count](https://www.w3.org/TR/shacl/#QualifiedValueShapeConstraintComponent),
with a minimum of zero for stored/optional collections and one for unconditional
required collections in the complete-records profile. Unrelated incoming records
neither cause a subtype error nor satisfy that minimum. Collections may overlap;
no disjointness is inferred. Scalar reference class, IRI and maximum-cardinality
checks remain enforced on their declaring types.

**Boundaries:** Rule evaluation, Formula computation, `@unique`, temporal comparisons,
`@final`, conditional applicability/requiredness, Story execution, authorization,
role holdings and derived membership are not translated. Every present construct
gets a partial/omitted coverage item. Role capability properties are omitted rather
than attached to the actor incorrectly. References to roles/subsets retain the
declared class requirement, but this exporter does not establish that membership.
Record input accepts concrete base actors and objects, not role/subset projections.
Seed rows are reported, not silently minted into supposedly persistent records.
Walkthroughs, template membership and Story organization remain portable JSON
companions, preserved by the package; RDF does not translate them.

**Verification:** `pnpm test:rdf` parses RDF with N3 and validates through the
independent `rdf-validate-shacl` implementation. Tests include valid and deliberately
invalid graphs, both requiredness profiles, transitive type/property use, inverse
paths with shared inherited predicates, filtered required counts, exact money,
identity overrides/collisions, Unicode escaping, CLI overwrite
protection and all six source corpora. Both dependencies are development-only;
export itself adds no RDF engine to the app/runtime.

The external format follows [RDF 1.1 Turtle](https://www.w3.org/TR/turtle/) and the
[SHACL Recommendation](https://www.w3.org/TR/shacl/). The validator's
[documented scope](https://github.com/zazuko/rdf-validate-shacl/tree/master/packages/shacl)
is why this first profile stays in SHACL Core.

## The loader — `ontolang/parse-project.ts` (core) + `parse-dir.ts` (Node wrapper)

Relationship pairing uses effective inherited fields. A collection may use an
inherited reference, including a reference to an ancestor of its owner; several
candidates require `@of`. Printing retains that choice even when the additional
candidates are inherited. Explicit scalar `@of` choices also survive printing;
implicit scalar pairs retain the declaring type's relation and do not acquire
new partners solely through a shared ancestor.

An explicit scalar `@of` selects the inverse on both sides. With
`Form.lead: Lead @of(form)`, `Lead.form` is paired and `Lead.sourceForm: Form`
remains a separate directed reference. Explicit choices that contradict each
other are rejected during file loading and direct model compilation, naming
both choices. The [seed and runtime contract](../rule-runtime/spec.md#seed-references-and-inverse-choices--2026-10-10)
also preserves these choices during initialization and subsequent writes.

**`parseProjectFiles(id, {relPath → content})`** is the pure core — no `node:fs`/`path` anywhere in its module graph, so the studio bundles it client-side (the paste/directory door). **`parseProject(dir)`** is the thin Node wrapper over the selected domain directory (`id` = the directory basename). Two whole-model passes — **collect** every block across files, then **resolve + assemble** — with every fragment delegated to the shipped parsers (beat sentences → `parseDSL` + the classifier, rule text → `parseRule`, formulas → `parseFormula`); no grammar is duplicated. **Errors carry `file:line`** (`OntolangError`), and every retired form is a **pointed replaced-syntax error** naming its replacement (the list at the end of this page).

The directory loader, Studio file import and printer also carry an optional
root `walkthroughs.json` companion. It is validated JSON project configuration;
there is no new `.onto` grammar. It round-trips into the seed’s `walkthroughs`
field; the runtime owns its [navigation semantics](../rule-runtime/spec.md#portable-walkthrough-configuration--2026-09-28).

### Recursive domain source loading — 2026-11-01

`readProjectFiles(directory)`, `parseProject(directory)` and
`parseProjectFiles(id, files)` load `.onto` sources recursively as **one domain**.
A standalone Node/TypeScript application can keep `domain/` beside `app/`:

```text
domain/
  project.onto
  customers/entities.onto
  customers/registration.onto
  orders/entities.onto
  orders/fulfillment.onto
  billing/invoicing.onto
```

Pass `./domain` to the Node APIs, or keys such as `customers/entities.onto` to
the pure file-map API. All declarations participate in the same collection and
resolution passes, including cross-folder references, Rules, Formulas, Stories
and seed records. Folders and filenames introduce no namespaces, rename no
entities and imply no separate deployments. Diagnostics retain the complete
relative path and line.

Ordering preserves root `.onto` files first, then direct `stories/*.onto`, then
all other nested `.onto` files. Each group sorts by JavaScript string order
(UTF-16 code units), independent of locale, directory enumeration and file-map
insertion order. Existing flat projects retain their source and Story ordering.
Printing still emits its existing canonical layout; it does not retain folders.

The caller selects the domain root explicitly. Discovery does not search its
parents or sibling `app/`, fixtures or other projects. Dot directories and
`node_modules` are excluded at every depth in both directory and file-map APIs;
other directories within the selected root belong to the domain, so keep unrelated
fixtures outside it. Regular dot-prefixed `.onto` files remain source files.
Descendant symlinks (files or directories, including broken links and cycles) are
skipped. A root selected explicitly may itself be a symlink. File-map source keys
must be relative, slash-separated paths without empty, `.` or `..` segments,
backslashes, colons or control characters; invalid keys are rejected rather than
normalized into aliases.

`imports.json`, `templates.json` and `walkthroughs.json` remain **root** companions.
Additional names supplied to `readProjectFiles` also select root files only.
Nested companion JSON has no effect. Explicit vocabulary imports keep their
[existing root + direct Stories selection and pinned contracts](#scoped-vocabulary-imports--2026-10-10).
An import written in a nested domain file is still relative to the selected
domain root, not that file's folder. Recursion adds no implicit imports or new
vocabulary snapshot paths.
When an explicit import selects a vocabulary directory inside the domain root,
its newly discovered nested sources belong to that vocabulary alone. They do not
also create unqualified domain declarations; transitive imported directories and
portable pins retain the same boundary. Keep domain import declarations outside
the vocabulary directories they select.

The standalone `releaseFromDirectory` uses this same reader. `createRelease`
and host admission parse all selected nested sources and retain existing source
bounds, workflow-readiness and pinned-import validation. Deployment still requires
portable vocabulary pins and does not resolve external import paths. Configurable
domain-root manifests and application scaffolding remain future work.

### Declarations

Entity names are at most **24 characters** (ruled 2026-09-02): a longer
`actor`/`object` declaration is a `file:line` error, and the composer
refuses to mint one. Sangha's two outliers were renamed in the same ruling.

- **Annotations (2026-08-29):** field lines stay bare; every non-field line in a declaration block wears `@` — `@description "…"` (project, block, field, and story positions) · `@type person | organization | system` (actors; **omission = person** — the `SYSTEM_ACTORS` lexicon is demoted on the loader path, so nothing acts autonomously unless the text says so; a role or subset **inherits** the first declared `@type` up its base chain, and a contradicting `@type` on a role is a pointed error) · `@rule <invariant>` (the type-block invariant — replaced `always`) · `@where <predicate>` (derived subset, below) · `@boundary external`.
- **Derived subsets:** `actor NewStudent is a Student` + an indented `@where <predicate>` line flips `is a` from role to **derived subset** — read-only, no fields (pointed error), never seeded, never granted (pointed errors); the predicate validates through the rule grammar with the base as subject; object side symmetric. Emitted as `subsets: {Name: {base, where}}`. A subset in no beat still registers (it exists by derivation). Header `=` subsets are a pointed replaced-syntax error.
- **Roles:** actor `is a` without `@where` stays the role spelling → `roles: {Name: {kind: 'role', base}}`. **Role blocks now accept capability fields and mirror lines** (the 2026-08-26 narrowing + the sangha reference corpus) — they load under the role type in `fields`; every declared role and actor is retained, whether or not a Story uses it. **Capability fields also land in the role catalog** (2026-08-30): the roles map entry carries them (`roles: {Name: {kind, base, fields}}`) as the **assignment edge's schema** — the block's fields are facts about the edge (decision 1, 2026-07-23), and the runtime writes/reads them per holding ([roles-permissions spec](../roles-permissions/spec.md)). Mirror lines and computed fields stay out of the catalog entry — declarations and derivations, never per-holding values.
- **Fields:** scalars (`string int bool timestamp money`), enums (declaration order = **rank only** — birth lives in the creating beat), refs (actors legal targets), and **`Type[]` link lines**. Attributes after the full type: `@required @unique @default(value) @of(field)`; **`@final` trails the status value it marks** (mid-list legal; emitted as `finalValues` on the status field). `@default` on a status enum stays banned (birth is per-door, written in the creating beat).
- **Mirror pairing (2026-08-24/26):** a `Type[]` line pairs with the scalar ref written on the other block — automatic when it is the only candidate, **`@of(field)`** when several links join the same two types (lead-intake `territories: Territory[] @of(owner)` beside `owner`/`backup`); the resolved partner is emitted as `of` on the link field. Unpaired or ambiguous mirrors are pointed errors, and two mirrors claiming one relation error too; **two `[]`-links between the same two types = error** (many-to-many needs a join record); self-pairs inside one block are legal (`parent` beside `children`). **One-to-one:** two scalar links between the same two types pair (Reservation.invoice ↔ Invoice.reservation) — automatic when unique (the pair stays implicit in the IR), `@of` on the scalar when the far side offers several refs (ambiguity without it is a pointed error, and a dangling scalar `@of` is too).

### Stories

- **Story blocks:** `story Title [about Type]` + `@description` are model data now (owner ruling 2026-08-30) — `storyBlocks` at the top level, `story/block` on every beat. **Sentences** parse exactly as before (one spelling, whole-input kind inference, declarations decide kind — since 2026-09-03 in the participant slot too (case-hunt row 14): a DECLARED actor the whole-input vote read as object-ish moves back to the actor slot and keeps/regains `story/recipient`, the vote only ever decides undeclared names, and a declared actor as the beat's direct object still stays a direct object (2026-08-16) — the preposition closed class, at most two participants, `Type:label` colon labels as data). New sentence-level surface: **`every`** — the language's only determiner (one per beat, before a singular noun; `a`/`an`/`the`/`all`/`each` are pointed errors in ANY casing and any position, and a mis-cased `Every` gets its own lowercase teaching — ruled 2026-09-03; a freestanding number is a pointed error naming the value homes) — emitted as `story/every`; a hyphen belongs only in a phrasal verb (re-ruled 2026-09-03, superseding the edge-only rule): any other hyphen-bearing token — name or label, edge or middle (`Order-`, `Gift-Card`, `Order:Bill-`) — is a pointed error in both doors, and a declaration never carries one (`object Gift-Card` is a file error; write `GiftCard`); a participant pair is written once, with the **label part of the pair's identity** (`to Barista:A to Barista:B` is two participants; a duplicate error quotes the pair as written, label included — same ruling); and the **`@correction`** trailing mark (D10d — the correction channel, the only beats that may leave `@final`) — emitted as `story/correction`, the mark stripped from the stored text and re-emitted by the printer.
- **`story Title about Type`** declares the story's working context (binding queue, ratified 2026-08-24); every beat of that story carries `story/about`.
- **The clause family** (bare words under beats; each validated against the declared model and landed on the story datom):
  - `sets <Name>.<field> to <value>` → `story/sets` — status values must be declared (never a silent enum extension), ref writes check the `is a` chain (a role narrows its base: `sets Appointment.teacher to AssistantTeacher`), numbers/bools type-check, money literals scale **digit-exact** from the written text (in `finds` conditions too) and print back as decimals, computed fields refuse writes, and the same field twice in one beat is an error (D12c).
  - `adds <Name> to <Owner>.<field>` → `story/adds` — the collection write; the field must be a `Type[]` link, and a one-link write points back at `sets`.
  - `grants <Role> to <Name>` / `revokes <Role> from <Name>` → `story/grants` / `story/revokes` — the role must be a declared actor (bare actors ARE roles under the collapse; subsets are never granted), and the receiver must be named in the beat's **own sentence** (any slot).
  - `where <Name>.<path> is [not] <Name>` → `story/where` — the entity-to-entity link check; both sides need sources, and disjoint `is a` chains are a pointed error EXCEPT between two actor kinds (person comparisons cross role types — one human under the hats, D13-amended). The membership guard `where <Name> is [not] in <Name>.<[]-field>` (D5) lands in the same list as `{member, in}`.
  - `finds <Type>[:label]` + indented `where`/`and` condition lines (one per line) → `story/finds` — introduces a record the sentence does not name; **bare fields in the conditions belong to the found type**; sentence and `about` names appear as values; exactly-one-match-or-refuse is the runtime's job.
  - **Every clause name needs a source** — the beat's sentence (token verbatim, labels included: `where Reservation.room is Room:current`), the story's `about`, or a `finds` introduction; anything else is a pointed error naming the finds fix.
- **Written birth (2026-08-29; the door rule sharpened 2026-09-05 with the runtime catch-up):** a beat is **creating** when nothing on it — or on any enclosing beat — presupposes its primary exists (no gate reads the primary's status, no `where` names it, no `finds` reaches it); then, for a status-bearing primary, the **written birth line** decides on a creating or unknown verb (an instantiate verb with a `finds` and no line is not a door; a curated transition/modify/query/emit verb never is — `completes Task` with no gate stays a transition), and a status-less primary has only the classifier's instantiate verdict (the point-event gap, recorded in the backlog). The runtime compiles the same rule (`rule-runtime/model.ts`). A creating beat's `sets X.status to "value"` is the **birth** — any declared value, per-door births first-class — and never a transition edge; omitted at the door it **fills with the first declared value**, so canon is always complete (the printer always emits the line). Every other status write on the primary is the beat's **`story/transition-to`** edge. The `produces` suffix and load-time verb conjugation are gone (D7 — pointed error). Seed rows may write `status:`; omitted, the first declared value fills only for managed lifecycles (below).

### Standalone models and workflow readiness — 2026-10-10

Actors, objects, fields, relationships, subsets, invariants and formulas may be
declared without Stories. Unused declarations remain in the model and its printed
source, including every actor kind and unused roles. A model with no Stories does
not acquire an empty Story block when printed. This is normal language behavior;
there is no ontology mode or alternate syntax. Unused vocabulary is also legal
alongside executable Stories and in published applications.

Object parents stay concrete. `object Bond is a Asset` declares conformance and
inherited fields; adding or removing Stories about either type never changes
that type graph. Both parent and child may carry records and participate in
polymorphic queries. Only an authored creating Story supplies a Story creation
action. Coffee's `Product` follows the same contract (seed v16). Reference-data
discovery includes a reached concrete parent and its concrete subtypes, so Coffee's
Product, Drink and Pastry remain available in the catalog rail through Order.product.

The internal store still supports explicit legacy `abstract` flags, but Ontolang
has no spelling for them. The printer now refuses these flags instead of silently
dropping their restriction. Stored flags are not automatically cleared: earlier
inferred flags and deliberately authored flags have no provenance to distinguish
them. Converting such a model to the current concrete-parent contract requires
deliberately removing the flag before native export or current-source publication.
The updated Coffee seed supplies that conversion for the bundled example.

A `status` enum is descriptive until a Story writes it. Reading it in a rule,
subset, formula, query Story or seed record does not make it a managed lifecycle.
Descriptive vocabularies need no producers or `@final` values. An omitted seed
status stays absent. Existing creating doors still fill their written birth, and
managed-lifecycle seed rows still default to the first declared value.

`rule-dsl/lifecycle-validation.ts` owns application-readiness analysis. Status
writes through a subset manage its underlying base; base writes also manage
descendants with the inherited field. Checks apply only to those managed lists:

- A list read by predicates/formulas or seed records needs an `@final` ending.
- Every value needs a written producer or a seed record.
- A list with endings needs a written route from each nonfinal value to an ending.
  Creating a new record supplies a producer, never a transition on an existing
  record. Cycles with an exit are legal. An unconstrained non-creating write is
  considered reachable from any nonfinal value; this is a structural check,
  not a proof that all data-dependent gates can be satisfied.
- A write whose gates or finds explicitly select a final from-value contradicts
  `@final` and remains a source error unless marked `@correction`. Corrections do
  not supply normal lifecycle producers or routes.

Incomplete workflows are legal authoring drafts. `parseProjectFiles(id, files,
{onDiagnostic})` and `parseProject(dir, {onDiagnostic})` report nonblocking
`workflow-readiness` diagnostics with a code, type, message and `file:line`.
`analyzeWorkflows(model)` returns the same checks over the assembled model.
`compileModel` enforces readiness with `WorkflowValidationError`, so reference
execution and current application publication reject incomplete managed workflows.
The server reparses the canonical source and repeats the check. Standalone models
can publish without authored Story commands; existing owner data controls remain.
Studio's lifecycle coaching is limited to managed statuses, and live-session
Stories may be kept independently while their workflow is incomplete.

Declaration/type correctness, field contracts, predicate bindings, acyclic
derivation and explicit final-state contradictions still block loading. This
change does not add recursive inference or open-world logic. The bounded RDF/SHACL export above is a separate interchange feature.
Regression coverage: `ontolang/standalone.test.ts`, the loader readiness tests,
store import/export, live-session draft tests, and the existing execution corpora.

### Rules and formulas

Gates (`requires`/`forbids` — `ensures` retired, D12a) and `@rule` invariants validate through `parseRule`, which now speaks the ratified quantifier family: **`some`** joins `no`/`all` beside the numeric bounds; the **`per`** counting scope (`at most 1 RetreatBooking per student and retreat [where …]`, D11c); the **trailing collection restrictor** (`no status is "attended" in retreatBookings` — closes exactly that atom, bare fields are the element's) and the introducer-first layout (`no RetreatBooking in retreatBookings` + filters); **`every X in <[]-field> [where …]`** (all emitted as `CollectionQuantAtom` / `per` on `CardinalityAtom` — parse-validated; runtime evaluation rides the joins queue). Formulas add **collection-scoped aggregation** — `count of bookings where …` and the D5 form `count of RetreatBooking in Retreat.bookings where …` both lower to the existing via-scoped agg IR through the mirror's paired ref (many-links never appear mid-path) — and **division with a mandatory rounding word** (`… / capacity rounded down` or `rounded up`; bare `/` is a pointed error — D14c, no global default; `rounded nearest` was cut by owner spelling 2026-08-30 until a corpus formula demands it). **`avg` names its rounding the same way** (`avg of Service.charge rounded down` — D14c covers "division/avg results"; a bare `avg` is a pointed error, so a fractional result never flows silently). The evaluator applies the words. **The money split has its surface (owner, 2026-08-30):** `split of <money-total> across <[]-collection>` — written on the MEMBER type, each member computes its own share; largest-remainder (leftover minor units to the first members in creation order), so the shares always reconcile to the total exactly; fail-closed for a subject outside the collection. The aggregation word is **`average`** (`avg` renamed 2026-08-30 — pointed error; the IR op stays `avg`).

### Complete-model semantic validation — 2026-10-10

`rule-dsl/model-validation.ts` validates the assembled model on file load and
at `compileModel`, including the current publication path. Invalid models fail
before execution. Draft storage and low-level AST evaluators are not admission
boundaries. The shared checks have four parts:

- **Inherited contracts:** a redeclared field retains its primitive type, ref
  target, enum values and their order, final values, inverse partner, default,
  applicability condition, and any inherited computed definition. Required and
  unique constraints can be strengthened but cannot be removed. A stored field
  can become computed if it retains its type and constraints; an inherited
  computed field cannot become editable or acquire a different formula. New
  fields are allowed. Omitting a redeclaration inherits the original definition.
  An identical computed expression with an explicit ancestor qualifier remains
  legal, as does the current-type spelling of that qualifier; Story labels and
  changed expressions remain distinct. Rules and formulas resolve against the
  effective inherited catalog.
- **Predicate checks:** one validator checks rule gates/invariants, subset
  predicates, formula conditions and aggregate filters, and `finds` conditions.
  It resolves every path, requires scalar refs on intermediate hops, checks
  comparison kinds and enum literals, collection endpoints, quantifier filters,
  counting bounds and `per` fields. A rule's record references need bindings from
  its type attachment, Story sentence, `about`, `finds`, or quantified member.
  Legacy `float` fields retain numeric ordered comparisons; counting bounds
  remain integer-only. Scalar/ref `exists` is legal; collections require member
  quantifiers rather than scalar existence checks. Labels remain exact; an
  unrelated declared type is not an implicit binding.
  Story `where` identity clauses require a scalar record reference; membership
  clauses require a collection. Neither `where` nor `finds` can equate a text
  field with a record or apply an ordered comparison to record identities.
- **Acyclic derivation:** subset membership and computed fields share one
  dependency graph. Ref paths, collections, filters, conditions, aggregation and
  subtype reads contribute edges. Positive recursion, negative recursion and
  mixed subset/formula cycles all fail with a named cycle and source location.
  Ordinary cyclic record references remain legal. Recursive inference is omitted.
- **Missing-data advice:** loading can receive warnings through
  `parseProjectFiles(id, files, {onDiagnostic})`; compiled models expose `warnings`.
  The Rule editor displays the same nonblocking advice for optional scalar reads
  in negative requirements and positive prohibitions. Explicit existence checks
  are intentional; a positive conjunct establishing the value suppresses advice
  in that branch. Warnings never rewrite predicates or change their truth values.

Native seed rows additionally validate each supplied scalar against its declared,
inherited field before publication: safe integers, booleans, strings, valid
calendar timestamps and declared enum values. Money is scaled exactly before
checking its stored value; references remain quoted labels resolved when the
seed world is built. Integer defaults must also be safe integers. Missing
capture-required fields remain legal in reference/catalog seeds. The stored
scalar contract is shared with current application publication.

Creation detection is shared between loading, workflow readiness and execution.
It reads parsed status predicates against the exact primary binding and effective
field catalog; quoted text such as `"Ticket.status"` has no effect. Reading an
existing `Ticket` does not suppress creation of a distinct `Ticket:copy`, while
a case-forgiving `Ticket.Status` read still presupposes the primary record exists.
The loader alone may fill an omitted initial status before compilation.

The operational truth table is preserved, including the distinction between
rule negation and query-filter inequality:

| Condition | Missing value or unresolved scalar path | Known empty collection |
| --- | --- | --- |
| `x is 4`, `x is more than 4` | false | — |
| `x is not 4`, `not x is more than 4` | true | — |
| `x exists` / `not x exists` | false / true | — |
| `some Entry in entries` | false if owner/path is unresolved | false |
| `no Entry in entries` | false if owner/path is unresolved | true |
| `all Entry in entries where …` | false if owner/path is unresolved | true |
| `where amount is not 4` in a query/aggregate/`finds` filter | false | — |

`requires` demands a true predicate; `forbids` demands a false predicate.
Thus `forbids x is 4` allows an unset `x`. To demand a value, add
`requires x exists`. A stored ref can exist even when its target is absent;
`x.targetField exists` checks the traversed value. Conditional formulas and
subset predicates use rule-atom truth values. Regression coverage lives in
`rule-dsl/semantic-validation.test.ts`, `rule-runtime/missing-data.test.ts`, and
the Rule editor component test.

### Literal fidelity — 2026-10-10

Authored integer literals must be safe integers, from `-9007199254740991` to
`9007199254740991`. This applies to Rules, counting bounds, Formula literals and
filters, Story writes/finds, defaults and seeds. Money literals must fit the same
range after conversion to minor units. Oversized values fail at their source;
they never enter the model as rounded numbers or infinity.
Integer seeds, writes and find filters also reject decimal spellings before
floating-point rounding or underflow can hide their fraction. For example,
`9007199254740990.1` cannot silently become `9007199254740990`; `1.0` also requires
a money context, while an integer field takes `1`.

The printer formats money directly from the minor-unit digits in defaults,
seeds, `sets` and `finds`, including negative amounts and the range boundaries.
For example, `90071992547409.90` round-trips exactly. An unsafe money value supplied
through a hand-built model fails printing. Duplicate enum values and repeated
fields within one seed record fail loading rather than changing rank or silently
discarding an authored value.

Backslashes are literal text in quoted strings; there is no escape syntax.
Rules and Formulas accept either quote delimiter. Native annotations, defaults,
seeds and Story value clauses use double quotes and reject embedded delimiters
that could not survive printing. Quoted `#` characters are values, including in
single-quoted Rules/Formulas and imported definitions; unquoted `#` begins a
comment. Apostrophes in Story titles remain ordinary prose.

**Runtime handoff:** parser checks now have matching
[runtime numeric safeguards](../rule-runtime/spec.md#numeric-safety-and-calendar-arithmetic--2026-10-10).
Unsafe arithmetic refuses the entire write in both the reference and SQLite
runtimes; exact allocation and calendar corrections ship alongside it.
Programs containing backslashes in Rule/Formula strings need source recompilation
and review: the previous fragment lexer consumed the backslashes. The runtime
interprets the parsed literal value, so this correction adds no new AST construct.

### Parser review follow-up — 2026-10-10

Labeled Story paths retain the record token separately from every field:
`Warehouse.Case:chosen.box.Product` resolves to `Warehouse.Case:chosen`, `box`,
and `Product`. This works for local names, qualified names and capitalized fields,
and survives printing and execution compilation. Rule gates now also accept
labeled field/identity references and negative comparison values, preserving
exact participant bindings through printing, compilation and execution.
Collection type names cannot carry record labels, and undeclared Story labels
are rejected. Negative comparison values also work in both collection layouts:
`every Item in Batch.items where amount is more than -1` and
`all amount is more than -1 in Batch.items`.

The [runtime binding follow-up](../rule-runtime/spec.md#record-bindings-in-quantified-gates--2026-10-10)
keeps labeled outer references separate from counted members and tracks
collection count bounds as required inputs. Distinct `finds` slots cannot supply
missing participants or change the creation verdict for a differently labeled
primary record. Both execution engines share these corrections; republish saved
applications to refresh their command inputs and creation behavior.

The [Formula parser](../rule-dsl/spec.md#the-formula-parser-rule-dslformula-parsets)
also accepts negative aggregate-filter literals and scopes aggregates through
references to a subject's parent type. A `Premium is a Account` total over
`Movement.account: Account` stays local to each Premium record. Multiple eligible
references require an explicit `via`; they cannot accidentally select a global sum.
These parser fixes emit existing AST constructs and require no new interpreter
construct or database schema change. The separate runtime arithmetic safeguards
and publication upgrade are described in the [runtime spec](../rule-runtime/spec.md#numeric-safety-and-calendar-arithmetic--2026-10-10). Previously published affected formulas must be
recompiled from source and republished to rebuild their stored values; reopening
alone retains the old results. A disposable SQLite upgrade check reproduced
`[14, 14]` before the correction and `[-6, 20]` after republication for two accounts.

### Cross-feature contract review — 2026-10-10

Timestamp literals in predicates must be valid calendar dates or supported
zoneless timestamps, using the same validation as stored values and defaults.
Enum equality and inequality remain supported. Ordered comparisons accept
numeric, timestamp and enum fields; enum values use declaration rank. Every
literal enum operand must be declared, including in invariants, subsets, Formula
filters and `finds` conditions. The [runtime contract](../rule-runtime/spec.md#declared-enum-ordering--2026-10-10)
owns comparison behavior and persistent interpreter upgrades.

The [runtime contract](../rule-runtime/spec.md#binding-and-formula-contract-review--2026-10-10)
owns the related record-binding, creation, live-subset, clock and republication
changes. RDF shapes also bound native integer and money values to the safe
integer range in both validation profiles; independent SHACL tests exercise
both endpoints and values immediately outside them.

`ontolang/contracts.test.ts` is part of `pnpm test`. Every authored fixture first
round-trips through portable printing/reopening. Execution then compares an
independent expected outcome with both the reference and SQLite engines,
including resulting facts and refusal rollback. Coverage includes:

- Local and imported ancestry across primary, participant, `finds` and counted
  member positions; exact labels, ambiguity, wrong types and missing identities.
- 1,120 counting combinations: ten quantifiers, global/collection scans,
  local/imported types, both gate polarities, negation, inheritance, empty sets
  and missing values.
- Signed integer arithmetic checked against exact BigInt results at ordinary
  and safe-range boundaries, plus early-year and leap-day comparisons.
- Two deterministic 120-operation sequences against persistent SQLite state:
  create/update, changing subset eligibility, moving references, dependent
  account invariants, accepted/refused writes and dependency rollback.
- Published clock advance/rewind/restart and version-2 republication, exercised
  through the application service in `current-application.test.ts`.
- Role capability reference paths in ordinary Formulas, aggregates, filters
  and splits; derived-subset collection gates; nested subset references and
  inverse pairing. Local/imported cases and published-app update/restart and
  version-3 republication checks exercise the
  [runtime path corrections](../rule-runtime/spec.md#binding-and-formula-contract-review--2026-10-10).

Running the new regression cases against the prior commit (`b9634c29`) in an
isolated temporary snapshot produces 31 failing cases. Those failures reproduce
the defects; the corrected implementations pass the same cases. These are
multiple witnesses of shared defects, not 31 independent bugs.

The subsequent role/subset path review adds twelve regression cases. All twelve
fail against `cf9594b1` in an isolated snapshot and pass after the runtime
corrections. Their source already parses, prints and compiles; these fixes
implement existing language contracts without changing the syntax.

The [relationship write review](../rule-runtime/spec.md#one-to-one-relationship-updates--2026-10-10)
adds six regressions that fail against `729f35e4`: displaced inherited/role-held
links and inverse links left behind by clearing a reference or renaming while
moving it. It verifies both
execution engines, invariant rollback and published-app restart. The parser and
printer retain the existing one-to-one relationship syntax and contracts.

The inverse/seed follow-up adds eight regressions that fail against `44214ec2`
and pass with the corrections: explicit inverse selection and contradictory
choices, self-referencing seeds, seeded role inverses, and label normalization
independent of record order. Seed and published-app tests cover ambiguous labels,
derived results and restart; local/imported write cases retain unrelated links.

The same-type inverse review checks 2,304 moves and clears across valid
three-record pairings, including symmetric pairs with explicit and fallback
labels, in local and imported models. It fixes displaced self-links left behind
and authored symmetric links erased during inverse cleanup; the
[runtime relationship contract](../rule-runtime/spec.md#one-to-one-relationship-updates--2026-10-10)
owns the correction, Formula retraction, invariant rollback and restart coverage.
The accepted syntax and parser behavior are unchanged.

The [reference identity and enum review](../rule-runtime/spec.md#reference-identity-and-role-enum-values--2026-10-10)
makes inverse collections, aggregates and splits agree with forward ID/label
resolution, and enforces declared enum values on role capability edits and
grants. Local/imported cases include ambiguous display labels, ineligible ID
collisions, inherited owners and live subsets. The runtime owns the correction
and version-5 republication of cached Formula values; the language syntax stays
unchanged.

The [constraint follow-up](../rule-runtime/spec.md#inherited-uniqueness-and-canonical-enum-values--2026-10-11)
enforces inherited uniqueness across descendants and effective role holders, and
normalizes unambiguous runtime enum input to the declared string while rejecting
primitive coercion. It preserves case-insensitive input and protects final
states stored with legacy casing. Twenty-one
regressions fail on the prior implementation. The authoring banner and published
standing issues share the corrected scopes; no new syntax is introduced.

This is bounded conformance evidence, not a proof that every possible program
is correct. Production scale/concurrency, automatic scheduling and durable
`every` remain separate runtime work. Full OWL and lossless RDF import remain
outside the selected language/export scope.

## The printer — `ontolang/print-project.ts`


**`printProject(seed)`** → `{relative path → content}`, deterministic and line-stable. Canonical emission is the full ratified surface: `project.onto` (`@description`); `entities.onto` — actor blocks then object blocks in seed order, each with its header claim (`is a` for roles/subtypes/subsets), **`@type` on every bare actor** (explicit is the rule; roles and subsets inherit silently), `@description`, `@boundary external`, `@where`, fields in declaration order (mirror lines as `Type[]`, **`@of` written exactly when several links join the same two types**, `@final` trailing its values, attributes in `@required @unique @default` order, field `@description` indented), then `@rule` lines; `stories/story.onto` — one canonical story per `about` context (`story Name about Type`), beats with `@correction` marks and their clauses in canonical order (`finds` + filters, `where`, gates, `sets` — **the birth line always written** — `adds`, `grants`, `revokes`), sub-beats nested, attachments at a repeated sentence's first occurrence only; `seed.onto` — rows with money as decimals and the filled `status:` always emitted. **Unprintable models fail loud, never silently:** non-token names, strings with `"`/newline (no escapes), postcondition rules (`ensures` has no surface), phase role entries, multi-target `is a`, double header claims, `@final` marks off the list, a repeated sentence whose LATER occurrence carries its own clauses (attachment is by text), and a rule row whose beat/type never printed (nothing may vanish). **Story blocks are KEPT (owner ruling 2026-08-30 — the old parse-and-drop rider is closed):** every beat carries its block's title as `story/block`, the model carries `storyBlocks` (the ordered `{title, about?, description?}` list), and the printer writes the authored blocks back — real titles, `about` headers, and `@description` lines. New fail-louds: a beat belonging to no block, a beat whose `about` disagrees with its block, a title that would re-parse as an `about` header, and adjacent same-title blocks (they would merge on re-parse). Hand-built seeds without `storyBlocks` keep the old one-canonical-story emission.

## The goldens — the enforcement harness

`ontolang/parse-project.test.ts` + `print-project.test.ts` + `examples/lead-intake-routing.test.ts`: hotel and coffee strict-deep-equal their seeds (minus `seedVersion`); **sangha loads whole (31 beats, 9 actors, 12 objects, 21 rules) with every ratified construct pinned** — subsets, mirror `of` resolution, the clause family, `per`, rounding words, `@final` sets; lead-intake (14 beats, 19 rules), investment-bank (84 beats, 10 actors, 56 objects, 8 roles), and canna-manufacturing (76 beats, 19 actors, 23 objects, 16 roles — four batch subtypes with their own lifecycles) load whole; **all six corpora round-trip and print idempotently**; the paste door parses the concatenated corpus to the same model; the lifecycle trace's four errors, the mirror-pairing errors, the clause-discipline errors, and every retired form's pointed error are pinned. The editor grammar test (`editors/vscode/grammar.test.ts`, 8/8) tokenizes the corpora against the same surface (extension 0.3.2 adds the `@correction` scope).

**For the example corpus, the `.onto` files ARE the seeds** — the hand-built seed code is the expected-output fixture (HOTEL_SEED bumped to 22, COFFEE_SEED to 12 with the swept content), retiring per the [backlog](backlog.md).

## Retired forms — pointed replaced-syntax errors

`produces "value"` (→ a written `sets` clause, D7) · `ensures` under beats (D12a) · bare `rule` · `given` · `role … over` · `has` / `has one/many` (→ colon link lines) · `@terminal` (→ `@final`) · comma field modifiers · `(stamped on create)` (→ `@default(now)`) · the determiners `a`/`an`/`the`/`all`/`each` in sentences (`every` is the only determiner) · freestanding numbers in sentences (→ the value homes) · `always` in type blocks (→ `@rule`) · bare `description`/`type`/`boundary` lines (→ `@description`/`@type`/`@boundary`) · header `=` subsets (→ `is a` + `@where`).

## The studio door — load ontolang into the app

Unchanged in shape (the new-project pane's paste/directory door, client-side via the `@ontolang/*` alias, version-0 imports, the name-dedupe re-seed guard) — it now parses the full grammar above. **Project identity:** `id` = the directory basename; `name` = the project block's compound, displayed; `description` verbatim.

## The composer door — `ontolang/parse-fragment.ts` (parser port v1, 2026-09-02)

One parser, two feeders (the [authoring-sync (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/authoring-sync/backlog.md) 2026-09-02 ruling): the file door parses files with errors; the studio composer parses ONE beat sentence through the same pieces with **`parseBeatFragment(text, {catalog})`** → `{beat?, newEntities, diagnostics}`. It **never throws**, is browser-safe (environment-pure deep imports only — never the `@ontolang` index barrel, which re-exports the `node:fs` directory walk), and **the loader is untouched** — behavior-identical, all corpora goldens green.

Composition, in order:

1. **Lexical pre-checks the file door would hide:** `#` anywhere or an embedded newline → error diagnostics (`hash` / `newline`) — the file grammar strips comments *before* validation and reads line by line, so `Guest pays #40` would silently truncate there.
2. **`collectBeatWords(text)`** — the loader's beat-word checks as a new exported collecting form (same checks, verbatim message strings, returns all findings plus the `every` noun; the throwing `checkBeatWords` keeps its exact signature and now wraps it, so printer and loader callers are untouched) — each finding a `beat-word` warning. Plus a `dangling-preposition` gating warning for a bare preposition in any position (trailing ruled 2026-09-04, mid-sentence completed 2026-09-05 — both doors refuse the empty pair; it used to be silently dropped). Composer-only, ahead of both (sweep ruling 2026-09-02): a token that case-insensitively matches a declared catalog name but not its exact spelling gets a `name-case` warning with a one-click rewrite fix; it supersedes that token's beat-word finding, never mints a twin entity, and — when the verb-slot token is itself mis-cased and the sentence is unreadable — suppresses the whole beat-word scan (it ran against the wrong verb). A near-missed verb in a readable sentence is a working verb and stays silent.
3. **`parseDSL`** on the single sentence — no story emitted, or more than one → `unreadable` error; a pronoun subject (`I`, `We`, `You`, `He`, `She`, `They`, `It` — sweep ruling 2026-09-02) → `first-person` error.
4. **`resolveBeatNames`** — the loader's pre-loop beat pass (the property-path-in-object-slot error, the declared-name check, object-cannot-act, the actor→object re-slot with recipient deletion, the declared-actor participant re-slot with recipient restore — case-hunt row 14, ruled 2026-09-03: parseDSL's whole-input vote decides only undeclared names, so a declared actor it read as object-ish through a preposition pair moves back and regains `story/recipient` in both doors — the `every`-noun check, plus the correction/block/about decoration), extracted into an exported pure function in `parse-project.ts` that the loader itself now calls. It takes the whole beat list (`BeatPassInput[]`, preserving the loader's two-phase cross-beat error ordering), a `kindOf(name)`, and an opts discriminator; loader mode throws exactly as before (an optional `opts.sourceOf` keeps the historical text-keyed error attribution for duplicate beat texts). **Fragment mode diverges ONLY on the undeclared-name case** — it collects `{name, kind, evidence}` instead of throwing; every other error throws in both modes. The composer passes `ctx.catalog` as `kindOf`, so **declared kind always wins over beat position** (a catalog actor stays an actor in the object slot; the loader's re-slot rule applies identically).
5. **Key-by-key mapping of ONLY the enumerated `BeatDatoms` keys** — `text`, `actors`, `actions`, `objects`, `subject`, `subjectLabel?`, `primaryObject?`, `primaryObjectLabel?`, `recipient?`, `participants` (ordered `{preposition, name, label?}` pairs), `every?` — never a spread: `parseDSL` hardcodes `story/status` and `story/order` and mints `actor/color`, none of which is the composer's to emit. `primaryObject` is **optional** in the type, but an objectless story is enforced since 2026-09-02 (sweep case 10): the loader throws, the composer emits a gating `objectless` warning.

**Severities:** only `unreadable`, `first-person` (a pronoun in ANY name slot since 2026-09-03 — the family plus the object-case forms `Me`/`Us`/`Him`/`Her`/`Them`; a pronoun never mints), `hash`, `newline` (U+2028/U+2029 included, 2026-09-03), `illegal-character` (the story alphabet: letters, digits, whitespace, `:`, currency marks, `-` only inside a phrasal verb, and `.` only inside a token; a no-break space normalizes to a plain space at intake — both 2026-09-03 — ruled 2026-09-02/03; an invisible offender is named by code point, `Illegal character: U+200B`, 2026-09-03 — U+FEFF counts as invisible even though JavaScript's whitespace class matches it, an interior one errors and an edge byte-order mark is trimmed as paste residue), `empty-label` (a colon with an empty side) are errors; a trailing `@correction` is stripped and carried as data exactly as the file door does (2026-09-03); everything else warns (the app-mode enforcement table lives in [story-authoring's spec](../story-authoring/spec.md) — that feature owns the sentence). **`newEntities`** mints only single CamelCase-able tokens (`/^[A-Za-z][A-Za-z0-9]*$/` — no hyphens, 2026-09-03), with kind evidence from the parse slots; a **spaced** undeclared name gets a `spaced-name` warning carrying a CamelCase-rewrite `fix` and NO mint — unless every word of the phrase is itself a declared name (the act-between-them warning, no fix), the glued form is over the 24-character cap (`name-too-long` naming the glued form — the cap never counts the spaces), or a determiner / mis-cased preposition inside the phrase already carries the pointed finding (rows 7/10/11, ruled 2026-09-03); a hyphen-bearing token outside a phrasal verb is an `illegal-character` error carrying a strip-the-hyphens fix (a declared name's exact casing when one matches; after `every` the stripped noun still counts as following the determiner); a capitalized preposition gets a composer-only `preposition-case` warning with a one-click lowercase fix; an undeclared name after `as` gets the composer-only gating `status-participant` warning (a status value is never a participant — the status is written as a `sets` line, row 13) and never mints, while a declared name after `as` stays a real participant; a name that is neither mintable nor spaced can no longer arrive — its special character is an `illegal-character` error first (case 11). The **no-throw promise:** any exception a composition step raises (the pass's remaining hard errors included) returns as an `unreadable` error diagnostic with the `file:line` prefix stripped and `newEntities` emptied — a blocked beat mints nothing. Pinned by `ontolang/parse-fragment.test.ts` (loader-exact messages, strict-deep-equal beat datoms).

**Not in v1** (recorded in [backlog.md](backlog.md), closes with the clause slice): the composer runs no per-beat clause loops and writes no birth `sets` — the wrap (printed context + synthetic files + a `parseProjectFiles` mode flag) is deferred; `parseProjectFiles` gained no flag.

## Editor syntax highlighting — `editors/vscode/` (0.3.2)

The VS Code extension (TextMate grammar + language config; `pnpm editor:install` / `pnpm editor:package`) highlights the same ratified surface the loader parses, flags retired forms `invalid.deprecated`, and flags non-preposition sentence words `invalid.illegal`; the grammar test pins the corpora clean and the preposition alternation equal to the loader's `PREPOSITIONS`. Deliberately unpublished while the language iterates — the runbook is [`editors/vscode/PUBLISHING.md`](../../../editor/PUBLISHING.md).
