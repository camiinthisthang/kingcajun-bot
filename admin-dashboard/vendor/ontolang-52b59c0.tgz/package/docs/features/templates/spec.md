> Portable snapshot of maintained Onto material. [Package capabilities](../../../START_HERE.md) define the shipped boundary; dated decisions and host implementation notes are context. [Source manifest](../../../SOURCE_MANIFEST.json) records provenance. Links marked “Onto source” are optional host/background references.

# Templates — spec

**Built: Warehouse and Accounting, 2026-09-30.** Templates install ordinary editable model content into a project. These are reusable business capabilities, not business classifications. Both can coexist in one project. The shared [registry (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/templates/registry.ts), [source loader (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/templates/source.ts), dependency resolver and composition engine serve both; whole-business bundles remain future work.

## Portable package API — 2026-10-13

Generic template definitions, dependency selection, source fragment ownership,
pure composition, provenance and portable identity handling live in
`@trigramco/ontolang/templates`. Existing Onto modules delegate through this public
entry. `templates.json` and `walkthroughs.json` now load and print through the
package independently, preserving ownership, stable Story IDs, folder hierarchy
and inert host extensions. The [owning package contract](../ontolang/spec.md#independent-language-package--2026-10-13)
describes its boundaries and distribution checks.

Warehouse/Accounting definitions, detection/proposals, library UI and persistence
remain in Onto. Onto validates its known proposal fields before restoring data;
unknown companion extensions are retained as inert JSON. Assembly-hook changes
to known proposal fields are revalidated before returning the model. Composition and removal
semantics are unchanged and covered by existing template/runtime tests.
Studio persists those extensions through import, source edits, template changes,
undo, export and backfill replay. Older peer operations retain extension fields
they cannot author. Extension changes participate in preview freshness; malformed
or oversized metadata is rejected before a local write.

## Warehouse model

The canonical source is [templates/warehouse](../../../examples/templates/warehouse/). A generated JSON source bundle lets the same parser run in the browser without filesystem access. Rebuild it with `node scripts/bundle-warehouse-template.mjs` after editing the `.onto` files or portable walkthroughs.

| Module | Model and work | Dependencies |
| --- | --- | --- |
| Shared inventory | WarehouseOperator, Product, Location, StockBalance and the common StockMovement ledger; register catalog/locations, open balances, browse stock | None |
| Receiving | Record an InventoryReceipt, expected/actual quantities and discrepancy; receive it once | Inventory |
| Storage | Request and complete a StockTransfer between locations for the same product | Inventory |
| Counts | Record expected/observed quantities and a reason; reconcile the computed signed adjustment | Inventory |
| Picking | Request and pick one FulfillmentRequest product line from a location | Inventory |
| Packing | Record package count and pack a picked line in a PackingRecord | Picking |
| Shipping | Record carrier/tracking in a Shipment and mark dispatch | Packing |

The full template has 25 Stories and 50 Rules. Inventory, receiving, storage and counts are independent of outbound fulfillment. All 32 dependency-complete arrangements parse, round-trip and publish on the existing application host. The pilot handles integer units, whole-line picks/packs and one packing/shipping record per upstream record.

**Stock accounting is model behavior.** Available stock is the sum of posted inbound movements minus posted outbound movements. Recording work has no stock effect. Receiving posts inbound stock; a transfer posts both sides of one ledger row and conserves total quantity. Picking removes units from available shelf stock into fulfillment. Packing and shipping never deduct them again. Counts compute `countedQuantity - expectedQuantity`, require an explanation, and refuse reconciliation if the expected quantity no longer matches live stock. Positive-unit guards and nonnegative stock rules reject invalid movements. Completed transaction states and posted guards prevent posting twice; the application host additionally handles retry keys.

Each outbound module owns its record and lifecycle: picked fulfillment, packed package, shipped shipment. Removing a later module does not leave an earlier module's statuses dependent on missing Stories. Business behavior remains in Stories, Rules and Formulas; the compiler and runtime contain no warehouse-specific business logic. Operator identity uses the existing actor creation/binding controls.

## Accounting model

The canonical source is [templates/accounting](../../../examples/templates/accounting/); rebuild its browser source bundle with `node scripts/bundle-accounting-template.mjs` after source changes. The full template has seven modules, 56 Stories, 234 Rules, 19 objects, one actor and five guides. All 64 dependency-complete module arrangements publish. Installation supplies no accounts, balances or transactions.

Warehouse and Accounting version 2 satisfy the shared [inherited field contract](../ontolang/spec.md#complete-model-semantic-validation--2026-10-10).
StockCount's computed quantity retains the ledger's required constraint.
Accounting documents retain JournalEntry's `draft | posted` status and use a
separate `approvalStatus` for approval/settlement progress; portable guides follow
that field. Subtype invariants prevent generic journal posting from bypassing
their approval workflows. Reversals inherit the ledger's computed amounts.

| Module | Model and work | Dependencies |
| --- | --- | --- |
| General ledger | Chart of accounts, posting periods, balanced journals and explained reversals | None |
| Accounts payable | Vendors, bill approval and partial or full payments | Ledger |
| Accounts receivable | Customers, invoice approval and partial or full receipts | Ledger |
| Expenses | Payees, expense approval and partial or full reimbursements | Ledger |
| Bank reconciliation | Statement lines, matching posted bank movements and outstanding items | Ledger |
| Financial reports | Live trial balance, account totals, income and balance equation | Ledger |
| Period close | Close a balanced period after its draft entries are posted | Ledger |

Money is integer USD cents. Each journal posts one equal, positive debit/credit pair to different active accounts in an open date range. Several pairs can describe a split transaction, but the model does not post a multiline split as one atomic journal. Posted entries are corrected by a full reversal with swapped accounts and a reason. Settlements cannot exceed the source document's remaining amount; reversing a settlement restores that amount. A source document with net settlements must have those settlements reversed before it can be reversed. Closed date windows also block posting through another overlapping open period.

Reconciliation matches each bank line to a posted movement once, checks account/amount/date compatibility, identifies outstanding movements and compares the adjusted bank balance with the supplied current book snapshot. Statement details can be amended only before any line or outstanding item is attached; this prevents changing the bank or period after reconciliation work starts. It does not calculate a historical as-of book balance. Reports are live totals, not frozen financial statements. Approval steps use the same AccountingOperator role and do not enforce separation of duties. There is no payroll, tax calculation or filing, payment-provider execution, bank feed or import integration. Warehouse and Accounting share a project but do not automatically connect stock movements to inventory valuation or cost-of-goods-sold journals.

[IRS Publication 583](https://www.irs.gov/publications/p583), specifically its double-entry bookkeeping and bank reconciliation descriptions, is a design reference. This implementation makes no tax or recordkeeping compliance claim.

## Composition and ownership

Templates remain editable installations. [Scoped vocabulary imports](../ontolang/spec.md#scoped-vocabulary-imports--2026-10-10)
reuse qualified, read-only definitions from pinned sources. They use the same
portable project envelope with an optional generated `imports.json` file, but do
not use template bindings or install template Stories. A complete Warehouse
template is not a vocabulary directory; the [vocabulary examples](../../../examples/vocabulary/README.md)
provide separate definitions for that use.

[templates/types.ts (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/templates/types.ts) defines a versioned template, modules, dependencies, evidence and project membership. [compose.ts (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/templates/compose.ts) implements pure application, detach and removal, returning an inspectable change list or conflicts before any mutation.

Applying a selection includes its dependencies. Existing entity names alone never establish a match: composition requires an explicit binding, and fields/types/roles/Stories/Rules are checked for compatibility. Additional compatible local fields survive; incompatible meanings or fields are surfaced instead of overwritten. Bindings can also give newly installed concepts different names. The composed model must preserve its authored semantics through canonical print/parse validation.

Each contribution has a stable source identity, its applied baseline, module memberships, ownership and current project identity. Stories receive stable project-scoped UIDs. Reapplying an active module leaves edits and local deletions intact. Entity/field renames move membership pointers. A library version change is refused instead of silently upgrading an installed project.

The composition API's **Detach** operation keeps all model content and relinquishes template deletion ownership. **Remove** deletes only unchanged, exclusively owned content whose dependencies can be resolved. Shared definitions, edits, outside references, record schemas and their lifecycle/guard support are retained as ordinary detached content. Removing a required module is blocked until dependents are removed, or detach can retain its content. Removing Shipping from an unused full setup leaves inventory and other operations valid; existing Shipment records retain their supporting definitions.

## Ingestion and evidence

[detect.ts (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/templates/detect.ts) uses bounded source evidence, not the generated draft, to identify explicit warehouse/stockroom operations or a proposal from multiple operational signals. Product sales alone are insufficient. A stockroom selects the four inventory-side modules. Explicit exclusions and outsourced fulfillment suppress internal outbound operations; explicitly retained storage can still receive a stockroom setup. Relevant user statements take precedence over external source excerpts. Software/data-warehouse descriptions are excluded.

Accounting detection requires accounting-work evidence. A business name, sales, employees or an accounting-software supplier alone do not justify installing books. Explicit accounting requests select the full capability; explicit payables, receivables, expenses, reconciliation, reports or close requests select only that scope and its ledger dependency. Indirect invoice/reimbursement work stays an inferred proposal. User exclusions and outsourced work override weaker external claims; explicitly retained internal work can still receive its narrow selection. Each capability keeps separate evidence, assumptions, conflicts and application membership, including when one composition succeeds and another requires review.

The shared [generate-project.ts (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/studio/app/lib/generate-project.ts) path covers composer and durable GitHub generation. It records the source excerpts, selection reason, assumptions and conflicts. Explicit compatible matches can install immediately. Inferred matches and incompatible overlaps remain stored proposals, preserving the generated draft. Evidence, assumptions and conflicts remain persisted after installation; installation does not turn them into confirmed business facts or automatically create Open Questions.

Warehouse or Accounting candidates skip invented sample instances and drafted catalog fallback; normal installation contains no fictional products, operators, stock, balances or transactions. A real fetched catalog may still be retained, and composition preserves supplied records. Explicit Ontolang imports remain deterministic and are not supplemented by automatic template matching.

## Project controls, persistence and Run

**New Project → browse templates** opens a full-height library headed **New project name**, with an autofocused name input, compact shared Cards and a persistent creation footer. The home links **browse templates** and **start with a blank canvas** share the same 14px text-link styling and hover/focus treatment. Warehouse and Accounting can both be included in the same project. Clicking a card toggles inclusion in either direction; adding it also opens its settings. The colored template names in the footer open their settings without changing selection. **Select your templates** has a single Clear all action. Warehouse icons, titles and footer names use the existing blue token; Accounting uses green. Selection has a neutral outline.

The right sidebar starts collapsed, including when a URL preselects a template. Its background and padded, rounded row treatment match the Projects rail. Its collapse control reduces its width to zero and expands the library, preserving the draft. The library and sidebar content scroll independently. On narrow panes the open sidebar uses the available width; collapsing it returns to the library. Activating the visually disabled Create project button with no name shows **Enter a project name.** beneath the input and focuses it. Reserved name-error space and a fixed footer message line prevent validation messages from shifting the layout.

The sidebar's **Setup** dropdown uses the complete shared `FieldSelect` wrapper to apply a preset. Warehouse offers Full warehouse, Stockroom only and Fulfillment. Accounting offers Full accounting, Ledger and reports, Bills and payments, Invoices and receipts, and Expenses. Clear all is available for the library and each template, and the sidebar's Add/Remove template action changes inclusion.

A feature's 14px checkbox is centered on its title line and changes only that explicit choice. Its separate disclosure expands an inventory of the actual Stories, Rules, Formulas and other definitions that the feature contributes. Feature and preview rows use the existing rounded, padded navigation treatment without internal divider lines. [preview.ts (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/templates/preview.ts) reads the real module content, preserving authored Rule text and Formula expressions; named prerequisites are shown separately rather than counted as the feature's own content. Preview entries reuse the existing Story and DSL token colors, with blue Story, green Rule and gold Formula headings and counts. Expanding a preview never selects it. Disclosures reuse the shared animated Radix primitive also used by [agent setup (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/cli/spec.md#distribution-and-discovery).

Supporting prerequisites are resolved during composition and explained separately; selecting or clearing one feature never silently changes another checkbox. Each included template needs at least one explicit feature before creation. Clear all removes that template from the selection; manually unchecking its last feature leaves the draft open for editing and disables creation until a feature is chosen or the template is removed. Create project composes every included template, saves the explicit choices and included support as creation evidence, and imports an editable model with no fictional records or generation request. Descriptions and presets belong to the template definition, and all composition uses the shared dependency resolver. Template controls are not in Project Settings.

Library creation organizes Stories with the existing editable folder model: a parent folder per template and a child folder per installed feature, including required support. Ownership metadata assigns each top-level Story once; nested Stories stay with their parent. Partial selections omit uninstalled branches. Folder hierarchy, order and Story membership survive save/reload, portable export/import and replay; imported copies rekey folder and Story identities together. This organization does not change template ownership or reapplication behavior.

Installed content remains editable through the normal Stories, Data Model and Rule authoring tools. Project overview no longer shows template summary rows, their divider or a Review setup entry. There is currently no UI entry point for post-creation template setup or the bounded model-source editor.

The lifecycle and source-editing APIs remain implemented. [template-source.ts (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/runtime/template-source.ts) previews and applies Rule, Formula, description and Story-clause edits while preserving Story identities, membership and guides; organization changes and concurrent model edits invalidate a draft. The portable export format includes canonical Ontolang, walkthroughs and template metadata, and New Project still imports its `.onto-project.json` bundles.

[runtime/template-project.ts (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/runtime/template-project.ts) turns a validated composition into one authoring transaction and sync operation. Prepared changes check a fingerprint of the complete authoring model plus template metadata before commit, so a new cross-module reference invalidates a stale preview. Browser-local evaluation results, including Story classification and annotations, are excluded from portable patches and revision guards; replay preserves each peer's own caches. Undo uses the saved patch rather than reconstructing the whole project. Local records prevent schema-erasing commits and undo; the lower-level helper performs no server lookup. These retained APIs do not imply an active setup or undo control in the overview. Membership, versions, source/project mappings, baselines, evidence and all proposals persist with save/reload/replay; `templates.json` carries them through portable export/import. Legacy singular warehouse proposals remain readable. Imported copies rekey Story identities. Backfill and replay retain Story blocks, clauses and stable references, including when a new browser rebuilds before receiving the next template change.

[template-codec.ts (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/runtime/template-codec.ts) uses standard DEFLATE through `fflate` for large atomic patches and complete template state/backfill. Packed input and expansion are bounded, decoded JSON passes the same metadata/patch validators, and old uncompressed operations remain readable. Compression keeps the existing 256 KB operation limit; it does not increase it or replace transactional guards.

Published runtime records are not stored in template patches. Removal conservatively retains supporting definitions when a published application exists or its state cannot be established. This pilot does not perform destructive data migrations.

Run uses its existing server-derived command forms, reference pickers, record lists and queries. Portable module-owned walkthroughs connect records to their next step; warehouse packing/shipping and accounting journal/settlement/reconciliation handoffs use the same guidance mechanism. Declared money metadata drives dollar entry/display and exact cents in requests. There is no template-specific runtime renderer or arbitrary layout editor. The bounded source-editing API has no current UI entry point; dedicated visual editors for every construct remain outside this pilot.

## Verification and explicit demonstration

[warehouse-template.test.ts (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/rule-runtime/application/warehouse-template.test.ts) starts from an empty published model, creates the operator through the standard identity path, and executes all 25 public Stories/actions/queries. It proves receipt discrepancies, integer/positive quantities, transfer conservation, insufficient-stock rejection, repeated request IDs and repeated completed actions, explained/stale counts, no double deduction on dispatch, walkthrough inputs and durable restart. It also publishes all 32 arrangements, runs a stockroom-only setup and checks source-bundle/print-parse fidelity.

Composition, detection, ingestion, metadata and authoring replay tests live in `templates/*.test.ts`, [runtime/templates.test.ts (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/runtime/templates.test.ts) and [runtime/template-source.test.ts (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/runtime/template-source.test.ts). They cover every nonempty selection, compatible/incompatible bindings, reapplication, edits/renames, detach/remove, reference retention, malformed metadata, atomic replay/undo, fresh-browser backfill, complete-model stale checks, source Formula/Rule/clause edits and organization/store-epoch changes. Browser smoke checks verified New Project template creation, reload and library controls. Lifecycle and source-editing coverage is API-level after removal of the overview setup entry. End-to-end operator acceptance and the receipt-to-dispatch browser walkthrough remain separate from the deterministic runtime tests.

Accounting coverage is in [accounting-template.test.ts (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/rule-runtime/application/accounting-template.test.ts). Its six tests exercise all 56 Stories and all 64 valid module arrangements, including partial AP/AR/expense settlements and their reversals, balanced reports after restart, all seven posting paths blocked by closed dates even with overlapping open periods, and two-bank statement scoping with future-journal guards. Statement amendment regressions prevent bank or period retargeting after deposits, withdrawals or outstanding items are linked. A forged settlement through generic journal amendment is rejected atomically. Combined-template ingestion tests preserve both applications/proposals and turn an unrelated existing Account concept into a reviewable conflict. Shared runtime regressions cover directed/inherited references in reference and SQLite writes, plus global quantified gates that retain outer record bindings without asking for the scan's local member.

PR verification: `pnpm test` passed 2,091 tests with one skipped and zero failures; TypeScript and focused Studio lint also passed. The subsequent evaluation-cache replay fix passed all 26 lifecycle/source-edit tests, including four new regressions, and TypeScript. Production webpack builds and browser QA at 390px passed during pilot development. Combined creation retained both template folders, all 14 feature subfolders and all 81 Stories after reload. Final browser checks verified independent feature selection and reopening an empty feature draft without resetting its choices. No additional test projects were created during PR verification. These checks do not replace the owner accounting workflow acceptance listed in the [backlog](backlog.md).

For an **explicit fictional QA project**, run:

```sh
node --import tsx scripts/export-warehouse-demo.ts /tmp/onto-warehouse-demo
```

Choose a new output directory. Import its `warehouse-demo.onto-project.json` through New Project, then publish in Run and bind **Demo Operator** to **WarehouseOperator**. This fixture contains a demo widget, receiving dock, shelf and two zero balances; it contains no receipts or shipments. It is separate from installed template content.

A short walkthrough: receive 10 units at the dock (expected 12), transfer 6 to the shelf, reconcile a shelf count from 6 to 5 with an explanation, pick 3, pack the line and record dispatch. Available stock ends at **dock 4, shelf 2**. The receipt retains a discrepancy of -2 and the count retains an adjustment of -1. Shipping does not change either balance.

See [backlog.md](backlog.md) for extensions and remaining limits. The [importer (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/importer/spec.md) owns source preparation; [rendering (Onto source)](https://github.com/trigramco/onto/blob/codex/package-ontolang-runtime/docs/features/rendering/spec.md) and [runtime](../rule-runtime/spec.md) own the shared Run surfaces and execution host.
