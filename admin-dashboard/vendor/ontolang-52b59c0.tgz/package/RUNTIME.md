# Ontolang runtime

`@trigramco/ontolang/runtime` executes Ontolang Stories, Rules and Formulas
headlessly. It is an entry in the single `@trigramco/ontolang` package, with
JavaScript and TypeScript declarations. Install one tarball for language and
execution APIs. Registry publication and a separate repository remain follow-up work.

The [package layout](README.md#internal-organization) separates `language/` from
`runtimes/typescript/engine/` and `runtimes/typescript/adapters/`. Execution uses
explicit facts and clocks, with no Studio, Clerk, DataScript, filesystem, network
or SQLite dependency. The language entry does not import the engine.

## Run headlessly

From the Onto checkout with Node 24+ and pnpm 10:

```sh
pnpm install
node packages/ontolang/examples/headless.mjs
```

The [example](examples/headless.mjs) parses an inline model, initializes its
records and Formulas, executes Stories, and checks a refused action. It needs no
server, credentials or Studio environment.

In your own program:

```js
import { parseProjectFiles } from '@trigramco/ontolang'
import {
  compileModel, initializeWorld, executeStory, inspectWorld, tick,
} from '@trigramco/ontolang/runtime'

const model = compileModel(parseProjectFiles('my-model', files))
const initial = initializeWorld(model, '2026-10-13')
let snapshot = initial.snapshot
const result = executeStory(model, snapshot, {
  story: 'Clerk closes Item', actor: 'Clerk:Ada', object: 'Item:example',
})
snapshot = result.snapshot
const view = inspectWorld(model, snapshot)
const later = tick(model.ruleset, snapshot, '2026-10-14')
```

`files` is your complete source-file map; the Story and record IDs must exist in
your model. Alternatively, load a directory through `@trigramco/ontolang/node`.

## API and state ownership

| API | Behavior |
|---|---|
| `compileModel(project)` | Validates executable workflows and prepares the type, Rule and Story catalogs |
| `initializeWorld(model, now)` | Seeds records and reciprocal references, derives initial Formulas and returns `snapshot`, `derived` and `standing` issues |
| `inspectWorld(model, snapshot)` | Supplies subtype, role, reference, collection and subset reads over the current snapshot |
| `executeStory(model, snapshot, input)` | Returns the resulting snapshot, bindings, changes, refusals and per-member results |
| `tick(model.ruleset, snapshot, now)` | Recomputes Formulas and standing issues for an explicit clock |
| `systemStep(context)` | Runs eligible System Stories with caller-owned completion/effect state and optional handlers |
| `replayExecutionLog(model, log)` | Replays an execution fixture and checks its expectations |
| `seedWorld(model, now)` | Lower-level seed absorption; use `initializeWorld` when initial Formula values are needed |

The caller owns snapshots and persists the canonical model source alongside its
matching facts and model revision. Compiled models contain functions and Maps;
recompile the source when reopening stored facts. Treat snapshots as read-only
inputs. Inspection does not advance time or recompute stale Formula values.

Always retain the returned snapshot. An `every` Story commits each member
separately: earlier successful members remain committed if a later member is
refused, even when the aggregate `committed` value is false. Its `derived` facts
also retain the latest committed member's results. Inspect `members`
and their violations to report the result. A normal single execution refuses
its candidate atomically. Clock changes and uniqueness problems produce
standing issues; they are not rejected commands.

Seed absorption fills missing or cleared reciprocal scalar references and
rejects contradictory nonempty one-to-one claims without changing compiled seed
rows. Supplying an existing snapshot does not repair inconsistent saved links.
Creation guards read declared defaults before deciding whether a Story can run;
explicit zero/false values remain explicit values.

Bindings for the same exact Story token must identify the same record. Conflicting
primary, participant, context or pre-solved inputs return `invalid-binding`.
Distinct labelled tokens remain independent. An exact participant token can
supply the `about` context; an exact `every` token supplies it per member.
Pass captured values in `ExecutionInput.fields` under their canonical domain
field names. Onto's qualified form inputs, such as `Item.Board` when `Board` is
also a selector, are a host command-schema convention.

Execution is a trusted engine API. Person-triggered Stories require an eligible
`actor` record. Anonymous execution is available only for explicitly public actor
policies whose Story needs no actor record; System Stories use their own path.
The host verifies the caller and chooses the actor record, controls enrollment
and management authority, and deduplicates command/effect keys. Pure execution
does not authenticate a user or persist receipts. Hosts also supply clocks,
scheduling, transactions and external delivery. System completion/effect state
must survive restart when effects must run only once.

## SQLite and Durable Object integration

The public `@trigramco/ontolang/runtime/adapters` entry exposes the shared
preparation, query and write contracts: `prepareStory`/`StoryReads`,
`WorldSource`/`makeQueryWorld`, `CommitWriter`, the guard/apply/check stages,
`FormulaReads`/`evalFormulaWithReads`, and System candidate/deadline helpers.
Adapters supply complete reads and atomic writes; partial reads must fail closed.
This is a trusted host interface, not an HTTP endpoint. These are shared contracts
and execution helpers, not complete SQLite or Cloudflare database implementations.

Onto's existing `rule-runtime/*.ts` paths delegate to this package. Its SQLite
adapter keeps indexed reads, incremental Formula dependency tracking and
transactional writes, so Studio and headless callers execute the same semantics.
Concrete SQL execution, indexed facts and transactions are packaged in explicit
adapter entries. Publication, HTTP identity and scheduler/outbox orchestration
also ship in the bundled deployment host.

Onto's compiler-version `2` schemas preserve selectors through capture mappings
and allow omitted required defaults on owner/actor creates. Existing saved
command schemas require same-source republication; interpreter stamp
`semantics:4` refreshes cached runtime state automatically. The package's
bundled `docs/features/rule-runtime/spec.md` documents the runtime review and
upgrade contract.

Concrete adapters are public at `/runtime/adapters/node-sqlite` and
`/runtime/adapters/cloudflare`, with shared relational machinery at
`/runtime/adapters/sqlite`. Platform imports stay behind these explicit entries;
`/runtime` and the base `/runtime/adapters` remain portable. Deployment accounts,
bindings, domains and secrets belong to the deploying application. The tarball
ships a Worker, participant assets and a local deployment runner; see
[deployment](DEPLOYMENT.md). Hosted acceptance and broader consumer SDKs remain
follow-up work.

## Build, verify and share

```sh
pnpm build:ontolang
pnpm test:ontolang
pnpm test:runtime
pnpm --dir packages/ontolang pack --pack-destination ../../out/ontolang
```

Run `pnpm watch:ontolang` alongside Studio for language or engine edits.
`build:ontolang-runtime` and `watch:ontolang-runtime` remain aliases for the single
package commands; `test:ontolang-runtime` runs focused execution checks.

In an independent consumer, run `npm install /path/to/trigramco-ontolang-0.1.0.tgz`,
then `node node_modules/@trigramco/ontolang/examples/headless.mjs`.
The isolation checks install exactly one tarball, exercise public JavaScript and
declarations, verify parser-only loading, private paths and browser/Worker bundles,
and replay all six existing execution logs from the installed package. The logs
pin expected worlds, refusals, standing issues and intents for future runtimes.
Onto retains the same reference/SQLite conformance and application/Studio integration tests.
